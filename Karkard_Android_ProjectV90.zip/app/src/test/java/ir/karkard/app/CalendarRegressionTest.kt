package ir.karkard.app

import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Regression coverage for the Solar Hijri/Gregorian bridge used across the app. */
class CalendarRegressionTest {
    @Test
    fun known1405CalendarAnchorsStayStable() {
        assertEquals(LocalDate.of(2026, 10, 23), jalaliToGregorian(1405, 8, 1))
        assertEquals(LocalDate.of(2026, 11, 11), jalaliToGregorian(1405, 8, 20))
        assertEquals(LocalDate.of(2026, 11, 13), jalaliToGregorian(1405, 8, 22))
    }

    @Test
    fun conversionRoundTripsForBoundariesAndLeapMonth() {
        val jalaliDates = listOf(
            Triple(1404, 1, 1),
            Triple(1404, 6, 31),
            Triple(1404, 7, 1),
            Triple(1405, 8, 30),
            Triple(1405, 12, 29)
        )

        jalaliDates.forEach { (year, month, day) ->
            assertTrue("Expected valid Jalali date $year/$month/$day", isValidJalali(year, month, day))
            assertEquals(Triple(year, month, day), gregorianToJalali(jalaliToGregorian(year, month, day)))
        }
    }

    @Test
    fun invalidMonthAndDayValuesAreRejected() {
        assertFalse(isValidJalali(1405, 0, 1))
        assertFalse(isValidJalali(1405, 13, 1))
        assertFalse(isValidJalali(1405, 8, 31))
        assertEquals(if (isValidJalali(1405, 12, 30)) 30 else 29, jalaliMonthLength(1405, 12))
    }
    @Test
    fun nonHolidayReligiousOccasionIsBundledWithoutBecomingHoliday() {
        val event = Calendar1405.events.single { it.first == "1405-09-02" }
        assertTrue(event.second.contains("وفات حضرت ام‌البنین"))
        assertFalse(Calendar1405.holidays.any { it.first == "1405-09-02" })
    }

    @Test
    fun calendarEventMigrationMergesWithoutDroppingExistingTitlesOrDuplicates() {
        assertEquals(
            "مناسبت قبلی، وفات حضرت ام‌البنین (س)",
            mergeCalendarEventTitles("مناسبت قبلی", listOf("وفات حضرت ام‌البنین (س)", "مناسبت قبلی"))
        )
    }

}
