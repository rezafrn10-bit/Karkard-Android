package ir.karkard.app

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Exercises the real Android SQLite implementation, including close/reopen.
 * A UI toast or an in-memory Compose state update is not accepted as proof of persistence.
 */
@RunWith(AndroidJUnit4::class)
class WorkDbPersistenceInstrumentedTest {
    private lateinit var context: Context

    @Before
    fun clearIsolatedTestDatabase() {
        context = ApplicationProvider.getApplicationContext()
        context.deleteDatabase("karkard.db")
    }

    @After
    fun removeTestDatabase() {
        context.deleteDatabase("karkard.db")
    }

    @Test
    fun dailyTimesAndHolidayReasonSurviveCommitAndDatabaseReopen() {
        val expected = WorkDay(
            date = "1405-02-12",
            in1 = "07:05",
            out1 = "14:10",
            in2 = "14:30",
            out2 = "16:00",
            in3 = "16:15",
            out3 = "17:00",
            in4 = "17:10",
            out4 = "17:40",
            note = "آزمون ماندگاری ذخیره‌سازی",
            dayType = "تعطیل خاص",
            holidayIn = "08:00",
            holidayOut = "10:30",
            leave1Start = "09:00",
            leave1End = "09:15",
            leave2Start = "11:00",
            leave2End = "11:10",
            hourlyLeaveEnabled = true,
            fixedHoursMode = true,
            dayTypeManual = true
        )

        val firstOpen = WorkDb(context)
        try {
            val committed = firstOpen.saveDayAndHoliday(expected, "آزمون تراکنش")
            assertEquals(expected, committed)
            assertTrue(firstOpen.hasWorkDay(expected.date))
            assertEquals("آزمون تراکنش", firstOpen.holidayTitle(expected.date))
        } finally {
            firstOpen.close()
        }

        val reopened = WorkDb(context)
        try {
            assertTrue(reopened.hasWorkDay(expected.date))
            assertEquals(expected, reopened.getDay(expected.date))
            assertEquals("آزمون تراکنش", reopened.holidayTitle(expected.date))

            // Removing an optional holiday title must not delete or alter the daily row.
            val savedWithoutReason = reopened.saveDayAndHoliday(expected.copy(note = "پس از بازگشایی"), null)
            assertEquals("پس از بازگشایی", savedWithoutReason.note)
            assertTrue(reopened.hasWorkDay(expected.date))
            assertFalse(reopened.holidayTitle(expected.date) != null)
        } finally {
            reopened.close()
        }
    }
}
