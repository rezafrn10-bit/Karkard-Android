package ir.karkard.app

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Result of validating and persisting one complete daily editor snapshot. */
internal sealed interface WorkDaySaveResult {
    data class Saved(val day: WorkDay) : WorkDaySaveResult
    data class ValidationFailed(val message: String) : WorkDaySaveResult
}

/**
 * Application boundary for daily-record IO.
 *
 * UI code calls this suspend API instead of opening SQLite on the main thread. The
 * repository owns the dispatcher boundary, while WorkDb remains responsible for
 * atomic transactions, schema compatibility, and post-commit verification.
 */
internal class WorkDayRepository(
    private val database: WorkDb,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {
    suspend fun saveDay(day: WorkDay, holidayReason: String?): WorkDaySaveResult =
        withContext(ioDispatcher) {
            val validationMessage = validateWorkDay(day, database)
            if (validationMessage != null) {
                WorkDaySaveResult.ValidationFailed(validationMessage)
            } else {
                WorkDaySaveResult.Saved(database.saveDayAndHoliday(day, holidayReason))
            }
        }

    suspend fun loadDay(date: String): WorkDay = withContext(ioDispatcher) {
        managementDayForDate(database, date)
    }
}
