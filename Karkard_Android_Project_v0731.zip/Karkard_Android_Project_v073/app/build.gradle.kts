plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val releaseStorePath = providers.environmentVariable("VAGHTNEGAR_KEYSTORE_PATH").orNull

android {
    signingConfigs {
        if (!releaseStorePath.isNullOrBlank()) {
            create("vaghtnegar") {
                storeFile = file(releaseStorePath)
                storePassword = System.getenv("VAGHTNEGAR_STORE_PASSWORD")
                keyAlias = System.getenv("VAGHTNEGAR_KEY_ALIAS")
                keyPassword = System.getenv("VAGHTNEGAR_KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            if (!releaseStorePath.isNullOrBlank()) {
                signingConfig = signingConfigs.getByName("vaghtnegar")
            }
        }
    }
    namespace = "ir.karkard.app"
    compileSdk = 37

    defaultConfig {
        applicationId = "ir.karkard.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 74
        versionName = "0.73.1"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
}

kotlin {
    compilerOptions {
        jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
    }
}

dependencies {
    implementation("com.ibm.icu:icu4j:76.1")
    implementation(platform("androidx.compose:compose-bom:2026.09.00"))
    implementation("androidx.activity:activity-compose:1.13.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.11.0")
    debugImplementation("androidx.compose.ui:ui-tooling")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.3.0")
    androidTestImplementation("androidx.test:runner:1.7.0")
    androidTestImplementation("androidx.test:core:1.7.0")
}