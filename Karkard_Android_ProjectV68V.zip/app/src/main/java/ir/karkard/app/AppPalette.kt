package ir.karkard.app

import androidx.compose.ui.graphics.Color

/** Shared, high-contrast light palette for every Morakh screen. */
internal object AppPalette {
    val Background = Color(0xFFF2F6FB)       // cool, very light page canvas
    val Surface = Color(0xFFFFFFFF)         // cards and navigation surfaces
    val SurfaceAlt = Color(0xFFEBF1F7)      // subtle field / alternate surface
    val Ink = Color(0xFF173A60)             // primary text
    val Muted = Color(0xFF526B83)           // secondary text
    val Primary = Color(0xFF245A8D)         // primary action and selected state
    val PrimarySoft = Color(0xFFE2ECF6)     // selection / input surface
    val Border = Color(0xFFD8E2EC)          // quiet neutral outlines and dividers
    val Error = Color(0xFFB3261E)
    val ErrorSoft = Color(0xFFFFF3F2)
    val ErrorBorder = Color(0xFFE7B9B5)
    val Success = Color(0xFF286344)
    val SuccessSoft = Color(0xFFEFF6F1)
    val SuccessBorder = Color(0xFFD8E7DD)
}
