# اصلاحیه ساخت نسخه ۵۲

- رفع مسیر resolve شدن پلاگین‌های Kotlin در Gradle با نگاشت شناسه‌های `org.jetbrains.kotlin.android` و `org.jetbrains.kotlin.plugin.compose` به ماژول رسمی `org.jetbrains.kotlin:kotlin-gradle-plugin` با همان نسخه اعلام‌شده.
- نسخه برنامه و منطق آن تغییر نکرده است؛ این اصلاح فقط پیکربندی دریافت پلاگین‌های Gradle را هدف می‌گیرد.
- اگر خطای دریافت artifact همچنان تکرار شد، احتمال اختلال دسترسی شبکه GitHub Actions به مخازن Maven/Plugin Portal وجود دارد و باید لاگ `--info` بررسی شود.
