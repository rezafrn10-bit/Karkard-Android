package ir.karkard.app

import com.ibm.icu.util.Calendar
import com.ibm.icu.util.PersianCalendar
import com.ibm.icu.util.TimeZone
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private val jalaliUtc = TimeZone.getTimeZone("UTC")

fun isValidJalali(y: Int, m: Int, d: Int): Boolean {
    if (m !in 1..12 || d !in 1..31) return false
    return try {
        PersianCalendar(jalaliUtc).apply {
            isLenient = false
            clear()
            set(Calendar.YEAR, y)
            set(Calendar.MONTH, m - 1)
            set(Calendar.DAY_OF_MONTH, d)
            timeInMillis
        }
        true
    } catch (_: Exception) {
        false
    }
}

fun jalaliToGregorian(y: Int, m: Int, d: Int): LocalDate {
    val c = PersianCalendar(jalaliUtc).apply {
        isLenient = false
        clear()
        set(Calendar.YEAR, y)
        set(Calendar.MONTH, m - 1)
        set(Calendar.DAY_OF_MONTH, d)
    }
    return Instant.ofEpochMilli(c.timeInMillis).atZone(ZoneOffset.UTC).toLocalDate()
}

fun gregorianToJalali(date: LocalDate): Triple<Int, Int, Int> {
    val c = PersianCalendar(jalaliUtc)
    c.timeInMillis = date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
    return Triple(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
}

fun jalaliMonthLength(y: Int, m: Int): Int = when (m) {
    in 1..6 -> 31
    in 7..11 -> 30
    12 -> if (isValidJalali(y, 12, 30)) 30 else 29
    else -> 0
}

@Composable
fun JalaliCalendarScreen(
    year: Int,
    month: Int,
    selectedDate: String,
    onMonthChange: (Int, Int) -> Unit,
    onSelectDate: (String) -> Unit,
    modifier: Modifier = Modifier,
    holidays: Map<String, String> = emptyMap()
) {
    val firstDay = jalaliToGregorian(year, month, 1)
    // Saturday is the first column; Sunday follows it.
    val offset = (firstDay.dayOfWeek.value + 1) % 7
    val count = jalaliMonthLength(year, month)
    val cells = ((0 until offset).map { 0 } + (1..count).toList()).let {
        it + List((42 - it.size).coerceAtLeast(0)) { 0 }
    }

    Column(
        modifier = modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            shape = RoundedCornerShape(24.dp)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("تقویم کارکرد", style = MaterialTheme.typography.titleLarge)
                    Text("روز موردنظر را برای ثبت یا ویرایش انتخاب کنید.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)
                ) {
                    IconButton(onClick = { onMonthChange(if (month == 12) year + 1 else year, if (month == 12) 1 else month + 1) }) {
                        Text("‹", style = MaterialTheme.typography.headlineMedium)
                    }
                }
            }
        }

        Card(shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(onClick = { onMonthChange(if (month == 1) year - 1 else year, if (month == 1) 12 else month - 1) }) {
                        Text("ماه قبل")
                    }
                    Text("${persianDigits(year.toString())} / ${persianDigits("%02d".format(month))}", style = MaterialTheme.typography.titleLarge)
                    TextButton(onClick = { onMonthChange(if (month == 12) year + 1 else year, if (month == 12) 1 else month + 1) }) {
                        Text("ماه بعد")
                    }
                }
                Row(Modifier.fillMaxWidth()) {
                    listOf("ش", "ی", "د", "س", "چ", "پ", "ج").forEachIndexed { i, label ->
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            Text(label, color = if (i == 6) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
                cells.chunked(7).forEach { week ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        week.forEachIndexed { col, d ->
                            Box(Modifier.weight(1f).aspectRatio(0.82f), contentAlignment = Alignment.Center) {
                                if (d != 0) {
                                    val key = "%04d-%02d-%02d".format(year, month, d)
                                    val selected = key == selectedDate
                                    Surface(
                                        onClick = { onSelectDate(key) },
                                        shape = RoundedCornerShape(13.dp),
                                        color = when {
                                            selected -> MaterialTheme.colorScheme.primary
                                            col == 6 || holidays.containsKey(key) -> Color(0xFFFFDAD6)
                                            else -> when ((d % 5)) { 0 -> Color(0xFFE0F2FE); 1 -> Color(0xFFDCFCE7); 2 -> Color(0xFFF3E8FF); 3 -> Color(0xFFFCE7F3); else -> Color(0xFFE8EAF6) }
                                        },
                                        modifier = Modifier.fillMaxSize(0.9f)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                            Text(
                                                persianDigits(d.toString()),
                                                color = when {
                                                    selected -> MaterialTheme.colorScheme.onPrimary
                                                    col == 6 || holidays.containsKey(key) -> Color(0xFFB42318)
                                                    else -> MaterialTheme.colorScheme.onSurface
                                                },
                                                style = MaterialTheme.typography.bodyMedium
                                            )
                                            if (holidays.containsKey(key)) Text("تعطیل", style = MaterialTheme.typography.labelSmall, color = Color(0xFFB42318), maxLines = 1)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        Text("جمعه‌ها و تعطیلات با رنگ قرمز مشخص شده‌اند. برای ثبت کارکرد، یک تاریخ را انتخاب کنید.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

fun persianDigits(value: String): String = value.map { if (it in '0'..'9') (0x06F0 + (it - '0')).toChar() else it }.joinToString("")
