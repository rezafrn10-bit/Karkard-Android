package ir.karkard.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

data class WorkDay(
    val date: String,
    val in1: String = "", val out1: String = "",
    val in2: String = "", val out2: String = "",
    val in3: String = "", val out3: String = "",
    val note: String = "",
    val dayType: String = "کاری",
    val overtimeOverride: String = "",
    val shiftEnabled: Boolean = false,
    val shiftStart: String = "",
    val shiftEnd: String = ""
)

class WorkDb(context: Context) : SQLiteOpenHelper(context, "karkard.db", null, 3) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE workdays(
            date TEXT PRIMARY KEY, in1 TEXT, out1 TEXT, in2 TEXT, out2 TEXT,
            in3 TEXT, out3 TEXT, note TEXT, day_type TEXT DEFAULT 'کاری',
            overtime_override TEXT DEFAULT '', shift_enabled INTEGER DEFAULT 0, shift_start TEXT DEFAULT '', shift_end TEXT DEFAULT '')""")
        db.execSQL("CREATE TABLE holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL)")
        db.execSQL("""CREATE TABLE settings(
            key TEXT PRIMARY KEY, value TEXT NOT NULL)""")
        val defaults = mapOf(
            "overtime" to "true", "leave_hourly" to "true", "leave_daily" to "true",
            "mission" to "true", "shifts" to "true", "thursday_hours" to "true",
            "fixed_hours" to "false", "calendar" to "true",
            "workday_hours" to "08:00", "thursday_hours_value" to "04:00", "shift_hours" to "12:00"
        )
        defaults.forEach { (k,v) ->
            val cv = ContentValues().apply { put("key", k); put("value", v) }
            db.insert("settings", null, cv)
        }
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN day_type TEXT DEFAULT 'کاری'")
            db.execSQL("ALTER TABLE workdays ADD COLUMN overtime_override TEXT DEFAULT ''")
            val defaults = mapOf("workday_hours" to "08:00", "thursday_hours_value" to "04:00", "shift_hours" to "12:00")
            defaults.forEach { (k,v) ->
                val cv = ContentValues().apply { put("key",k); put("value",v) }
                db.insertWithOnConflict("settings", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
            }
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_enabled INTEGER DEFAULT 0")
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_start TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_end TEXT DEFAULT ''")
        }
        db.execSQL("CREATE TABLE IF NOT EXISTS holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL)")
        val shiftDefault = ContentValues().apply { put("key", "shift_hours"); put("value", "12:00") }
        db.insertWithOnConflict("settings", null, shiftDefault, SQLiteDatabase.CONFLICT_IGNORE)
    }

    fun getDay(date: String): WorkDay {
        readableDatabase.rawQuery("SELECT * FROM workdays WHERE date=?", arrayOf(date)).use { c ->
            if (c.moveToFirst()) return WorkDay(
                c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "",
                c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "",
                c.getString(6) ?: "", c.getString(7) ?: "",
                if (c.columnCount > 8) c.getString(8) ?: "کاری" else "کاری",
                if (c.columnCount > 9) c.getString(9) ?: "" else "",
                if (c.columnCount > 10) c.getInt(10) == 1 else false,
                if (c.columnCount > 11) c.getString(11) ?: "" else "",
                if (c.columnCount > 12) c.getString(12) ?: "" else ""
            )
        }
        return WorkDay(date)
    }
    fun saveDay(d: WorkDay) {
        val v = ContentValues().apply {
            put("date", d.date); put("in1",d.in1); put("out1",d.out1)
            put("in2",d.in2); put("out2",d.out2); put("in3",d.in3); put("out3",d.out3)
            put("note",d.note); put("day_type",d.dayType); put("overtime_override",d.overtimeOverride); put("shift_enabled", if(d.shiftEnabled) 1 else 0); put("shift_start",d.shiftStart); put("shift_end",d.shiftEnd)
        }
        writableDatabase.insertWithOnConflict("workdays", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun allDays(month: String): List<WorkDay> {
        val result = mutableListOf<WorkDay>()
        readableDatabase.rawQuery("SELECT * FROM workdays WHERE date LIKE ? ORDER BY date", arrayOf("$month%")).use { c ->
            while(c.moveToNext()) result.add(WorkDay(
                c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "",
                c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "",
                c.getString(6) ?: "", c.getString(7) ?: "",
                c.getString(8) ?: "کاری", c.getString(9) ?: "", c.getInt(10) == 1, c.getString(11) ?: "", c.getString(12) ?: ""
            ))
        }
        return result
    }
    fun allDaysYear(year: Int): List<WorkDay> = allDaysForBackup().filter { it.date.startsWith("%04d-".format(year)) }
    fun saveHoliday(date: String, title: String) {
        val v = ContentValues().apply { put("date", date); put("title", title) }
        writableDatabase.insertWithOnConflict("holidays", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun allHolidays(): List<Pair<String,String>> {
        val out = mutableListOf<Pair<String,String>>()
        readableDatabase.rawQuery("SELECT date,title FROM holidays ORDER BY date", null).use { c -> while(c.moveToNext()) out.add(c.getString(0) to c.getString(1)) }
        return out
    }
    fun holidayTitle(date: String): String? {
        readableDatabase.rawQuery("SELECT title FROM holidays WHERE date=?", arrayOf(date)).use { c -> return if(c.moveToFirst()) c.getString(0) else null }
    }
    fun getSetting(key: String): Boolean {
        readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?", arrayOf(key)).use { c ->
            return c.moveToFirst() && c.getString(0) == "true"
        }
    }
    fun getSettingText(key: String, fallback: String = ""): String {
        readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?", arrayOf(key)).use { c ->
            return if (c.moveToFirst()) c.getString(0) else fallback
        }
    }
    fun setSettingText(key: String, value: String) {
        val v = ContentValues().apply { put("key",key); put("value",value) }
        writableDatabase.insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun setSetting(key: String, value: Boolean) {
        val v = ContentValues().apply { put("key",key); put("value",value.toString()) }
        writableDatabase.insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun allDaysForBackup(): List<WorkDay> {
        val result = mutableListOf<WorkDay>()
        readableDatabase.rawQuery("SELECT * FROM workdays ORDER BY date", null).use { c ->
            while(c.moveToNext()) result.add(WorkDay(
                c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "",
                c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "",
                c.getString(6) ?: "", c.getString(7) ?: "", c.getString(8) ?: "کاری",
                c.getString(9) ?: "", c.getInt(10) == 1, c.getString(11) ?: "", c.getString(12) ?: ""
            ))
        }
        return result
    }
    fun allSettings(): List<Pair<String,String>> {
        val result = mutableListOf<Pair<String,String>>()
        readableDatabase.rawQuery("SELECT key,value FROM settings ORDER BY key", null).use { c ->
            while(c.moveToNext()) result.add(c.getString(0) to c.getString(1))
        }
        allHolidays().forEach { (date,title) -> result.add("holiday:$date" to title) }
        return result
    }
    fun restoreBackup(days: List<WorkDay>, settings: List<Pair<String,String>>) {
        writableDatabase.beginTransaction()
        try {
            writableDatabase.delete("workdays", null, null)
            writableDatabase.delete("holidays", null, null)
            days.forEach { d ->
                val v = ContentValues().apply {
                    put("date",d.date); put("in1",d.in1); put("out1",d.out1)
                    put("in2",d.in2); put("out2",d.out2); put("in3",d.in3); put("out3",d.out3)
                    put("note",d.note); put("day_type",d.dayType); put("overtime_override",d.overtimeOverride); put("shift_enabled", if(d.shiftEnabled) 1 else 0); put("shift_start",d.shiftStart); put("shift_end",d.shiftEnd)
                }
                writableDatabase.insertWithOnConflict("workdays",null,v,SQLiteDatabase.CONFLICT_REPLACE)
            }
            settings.forEach { (k,v) ->
                if (k.startsWith("holiday:")) {
                    val cv = ContentValues().apply { put("date",k.removePrefix("holiday:")); put("title",v) }
                    writableDatabase.insertWithOnConflict("holidays",null,cv,SQLiteDatabase.CONFLICT_REPLACE)
                } else {
                    val cv = ContentValues().apply { put("key",k); put("value",v) }
                    writableDatabase.insertWithOnConflict("settings",null,cv,SQLiteDatabase.CONFLICT_REPLACE)
                }
            }
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var appDb: WorkDb
    private var pendingBackup = false
    private var reportYear = 1405
    private var reportMonth = 1
    private var reportAnnual = false
    private var reportPdf = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        val db = WorkDb(this)
        appDb = db
        setContent { KarkardApp(db) }
    }

    fun createExcelBackup() {
        pendingBackup = true
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            putExtra(Intent.EXTRA_TITLE, "پشتیبان_دفتر_کارکرد.xlsx")
        }
        startActivityForResult(intent, 4101)
    }
    fun createReportExcel(year: Int, month: Int, annual: Boolean) {
        reportYear = year; reportMonth = month; reportAnnual = annual; reportPdf = false
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            putExtra(Intent.EXTRA_TITLE, if (annual) "گزارش_سالانه_$year.xlsx" else "گزارش_ماهانه_${year}_$month.xlsx")
        }
        startActivityForResult(intent, 4103)
    }
    fun createReportPdf(year: Int, month: Int, annual: Boolean) {
        reportYear = year; reportMonth = month; reportAnnual = annual; reportPdf = true
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"
            putExtra(Intent.EXTRA_TITLE, if (annual) "گزارش_سالانه_$year.pdf" else "گزارش_ماهانه_${year}_$month.pdf")
        }
        startActivityForResult(intent, 4104)
    }
    fun chooseExcelRestore() {
        pendingBackup = false
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        }
        startActivityForResult(intent, 4102)
    }
    @Deprecated("Deprecated Android callback kept for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        try {
            if (requestCode == 4101) {
                contentResolver.openOutputStream(uri)?.use { it.write(buildBackupXlsx(appDb)) }
                android.widget.Toast.makeText(this, "فایل Excel پشتیبان ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
            } else if (requestCode == 4103) {
                contentResolver.openOutputStream(uri)?.use { it.write(buildReportXlsx(appDb, reportYear, reportMonth, reportAnnual)) }
                android.widget.Toast.makeText(this, "گزارش Excel ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
            } else if (requestCode == 4104) {
                contentResolver.openOutputStream(uri)?.use { it.write(buildReportPdf(appDb, reportYear, reportMonth, reportAnnual)) }
                android.widget.Toast.makeText(this, "گزارش PDF ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
            } else if (requestCode == 4102) {
                val input = contentResolver.openInputStream(uri) ?: error("فایل خوانده نشد")
                val restored = input.use { readBackupXlsx(it.readBytes()) }
                android.app.AlertDialog.Builder(this)
                    .setTitle("بازیابی پشتیبان")
                    .setMessage("با ادامه، اطلاعات فعلی جایگزین می‌شود. ادامه می‌دهید؟")
                    .setNegativeButton("انصراف", null)
                    .setPositiveButton("بازیابی") { _, _ ->
                        appDb.restoreBackup(restored.first, restored.second)
                        android.widget.Toast.makeText(this, "بازیابی انجام شد؛ صفحه را دوباره باز کنید", android.widget.Toast.LENGTH_LONG).show()
                    }.show()
            }
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, "خطا در فایل Excel: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
        }
    }
}

private fun formatTimeInput(raw: String): String {
    val digits = raw.filter { it.isDigit() }.take(4)
    return when (digits.length) {
        0, 1 -> digits
        2 -> digits
        else -> digits.substring(0, 2) + ":" + digits.substring(2)
    }
}

private fun mins(time: String): Int? {
    val p = time.trim().split(":")
    if (p.size != 2) return null
    val h = p[0].toIntOrNull() ?: return null
    val m = p[1].toIntOrNull() ?: return null
    if (h !in 0..23 || m !in 0..59) return null
    return h*60+m
}
private fun duration(day: WorkDay): Int {
    return listOf(day.in1 to day.out1, day.in2 to day.out2, day.in3 to day.out3).sumOf { (a,b) ->
        val start = mins(a); val end = mins(b)
        if (start != null && end != null) {
            if (end >= start) end - start else (end + 24 * 60) - start
        } else 0
    }
}
private fun hm(n: Int) = "%02d:%02d".format(Locale.ROOT, n/60, n%60)

private fun jalaliWeekday(date: String): Int? {
    val p = date.split("-").mapNotNull { it.toIntOrNull() }
    if (p.size != 3 || !isValidJalali(p[0],p[1],p[2])) return null
    return jalaliToGregorian(p[0],p[1],p[2]).dayOfWeek.value % 7
    // Java Sunday=0, Saturday=6
}
private fun officialJalaliHolidays(year: Int): List<Pair<String,String>> {
    val fixed = mutableListOf<Triple<Int,Int,String>>()
    for (d in 1..4) fixed.add(Triple(1, d, "تعطیل رسمی نوروز"))
    fixed.add(Triple(1, 12, "روز جمهوری اسلامی"))
    fixed.add(Triple(1, 13, "روز طبیعت"))
    fixed.add(Triple(3, 14, "رحلت امام خمینی"))
    fixed.add(Triple(3, 15, "قیام ۱۵ خرداد"))
    fixed.add(Triple(11, 22, "پیروزی انقلاب اسلامی"))
    fixed.add(Triple(12, 29, "روز ملی شدن صنعت نفت"))
    return fixed.map { (m,d,title) -> "%04d-%02d-%02d".format(year,m,d) to title }
}

private fun defaultDayType(date: String): String =
    if (jalaliWeekday(date) == 5) "تعطیل" else "کاری"

private fun overtimeMinutes(day: WorkDay, db: WorkDb): Int {
    val override = mins(day.overtimeOverride)
    if (override != null) return override
    if (day.dayType != "کاری") return 0
    val weekday = jalaliWeekday(day.date)
    val targetText = if (day.shiftEnabled) db.getSettingText("shift_hours", "12:00") else if (weekday == 4 && db.getSetting("thursday_hours"))
        db.getSettingText("thursday_hours_value") else db.getSettingText("workday_hours")
    val target = mins(targetText) ?: 480
    return (duration(day) - target).coerceAtLeast(0)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KarkardApp(db: WorkDb) {
    val context = LocalContext.current
    var screen by remember { mutableStateOf("home") }
    val nowJalali = remember { gregorianToJalali(LocalDate.now()) }
    var jalaliYear by remember { mutableIntStateOf(nowJalali.first) }
    var jalaliMonth by remember { mutableIntStateOf(nowJalali.second) }
    var date by remember { mutableStateOf("%04d-%02d-%02d".format(nowJalali.first, nowJalali.second, nowJalali.third)) }
    var day by remember(date) {
        mutableStateOf(db.getDay(date).let { if (db.allDays(date.take(7)).any { d -> d.date == date }) it else it.copy(dayType=defaultDayType(date)) })
    }
    var refresh by remember { mutableIntStateOf(0) }
    val today = LocalDate.of(jalaliYear.coerceAtLeast(1), jalaliMonth.coerceIn(1,12), 1)

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF3949AB),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFE0E7FF),
            onPrimaryContainer = Color(0xFF1E1B4B),
            secondary = Color(0xFF00897B),
            tertiary = Color(0xFFAD1457),
            background = Color(0xFFF7F8FC),
            surface = Color(0xFFFFFFFF)
        )
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = { Text("دفتر کارکرد") },
                    actions = {
                        TextButton(onClick = { screen = "calendar" }) { Text("تقویم") }
                        TextButton(onClick = { screen = "report" }) { Text("گزارش ماهانه") }
                        TextButton(onClick = { screen = "settings" }) { Text("تنظیمات") }
                    }
                )
            }
        ) { padding ->
            when(screen) {
                "settings" -> SettingsScreen(db, Modifier.padding(padding), onBackup = { (context as? MainActivity)?.createExcelBackup() }, onRestore = { (context as? MainActivity)?.chooseExcelRestore() }) { screen = "home" }
                "calendar" -> JalaliCalendarScreen(
                    year = jalaliYear, month = jalaliMonth, selectedDate = date,
                    onMonthChange = { y,m -> jalaliYear = y; jalaliMonth = m },
                    onSelectDate = { selected ->
                        date = selected
                        val parts = selected.split("-")
                        jalaliYear = parts[0].toInt()
                        jalaliMonth = parts[1].toInt()
                        screen = "home"
                    },
                    modifier = Modifier.padding(padding),
                    holidays = remember(refresh, jalaliYear, jalaliMonth) { (officialJalaliHolidays(jalaliYear) + db.allHolidays()).toMap() }
                )
                "report" -> ReportScreen(db, jalaliYear, jalaliMonth, refresh, Modifier.padding(padding),
                    export = { annual -> (context as? MainActivity)?.createReportExcel(jalaliYear, jalaliMonth, annual) },
                    exportPdf = { annual -> (context as? MainActivity)?.createReportPdf(jalaliYear, jalaliMonth, annual) }
                )
                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item { Text("ثبت دستی ساعت کاری", style = MaterialTheme.typography.headlineSmall) }
                    item {
                        OutlinedTextField(
                            value = date, onValueChange = { date = it },
                            label = { Text("تاریخ شمسی (YYYY-MM-DD)") },
                            supportingText = { Text("تاریخ را به شکل 1405-07-27 وارد کنید یا از تقویم انتخاب کنید.") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true
                        )
                    }
                    item { Text("بازه اول", style = MaterialTheme.typography.titleMedium) }
                    item { TimePair("ورود", day.in1, "خروج", day.out1, { day = day.copy(in1=it) }, { day = day.copy(out1=it) }) }
                    item { Text("بازه دوم (اختیاری)", style = MaterialTheme.typography.titleMedium) }
                    item { TimePair("ورود", day.in2, "خروج", day.out2, { day = day.copy(in2=it) }, { day = day.copy(out2=it) }) }
                    item { Text("بازه سوم (اختیاری)", style = MaterialTheme.typography.titleMedium) }
                    item { TimePair("ورود", day.in3, "خروج", day.out3, { day = day.copy(in3=it) }, { day = day.copy(out3=it) }) }
                    item { Text("وضعیت روز", style = MaterialTheme.typography.titleMedium) }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                            listOf("کاری","تعطیل","مرخصی","استعلاجی","مأموریت").forEach { type ->
                                FilterChip(
                                    selected = day.dayType == type,
                                    onClick = { day = day.copy(dayType=type) },
                                    label = { Text(type) }
                                )
                            }
                        }
                    }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
                            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("شیفت کاری", modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                                    Switch(checked = day.shiftEnabled, onCheckedChange = { day = day.copy(shiftEnabled=it) })
                                }
                                Text("مدت شیفت از تنظیمات محاسبه می‌شود: ${db.getSettingText("shift_hours", "12:00")}", style = MaterialTheme.typography.bodySmall)
                                TimePair("شروع شیفت", day.shiftStart, "پایان شیفت", day.shiftEnd, { day = day.copy(shiftStart=it) }, { day = day.copy(shiftEnd=it) })
                            }
                        }
                    }
                    item {
                        OutlinedTextField(
                            value = day.overtimeOverride,
                            onValueChange = { day = day.copy(overtimeOverride=formatTimeInput(it)) },
                            label = { Text("اصلاح دستی اضافه‌کاری (HH:MM)") },
                            supportingText = { Text("خالی بماند تا خودکار محاسبه شود؛ مثلاً 01:30") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true
                        )
                    }
                    item {
                        OutlinedTextField(day.note, { day = day.copy(note=it) },
                            label = { Text("یادداشت روز") }, modifier = Modifier.fillMaxWidth())
                    }
                    item {
                        Card {
                            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                Text("مجموع کارکرد ثبت‌شده", style = MaterialTheme.typography.titleMedium)
                                Text(hm(duration(day)), style = MaterialTheme.typography.headlineMedium)
                                if (db.getSetting("overtime")) {
                                    Text("اضافه‌کاری: ${hm(overtimeMinutes(day, db))}", style = MaterialTheme.typography.titleMedium)
                                    Text("محاسبه بر اساس ساعت موظفی تنظیم‌شده؛ مقدار دستی در صورت وارد شدن جایگزین می‌شود.",
                                        style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                    item {
                        Button(onClick = {
                            val parts = date.split("-").mapNotNull { it.toIntOrNull() }
                            if (parts.size == 3 && isValidJalali(parts[0], parts[1], parts[2])) {
                                db.saveDay(day.copy(date="%04d-%02d-%02d".format(parts[0],parts[1],parts[2])))
                                refresh++
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("ذخیره کارکرد") }
                    }
                    item { Text("راهنما: ساعت را با قالب 08:30 وارد کنید. تاریخ باید معتبر باشد.") }
                }
            }
        }
    }
}

@Composable
fun TimePair(label1: String, v1: String, label2: String, v2: String, c1: (String)->Unit, c2: (String)->Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(v1, { c1(formatTimeInput(it)) }, label = { Text("$label1 (HH:MM)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
            modifier = Modifier.weight(1f), singleLine = true)
        OutlinedTextField(v2, { c2(formatTimeInput(it)) }, label = { Text("$label2 (HH:MM)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
            modifier = Modifier.weight(1f), singleLine = true)
    }
}

@Composable
fun SettingsScreen(db: WorkDb, modifier: Modifier = Modifier, onBackup: () -> Unit, onRestore: () -> Unit, back: () -> Unit) {
    var tick by remember { mutableIntStateOf(0) }
    val settings = listOf(
        "fixed_hours" to "ساعت ورود و خروج ثابت",
        "thursday_hours" to "تنظیم جداگانه ساعت پنجشنبه",
        "overtime" to "ثبت و محاسبه اضافه‌کاری",
        "leave_hourly" to "مرخصی ساعتی",
        "leave_daily" to "مرخصی روزانه و نوع مرخصی",
        "mission" to "مأموریت روزانه",
        "shifts" to "تعریف و ثبت شیفت کاری",
        "calendar" to "تقویم ماهانه و تعطیلات"
    )
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("تنظیمات امکانات", style = MaterialTheme.typography.headlineSmall)
        Text("هر قابلیت را می‌توانید روشن یا خاموش کنید.")
        Text("پشتیبان‌گیری و بازیابی", style = MaterialTheme.typography.titleMedium)
        Button(onClick = onBackup, modifier = Modifier.fillMaxWidth()) { Text("ساخت پشتیبان Excel (.xlsx)") }
        OutlinedButton(onClick = onRestore, modifier = Modifier.fillMaxWidth()) { Text("بازیابی از فایل Excel") }
        Text("بازیابی، اطلاعات فعلی را پس از تأیید جایگزین می‌کند.", style = MaterialTheme.typography.bodySmall)
        settings.forEach { (key, label) ->
            val enabled = remember(key, tick) { db.getSetting(key) }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text(label, modifier = Modifier.weight(1f))
                Switch(checked = enabled, onCheckedChange = { db.setSetting(key,it); tick++ })
            }
        }
        var dailyHours by remember { mutableStateOf(db.getSettingText("workday_hours","08:00")) }
        var thursdayHours by remember { mutableStateOf(db.getSettingText("thursday_hours_value","04:00")) }
        var shiftHours by remember { mutableStateOf(db.getSettingText("shift_hours","12:00")) }
        Text("ساعت موظفی و شیفت", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(dailyHours, { dailyHours = formatTimeInput(it) }, label = { Text("شنبه تا چهارشنبه (HH:MM)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(thursdayHours, { thursdayHours = formatTimeInput(it) }, label = { Text("پنجشنبه (HH:MM)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(shiftHours, { shiftHours = formatTimeInput(it) }, label = { Text("مدت شیفت کاری (HH:MM)") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            if (mins(dailyHours) != null && mins(thursdayHours) != null && mins(shiftHours) != null) {
                db.setSettingText("workday_hours",dailyHours)
                db.setSettingText("thursday_hours_value",thursdayHours)
                db.setSettingText("shift_hours",shiftHours)
                tick++
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("ذخیره ساعت موظفی") }
        Divider()
        Text("تعطیلات مناسبتی شخصی", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        var holidayDate by remember { mutableStateOf("") }
        var holidayTitle by remember { mutableStateOf("") }
        OutlinedTextField(holidayDate, { holidayDate = it }, label = { Text("تاریخ شمسی (مثلاً 1405-01-01)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(holidayTitle, { holidayTitle = it }, label = { Text("عنوان مناسبت") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Button(onClick = {
            val parts = holidayDate.split("-").mapNotNull { it.toIntOrNull() }
            if (parts.size == 3 && isValidJalali(parts[0],parts[1],parts[2]) && holidayTitle.isNotBlank()) {
                db.saveHoliday("%04d-%02d-%02d".format(parts[0],parts[1],parts[2]), holidayTitle.trim())
                holidayDate = ""; holidayTitle = ""; tick++
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("ثبت تعطیلی مناسبتی") }
        db.allHolidays().forEach { (date, title) -> Text("$date — $title", color = MaterialTheme.colorScheme.error) }
        Spacer(Modifier.height(12.dp))
        Button(onClick = back, modifier = Modifier.fillMaxWidth()) { Text("بازگشت") }
    }
}



@Composable
fun SummaryTile(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.fillMaxWidth().padding(vertical = 10.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.titleMedium)
            Text(label, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun ReportScreen(db: WorkDb, year: Int, monthNumber: Int, refresh: Int, modifier: Modifier = Modifier, export: (Boolean) -> Unit, exportPdf: (Boolean) -> Unit) {
    var annual by remember { mutableStateOf(false) }
    val month = "%04d-%02d".format(year, monthNumber)
    val days = remember(month, refresh, annual) { if (annual) db.allDaysYear(year) else db.allDays(month) }
    val total = days.sumOf { duration(it) }
    val totalOvertime = days.sumOf { overtimeMinutes(it, db) }
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(if (annual) "گزارش سالانه" else "گزارش ماهانه", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            FilterChip(selected = !annual, onClick = { annual = false }, label = { Text("ماهانه") })
            FilterChip(selected = annual, onClick = { annual = true }, label = { Text("سالانه") })
        }
        Text(if (annual) "سال شمسی: $year" else "ماه: $month")
        Text("مجموع کارکرد: ${hm(total)}")
        Text("مجموع اضافه‌کاری: ${hm(totalOvertime)}")
        Text("روزهای ثبت‌شده: ${days.size}")
        val workCount = days.count { it.dayType == "کاری" }
        val offCount = days.count { it.dayType == "تعطیل" }
        val leaveCount = days.count { it.dayType == "مرخصی" }
        val missionCount = days.count { it.dayType == "مأموریت" }
        val sickCount = days.count { it.dayType == "استعلاجی" }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SummaryTile("کاری", workCount.toString(), Modifier.weight(1f))
            SummaryTile("تعطیل", offCount.toString(), Modifier.weight(1f))
            SummaryTile("مرخصی", leaveCount.toString(), Modifier.weight(1f))
            SummaryTile("مأموریت", missionCount.toString(), Modifier.weight(1f))
            SummaryTile("استعلاجی (ج)", sickCount.toString(), Modifier.weight(1f))
        }
        if (!annual) {
        Text("نمای کلی ماه", style = MaterialTheme.typography.titleMedium)
        val lastDay = jalaliMonthLength(year, monthNumber)
        val firstOffset = (jalaliToGregorian(year,monthNumber,1).dayOfWeek.value + 1) % 7
        val byDay = days.associateBy { it.date.substringAfterLast("-").toIntOrNull() ?: 0 }
        val cells = (1..firstOffset).map { 0 } + (1..lastDay).toList()
        cells.chunked(7).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                row.forEach { n ->
                    Box(Modifier.weight(1f).height(36.dp), contentAlignment = Alignment.Center) {
                        if (n == 0) Spacer(Modifier.size(30.dp)) else {
                            val record = byDay[n]
                            val label = when(record?.dayType) {
                                "تعطیل" -> "ت"
                                "مرخصی" -> "م"
                                "مأموریت" -> "س"
                                "استعلاجی" -> "ج"
                                else -> n.toString()
                            }
                            Surface(
                                color = when(record?.dayType) {
                                    "تعطیل" -> MaterialTheme.colorScheme.errorContainer
                                    "مرخصی" -> MaterialTheme.colorScheme.tertiaryContainer
                                    "مأموریت" -> MaterialTheme.colorScheme.secondaryContainer
                                    else -> MaterialTheme.colorScheme.surfaceVariant
                                },
                                shape = MaterialTheme.shapes.small
                            ) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(label) } }
                        }
                    }
                }
                repeat(7-row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        Text("راهنما: ت = تعطیل، م = مرخصی، س = مأموریت، ج = استعلاجی.", style = MaterialTheme.typography.bodySmall)
        }
        if (annual) {
            Text("خلاصه ماه‌به‌ماه", style = MaterialTheme.typography.titleMedium)
            (1..12).forEach { m ->
                val md = days.filter { it.date.startsWith("%04d-%02d".format(year,m)) }
                if (md.isNotEmpty()) Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("ماه ${persianDigits(m.toString())}")
                        Text("کارکرد ${hm(md.sumOf { duration(it) })}")
                        Text("اضافه ${hm(md.sumOf { overtimeMinutes(it, db) })}")
                    }
                }
            }
        }
        Button(onClick = { export(annual) }, modifier = Modifier.fillMaxWidth()) { Text("خروجی Excel گزارش ${if (annual) "سالانه" else "ماهانه"}") }
        OutlinedButton(onClick = { exportPdf(annual) }, modifier = Modifier.fillMaxWidth()) { Text("خروجی PDF گزارش ${if (annual) "سالانه" else "ماهانه"}") }
        Divider()
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(days) { d ->
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Text(d.date, style = MaterialTheme.typography.titleMedium)
                        Text("وضعیت: ${d.dayType}  |  کارکرد: ${hm(duration(d))}  |  اضافه‌کاری: ${hm(overtimeMinutes(d, db))}")
                        val ranges = listOf(d.in1 to d.out1, d.in2 to d.out2, d.in3 to d.out3)
                            .filter { it.first.isNotBlank() || it.second.isNotBlank() }
                            .joinToString(" | ") { "${it.first} تا ${it.second}" }
                        Text(ranges.ifBlank { "بدون بازه ثبت‌شده" })
                        if (d.shiftEnabled) Text("شیفت: ${d.shiftStart} تا ${d.shiftEnd} | مدت مبنا: ${db.getSettingText("shift_hours", "12:00")}", color = MaterialTheme.colorScheme.tertiary)
                        if (d.note.isNotBlank()) Text("یادداشت: ${d.note}")
                    }
                }
            }
        }
    }
}


fun buildReportXlsx(db: WorkDb, year: Int, month: Int, annual: Boolean): ByteArray {
    val days = if (annual) db.allDaysYear(year) else db.allDays("%04d-%02d".format(year, month))
    val title = if (annual) "گزارش سال $year" else "گزارش ماه %04d-%02d".format(year, month)
    val summary = mutableListOf(listOf("عنوان", "مقدار"), listOf(title, ""), listOf("مجموع کارکرد", hm(days.sumOf { duration(it) })), listOf("مجموع اضافه کاری", hm(days.sumOf { overtimeMinutes(it, db) })), listOf("روزهای ثبت شده", days.size.toString()), listOf("مرخصی استعلاجی (ج)", days.count { it.dayType == "استعلاجی" }.toString()), listOf("شیفت های ثبت شده", days.count { it.shiftEnabled }.toString()))
    if (annual) (1..12).forEach { m ->
        val md = days.filter { it.date.startsWith("%04d-%02d".format(year,m)) }
        summary.add(listOf("ماه $m - کارکرد", hm(md.sumOf { duration(it) })))
        summary.add(listOf("ماه $m - اضافه کاری", hm(md.sumOf { overtimeMinutes(it, db) })))
    }
    val details = mutableListOf(listOf("تاریخ شمسی", "وضعیت", "بازه ۱", "بازه ۲", "بازه ۳", "کارکرد", "اضافه کاری", "شیفت فعال", "شروع شیفت", "پایان شیفت", "مدت مبنای شیفت", "یادداشت"))
    days.forEach { d -> details.add(listOf(d.date, d.dayType, "${d.in1}-${d.out1}", "${d.in2}-${d.out2}", "${d.in3}-${d.out3}", hm(duration(d)), hm(overtimeMinutes(d,db)), if(d.shiftEnabled) "بله" else "خیر", d.shiftStart, d.shiftEnd, db.getSettingText("shift_hours","12:00"), d.note)) }
    val entries = linkedMapOf(
        "[Content_Types].xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""",
        "_rels/.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""",
        "xl/workbook.xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Summary" sheetId="1" r:id="rId1"/><sheet name="Details" sheetId="2" r:id="rId2"/></sheets></workbook>""",
        "xl/_rels/workbook.xml.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/></Relationships>""",
        "xl/worksheets/sheet1.xml" to sheetXml(summary), "xl/worksheets/sheet2.xml" to sheetXml(details)
    )
    val output = java.io.ByteArrayOutputStream()
    java.util.zip.ZipOutputStream(output).use { zip -> entries.forEach { (name,content) -> zip.putNextEntry(java.util.zip.ZipEntry(name)); zip.write(content.toByteArray(Charsets.UTF_8)); zip.closeEntry() } }
    return output.toByteArray()
}

fun buildReportPdf(db: WorkDb, year: Int, month: Int, annual: Boolean): ByteArray {
    val days = if (annual) db.allDaysYear(year) else db.allDays("%04d-%02d".format(year, month))
    val pdf = android.graphics.pdf.PdfDocument()
    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { textSize = 12f; color = android.graphics.Color.BLACK; textAlign = android.graphics.Paint.Align.RIGHT }
    val titlePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { textSize = 18f; typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD); color = android.graphics.Color.rgb(57,73,171); textAlign = android.graphics.Paint.Align.RIGHT }
    val lines = mutableListOf<String>()
    lines.add(if(annual) "گزارش سالانه کارکرد - $year" else "گزارش ماهانه کارکرد - $year/$month")
    lines.add("مجموع کارکرد: ${hm(days.sumOf { duration(it) })}")
    lines.add("مجموع اضافه کاری: ${hm(days.sumOf { overtimeMinutes(it, db) })}")
    lines.add("روزهای ثبت شده: ${days.size} | استعلاجی (ج): ${days.count { it.dayType == "استعلاجی" }} | شیفت ها: ${days.count { it.shiftEnabled }}")
    if (annual) (1..12).forEach { m -> val md = days.filter { it.date.startsWith("%04d-%02d".format(year,m)) }; lines.add("ماه $m: کارکرد ${hm(md.sumOf { duration(it) })} - اضافه کاری ${hm(md.sumOf { overtimeMinutes(it,db) })}") }
    lines.add("جزئیات روزانه:")
    days.forEach { d -> lines.add("${d.date} | ${d.dayType} | کارکرد ${hm(duration(d))} | اضافه کاری ${hm(overtimeMinutes(d,db))}${if(d.shiftEnabled) " | شیفت ${d.shiftStart}-${d.shiftEnd}" else ""}") }
    val perPage = 38
    lines.chunked(perPage).forEachIndexed { index, pageLines ->
        val info = android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, index+1).create()
        val page = pdf.startPage(info)
        var y = 48f
        pageLines.forEachIndexed { i, line ->
            if(index == 0 && i == 0) { page.canvas.drawText(line, 560f, y, titlePaint); y += 34f }
            else { page.canvas.drawText(line.take(100), 560f, y, paint); y += 19f }
        }
        pdf.finishPage(page)
    }
    val out = java.io.ByteArrayOutputStream(); pdf.writeTo(out); pdf.close(); return out.toByteArray()
}

private fun xmlEscape(v: String): String = v.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;")
private fun colName(n: Int): String {
    var x=n; var out=""
    while(x>0){ val r=(x-1)%26; out=(('A'.code+r).toChar())+out; x=(x-1)/26 }
    return out
}
private fun sheetXml(rows: List<List<String>>): String {
    val body = rows.mapIndexed { ri,row ->
        val cells = row.mapIndexed { ci,value ->
            val ref = colName(ci+1)+(ri+1)
            "<c r=\"$ref\" t=\"inlineStr\"><is><t>${xmlEscape(value)}</t></is></c>"
        }.joinToString("")
        "<row r=\"${ri+1}\">$cells</row>"
    }.joinToString("")
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>$body</sheetData></worksheet>"""
}
fun buildBackupXlsx(db: WorkDb): ByteArray {
    val workRows = mutableListOf(listOf("date","dayType","in1","out1","in2","out2","in3","out3","duration","overtimeOverride","note","shiftEnabled","shiftStart","shiftEnd"))
    db.allDaysForBackup().forEach { d ->
        workRows.add(listOf(d.date,d.dayType,d.in1,d.out1,d.in2,d.out2,d.in3,d.out3,hm(duration(d)),d.overtimeOverride,d.note,d.shiftEnabled.toString(),d.shiftStart,d.shiftEnd))
    }
    val settingsRows = mutableListOf(listOf("key","value"))
    db.allSettings().forEach { settingsRows.add(listOf(it.first,it.second)) }
    val entries = linkedMapOf(
        "[Content_Types].xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""",
        "_rels/.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""",
        "xl/workbook.xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Workdays" sheetId="1" r:id="rId1"/><sheet name="Settings" sheetId="2" r:id="rId2"/></sheets></workbook>""",
        "xl/_rels/workbook.xml.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/></Relationships>""",
        "xl/worksheets/sheet1.xml" to sheetXml(workRows),
        "xl/worksheets/sheet2.xml" to sheetXml(settingsRows)
    )
    val output = java.io.ByteArrayOutputStream()
    java.util.zip.ZipOutputStream(output).use { zip ->
        entries.forEach { (name,content) ->
            zip.putNextEntry(java.util.zip.ZipEntry(name))
            zip.write(content.toByteArray(Charsets.UTF_8))
            zip.closeEntry()
        }
    }
    return output.toByteArray()
}
private fun readBackupXlsx(bytes: ByteArray): Pair<List<WorkDay>,List<Pair<String,String>>> {
    val entries = mutableMapOf<String,ByteArray>()
    java.util.zip.ZipInputStream(bytes.inputStream()).use { zip ->
        while(true) {
            val e = zip.nextEntry ?: break
            if (e.name == "xl/worksheets/sheet1.xml" || e.name == "xl/worksheets/sheet2.xml") {
                entries[e.name] = zip.readBytes()
            }
            zip.closeEntry()
        }
    }
    fun parseSheet(xmlBytes: ByteArray?): List<List<String>> {
        if(xmlBytes == null) return emptyList()
        val parser = android.util.Xml.newPullParser()
        parser.setInput(xmlBytes.inputStream(), "UTF-8")
        val rows = mutableListOf<List<String>>()
        var row: MutableList<String>? = null
        var cellText = StringBuilder()
        var inCell = false
        var event = parser.eventType
        while(event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
            when(event) {
                org.xmlpull.v1.XmlPullParser.START_TAG -> when(parser.name) {
                    "row" -> row = mutableListOf()
                    "c" -> { inCell = true; cellText = StringBuilder() }
                    "t" -> if(inCell) { }
                }
                org.xmlpull.v1.XmlPullParser.TEXT -> if(inCell) cellText.append(parser.text)
                org.xmlpull.v1.XmlPullParser.END_TAG -> when(parser.name) {
                    "c" -> { row?.add(cellText.toString()); inCell = false }
                    "row" -> { row?.let { rows.add(it) }; row = null }
                }
            }
            event = parser.next()
        }
        return rows
    }
    val workRows = parseSheet(entries["xl/worksheets/sheet1.xml"])
    val settingsRows = parseSheet(entries["xl/worksheets/sheet2.xml"])
    require(workRows.isNotEmpty() && workRows.first().firstOrNull() == "date") { "ساختار فایل پشتیبان معتبر نیست" }
    val days = workRows.drop(1).filter { it.size >= 11 && it[0].matches(Regex("\\d{4}-\\d{2}-\\d{2}")) }.map { r ->
        WorkDay(r[0],r[2],r[3],r[4],r[5],r[6],r[7],r[10],r[1].ifBlank{"کاری"},r[9], r.getOrNull(11)?.toBoolean() ?: false, r.getOrNull(12) ?: "", r.getOrNull(13) ?: "")
    }
    val settings = settingsRows.drop(1).filter { it.size >= 2 }.map { it[0] to it[1] }
    return days to settings
}
