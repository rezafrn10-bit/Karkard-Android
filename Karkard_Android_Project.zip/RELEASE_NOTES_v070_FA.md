# یادداشت انتشار مورخ ۰.۷۰.۰

## اصلاح ساخت فونت B Yekan
- خطای کامپایل اسکریپت Gradle در `app/build.gradle.kts` برطرف شد.
- مسیر مقصد فونت اکنون با `file("src/main/res/font/byekan.ttf")` دریافت می‌شود؛ دیگر فراخوانی نامعتبر `.get().asFile` وجود ندارد.
- task `prepareByekanFont` حفظ شده تا فایل `BYekan.ttf` از ریشه مخزن به منابع Android منتقل شود.
- هر دو کپی پروژه (ساخت مستقیم و بسته داخلی GitHub Actions) اصلاح شدند.
- نسخه تنظیمات و Gradle هماهنگ شد: `versionName=0.70.0` و `versionCode=70`.

## توجه به ساخت
فایل `BYekan.ttf` باید در ریشه مخزن GitHub باقی بماند. گردش‌کارهای `build.yml` و `build-signed.yml` آن را پس از استخراج بسته داخلی در منابع برنامه کپی می‌کنند.
