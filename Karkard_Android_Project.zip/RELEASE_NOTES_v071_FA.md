# یادداشت انتشار نسخه ۷۱ مورخ

- رفع خطای کامپایل در ساخت آیکون تاریخ اعلان: اکنون `Context` به تابع `dayIcon` به‌صورت صریح ارسال می‌شود.
- اصلاح import مربوط به `LocalTextStyle` در `DigitAwareText.kt` به مسیر Material 3.
- شماره نسخه به `versionName=0.71.0` و `versionCode=71` افزایش یافت.
- فونت واقعی B Yekan از فایل `BYekan.ttf` ریشه مخزن در مرحله `prepareByekanFont` به منابع برنامه منتقل می‌شود.
