package ir.karkard.app

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.LocalTime
import java.util.Locale

/** Calendar recurrence is evaluated against the Solar Hijri calendar, not Gregorian month lengths. */
internal object ReminderRecurrence {
    const val NONE = "NONE"
    const val DAILY = "DAILY"
    const val WEEKLY = "WEEKLY"
    const val MONTHLY = "MONTHLY"
    const val YEARLY = "YEARLY"
    const val END_NEVER = "NEVER"
    const val END_DATE = "DATE"
    const val END_COUNT = "COUNT"

    fun normalizedWeekdays(value: String): Set<Int> = value.split(',')
        .mapNotNull { it.trim().toIntOrNull() }.filter { it in 1..7 }.toSet()

    /** Returns the next due instant strictly after [afterMillis], or null when recurrence ended. */
    fun next(reminder: PersonalReminder, afterMillis: Long): Long? {
        val recurrence = if (reminder.recurrence == NONE && reminder.monthly) MONTHLY else reminder.recurrence
        if (recurrence == NONE) return null
        if (reminder.repeatEndType == END_COUNT && reminder.occurrenceLimit > 0 &&
            reminder.firedCount + 1 >= reminder.occurrenceLimit) return null
        val zone = ZoneId.systemDefault()
        val anchorMillis = reminder.anchorMillis.takeIf { it > 0L } ?: reminder.whenMillis
        val anchor = Instant.ofEpochMilli(anchorMillis).atZone(zone)
        val anchorDate = anchor.toLocalDate()
        val time = anchor.toLocalTime()
        val (anchorYear, anchorMonth, anchorDay) = gregorianToJalali(anchorDate)
        val candidateDate = when (recurrence) {
            DAILY -> generateSequence(anchorDate.plusDays(1)) { it.plusDays(1) }
                .take(100000).firstOrNull { date -> date.atTime(time).atZone(zone).toInstant().toEpochMilli() > afterMillis }
            WEEKLY -> {
                val days = normalizedWeekdays(reminder.weekdays).ifEmpty { setOf(anchorDate.dayOfWeek.value) }
                generateSequence(anchorDate.plusDays(1)) { it.plusDays(1) }
                    .take(100000).firstOrNull { date -> date.dayOfWeek.value in days && date.atTime(time).atZone(zone).toInstant().toEpochMilli() > afterMillis }
            }
            MONTHLY -> {
                var result: LocalDate? = null
                for (offset in 1..1200) {
                    val index = anchorYear * 12 + (anchorMonth - 1) + offset
                    val year = index / 12
                    val month = index % 12 + 1
                    val date = jalaliToGregorian(year, month, anchorDay.coerceAtMost(jalaliMonthLength(year, month)))
                    if (date.atTime(time).atZone(zone).toInstant().toEpochMilli() > afterMillis) { result = date; break }
                }
                result
            }
            YEARLY -> {
                var result: LocalDate? = null
                for (year in (anchorYear + 1)..(anchorYear + 500)) {
                    val day = anchorDay.coerceAtMost(jalaliMonthLength(year, anchorMonth))
                    val date = jalaliToGregorian(year, anchorMonth, day)
                    if (date.atTime(time).atZone(zone).toInstant().toEpochMilli() > afterMillis) { result = date; break }
                }
                result
            }
            else -> null
        } ?: return null
        val millis = candidateDate.atTime(time).atZone(zone).toInstant().toEpochMilli()
        if (reminder.repeatEndType == END_DATE && reminder.repeatEndDateMillis > 0L && millis > endOfLocalDay(reminder.repeatEndDateMillis, zone)) return null
        return millis
    }

    private fun endOfLocalDay(millis: Long, zone: ZoneId): Long =
        Instant.ofEpochMilli(millis).atZone(zone).toLocalDate().plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli() - 1L

    fun alarmTime(reminder: PersonalReminder): Long =
        reminder.whenMillis - reminder.alertOffsetMinutes.coerceAtLeast(0).toLong() * 60_000L
}
