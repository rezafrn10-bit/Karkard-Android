package ir.karkard.app

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.em
import androidx.compose.material3.LocalTextStyle

/** The actual BYekan.ttf is copied from the repository root by the app Gradle task. */
internal val BYekanFontFamily: FontFamily = FontFamily(Font(R.font.byekan))

/** Refine numeric typography without changing the size or typeface of Persian copy.
 * Dates receive thin spaces around slashes, digit runs use B Yekan at 90% size,
 * and the colon in HH:mm is deliberately smaller and optically centered.
 */
internal fun withBYekanNumerals(value: String): AnnotatedString {
    val dateSpaced = value.replace(
        Regex("(?<=[0-9۰-۹٠-٩])/(?=[0-9۰-۹٠-٩])"),
        "\u2009/\u2009"
    )
    val digitPattern = Regex("[0-9۰-۹٠-٩]+")
    val timeColonPattern = Regex("(?<=[0-9۰-۹٠-٩]):(?=[0-9۰-۹٠-٩])")
    return buildAnnotatedString {
        append(dateSpaced)
        digitPattern.findAll(dateSpaced).forEach { match ->
            addStyle(
                SpanStyle(fontFamily = BYekanFontFamily, fontSize = 0.90.em),
                match.range.first,
                match.range.last + 1
            )
        }
        timeColonPattern.findAll(dateSpaced).forEach { match ->
            addStyle(
                SpanStyle(fontSize = 0.62.em, baselineShift = BaselineShift(0.10f)),
                match.range.first,
                match.range.last + 1
            )
        }
    }
}

/** Material3 Text equivalent with B Yekan applied to every numeric run. */
@Composable
internal fun DigitAwareText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    textDecoration: TextDecoration? = null,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    onTextLayout: (TextLayoutResult) -> Unit = {},
    style: TextStyle = LocalTextStyle.current
) {
    val annotated = remember(text) { withBYekanNumerals(text) }
    Text(
        text = annotated,
        modifier = modifier,
        color = color,
        fontSize = fontSize,
        fontStyle = fontStyle,
        fontWeight = fontWeight,
        fontFamily = fontFamily,
        letterSpacing = letterSpacing,
        textDecoration = textDecoration,
        textAlign = textAlign,
        lineHeight = lineHeight,
        overflow = overflow,
        softWrap = softWrap,
        maxLines = maxLines,
        minLines = minLines,
        onTextLayout = onTextLayout,
        style = style
    )
}
