package ir.karkard.app

/** A validated minute-of-day interval. End must be later than start; day ranges do not cross midnight. */
internal data class WorkMinuteInterval(val start: Int, val end: Int) {
    val duration: Int get() = (end - start).coerceAtLeast(0)
    val durationMinutes: Int get() = duration
}

internal data class WorkCalculationInput(
    val attendance: List<WorkMinuteInterval>,
    val hourlyLeave: List<WorkMinuteInterval>,
    val fixedMode: Boolean,
    val targetMinutes: Int,
    val fixedStartMinute: Int,
    val fixedEndMinute: Int,
    val hourlyLeaveEnabled: Boolean = true,
    val incomplete: Boolean = false,
    /** Non-null for a manually designated holiday-work day. */
    val holidayWorkMinutes: Int? = null
)

internal data class WorkCalculationResult(
    val workedMinutes: Int = 0,
    val requiredMinutes: Int = 0,
    val overtimeMinutes: Int = 0,
    val hourlyLeaveMinutes: Int = 0,
    val incomplete: Boolean = false,
    val recordedRequiredMinutes: Int = 0
)

/**
 * Pure, UI/database-independent work calculation engine.
 * All minute values are calculated once here and then reused by day/month/year/export reports.
 */
internal object WorkCalculationEngine {
    fun calculate(input: WorkCalculationInput): WorkCalculationResult {
        val target = input.targetMinutes.coerceAtLeast(0)
        if (input.holidayWorkMinutes != null) {
            val holidayMinutes = if (input.incomplete) 0 else input.holidayWorkMinutes.coerceAtLeast(0)
            return WorkCalculationResult(
                workedMinutes = holidayMinutes,
                requiredMinutes = 0,
                overtimeMinutes = holidayMinutes,
                hourlyLeaveMinutes = 0,
                incomplete = input.incomplete,
                recordedRequiredMinutes = 0
            )
        }

        if (input.incomplete) {
            val knownLeave = if (!input.hourlyLeaveEnabled || target == 0) 0 else {
                val leave = merge(input.hourlyLeave)
                if (input.fixedMode) {
                    minOf(clippedUnion(leave, input.fixedStartMinute, input.fixedEndMinute), target)
                } else minOf(unionMinutes(leave), target)
            }
            return WorkCalculationResult(
                requiredMinutes = if (input.fixedMode) (target - knownLeave).coerceAtLeast(0) else target,
                hourlyLeaveMinutes = knownLeave,
                incomplete = true
            )
        }

        val attendance = merge(input.attendance)
        val leave = merge(input.hourlyLeave)
        val grossPresence = unionMinutes(attendance)
        val countedLeave = if (!input.hourlyLeaveEnabled || target == 0) 0 else {
            val overlappingLeave = overlapMinutes(attendance, leave)
            if (input.fixedMode) {
                val leaveInsideWindow = leave.mapNotNull { interval ->
                    clip(interval, input.fixedStartMinute, input.fixedEndMinute)
                }
                minOf(overlapMinutes(attendance, leaveInsideWindow), target)
            } else minOf(overlappingLeave, target)
        }
        val netWork = (grossPresence - countedLeave).coerceAtLeast(0)

        if (input.fixedMode) {
            val insideFixedWindow = clippedUnion(attendance, input.fixedStartMinute, input.fixedEndMinute)
            val overtime = (grossPresence - insideFixedWindow).coerceAtLeast(0)
            val requiredAfterLeave = (target - countedLeave).coerceAtLeast(0)
            val recordedInWindow = (insideFixedWindow - countedLeave).coerceAtLeast(0).coerceAtMost(requiredAfterLeave)
            return WorkCalculationResult(
                workedMinutes = netWork,
                requiredMinutes = requiredAfterLeave,
                overtimeMinutes = overtime,
                hourlyLeaveMinutes = countedLeave,
                recordedRequiredMinutes = recordedInWindow
            )
        }

        return WorkCalculationResult(
            workedMinutes = netWork,
            requiredMinutes = target,
            overtimeMinutes = (netWork - target).coerceAtLeast(0),
            hourlyLeaveMinutes = countedLeave,
            recordedRequiredMinutes = netWork.coerceAtMost(target)
        )
    }

    private fun valid(interval: WorkMinuteInterval): Boolean = interval.start >= 0 && interval.end > interval.start

    private fun merge(intervals: List<WorkMinuteInterval>): List<WorkMinuteInterval> {
        val sorted = intervals.filter(::valid).sortedBy { it.start }
        if (sorted.isEmpty()) return emptyList()
        val result = mutableListOf<WorkMinuteInterval>()
        for (current in sorted) {
            val previous = result.lastOrNull()
            if (previous == null || current.start > previous.end) result.add(current)
            else result[result.lastIndex] = WorkMinuteInterval(previous.start, maxOf(previous.end, current.end))
        }
        return result
    }

    private fun unionMinutes(intervals: List<WorkMinuteInterval>): Int = merge(intervals).sumOf { it.durationMinutes }

    private fun clip(interval: WorkMinuteInterval, from: Int, until: Int): WorkMinuteInterval? {
        val start = maxOf(interval.start, from)
        val end = minOf(interval.end, until)
        return if (end > start) WorkMinuteInterval(start, end) else null
    }

    private fun clippedUnion(intervals: List<WorkMinuteInterval>, from: Int, until: Int): Int =
        unionMinutes(intervals.mapNotNull { clip(it, from, until) })

    private fun overlapMinutes(first: List<WorkMinuteInterval>, second: List<WorkMinuteInterval>): Int {
        val a = merge(first)
        val b = merge(second)
        val intersections = mutableListOf<WorkMinuteInterval>()
        var i = 0
        var j = 0
        while (i < a.size && j < b.size) {
            clip(a[i], b[j].start, b[j].end)?.let(intersections::add)
            if (a[i].end <= b[j].end) i++ else j++
        }
        return unionMinutes(intersections)
    }
}
