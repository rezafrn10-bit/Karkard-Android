package ir.karkard.app

/**
 * Resolves calendar-derived status without mutating an explicitly selected workday category.
 * A database row by itself is not evidence of a manual category: it may contain only a note
 * or attendance data saved while the category was still the default.
 */
internal fun resolveCalendarWorkdayStatus(
    current: WorkDay,
    hasManualDayType: Boolean,
    isFriday: Boolean,
    isOfficialHoliday: Boolean
): WorkDay {
    if (hasManualDayType) return current
    val defaultStatus = if (isFriday || isOfficialHoliday) "تعطیل رسمی" else "کاری"
    return current.copy(dayType = defaultStatus, dayTypeManual = false)
}

/** A manual override is created only by an actual change to the category fields. */
internal fun hasDayTypeCategoryChanged(
    currentDayType: String,
    currentExtraDayTypes: String,
    updatedDayType: String,
    updatedExtraDayTypes: String
): Boolean = currentDayType != updatedDayType || currentExtraDayTypes != updatedExtraDayTypes

/**
 * Legacy databases stored attendance and day category in the same row, but did not
 * record whether the user tapped a category. Attendance is NOT proof of a manual
 * category choice. Only an explicit non-default category can be safely migrated as
 * manual; a legacy "کاری" value remains eligible for calendar holiday resolution.
 */
internal fun legacyDayTypeWasManuallyChosen(
    dayType: String,
    extraDayTypes: String
): Boolean =
    (dayType.trim().isNotEmpty() && dayType.trim() !in setOf("کاری")) ||
        extraDayTypes.isNotBlank()

/** A v0.66 flag on a plain working-day row with attendance may be a false positive. */
internal fun hasAnyAttendanceData(vararg entries: String?): Boolean =
    entries.any { !it.isNullOrBlank() }

internal fun shouldReleaseLegacyWorkingDayFlag(
    dayType: String,
    extraDayTypes: String,
    hasAttendanceData: Boolean,
    isOfficialHoliday: Boolean
): Boolean =
    isOfficialHoliday && dayType.trim().ifBlank { "کاری" } == "کاری" &&
        extraDayTypes.isBlank() && hasAttendanceData
/** Calendar defaults apply only while the user has not explicitly managed this date. */
internal fun isCalendarDefaultHoliday(
    day: WorkDay,
    isFriday: Boolean,
    isOfficialHoliday: Boolean
): Boolean = !day.dayTypeManual && (isFriday || isOfficialHoliday)

