package ir.karkard.app

/**
 * Resolves calendar-derived status without mutating an existing work-management record.
 * Official calendar dates and Fridays are defaults only for dates with no saved record.
 */
internal fun resolveCalendarWorkdayStatus(
    current: WorkDay,
    hasSavedRecord: Boolean,
    isFriday: Boolean,
    isOfficialHoliday: Boolean
): WorkDay {
    if (hasSavedRecord) return current
    val defaultStatus = if (isFriday || isOfficialHoliday) "تعطیل رسمی" else "کاری"
    return current.copy(dayType = defaultStatus)
}
