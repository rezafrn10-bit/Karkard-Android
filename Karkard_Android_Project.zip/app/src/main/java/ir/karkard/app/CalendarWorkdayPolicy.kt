package ir.karkard.app

/**
 * Resolves calendar-derived status without mutating an explicitly selected workday category.
 * A database row by itself is not evidence of a manual category: it may contain only a note
 * or attendance data saved while the category was still the default.
 */
internal fun resolveCalendarWorkdayStatus(
    current: WorkDay,
    hasManualDayType: Boolean,
    isFriday: Boolean,
    isOfficialHoliday: Boolean
): WorkDay {
    if (hasManualDayType) return current
    val defaultStatus = if (isFriday || isOfficialHoliday) "تعطیل رسمی" else "کاری"
    return current.copy(dayType = defaultStatus, dayTypeManual = false)
}

/**
 * Best-effort migration for versions that did not persist category provenance.
 * Non-default categories, secondary categories, or actual attendance entries are
 * treated as manually managed. A plain "کاری" row with no attendance is a legacy default.
 */
internal fun legacyDayTypeWasManuallyChosen(
    dayType: String,
    extraDayTypes: String,
    hasAttendanceData: Boolean
): Boolean =
    (dayType.trim().isNotEmpty() && dayType.trim() !in setOf("کاری")) ||
        extraDayTypes.isNotBlank() || hasAttendanceData
/** Calendar defaults apply only while the user has not explicitly managed this date. */
internal fun isCalendarDefaultHoliday(
    day: WorkDay,
    isFriday: Boolean,
    isOfficialHoliday: Boolean
): Boolean = !day.dayTypeManual && (isFriday || isOfficialHoliday)

