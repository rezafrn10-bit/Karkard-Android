package ir.karkard.app

/**
 * Resolves calendar-derived status without mutating an explicitly selected workday category.
 * A database row by itself is not evidence of a manual category: it may contain only a note
 * or attendance data saved while the category was still the default.
 */
internal fun resolveCalendarWorkdayStatus(
    current: WorkDay,
    hasManualDayType: Boolean,
    isFriday: Boolean,
    isOfficialHoliday: Boolean
): WorkDay {
    val calendarHoliday = isFriday || isOfficialHoliday
    val resolvedType = when {
        // An explicitly declared exceptional closure is a user-owned override.
        hasManualDayType && current.dayType == "تعطیل خاص" -> "تعطیل خاص"
        // Official dates are immutable: even a legacy/manual "کاری" value cannot turn them into workdays.
        calendarHoliday -> "تعطیل رسمی"
        hasManualDayType -> current.dayType
        else -> "کاری"
    }
    val attendance = when {
        resolvedType != "کاری" && current.attendanceStatus == "عادی" -> ""
        resolvedType == "کاری" && current.attendanceStatus.isBlank() -> "عادی"
        else -> current.attendanceStatus
    }
    return current.copy(
        dayType = resolvedType,
        dayTypeManual = hasManualDayType && resolvedType != "تعطیل رسمی",
        attendanceStatus = attendance
    )
}

/** A manual override is created only by an actual change to the category fields. */
internal fun hasDayTypeCategoryChanged(
    currentDayType: String,
    currentExtraDayTypes: String,
    updatedDayType: String,
    updatedExtraDayTypes: String
): Boolean = currentDayType != updatedDayType || currentExtraDayTypes != updatedExtraDayTypes

/**
 * Legacy databases stored attendance and day category in the same row, but did not
 * record whether the user tapped a category. Attendance is NOT proof of a manual
 * category choice. Only an explicit non-default category can be safely migrated as
 * manual; a legacy "کاری" value remains eligible for calendar holiday resolution.
 */
internal fun legacyDayTypeWasManuallyChosen(
    dayType: String,
    extraDayTypes: String
): Boolean =
    (dayType.trim().isNotEmpty() && dayType.trim() !in setOf("کاری")) ||
        extraDayTypes.isNotBlank()

/** A v0.66 flag on a plain working-day row with attendance may be a false positive. */
internal fun hasAnyAttendanceData(vararg entries: String?): Boolean =
    entries.any { !it.isNullOrBlank() }

internal fun shouldReleaseLegacyWorkingDayFlag(
    dayType: String,
    extraDayTypes: String,
    hasAttendanceData: Boolean,
    isOfficialHoliday: Boolean
): Boolean =
    isOfficialHoliday && dayType.trim().ifBlank { "کاری" } == "کاری" &&
        extraDayTypes.isBlank() && hasAttendanceData
/** Official dates stay holidays regardless of legacy manual flags; special closures remain user-owned. */
internal fun isCalendarDefaultHoliday(
    day: WorkDay,
    isFriday: Boolean,
    isOfficialHoliday: Boolean
): Boolean = isFriday || isOfficialHoliday || day.dayType == "تعطیل خاص"


/** Converts the legacy mixed status column into the independent attendance field. */
internal fun migrateLegacyAttendanceStatus(dayType: String, extraDayTypes: String): String {
    val candidates = listOf(dayType.trim()) + extraDayTypes.split('|').map(String::trim)
    return when (candidates.firstOrNull { it in setOf("مرخصی", "استحقاقی", "استعلاجی", "مأموریت") }.orEmpty()) {
        "مرخصی", "استحقاقی" -> "استحقاقی"
        "استعلاجی" -> "استعلاجی"
        "مأموریت" -> "مأموریت"
        else -> ""
    }
}

/** Converts legacy day categories to the new three-value day-type vocabulary. */
internal fun migrateLegacyDayCategory(dayType: String): String = when (dayType.trim()) {
    "تعطیل" -> "تعطیل رسمی"
    "تعطیل مناسبتی", "تعطیل خاص" -> "تعطیل خاص"
    "کاری", "تعطیل رسمی" -> dayType.trim()
    "مرخصی", "استحقاقی", "استعلاجی", "مأموریت", "" -> "کاری"
    else -> "کاری"
}
