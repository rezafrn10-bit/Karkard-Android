package ir.karkard.app

/**
 * Calendar facts and user-owned workday choices are separate sources.
 * The only user-owned primary holiday is "تعطیل مناسبتی"; official holidays
 * are always derived from the calendar tables/bundled calendar.
 */
internal val independentDayStatuses: Set<String> = linkedSetOf("مرخصی", "استعلاجی", "مأموریت")

/**
 * Resolves the primary day category from the calendar unless the user explicitly
 * marked the day as an exceptional occasion holiday. Attendance, notes and the
 * independent leave/mission flags never freeze a calendar holiday.
 */
internal fun resolveCalendarWorkdayStatus(
    current: WorkDay,
    isFriday: Boolean,
    isOfficialHoliday: Boolean
): WorkDay {
    if (current.dayType == "تعطیل مناسبتی" && current.dayTypeManual) return current
    val calendarDefault = if (isFriday || isOfficialHoliday) "تعطیل رسمی" else "کاری"
    return if (current.dayType == calendarDefault && !current.dayTypeManual) current
    else current.copy(dayType = calendarDefault, dayTypeManual = false)
}

/** One shared rule for both the card's enabled state and its state transition. */
internal fun canToggleWorkdayStatus(
    day: WorkDay,
    selected: String,
    isOfficialCalendarHoliday: Boolean,
    isFriday: Boolean
): Boolean {
    if (selected in independentDayStatuses) return true
    if (selected == "تعطیل رسمی") return false
    val protectedCalendarDay = isOfficialCalendarHoliday || isFriday
    return when (selected) {
        "کاری" -> !protectedCalendarDay
        "تعطیل مناسبتی" -> !protectedCalendarDay ||
            (day.dayType == "تعطیل مناسبتی" && day.dayTypeManual)
        else -> false
    }
}

/**
 * Applies a card action without allowing user controls to manufacture an official
 * holiday or turn a calendar/weekly holiday into a working day. Independent statuses
 * are stored together and can all be active at once.
 */
internal fun toggleWorkdayStatus(
    day: WorkDay,
    selected: String,
    isOfficialCalendarHoliday: Boolean,
    isFriday: Boolean
): WorkDay {
    if (!canToggleWorkdayStatus(day, selected, isOfficialCalendarHoliday, isFriday)) return day

    if (selected in independentDayStatuses) {
        val statuses = day.extraDayTypes.split('|')
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toMutableSet()
        if (!statuses.add(selected)) statuses.remove(selected)
        val ordered = independentDayStatuses.filter { it in statuses }
        return day.copy(
            extraDayTypes = ordered.joinToString("|"),
            // These flags are independent of the primary day category.
            dayTypeManual = day.dayType == "تعطیل مناسبتی" && day.dayTypeManual
        )
    }

    // "تعطیل رسمی" is read-only and comes only from the verified calendar/weekly rule.
    if (selected == "تعطیل رسمی") return day

    val protectedCalendarDay = isOfficialCalendarHoliday || isFriday
    if (selected == "کاری") {
        if (protectedCalendarDay) return day
        return day.copy(dayType = "کاری", dayTypeManual = false)
    }

    if (selected == "تعطیل مناسبتی") {
        val alreadyManualOccasion = day.dayType == "تعطیل مناسبتی" && day.dayTypeManual
        if (alreadyManualOccasion) {
            val calendarDefault = if (protectedCalendarDay) "تعطیل رسمی" else "کاری"
            return day.copy(dayType = calendarDefault, dayTypeManual = false)
        }
        if (protectedCalendarDay) return day
        return day.copy(dayType = "تعطیل مناسبتی", dayTypeManual = true)
    }

    return day
}

/** Calendar and manual holiday summaries use the same source-of-truth rule. */
internal fun isCalendarDefaultHoliday(
    day: WorkDay,
    isFriday: Boolean,
    isOfficialHoliday: Boolean
): Boolean =
    !(day.dayType == "تعطیل مناسبتی" && day.dayTypeManual) && (isFriday || isOfficialHoliday)

/**
 * Normalizes pre-v0.68 records where leave/mission could be stored as the primary
 * category. They are now independent flags; only an occasion holiday stays primary.
 */
internal fun normalizeWorkDayCategories(day: WorkDay): WorkDay {
    val extras = day.extraDayTypes.split('|')
        .map { it.trim() }
        .filter { it in independentDayStatuses }
        .toMutableSet()
    if (day.dayType in independentDayStatuses) extras.add(day.dayType)
    // There is no calendar-generated "تعطیل مناسبتی"; its presence is always a
    // user choice, including records imported from older backup formats.
    val primary = if (day.dayType == "تعطیل مناسبتی") "تعطیل مناسبتی" else "کاری"
    val manual = primary == "تعطیل مناسبتی"
    return day.copy(
        dayType = primary,
        extraDayTypes = independentDayStatuses.filter { it in extras }.joinToString("|"),
        dayTypeManual = manual
    )
}
