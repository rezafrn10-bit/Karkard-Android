package ir.karkard.app

/**
 * Persian calendar 1405: offline, year-specific national and religious public holidays.
 * Transcribed from the published 1405 FarsiUI holidays dataset, which cross-checks
 * the University of Tehran Calendar Center's official 1405 calendar.
 * https://github.com/MiladJoodi/FarsiUI/tree/main/calendar/years/1405
 * https://calendar.ut.ac.ir/
 *
 * The additional non-holiday events below are a curated starter list only;
 * Settings > Download calendar fetches the full published yearly occasions.
 * DO NOT calculate Iranian official lunar holidays from civil Islamic dates.
 */
internal object Calendar1405 {
    val holidays: List<Pair<String, String>> = listOf(
        "1405-01-01" to "عید سعید فطر، آغاز نوروز",
        "1405-01-02" to "تعطیل عید سعید فطر، عید نوروز",
        "1405-01-03" to "عید نوروز",
        "1405-01-04" to "عید نوروز",
        "1405-01-12" to "روز جمهوری اسلامی ایران",
        "1405-01-13" to "روز طبیعت (سیزده‌به‌در)",
        "1405-01-25" to "شهادت امام جعفر صادق (ع)",
        "1405-03-06" to "عید سعید قربان",
        "1405-03-14" to "عید سعید غدیر خم، رحلت امام خمینی",
        "1405-03-15" to "قیام ۱۵ خرداد",
        "1405-04-03" to "تاسوعای حسینی",
        "1405-04-04" to "عاشورای حسینی",
        "1405-05-13" to "اربعین حسینی",
        "1405-05-21" to "رحلت رسول اکرم (ص)، شهادت امام حسن مجتبی (ع)",
        "1405-05-22" to "شهادت امام رضا (ع)",
        "1405-05-30" to "شهادت امام حسن عسکری (ع) و آغاز امامت حضرت ولی‌عصر (عج)",
        "1405-06-08" to "میلاد رسول اکرم (ص) و امام جعفر صادق (ع)",
        "1405-08-22" to "شهادت حضرت فاطمه زهرا (س)",
        "1405-10-02" to "ولادت امام علی (ع) و روز پدر",
        "1405-10-16" to "مبعث رسول اکرم (ص)",
        "1405-11-04" to "ولادت حضرت قائم (عج) و جشن نیمه شعبان",
        "1405-11-22" to "پیروزی انقلاب اسلامی",
        "1405-12-09" to "شهادت حضرت علی (ع)",
        "1405-12-19" to "عید سعید فطر",
        "1405-12-20" to "تعطیل عید سعید فطر",
        "1405-12-29" to "روز ملی شدن صنعت نفت ایران"
    )

    // A selection of correctly dated occasions with no statutory holiday status.
    // The full events list (national, religious, cultural) is downloaded when online.
    val events: List<Pair<String, String>> = listOf(
        "1405-01-29" to "ولادت حضرت معصومه (س) و روز دختران",
        "1405-02-01" to "روز بزرگداشت سعدی",
        "1405-02-08" to "ولادت امام رضا (ع)",
        "1405-02-12" to "روز معلم و شهادت استاد مطهری",
        "1405-02-27" to "شهادت امام محمد تقی (ع)",
        "1405-03-03" to "شهادت امام محمد باقر (ع)",
        "1405-03-05" to "روز عرفه",
        "1405-03-11" to "ولادت امام علی النقی (ع)",
        "1405-03-16" to "ولادت امام موسی کاظم (ع)",
        "1405-06-28" to "ولادت امام حسن عسکری (ع)",
        "1405-09-02" to "وفات حضرت ام‌البنین (س) و روز تکریم مادران و همسران شهدا",
        "1405-09-28" to "ولادت امام محمد تقی (ع)",
        "1405-09-30" to "شب یلدا",
        "1405-10-13" to "شهادت امام موسی کاظم (ع)",
        "1405-10-21" to "ولادت امام حسین (ع) و روز پاسدار",
        "1405-10-22" to "ولادت حضرت ابوالفضل (ع) و روز جانباز",
        "1405-10-23" to "ولادت امام زین العابدین (ع)",
        "1405-10-29" to "ولادت حضرت علی اکبر (ع) و روز جوان",
        "1405-11-10" to "جشن سده",
        "1405-12-03" to "ولادت امام حسن مجتبی (ع)"
    )
}

/**
 * Normalize a title only for comparison. The first-seen original spelling remains
 * the stored/displayed spelling so merging sources never rewrites the user's text.
 */
private fun normalizedCalendarEventTitle(value: String): String =
    java.text.Normalizer.normalize(value, java.text.Normalizer.Form.NFKC)
        .replace('\u064A', '\u06CC') // Arabic Yeh -> Persian Yeh
        .replace('\u0643', '\u06A9') // Arabic Kaf -> Persian Kaf
        .replace(Regex("[\\u064B-\\u065F\\u0670]"), "") // Arabic diacritics
        .replace("\u200C", " ") // treat ZWNJ and ordinary spacing equally
        .replace(Regex("\\s+"), " ")
        .trim()
        .lowercase(java.util.Locale.ROOT)

/**
 * Merge titles using the persisted Persian-comma separator. Deduplication is
 * Unicode-aware (Arabic/Persian letter variants, spacing and diacritics) while
 * preserving the first source's visible title.
 */
internal fun mergeCalendarEventTitles(existing: String?, additions: List<String>): String? {
    val merged = linkedMapOf<String, String>()
    fun add(raw: String) {
        val title = raw.trim()
        if (title.isBlank()) return
        val key = normalizedCalendarEventTitle(title)
        if (key.isNotBlank() && key !in merged) merged[key] = title
    }
    existing.orEmpty().split("،").forEach(::add)
    additions.forEach { value -> value.split("،").forEach(::add) }
    return merged.values.takeIf { it.isNotEmpty() }?.joinToString("، ")
}

/**
 * Merge event rows from multiple calendar sources. Rows retain first-seen order;
 * identical date/title pairs are collapsed without changing their visible spelling.
 */
internal fun mergeCalendarEventPairs(vararg sources: List<Pair<String, String>>): List<Pair<String, String>> {
    val titlesByDate = linkedMapOf<String, MutableList<String>>()
    sources.forEach { source ->
        source.forEach { (date, title) ->
            val merged = mergeCalendarEventTitles(titlesByDate[date]?.joinToString("، "), listOf(title))
            if (merged != null) {
                titlesByDate[date] = merged.split("،").map { it.trim() }.filter { it.isNotBlank() }.toMutableList()
            }
        }
    }
    return titlesByDate.map { (date, titles) -> date to titles.joinToString("، ") }
}
