package ir.karkard.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


private val ShiftYellow = AppPalette.PrimarySoft
private val ShiftYellowText = AppPalette.Primary
private val OvertimeGreen = AppPalette.SuccessSoft
private val OvertimeGreenText = AppPalette.Success

private fun String.toLatinDigits(): String = map { ch ->
    when (ch) {
        '۰' -> '0'; '۱' -> '1'; '۲' -> '2'; '۳' -> '3'; '۴' -> '4'
        '۵' -> '5'; '۶' -> '6'; '۷' -> '7'; '۸' -> '8'; '۹' -> '9'
        '٠' -> '0'; '١' -> '1'; '٢' -> '2'; '٣' -> '3'; '٤' -> '4'
        '٥' -> '5'; '٦' -> '6'; '٧' -> '7'; '٨' -> '8'; '٩' -> '9'
        else -> ch
    }
}.joinToString("")

private val JalaliMonthNames = listOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
private val JalaliWeekdayNames = listOf("یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه")
private fun jalaliDisplayDate(value: String): String = value.replace('-', '/').toPersianDigits()

private fun String.toPersianDigits(): String = map { ch ->
    when (ch) {
        '0' -> '۰'; '1' -> '۱'; '2' -> '۲'; '3' -> '۳'; '4' -> '۴'
        '5' -> '۵'; '6' -> '۶'; '7' -> '۷'; '8' -> '۸'; '9' -> '۹'
        else -> ch
    }
}.joinToString("")

@Composable
private fun PersianText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = FontFamily.SansSerif,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    textDecoration: TextDecoration? = null,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    style: TextStyle = LocalTextStyle.current
) {
    androidx.compose.material3.Text(
        text = text.toPersianDigits(),
        modifier = modifier,
        color = color,
        fontSize = fontSize,
        fontStyle = fontStyle,
        fontWeight = fontWeight,
        fontFamily = fontFamily,
        letterSpacing = letterSpacing,
        textDecoration = textDecoration,
        textAlign = textAlign,
        lineHeight = lineHeight,
        overflow = overflow,
        softWrap = softWrap,
        maxLines = maxLines,
        minLines = minLines,
        style = style
    )
}

data class WorkDay(
    val date: String,
    val in1: String = "", val out1: String = "",
    val in2: String = "", val out2: String = "",
    val in3: String = "", val out3: String = "",
    val note: String = "",
    val dayType: String = "کاری",
    val overtimeOverride: String = "",
    val shiftEnabled: Boolean = false,
    val shiftStart: String = "",
    val shiftEnd: String = "",
    val shiftStartDate: String = "",
    val shiftEndDate: String = "",
    val holidayIn: String = "",
    val holidayOut: String = "",
    val leave1Start: String = "", val leave1End: String = "",
    val leave2Start: String = "", val leave2End: String = "",
    val hourlyLeaveEnabled: Boolean = false,
    val extraDayTypes: String = "", // persisted attendance status (legacy-compatible)
    val leave3Start: String = "", val leave3End: String = "",
    val holidayIn2: String = "", val holidayOut2: String = "",
    val scheduleMode: String = "شناور"
)

private val workHolidayStatuses = setOf("تعطیل رسمی", "تعطیل مناسبتی")
private val workDayCategories = setOf("کاری") + workHolidayStatuses
private val workAttendanceStatuses = setOf("عادی", "استحقاقی", "استعلاجی", "مأموریت")
private val workLeaveStatuses = setOf("استحقاقی", "استعلاجی")

/** Normalize legacy records into independent day-category and attendance dimensions. */
private fun normalizedDayCategory(day: WorkDay): String = when (day.dayType) {
    "تعطیل" -> "تعطیل رسمی"
    "مرخصی", "استحقاقی", "استعلاجی", "مأموریت" -> "کاری"
    in workDayCategories -> day.dayType
    else -> "کاری"
}
private fun normalizedAttendance(day: WorkDay): String {
    val legacyPrimary = when (day.dayType) {
        "مرخصی" -> "استحقاقی"
        in workAttendanceStatuses -> day.dayType
        else -> null
    }
    val stored = day.extraDayTypes.split('|').firstOrNull { it in workAttendanceStatuses }
    return stored ?: legacyPrimary ?: if (normalizedDayCategory(day) == "کاری") "عادی" else ""
}
private fun dayStatuses(day: WorkDay): Set<String> = buildSet {
    add(normalizedDayCategory(day))
    normalizedAttendance(day).takeIf { it.isNotBlank() }?.let(::add)
}
private fun hasDayStatus(day: WorkDay, status: String) = status in dayStatuses(day)

private fun toggleDayStatus(day: WorkDay, selected: String): WorkDay {
    var category = normalizedDayCategory(day)
    var attendance = normalizedAttendance(day)
    if (selected in workDayCategories) {
        category = if (category == selected) "" else selected
        if (category in workHolidayStatuses && attendance == "عادی") attendance = ""
        if (category.isBlank()) attendance = ""
    } else if (selected in workAttendanceStatuses) {
        if (selected == "عادی" && category in workHolidayStatuses) return day
        attendance = if (attendance == selected) "" else selected
    }
    return day.copy(
        dayType = category.ifBlank { "کاری" },
        extraDayTypes = attendance
    )
}

class WorkDb(context: Context) : SQLiteOpenHelper(context, "karkard.db", null, 20) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE workdays(
            date TEXT PRIMARY KEY, in1 TEXT, out1 TEXT, in2 TEXT, out2 TEXT,
            in3 TEXT, out3 TEXT, note TEXT, day_type TEXT DEFAULT 'کاری',
            overtime_override TEXT DEFAULT '', shift_enabled INTEGER DEFAULT 0, shift_start TEXT DEFAULT '', shift_end TEXT DEFAULT '', shift_start_date TEXT DEFAULT '', shift_end_date TEXT DEFAULT '', holiday_in TEXT DEFAULT '', holiday_out TEXT DEFAULT '', leave1_start TEXT DEFAULT '', leave1_end TEXT DEFAULT '', leave2_start TEXT DEFAULT '', leave2_end TEXT DEFAULT '', leave_enabled INTEGER DEFAULT 0, extra_day_types TEXT DEFAULT '', leave3_start TEXT DEFAULT '', leave3_end TEXT DEFAULT '', holiday_in2 TEXT DEFAULT '', holiday_out2 TEXT DEFAULT '', schedule_mode TEXT DEFAULT 'شناور')""")
        db.execSQL("CREATE TABLE holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL)")
        db.execSQL("CREATE TABLE official_holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL, year INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE holiday_sync(year INTEGER PRIMARY KEY, synced_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE calendar_events(date TEXT PRIMARY KEY, title TEXT NOT NULL, year INTEGER NOT NULL)")
        db.execSQL("""CREATE TABLE settings(
            key TEXT PRIMARY KEY, value TEXT NOT NULL)""")
        val defaults = mapOf(
            "workday_hours" to "07:00", "thursday_hours_value" to "05:00",
            "work_schedule_mode" to "شناور",
            "fixed_weekday_start" to "07:00", "fixed_weekday_end" to "14:00",
            "fixed_thursday_start" to "07:00", "fixed_thursday_end" to "12:00"
        )
        defaults.forEach { (k,v) ->
            val cv = ContentValues().apply { put("key", k); put("value", v) }
            db.insert("settings", null, cv)
        }
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN day_type TEXT DEFAULT 'کاری'")
            db.execSQL("ALTER TABLE workdays ADD COLUMN overtime_override TEXT DEFAULT ''")
            val defaults = mapOf("workday_hours" to "07:00", "thursday_hours_value" to "05:00")
            defaults.forEach { (k,v) ->
                val cv = ContentValues().apply { put("key",k); put("value",v) }
                db.insertWithOnConflict("settings", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
            }
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_enabled INTEGER DEFAULT 0")
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_start TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_end TEXT DEFAULT ''")
        }
        if (oldVersion < 4) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_start_date TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_end_date TEXT DEFAULT ''")
            db.execSQL("DELETE FROM settings WHERE key='shift_hours'")
        }
        if (oldVersion < 5) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN holiday_in TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN holiday_out TEXT DEFAULT ''")
        }
        if (oldVersion < 11) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave1_start TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave1_end TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave2_start TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave2_end TEXT DEFAULT ''")
        }
        if (oldVersion < 12) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave_enabled INTEGER DEFAULT 0")
            // Existing leave entries must remain active after an upgrade.
            db.execSQL("""UPDATE workdays SET leave_enabled=1 WHERE
                COALESCE(leave1_start,'')<>'' OR COALESCE(leave1_end,'')<>'' OR
                COALESCE(leave2_start,'')<>'' OR COALESCE(leave2_end,'')<>''""")
        }
        if (oldVersion < 13) {
            // Migrate factory defaults from prior versions, without overriding other custom choices.
            db.execSQL("UPDATE settings SET value='07:00' WHERE key='workday_hours' AND value='08:00'")
            db.execSQL("UPDATE settings SET value='05:00' WHERE key='thursday_hours_value' AND value='04:00'")
            db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('workday_hours','07:00')")
            db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('thursday_hours_value','05:00')")
        }
        if (oldVersion < 14) {
            // Older versions stored Fridays as the legacy 'تعطیل' status.
            db.execSQL("UPDATE workdays SET day_type='تعطیل رسمی' WHERE day_type='تعطیل'")
        }
        if (oldVersion < 15) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN extra_day_types TEXT DEFAULT ''")
        }
        if (oldVersion < 17) db.execSQL("DROP TABLE IF EXISTS long_leave_days")
        if (oldVersion < 18) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave3_start TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave3_end TEXT DEFAULT ''")
        }
        if (oldVersion < 19) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN holiday_in2 TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN holiday_out2 TEXT DEFAULT ''")
        }
        if (oldVersion < 20) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN schedule_mode TEXT DEFAULT 'شناور'")
            val scheduleDefaults = mapOf(
                "work_schedule_mode" to "شناور",
                "fixed_weekday_start" to "07:00", "fixed_weekday_end" to "14:00",
                "fixed_thursday_start" to "07:00", "fixed_thursday_end" to "12:00"
            )
            scheduleDefaults.forEach { (k, v) ->
                val cv = ContentValues().apply { put("key", k); put("value", v) }
                db.insertWithOnConflict("settings", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
            }
        }
        db.execSQL("CREATE TABLE IF NOT EXISTS holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS official_holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL, year INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS holiday_sync(year INTEGER PRIMARY KEY, synced_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS calendar_events(date TEXT PRIMARY KEY, title TEXT NOT NULL, year INTEGER NOT NULL)")
        db.execSQL("DELETE FROM settings WHERE key='shift_hours'")
        if (oldVersion < 10) {
            // Force a fresh calendar download after holiday parser improvements.
            // Existing work records and saved calendar data are retained.
            db.delete("holiday_sync", null, null)
        }
    }

    fun hasWorkDay(date: String): Boolean = readableDatabase.rawQuery(
        "SELECT 1 FROM workdays WHERE date=? LIMIT 1", arrayOf(date)
    ).use { it.moveToFirst() }

    fun getDay(date: String): WorkDay {
        readableDatabase.rawQuery("SELECT * FROM workdays WHERE date=?", arrayOf(date)).use { c ->
            if (c.moveToFirst()) return WorkDay(
                c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "",
                c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "",
                c.getString(6) ?: "", c.getString(7) ?: "",
                if (c.columnCount > 8) c.getString(8) ?: "کاری" else "کاری",
                if (c.columnCount > 9) c.getString(9) ?: "" else "",
                if (c.columnCount > 10) c.getInt(10) == 1 else false,
                if (c.columnCount > 11) c.getString(11) ?: "" else "",
                if (c.columnCount > 12) c.getString(12) ?: "" else "",
                if (c.columnCount > 13) c.getString(13) ?: "" else "",
                if (c.columnCount > 14) c.getString(14) ?: "" else "",
                if (c.columnCount > 15) c.getString(15) ?: "" else "",
                if (c.columnCount > 16) c.getString(16) ?: "" else "",
                if (c.columnCount > 17) c.getString(17) ?: "" else "", if (c.columnCount > 18) c.getString(18) ?: "" else "",
                if (c.columnCount > 19) c.getString(19) ?: "" else "", if (c.columnCount > 20) c.getString(20) ?: "" else "",
                if (c.columnCount > 21) c.getInt(21) == 1 else listOf(17,18,19,20).any { i -> i < c.columnCount && !c.getString(i).isNullOrBlank() },
                if (c.columnCount > 22) c.getString(22) ?: "" else "",
                if (c.columnCount > 23) c.getString(23) ?: "" else "", if (c.columnCount > 24) c.getString(24) ?: "" else "",
                if (c.columnCount > 25) c.getString(25) ?: "" else "", if (c.columnCount > 26) c.getString(26) ?: "" else "",
                if (c.columnCount > 27) c.getString(27) ?: "شناور" else "شناور"
            )
        }
        return WorkDay(date)
    }
    fun calendarSyncTime(year: Int): Long = readableDatabase.rawQuery(
        "SELECT synced_at FROM holiday_sync WHERE year=?", arrayOf(year.toString())
    ).use { if (it.moveToFirst()) it.getLong(0) else 0L }

    /** Deletes user-entered work data for one exact Jalali date only.
     * Official calendar holidays, events, preferences and reminders are preserved. */
    fun deleteWorkRecord(date: String) {
        val database = writableDatabase
        database.beginTransaction()
        try {
            database.delete("workdays", "date = ?", arrayOf(date))
            // Remove only the user-authored holiday reason for this date.
            database.delete("holidays", "date = ?", arrayOf(date))
            database.setTransactionSuccessful()
        } finally { database.endTransaction() }
    }

    /** Deletes user-entered records in one Jalali month while preserving official calendar data. */
    fun deleteWorkRecordsForMonth(year: Int, month: Int) {
        val prefix = "%04d-%02d".format(year, month)
        val database = writableDatabase
        database.beginTransaction()
        try {
            database.delete("workdays", "date LIKE ?", arrayOf("$prefix-%"))
            database.delete("holidays", "date LIKE ?", arrayOf("$prefix-%"))
            database.delete("settings", "key = ?", arrayOf("tourahi_deduction_$prefix"))
            database.setTransactionSuccessful()
        } finally { database.endTransaction() }
    }

    fun saveDay(d: WorkDay) {
        val v = ContentValues().apply {
            put("date", d.date); put("in1",d.in1); put("out1",d.out1)
            put("in2",d.in2); put("out2",d.out2); put("in3",d.in3); put("out3",d.out3)
            put("note",d.note); put("day_type",d.dayType); put("overtime_override",d.overtimeOverride); put("shift_enabled", if(d.shiftEnabled) 1 else 0); put("shift_start",d.shiftStart); put("shift_end",d.shiftEnd); put("shift_start_date",d.shiftStartDate); put("shift_end_date",d.shiftEndDate)
            put("holiday_in", d.holidayIn); put("holiday_out", d.holidayOut); put("leave1_start", d.leave1Start); put("leave1_end", d.leave1End); put("leave2_start", d.leave2Start); put("leave2_end", d.leave2End); put("leave_enabled", 1); put("extra_day_types", d.extraDayTypes); put("leave3_start", d.leave3Start); put("leave3_end", d.leave3End); put("holiday_in2", d.holidayIn2); put("holiday_out2", d.holidayOut2); put("schedule_mode", d.scheduleMode)
        }
        writableDatabase.insertWithOnConflict("workdays", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun allDays(month: String): List<WorkDay> {
        val result = mutableListOf<WorkDay>()
        readableDatabase.rawQuery("SELECT * FROM workdays WHERE date LIKE ? ORDER BY date", arrayOf("$month%")).use { c ->
            while(c.moveToNext()) result.add(WorkDay(
                c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "",
                c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "",
                c.getString(6) ?: "", c.getString(7) ?: "",
                c.getString(8) ?: "کاری", c.getString(9) ?: "", c.getInt(10) == 1, c.getString(11) ?: "", c.getString(12) ?: "", c.getString(13) ?: "", c.getString(14) ?: "",
                if (c.columnCount > 15) c.getString(15) ?: "" else "", if (c.columnCount > 16) c.getString(16) ?: "" else "",
                if (c.columnCount > 17) c.getString(17) ?: "" else "", if (c.columnCount > 18) c.getString(18) ?: "" else "",
                if (c.columnCount > 19) c.getString(19) ?: "" else "", if (c.columnCount > 20) c.getString(20) ?: "" else "",
                if (c.columnCount > 21) c.getInt(21) == 1 else listOf(17,18,19,20).any { i -> i < c.columnCount && !c.getString(i).isNullOrBlank() },
                if (c.columnCount > 22) c.getString(22) ?: "" else "",
                if (c.columnCount > 23) c.getString(23) ?: "" else "", if (c.columnCount > 24) c.getString(24) ?: "" else "",
                if (c.columnCount > 25) c.getString(25) ?: "" else "", if (c.columnCount > 26) c.getString(26) ?: "" else "",
                if (c.columnCount > 27) c.getString(27) ?: "شناور" else "شناور"
            ))
        }
        return result
    }
    fun allDaysYear(year: Int): List<WorkDay> = allDaysForBackup().filter { it.date.startsWith("%04d-".format(year)) }
    fun officialHolidays(year: Int): List<Pair<String, String>> {
        val result = mutableListOf<Pair<String, String>>()
        readableDatabase.rawQuery(
            "SELECT date,title FROM official_holidays WHERE year=? ORDER BY date",
            arrayOf(year.toString())
        ).use { c -> while (c.moveToNext()) result.add(c.getString(0) to c.getString(1)) }
        return result
    }

    fun officialHolidayTitle(date: String): String? {
        readableDatabase.rawQuery("SELECT title FROM official_holidays WHERE date=?", arrayOf(date)).use { c ->
            return if (c.moveToFirst()) c.getString(0) else null
        }
    }

    fun calendarEventTitle(date: String): String? {
        readableDatabase.rawQuery("SELECT title FROM calendar_events WHERE date=?", arrayOf(date)).use { c ->
            return if (c.moveToFirst()) c.getString(0) else null
        }
    }

    fun displayHolidayTitle(date: String): String? {
        val titles = listOfNotNull(officialHolidayTitle(date), holidayTitle(date), calendarEventTitle(date))
            .flatMap { value -> value.split("،").map { title -> title.trim() } }
            .filter { it.isNotBlank() }.distinct()
        return titles.takeIf { it.isNotEmpty() }?.joinToString("، ")
    }

    /** One-time verified offline seed for 1405. User workdays and manual holidays stay untouched. */
    fun ensureBundled1405Calendar() {
        if (getSettingText("calendar_1405_seed", "") == "1405.1") return
        val storedHolidays = officialHolidays(1405)
        val storedEvents = calendarEvents(1405)
        // A complete remotely synchronized calendar already has more observances than the seed.
        if (storedHolidays.size < 20 || storedEvents.size < 100) {
            val verified = Calendar1405.holidays
            val titles = (storedEvents + Calendar1405.events + verified).groupBy({ it.first }, { it.second })
                .map { (date, list) -> date to list.distinct().joinToString("، ") }
            replaceCalendarData(1405, verified, titles)
        }
        setSettingText("calendar_1405_seed", "1405.1")
    }

    fun shouldSyncOfficialHolidays(year: Int, now: Long = System.currentTimeMillis()): Boolean {
        // Force a refresh of 1405 data if the previous app version saved a partial calendar
        // without the official Mab'ath holiday. This avoids the old 7-day cache hiding the fix.
        if (year == 1405 && officialHolidayTitle("1405-10-16").isNullOrBlank()) return true
        readableDatabase.rawQuery("SELECT synced_at FROM holiday_sync WHERE year=?", arrayOf(year.toString())).use { c ->
            if (!c.moveToFirst()) return true
            // Refresh at most once per week unless the user explicitly requests an update.
            return now - c.getLong(0) >= 7L * 24L * 60L * 60L * 1000L
        }
    }

    fun replaceOfficialHolidays(year: Int, holidays: List<Pair<String, String>>) {
        require(holidays.isNotEmpty()) { "فهرست تعطیلات خالی است؛ اطلاعات قبلی حفظ شد." }
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("official_holidays", "year=?", arrayOf(year.toString()))
            holidays.forEach { (date, title) ->
                val values = ContentValues().apply {
                    put("date", date); put("title", title); put("year", year)
                }
                db.insertWithOnConflict("official_holidays", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            val meta = ContentValues().apply { put("year", year); put("synced_at", System.currentTimeMillis()) }
            db.insertWithOnConflict("holiday_sync", null, meta, SQLiteDatabase.CONFLICT_REPLACE)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun calendarEvents(year: Int): List<Pair<String, String>> {
        val result = mutableListOf<Pair<String, String>>()
        readableDatabase.rawQuery("SELECT date,title FROM calendar_events WHERE year=? ORDER BY date", arrayOf(year.toString())).use { c ->
            while (c.moveToNext()) result.add(c.getString(0) to c.getString(1))
        }
        return result
    }

    fun replaceCalendarData(year: Int, holidays: List<Pair<String, String>>, events: List<Pair<String, String>>) {
        require(holidays.isNotEmpty()) { "فهرست تعطیلات خالی است؛ اطلاعات قبلی حفظ شد." }
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("official_holidays", "year=?", arrayOf(year.toString()))
            holidays.forEach { (date, title) ->
                val values = ContentValues().apply { put("date", date); put("title", title); put("year", year) }
                db.insertWithOnConflict("official_holidays", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.delete("calendar_events", "year=?", arrayOf(year.toString()))
            events.forEach { (date, title) ->
                val values = ContentValues().apply { put("date", date); put("title", title); put("year", year) }
                db.insertWithOnConflict("calendar_events", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            val meta = ContentValues().apply { put("year", year); put("synced_at", System.currentTimeMillis()) }
            db.insertWithOnConflict("holiday_sync", null, meta, SQLiteDatabase.CONFLICT_REPLACE)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun saveHoliday(date: String, title: String) {
        val v = ContentValues().apply { put("date", date); put("title", title) }
        writableDatabase.insertWithOnConflict("holidays", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun removeHoliday(date: String) { writableDatabase.delete("holidays", "date=?", arrayOf(date)) }
    fun allHolidays(): List<Pair<String,String>> {
        val out = mutableListOf<Pair<String,String>>()
        readableDatabase.rawQuery("SELECT date,title FROM holidays ORDER BY date", null).use { c -> while(c.moveToNext()) out.add(c.getString(0) to c.getString(1)) }
        return out
    }
    fun holidayTitle(date: String): String? {
        readableDatabase.rawQuery("SELECT title FROM holidays WHERE date=?", arrayOf(date)).use { c -> return if(c.moveToFirst()) c.getString(0) else null }
    }
    fun getSetting(key: String): Boolean {
        readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?", arrayOf(key)).use { c ->
            return c.moveToFirst() && c.getString(0) == "true"
        }
    }
    fun getSettingText(key: String, fallback: String = ""): String {
        readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?", arrayOf(key)).use { c ->
            return if (c.moveToFirst()) c.getString(0) else fallback
        }
    }
    fun setSettingText(key: String, value: String) {
        val v = ContentValues().apply { put("key",key); put("value",value) }
        writableDatabase.insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun setSetting(key: String, value: Boolean) {
        val v = ContentValues().apply { put("key",key); put("value",value.toString()) }
        writableDatabase.insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun allDaysForBackup(): List<WorkDay> {
        val result = mutableListOf<WorkDay>()
        readableDatabase.rawQuery("SELECT * FROM workdays ORDER BY date", null).use { c ->
            while(c.moveToNext()) result.add(WorkDay(
                c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "",
                c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "",
                c.getString(6) ?: "", c.getString(7) ?: "", c.getString(8) ?: "کاری",
                c.getString(9) ?: "", c.getInt(10) == 1, c.getString(11) ?: "", c.getString(12) ?: "", c.getString(13) ?: "", c.getString(14) ?: "",
                if (c.columnCount > 15) c.getString(15) ?: "" else "", if (c.columnCount > 16) c.getString(16) ?: "" else "",
                if (c.columnCount > 17) c.getString(17) ?: "" else "", if (c.columnCount > 18) c.getString(18) ?: "" else "",
                if (c.columnCount > 19) c.getString(19) ?: "" else "", if (c.columnCount > 20) c.getString(20) ?: "" else "",
                if (c.columnCount > 21) c.getInt(21) == 1 else listOf(17,18,19,20).any { i -> i < c.columnCount && !c.getString(i).isNullOrBlank() },
                if (c.columnCount > 22) c.getString(22) ?: "" else "",
                if (c.columnCount > 23) c.getString(23) ?: "" else "", if (c.columnCount > 24) c.getString(24) ?: "" else "",
                if (c.columnCount > 25) c.getString(25) ?: "" else "", if (c.columnCount > 26) c.getString(26) ?: "" else "",
                if (c.columnCount > 27) c.getString(27) ?: "شناور" else "شناور"
            ))
        }
        return result
    }
    fun allSettings(): List<Pair<String,String>> {
        val result = mutableListOf<Pair<String,String>>()
        readableDatabase.rawQuery("SELECT key,value FROM settings ORDER BY key", null).use { c ->
            while(c.moveToNext()) result.add(c.getString(0) to c.getString(1))
        }
        allHolidays().forEach { (date,title) -> result.add("holiday:$date" to title) }
        return result
    }
    fun restoreBackup(days: List<WorkDay>, settings: List<Pair<String,String>>) {
        writableDatabase.beginTransaction()
        try {
            writableDatabase.delete("workdays", null, null)
            writableDatabase.delete("holidays", null, null)
            days.forEach { d ->
                val v = ContentValues().apply {
                    put("date",d.date); put("in1",d.in1); put("out1",d.out1)
                    put("in2",d.in2); put("out2",d.out2); put("in3",d.in3); put("out3",d.out3)
                    put("note",d.note); put("day_type",d.dayType); put("overtime_override",d.overtimeOverride); put("shift_enabled", if(d.shiftEnabled) 1 else 0); put("shift_start",d.shiftStart); put("shift_end",d.shiftEnd); put("shift_start_date",d.shiftStartDate); put("shift_end_date",d.shiftEndDate)
                    put("holiday_in", d.holidayIn); put("holiday_out", d.holidayOut); put("leave1_start", d.leave1Start); put("leave1_end", d.leave1End); put("leave2_start", d.leave2Start); put("leave2_end", d.leave2End); put("leave_enabled", 1); put("extra_day_types", d.extraDayTypes); put("leave3_start", d.leave3Start); put("leave3_end", d.leave3End); put("holiday_in2", d.holidayIn2); put("holiday_out2", d.holidayOut2); put("schedule_mode", d.scheduleMode)
                }
                writableDatabase.insertWithOnConflict("workdays",null,v,SQLiteDatabase.CONFLICT_REPLACE)
            }
            settings.forEach { (k,v) ->
                if (k.startsWith("holiday:")) {
                    val cv = ContentValues().apply { put("date",k.removePrefix("holiday:")); put("title",v) }
                    writableDatabase.insertWithOnConflict("holidays",null,cv,SQLiteDatabase.CONFLICT_REPLACE)
                } else if (!k.startsWith("continuousleave:")) {
                    val cv = ContentValues().apply { put("key",k); put("value",v) }
                    writableDatabase.insertWithOnConflict("settings",null,cv,SQLiteDatabase.CONFLICT_REPLACE)
                }
            }
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }
}

private data class DownloadedCalendarData(
    val holidays: List<Pair<String, String>>,
    val events: List<Pair<String, String>>
)

private fun fetchJson(url: String): org.json.JSONObject {
    val connection = java.net.URL(url).openConnection() as java.net.HttpURLConnection
    connection.requestMethod = "GET"
    connection.connectTimeout = 12_000
    connection.readTimeout = 18_000
    connection.setRequestProperty("Accept", "application/json")
    connection.setRequestProperty("User-Agent", "Morakh/0.30")
    try {
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        if (code !in 200..299) throw IllegalStateException("پاسخ سرویس تقویم: HTTP $code")
        return org.json.JSONObject(body)
    } finally { connection.disconnect() }
}

private fun fetchFarsiUiCalendarData(year: Int): DownloadedCalendarData? {
    // This source has an explicit, stable schema: items[].date, items[].title.fa,
    // and items[].isHoliday. It is the primary source to avoid schema drift in the
    // older Persian-Calendar API response.
    val base = "https://raw.githubusercontent.com/MiladJoodi/FarsiUI/main/calendar/years/$year"
    val holidayRoot = fetchJson("$base/holidays.json")
    if (holidayRoot.has("year") && holidayRoot.optInt("year", -1) != year) return null
    val holidayItems = holidayRoot.optJSONArray("items") ?: return null
    if (holidayItems.length() == 0) return null

    val holidays = linkedMapOf<String, MutableList<String>>()
    val allEvents = linkedMapOf<String, MutableList<String>>()
    fun add(target: MutableMap<String, MutableList<String>>, date: String, title: String) {
        val clean = title.trim()
        if (clean.isNotBlank()) {
            val list = target.getOrPut(date) { mutableListOf() }
            if (clean !in list) list.add(clean)
        }
    }
    fun parseItems(items: org.json.JSONArray, holidayOnly: Boolean) {
        for (i in 0 until items.length()) {
            val item = items.optJSONObject(i) ?: continue
            val date = item.optString("date")
            val parts = date.split("-").mapNotNull { it.toIntOrNull() }
            if (parts.size != 3 || parts[0] != year || parts[1] !in 1..12 || parts[2] !in 1..jalaliMonthLength(year, parts[1])) continue
            val titleObject = item.optJSONObject("title")
            val title = titleObject?.optString("fa").orEmpty().ifBlank { item.optString("title_fa") }
            if (title.isBlank()) continue
            if (!holidayOnly || item.optBoolean("isHoliday", item.optBoolean("is_holiday", false))) {
                if (item.optBoolean("isHoliday", item.optBoolean("is_holiday", false))) add(holidays, date, title)
            }
            add(allEvents, date, title)
        }
    }
    parseItems(holidayItems, holidayOnly = true)
    // Events file contains non-holiday observances, including non-holiday religious dates.
    val eventRoot = fetchJson("$base/events.json")
    if (eventRoot.has("year") && eventRoot.optInt("year", -1) != year) return null
    val eventItems = eventRoot.optJSONArray("items") ?: return null
    if (eventItems.length() == 0) return null
    parseItems(eventItems, holidayOnly = false)

    val holidayList = holidays.map { it.key to it.value.joinToString("، ") }
    val eventList = allEvents.map { it.key to it.value.joinToString("، ") }
    if (holidayList.isEmpty() || eventList.isEmpty()) return null
    return DownloadedCalendarData(holidayList, eventList)
}

private fun fetchCalendarData(year: Int): DownloadedCalendarData {
    require(year in 1347..1500) { "سال باید بین ۱۳۴۷ و ۱۵۰۰ باشد." }
    try {
        fetchFarsiUiCalendarData(year)?.let { return it }
    } catch (_: Exception) {
        // Use the documented Persian-Calendar API below as a fallback if this year
        // has not been published by FarsiUI or the static source is temporarily down.
    }
    val holidayRoot = try {
        fetchJson("https://www.persian-calendar.com/api/holidays?year=$year")
    } catch (e: Exception) {
        // No guessed lunar public holidays: preserve the previously saved calendar.
        throw e
    }
    if (holidayRoot.has("year") && holidayRoot.optInt("year", -1) != year) throw IllegalStateException("سال دریافت‌شده با سال درخواستی یکسان نیست.")
    val holidayDays = holidayRoot.optJSONArray("data") ?: throw IllegalStateException("فهرست تعطیلات معتبر نیست.")
    val holidays = linkedMapOf<String, MutableList<String>>()
    val allEvents = linkedMapOf<String, MutableList<String>>()

    fun addTitle(target: MutableMap<String, MutableList<String>>, date: String, title: String) {
        val cleaned = title.trim()
        if (cleaned.isNotBlank()) {
            val list = target.getOrPut(date) { mutableListOf() }
            if (cleaned !in list) list.add(cleaned)
        }
    }

    // The holidays endpoint is authoritative for days off and also supplies each holiday's title.
    for (i in 0 until holidayDays.length()) {
        val item = holidayDays.optJSONObject(i) ?: continue
        val month = item.optInt("month_sh", 0)
        val day = item.optInt("day_sh", 0)
        if (item.optInt("year_sh", year) != year || month !in 1..12 || day !in 1..jalaliMonthLength(year, month)) continue
        val date = "%04d-%02d-%02d".format(Locale.ROOT, year, month, day)
        val events = item.optJSONArray("events") ?: continue
        for (j in 0 until events.length()) {
            val event = events.optJSONObject(j) ?: continue
            val title = event.optString("title_fa").trim()
            if (event.optBoolean("is_holiday", false)) addTitle(holidays, date, title)
            // Put official holidays in the event list too, so their title is visible in every calendar view.
            addTitle(allEvents, date, title)
        }
    }

    // Fetch all other occasions month by month. A failed month must not discard the verified holiday list.
    for (month in 1..12) {
        try {
            val root = fetchJson("https://www.persian-calendar.com/api/events?year=$year&month_sh=$month")
            if (root.optInt("year", year) != year) continue
            val days = root.optJSONArray("data") ?: continue
            for (i in 0 until days.length()) {
                val item = days.optJSONObject(i) ?: continue
                val m = item.optInt("month_sh", month)
                val d = item.optInt("day_sh", 0)
                if (item.optInt("year_sh", year) != year || m !in 1..12 || d !in 1..jalaliMonthLength(year, m)) continue
                val date = "%04d-%02d-%02d".format(Locale.ROOT, year, m, d)
                // Current API returns one event per item; also accept nested event arrays for compatibility.
                val title = item.optString("title_fa").trim()
                if (title.isNotBlank()) addTitle(allEvents, date, title)
                val nested = item.optJSONArray("events")
                if (nested != null) for (j in 0 until nested.length()) {
                    val event = nested.optJSONObject(j) ?: continue
                    addTitle(allEvents, date, event.optString("title_fa"))
                    if (event.optBoolean("is_holiday", false)) addTitle(holidays, date, event.optString("title_fa"))
                }
            }
        } catch (_: Exception) {
            // Continue; official holiday data is still usable offline even if this month's occasions endpoint fails.
        }
    }

    // Do not mix calculated Hijri dates into an official holiday list. Iran's
    // announced lunar holiday dates can differ by a day from civil calculations.
    val holidayList = holidays.map { it.key to it.value.distinct().joinToString("، ") }
    val eventList = allEvents.map { it.key to it.value.distinct().joinToString("، ") }
    if (holidayList.isEmpty()) throw IllegalStateException("سرویس تعطیلات معتبری برنگرداند؛ اطلاعات قبلی حفظ شد.")
    if (eventList.isEmpty()) throw IllegalStateException("فهرست مناسبت‌ها خالی است؛ اطلاعات قبلی حفظ شد.")
    return DownloadedCalendarData(holidayList, eventList)
}

class MainActivity : ComponentActivity() {
    private lateinit var appDb: WorkDb
    private var systemDate by mutableStateOf(LocalDate.now())
    private var pendingBackup = false
    private var reportYear = 1405
    private var reportMonth = 1
    private var reportAnnual = false
    private var reportPdf = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        // Keep Android system status icons (time, signal, battery) visible.
        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN)
        // Splash image and Android system bars share a white background.
        window.statusBarColor = android.graphics.Color.WHITE
        window.navigationBarColor = android.graphics.Color.WHITE
        // Dark system icons remain visible against the white splash background.
        window.decorView.systemUiVisibility =
            (window.decorView.systemUiVisibility and android.view.View.SYSTEM_UI_FLAG_FULLSCREEN.inv()) or
                android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val db = WorkDb(this)
        db.ensureBundled1405Calendar()
        appDb = db
        // Refresh enabled reminders and the optional date notification on every launch.
        CompanionAlerts.refresh(this)
        systemDate = LocalDate.now()
        setContent {
            var showIntro by remember { mutableStateOf(true) }
            LaunchedEffect(Unit) {
                kotlinx.coroutines.delay(1000)
                showIntro = false
            }
            LaunchedEffect(showIntro) {
                val bars = if (showIntro) android.graphics.Color.WHITE else android.graphics.Color.WHITE
                window.statusBarColor = bars
                window.navigationBarColor = bars
                window.decorView.systemUiVisibility =
                    window.decorView.systemUiVisibility or android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
            if (showIntro) {
                BoxWithConstraints(
                    modifier = Modifier.fillMaxSize().background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    val imageSide = minOf(maxWidth * 0.75f, maxHeight * 0.58f)
                    Column(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.splash_vaghtnegar),
                            contentDescription = "نشان مورخ",
                            modifier = Modifier.size(imageSide),
                            contentScale = ContentScale.Fit
                        )
                        Spacer(Modifier.height(4.dp))
                        PersianText("مورخ", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00B7C8))
                        PersianText("تقویم و مدیریت کارکرد", fontSize = 13.sp, color = Color(0xFF008FA0))
                    }
                }
            } else {
                KarkardApp(db, systemDate)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh the phone's local date whenever the app returns to the foreground.
        systemDate = LocalDate.now()
        CompanionAlerts.refresh(this)
        // Do not download prayer times automatically. Network refresh is intentionally
        // user-initiated via the dedicated "دریافت تازهٔ شهرها و اوقات شرعی" button.
    }

    fun selectAlertSound(prayer: Boolean, fileAudio: Boolean = false) {
        if (fileAudio) {
            val fileIntent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "audio/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(fileIntent,if(prayer) 5302 else 5301)
            return
        }
        val intent = Intent(android.media.RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TYPE, android.media.RingtoneManager.TYPE_ALL)
            putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
            putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TITLE, if(prayer) "صدای اذان" else "صدای یادآور")
            val selected = CompanionAlerts.ringtone(this@MainActivity,prayer)
            if(selected.isNotBlank()) putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,android.net.Uri.parse(selected))
        }
        startActivityForResult(intent,if(prayer) 5202 else 5201)
    }

    fun createExcelBackup() {
        pendingBackup = true
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            putExtra(Intent.EXTRA_TITLE, "پشتیبان_دفتر_کارکرد.xlsx")
        }
        startActivityForResult(intent, 4101)
    }
    private var reportIncludeNotes: Boolean = true
    private var reportSummaryOnly: Boolean = false
    fun createReportExcel(year: Int, month: Int, annual: Boolean, includeNotes: Boolean = true, summaryOnly: Boolean = false) {
        reportIncludeNotes = includeNotes
        reportSummaryOnly = summaryOnly && annual
        reportYear = year; reportMonth = month; reportAnnual = annual; reportPdf = false
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            putExtra(Intent.EXTRA_TITLE, if (reportSummaryOnly) "مورخ_خلاصه_جامع_سال_$year.xlsx" else if (annual) "مورخ_گزارش_سالانه_$year.xlsx" else "مورخ_گزارش_ماهانه_${year}_$month.xlsx")
        }
        startActivityForResult(intent, 4103)
    }
    fun createReportPdf(year: Int, month: Int, annual: Boolean, includeNotes: Boolean = true, summaryOnly: Boolean = false) {
        reportIncludeNotes = includeNotes
        reportSummaryOnly = summaryOnly && annual
        reportYear = year; reportMonth = month; reportAnnual = annual; reportPdf = true
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"
            putExtra(Intent.EXTRA_TITLE, if (reportSummaryOnly) "مورخ_خلاصه_جامع_سال_$year.pdf" else if (annual) "مورخ_گزارش_سالانه_$year.pdf" else "مورخ_گزارش_ماهانه_${year}_$month.pdf")
        }
        startActivityForResult(intent, 4104)
    }
    fun chooseExcelRestore() {
        pendingBackup = false
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        }
        startActivityForResult(intent, 4102)
    }
    fun createCsvBackup() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "پشتیبان_مورخ.csv")
        }
        startActivityForResult(intent, 4105)
    }
    fun chooseCsvRestore() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/*"
        }
        startActivityForResult(intent, 4106)
    }
    @Deprecated("Deprecated Android callback kept for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        if (requestCode == 5301 || requestCode == 5302) {
            data?.data?.let { audioUri ->
                try { contentResolver.takePersistableUriPermission(audioUri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                if (requestCode == 5302) {
                    AdhanSelection.setPending(this, audioUri.toString())
                    android.widget.Toast.makeText(this,"فایل اذان آمادهٔ پیش‌شنیدن و انتخاب است؛ صفحهٔ اذان را باز کن",android.widget.Toast.LENGTH_LONG).show()
                } else {
                    CompanionAlerts.saveRingtone(this,false,audioUri.toString())
                    android.widget.Toast.makeText(this,"آهنگ یادآور ذخیره شد",android.widget.Toast.LENGTH_SHORT).show()
                }
            }
            return
        }
        if (requestCode == 5201 || requestCode == 5202) {
            val ringtone = if (android.os.Build.VERSION.SDK_INT >= 33)
                data?.getParcelableExtra(android.media.RingtoneManager.EXTRA_RINGTONE_PICKED_URI,android.net.Uri::class.java)
            else data?.getParcelableExtra<android.net.Uri>(android.media.RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            ringtone?.let {
                CompanionAlerts.saveRingtone(this,requestCode == 5202,it.toString())
                android.widget.Toast.makeText(this,"صدای انتخاب‌شده ذخیره شد",android.widget.Toast.LENGTH_SHORT).show()
            }
            return
        }
        if (data?.data == null) return
        val uri = data.data!!
        try {
            if (requestCode == 4101) {
                contentResolver.openOutputStream(uri)?.use { it.write(buildBackupXlsx(appDb)) }
                android.widget.Toast.makeText(this, "فایل Excel پشتیبان ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
            } else if (requestCode == 4105) {
                contentResolver.openOutputStream(uri)?.use { it.write(buildBackupCsv(appDb).toByteArray(Charsets.UTF_8)) }
                android.widget.Toast.makeText(this, "فایل CSV پشتیبان ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
            } else if (requestCode == 4103) {
                contentResolver.openOutputStream(uri)?.use { it.write(buildReportXlsx(appDb, reportYear, reportMonth, reportAnnual, reportIncludeNotes, reportSummaryOnly)) }
                android.widget.Toast.makeText(this, "گزارش Excel ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
            } else if (requestCode == 4104) {
                contentResolver.openOutputStream(uri)?.use { it.write(buildReportPdf(appDb, reportYear, reportMonth, reportAnnual, reportIncludeNotes, reportSummaryOnly)) }
                android.widget.Toast.makeText(this, "گزارش PDF ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
            } else if (requestCode == 4102 || requestCode == 4106) {
                val input = contentResolver.openInputStream(uri) ?: error("فایل خوانده نشد")
                val restored = input.use { stream -> if (requestCode == 4106) readBackupCsv(stream.readBytes().toString(Charsets.UTF_8)) else readBackupXlsx(stream.readBytes()) }
                val isReport = restored.second.any { it.first == "export_format" && it.second == "period_report_v1" }
                android.app.AlertDialog.Builder(this)
                    .setTitle(if(isReport) "ورود اطلاعات گزارش" else "بازیابی پشتیبان")
                    .setMessage(if(isReport) "فقط روزهای ثبت‌شدهٔ همین گزارش با داده‌های موجود ادغام می‌شوند؛ سایر ماه‌ها پاک نمی‌شوند. ادامه؟" else "با ادامه، اطلاعات فعلی جایگزین می‌شود. ادامه می‌دهید؟")
                    .setNegativeButton("انصراف", null)
                    .setPositiveButton("بازیابی") { _, _ ->
                        if(isReport) restored.first.forEach { appDb.saveDay(it) }
                        else appDb.restoreBackup(restored.first, restored.second)
                        android.widget.Toast.makeText(this, "بازیابی انجام شد؛ صفحه را دوباره باز کنید", android.widget.Toast.LENGTH_LONG).show()
                    }.show()
            }
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, "خطا در فایل پشتیبان: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
        }
    }
}

private fun formatTimeInput(raw: String): String {
    val digits = raw.toLatinDigits().filter { it.isDigit() }.take(4)
    return when (digits.length) {
        0, 1 -> digits
        2 -> digits
        else -> digits.substring(0, 2) + ":" + digits.substring(2)
    }
}

private fun mins(time: String): Int? {
    val p = time.trim().split(":")
    if (p.size != 2) return null
    val h = p[0].toIntOrNull() ?: return null
    val m = p[1].toIntOrNull() ?: return null
    if (h !in 0..23 || m !in 0..59) return null
    return h*60+m
}
private fun timeRangeMinutes(startText: String, endText: String): Int {
    val start = mins(startText) ?: return 0
    val end = mins(endText) ?: return 0
    return if (end >= start) end - start else end + 24 * 60 - start
}
private data class MinuteInterval(val start: Int, val end: Int)

private fun dailyRequiredMinutes(day: WorkDay, db: WorkDb): Int {
    if (normalizedDayCategory(day) != "کاری" || normalizedAttendance(day) in workLeaveStatuses) return 0
    val weekday = jalaliWeekday(day.date) ?: return 0
    if (weekday == 5) return 0 // Friday
    return if (day.scheduleMode == "ثابت") {
        val startKey = if (weekday == 4) "fixed_thursday_start" else "fixed_weekday_start"
        val endKey = if (weekday == 4) "fixed_thursday_end" else "fixed_weekday_end"
        timeRangeMinutes(db.getSettingText(startKey, if (weekday == 4) "07:00" else "07:00"),
            db.getSettingText(endKey, if (weekday == 4) "12:00" else "14:00"))
    } else {
        val key = if (weekday == 4) "thursday_hours_value" else "workday_hours"
        mins(db.getSettingText(key, if (weekday == 4) "05:00" else "07:00")) ?: if (weekday == 4) 300 else 420
    }
}

private fun rawHourlyLeaveIntervals(day: WorkDay): List<MinuteInterval> = listOf(
    day.leave1Start to day.leave1End,
    day.leave2Start to day.leave2End,
    day.leave3Start to day.leave3End
).mapNotNull { (startText, endText) ->
    val start = mins(startText) ?: return@mapNotNull null
    val endRaw = mins(endText) ?: return@mapNotNull null
    if (startText.isBlank() || endText.isBlank()) return@mapNotNull null
    if (endRaw == start) return@mapNotNull null
    val end = if (endRaw < start) endRaw + 1440 else endRaw
    MinuteInterval(start, end)
}

private fun fixedScheduleWindow(day: WorkDay, db: WorkDb): MinuteInterval? {
    val weekday = jalaliWeekday(day.date) ?: return null
    if (weekday == 5 || normalizedDayCategory(day) != "کاری") return null
    val startKey = if (weekday == 4) "fixed_thursday_start" else "fixed_weekday_start"
    val endKey = if (weekday == 4) "fixed_thursday_end" else "fixed_weekday_end"
    val start = mins(db.getSettingText(startKey, "07:00")) ?: return null
    val endRaw = mins(db.getSettingText(endKey, if (weekday == 4) "12:00" else "14:00")) ?: return null
    return MinuteInterval(start, if (endRaw <= start) endRaw + 1440 else endRaw)
}

private fun hourlyLeaveMinutes(day: WorkDay, db: WorkDb? = null): Int {
    val intervals = rawHourlyLeaveIntervals(day)
    if (intervals.isEmpty()) return 0
    val valid = if (day.scheduleMode == "ثابت" && db != null) {
        val window = fixedScheduleWindow(day, db) ?: return 0
        intervals.filter { interval ->
            val shift = fixedWindowShift(interval, window)
            val adjustedStart = interval.start + shift
            val adjustedEnd = interval.end + shift
            adjustedStart >= window.start && adjustedEnd <= window.end && adjustedEnd > adjustedStart
        }.map { interval ->
            val shift = fixedWindowShift(interval, window)
            MinuteInterval(interval.start + shift, interval.end + shift)
        }
    } else intervals
    // Union intervals so overlapping leave entries are never deducted twice.
    val sorted = valid.sortedBy { it.start }
    var total = 0
    var currentStart: Int? = null
    var currentEnd = 0
    sorted.forEach { interval ->
        if (currentStart == null) {
            currentStart = interval.start; currentEnd = interval.end
        } else if (interval.start <= currentEnd) {
            currentEnd = maxOf(currentEnd, interval.end)
        } else {
            total += (currentEnd - currentStart!!).coerceAtLeast(0)
            currentStart = interval.start; currentEnd = interval.end
        }
    }
    if (currentStart != null) total += (currentEnd - currentStart!!).coerceAtLeast(0)
    return total
}

/** Gross attendance before hourly leave is deducted. */
private fun grossAttendanceMinutes(day: WorkDay): Int = listOf(
    day.in1 to day.out1, day.in2 to day.out2, day.in3 to day.out3
).sumOf { (startText, endText) ->
    val start = mins(startText)
    val end = mins(endText)
    if (start != null && end != null) {
        if (end >= start) end - start else end + 24 * 60 - start
    } else 0
}

/** Floating-mode overtime before applying hourly leave. */
private fun rawFloatingOvertimeMinutes(day: WorkDay, db: WorkDb): Int {
    if (day.scheduleMode == "ثابت" || isHolidayWorkDay(day) || !hasDayStatus(day, "کاری")) return 0
    val override = mins(day.overtimeOverride)
    if (override != null) return override
    return (grossAttendanceMinutes(day) - dailyRequiredMinutes(day, db)).coerceAtLeast(0)
}

private fun isFloatingWorkDayForLeavePool(day: WorkDay): Boolean =
    day.scheduleMode != "ثابت" && !isHolidayWorkDay(day) && hasDayStatus(day, "کاری")

/** The part of a floating day's hourly leave that passes that day's own overtime. */
private fun floatingUnderworkMinutes(day: WorkDay, db: WorkDb): Int =
    if (!isFloatingWorkDayForLeavePool(day)) 0
    else (hourlyLeaveMinutes(day, db) - rawFloatingOvertimeMinutes(day, db)).coerceAtLeast(0)

private fun periodFloatingUnderworkMinutes(days: List<WorkDay>, db: WorkDb): Int =
    days.sumOf { floatingUnderworkMinutes(it, db) }

/** Fixed-mode overtime stays isolated; floating leave can offset only floating overtime in the same month. */
private fun monthlyOvertimeMinutes(days: List<WorkDay>, db: WorkDb): Int {
    val fixedAndHolidayOvertime = days.filter { it.scheduleMode == "ثابت" || isHolidayWorkDay(it) || !hasDayStatus(it, "کاری") }
        .sumOf { overtimeMinutes(it, db) }
    val floatingDays = days.filter { isFloatingWorkDayForLeavePool(it) }
    val floatingBaseOvertime = floatingDays.sumOf { rawFloatingOvertimeMinutes(it, db) }
    val floatingLeave = floatingDays.sumOf { hourlyLeaveMinutes(it, db) }
    return fixedAndHolidayOvertime + (floatingBaseOvertime - floatingLeave).coerceAtLeast(0)
}

/** Fixed-mode leave counts in full; floating leave counts only when it exceeds the total floating overtime pool for the month. */
private fun monthlyEffectiveHourlyLeaveMinutes(days: List<WorkDay>, db: WorkDb): Int {
    val fixedLeave = days.filter { it.scheduleMode == "ثابت" }.sumOf { hourlyLeaveMinutes(it, db) }
    val floatingDays = days.filter { isFloatingWorkDayForLeavePool(it) }
    val floatingLeave = floatingDays.sumOf { hourlyLeaveMinutes(it, db) }
    val floatingBaseOvertime = floatingDays.sumOf { rawFloatingOvertimeMinutes(it, db) }
    return fixedLeave + (floatingLeave - floatingBaseOvertime).coerceAtLeast(0)
}

/** Annual totals are accumulated month by month; one month cannot use another month's overtime allowance. */
private fun periodOvertimeMinutes(days: List<WorkDay>, db: WorkDb): Int =
    days.groupBy { it.date.take(7) }.values.sumOf { monthlyOvertimeMinutes(it, db) }

private fun periodEffectiveHourlyLeaveMinutes(days: List<WorkDay>, db: WorkDb): Int =
    days.groupBy { it.date.take(7) }.values.sumOf { monthlyEffectiveHourlyLeaveMinutes(it, db) }

private fun floatingUnderworkReminder(days: List<WorkDay>, db: WorkDb): String {
    // Keep every monthly overtime pool isolated, including when this helper is
    // used by an annual report. A month must never consume another month's OT.
    val monthGroups = days.groupBy { it.date.take(7) }.values
    val underwork = monthGroups.sumOf { monthDays ->
        monthDays.sumOf { floatingUnderworkMinutes(it, db) }
    }
    if (underwork <= 0) return ""
    val uncovered = monthGroups.sumOf { monthDays ->
        val floatingDays = monthDays.filter { isFloatingWorkDayForLeavePool(it) }
        val floatingLeave = floatingDays.sumOf { hourlyLeaveMinutes(it, db) }
        val floatingBaseOvertime = floatingDays.sumOf { rawFloatingOvertimeMinutes(it, db) }
        (floatingLeave - floatingBaseOvertime).coerceAtLeast(0)
    }
    val remainderNote = if (uncovered > 0) {
        " مازاد پوشش‌داده‌نشده ${hm(uncovered)} به مرخصی ساعتی مؤثر ماه افزوده شد."
    } else " تمام کم‌کاری با اضافه‌کاری شناور همان ماه پوشش داده شد."
    return "یادآوری: ${hm(underwork)} کم‌کاری ناشی از مرخصی ساعتی روزهای شناور از اضافه‌کاری شناور همان ماه کسر شد.$remainderNote اضافه‌کاری روزهای ثابت و مانده ماه‌های دیگر مستقل باقی ماند."
}

private fun fixedWindowShift(interval: MinuteInterval, window: MinuteInterval): Int {
    // For an overnight fixed schedule (for example 22:00–06:00), an entry
    // whose clock time falls in the morning portion belongs to the next day.
    val morningWindowEnd = window.end - 1440
    return if (morningWindowEnd > 0 && interval.start < morningWindowEnd) 1440 else 0
}

private fun mergeMinuteIntervals(intervals: List<MinuteInterval>): List<MinuteInterval> {
    val sorted = intervals.filter { it.end > it.start }.sortedBy { it.start }
    if (sorted.isEmpty()) return emptyList()
    val merged = mutableListOf<MinuteInterval>()
    var start = sorted.first().start
    var end = sorted.first().end
    sorted.drop(1).forEach { interval ->
        if (interval.start <= end) end = maxOf(end, interval.end)
        else {
            merged += MinuteInterval(start, end)
            start = interval.start
            end = interval.end
        }
    }
    merged += MinuteInterval(start, end)
    return merged
}

private fun attendanceIntervals(day: WorkDay): List<MinuteInterval> = listOf(
    day.in1 to day.out1, day.in2 to day.out2, day.in3 to day.out3
).mapNotNull { (startText, endText) ->
    val start = mins(startText) ?: return@mapNotNull null
    val endRaw = mins(endText) ?: return@mapNotNull null
    if (startText.isBlank() || endText.isBlank() || endRaw == start) return@mapNotNull null
    MinuteInterval(start, if (endRaw < start) endRaw + 1440 else endRaw)
}

private data class FixedAttendanceSplit(val totalMinutes: Int, val insideScheduleMinutes: Int)

private fun fixedAttendanceSplit(day: WorkDay, db: WorkDb): FixedAttendanceSplit? {
    val window = fixedScheduleWindow(day, db) ?: return null
    val intervals = mergeMinuteIntervals(attendanceIntervals(day))
    val aligned = mergeMinuteIntervals(intervals.map { interval ->
        val shift = fixedWindowShift(interval, window)
        MinuteInterval(interval.start + shift, interval.end + shift)
    })
    val total = aligned.sumOf { it.end - it.start }
    val inside = aligned.sumOf { interval ->
        (minOf(interval.end, window.end) - maxOf(interval.start, window.start)).coerceAtLeast(0)
    }
    return FixedAttendanceSplit(total, inside)
}

private fun hasInvalidFixedLeave(day: WorkDay, db: WorkDb): Boolean {
    if (day.scheduleMode != "ثابت") return false
    val window = fixedScheduleWindow(day, db) ?: return rawHourlyLeaveIntervals(day).isNotEmpty()
    return rawHourlyLeaveIntervals(day).any { interval ->
        val shift = fixedWindowShift(interval, window)
        val start = interval.start + shift
        val end = interval.end + shift
        start < window.start || end > window.end || end <= start
    }
}

private fun duration(day: WorkDay, db: WorkDb? = null): Int {
    if (dayStatuses(day).isEmpty()) return 0
    if (isHolidayWorkDay(day)) return 0
    val gross = listOf(day.in1 to day.out1, day.in2 to day.out2, day.in3 to day.out3).sumOf { (a,b) ->
        val start = mins(a); val end = mins(b)
        if (start != null && end != null) { if (end >= start) end - start else (end + 24 * 60) - start } else 0
    }
    return (gross - hourlyLeaveMinutes(day, db)).coerceAtLeast(0)
}

private fun registeredMandatoryMinutes(day: WorkDay, db: WorkDb): Int {
    if (isHolidayWorkDay(day) || !hasDayStatus(day, "کاری")) return 0
    val required = dailyRequiredMinutes(day, db)
    val eligibleAttendance = if (day.scheduleMode == "ثابت") {
        val split = fixedAttendanceSplit(day, db) ?: return 0
        (split.insideScheduleMinutes - hourlyLeaveMinutes(day, db)).coerceAtLeast(0)
    } else duration(day, db)
    return minOf(eligibleAttendance, required)
}

private fun remainingMandatoryMinutes(day: WorkDay, db: WorkDb): Int =
    if (hasDayStatus(day, "استحقاقی") || hasDayStatus(day, "استعلاجی") || isHolidayWorkDay(day)) 0
    else (dailyRequiredMinutes(day, db) - registeredMandatoryMinutes(day, db)).coerceAtLeast(0)

private fun periodRequiredMinutes(days: List<WorkDay>, db: WorkDb): Int = days.sumOf { dailyRequiredMinutes(it, db) }
private fun periodRegisteredMinutes(days: List<WorkDay>, db: WorkDb): Int = days.sumOf { registeredMandatoryMinutes(it, db) }
private fun hourlyLeaveCreditDays(days: List<WorkDay>, db: WorkDb): Int {
    // Apply the 8-hour threshold to the effective hourly leave for this month.
    val effectiveLeave = monthlyEffectiveHourlyLeaveMinutes(days, db)
    val excess = (effectiveLeave - 8 * 60).coerceAtLeast(0)
    return if (excess == 0) 0 else (excess + 8 * 60 - 1) / (8 * 60)
}
private fun hourlyLeaveCreditReminder(days: List<WorkDay>, db: WorkDb): String {
    val credit = hourlyLeaveCreditDays(days, db)
    return if (credit == 0) "" else "یادآوری: به دلیل عبور مرخصی ساعتی از سقف ۸ ساعت، $credit روز به مرخصی استحقاقی این دوره افزوده شد."
}

private fun normalizeDateInput(raw: String): String {
    val digits = raw.toLatinDigits().filter { it.isDigit() }.take(8)
    return when {
        digits.length <= 4 -> digits
        digits.length <= 6 -> digits.take(4) + "-" + digits.drop(4)
        else -> digits.take(4) + "-" + digits.substring(4, 6) + "-" + digits.drop(6)
    }
}

private fun parsedJalaliDate(value: String): LocalDate? {
    val parts = value.replace('/', '-').split("-").mapNotNull { it.toIntOrNull() }
    if (parts.size != 3 || !isValidJalali(parts[0], parts[1], parts[2])) return null
    return jalaliToGregorian(parts[0], parts[1], parts[2])
}

private fun jalaliDateString(date: LocalDate): String {
    val (y, m, d) = gregorianToJalali(date)
    return "%04d-%02d-%02d".format(Locale.ROOT, y, m, d)
}

private fun defaultShiftEndDate(startDate: String, startTime: String, endTime: String): String {
    val start = parsedJalaliDate(startDate) ?: return startDate
    val startMinutes = mins(startTime)
    val endMinutes = mins(endTime)
    val endDate = if (startMinutes != null && endMinutes != null && endMinutes <= startMinutes) start.plusDays(1) else start
    return jalaliDateString(endDate)
}

private fun shiftDurationMinutes(day: WorkDay, fallbackDate: String = day.date): Int {
    if (!day.shiftEnabled) return 0

    val startDateText = day.shiftStartDate.ifBlank { fallbackDate }
    val endDateText = day.shiftEndDate.ifBlank {
        defaultShiftEndDate(startDateText, day.shiftStart, day.shiftEnd)
    }
    val startDate = parsedJalaliDate(startDateText) ?: return 0
    var endDate = parsedJalaliDate(endDateText) ?: return 0
    val startMinutes = mins(day.shiftStart) ?: return 0
    val endMinutes = mins(day.shiftEnd) ?: return 0

    // If both dates are the same but the entered end time is earlier (or equal),
    // treat the shift as crossing midnight. Explicit end dates on a later day
    // are respected as entered.
    if (endDate == startDate && endMinutes <= startMinutes) {
        endDate = startDate.plusDays(1)
    }
    if (endDate.isBefore(startDate)) return 0

    val total = (endDate.toEpochDay() - startDate.toEpochDay()) * 1440L +
        endMinutes.toLong() - startMinutes.toLong()
    return total.coerceIn(0L, 31L * 1440L).toInt()
}
private fun hm(n: Int) = "%02d:%02d".format(Locale.ROOT, n/60, n%60)

private fun jalaliWeekday(date: String): Int? {
    val p = date.split("-").mapNotNull { it.toIntOrNull() }
    if (p.size != 3 || !isValidJalali(p[0],p[1],p[2])) return null
    return jalaliToGregorian(p[0],p[1],p[2]).dayOfWeek.value % 7
    // Java Sunday=0, Saturday=6
}
private fun officialJalaliHolidays(year: Int): List<Pair<String,String>> {
    val fixed = mutableListOf<Triple<Int,Int,String>>()
    for (d in 1..4) fixed.add(Triple(1, d, "تعطیل رسمی نوروز"))
    fixed.add(Triple(1, 12, "روز جمهوری اسلامی"))
    fixed.add(Triple(1, 13, "روز طبیعت"))
    fixed.add(Triple(3, 14, "رحلت امام خمینی"))
    fixed.add(Triple(3, 15, "قیام ۱۵ خرداد"))
    fixed.add(Triple(11, 22, "پیروزی انقلاب اسلامی"))
    fixed.add(Triple(12, 29, "روز ملی شدن صنعت نفت"))
    return fixed.map { (m,d,title) -> "%04d-%02d-%02d".format(year,m,d) to title }
}

private fun defaultDayType(date: String): String =
    if (jalaliWeekday(date) == 5) "تعطیل رسمی" else "کاری"

private fun isOfficialCalendarHoliday(date: String, db: WorkDb): Boolean =
    db.officialHolidayTitle(date) != null ||
        officialJalaliHolidays(date.take(4).toIntOrNull() ?: 0).any { it.first == date }

private fun freshWorkDay(date: String, db: WorkDb): WorkDay = applyCalendarHoliday(
    WorkDay(
        date = date,
        dayType = defaultDayType(date),
        scheduleMode = db.getSettingText("work_schedule_mode", "شناور").ifBlank { "شناور" }
    ), db
)

private fun applyCalendarHoliday(day: WorkDay, db: WorkDb): WorkDay {
    val fixedHoliday = officialJalaliHolidays(day.date.take(4).toIntOrNull() ?: 0).toMap()[day.date]
    val officialTitle = db.officialHolidayTitle(day.date) ?: fixedHoliday
    return when {
        !officialTitle.isNullOrBlank() -> {
            val attendance = normalizedAttendance(day).takeIf { it.isNotBlank() && it != "عادی" }.orEmpty()
            day.copy(dayType = "تعطیل رسمی", extraDayTypes = attendance)
        }
        jalaliWeekday(day.date) == 5 && day.dayType == "کاری" -> {
            val attendance = normalizedAttendance(day).takeIf { it.isNotBlank() && it != "عادی" }.orEmpty()
            day.copy(dayType = "تعطیل رسمی", extraDayTypes = attendance)
        }
        !db.holidayTitle(day.date).isNullOrBlank() && day.dayType == "کاری" && day.extraDayTypes.isBlank() -> day.copy(dayType = "تعطیل مناسبتی")
        else -> day
    }
}

private fun reportPeriodDays(db: WorkDb, year: Int, month: Int, annual: Boolean): List<WorkDay> {
    val stored = db.allDaysYear(year).associateBy { it.date }
    val months = if (annual) (1..12).toList() else listOf(month)
    return months.flatMap { m ->
        (1..jalaliMonthLength(year, m)).map { d ->
            val key = "%04d-%02d-%02d".format(year, m, d)
            val base = stored[key] ?: freshWorkDay(key, db)
            applyCalendarHoliday(base, db)
        }
    }
}

private fun isHolidayWorkDay(day: WorkDay): Boolean =
    dayStatuses(day).any { it in workHolidayStatuses || it in workLeaveStatuses } ||
        day.dayType == "تعطیل" || jalaliWeekday(day.date) == 5

/** All leave balances exclude Friday and official or individually marked holiday days. */
private fun isExcludedLeaveHoliday(day: WorkDay, db: WorkDb): Boolean =
    jalaliWeekday(day.date) == 5 || dayStatuses(day).any { it in workHolidayStatuses } ||
    db.officialHolidayTitle(day.date) != null ||
    officialJalaliHolidays(day.date.take(4).toIntOrNull() ?: 0).any { it.first == day.date } ||
    db.holidayTitle(day.date) != null

private fun reportDayStatusText(day: WorkDay, db: WorkDb): String {
    val selected=dayStatuses(day).filter { it != "توراهی" }.joinToString(" + ") { if(it=="مرخصی") "استحقاقی" else it }
    return selected
}

private fun isEntitledCountable(day: WorkDay, db: WorkDb): Boolean =
    hasDayStatus(day,"استحقاقی") && !isExcludedLeaveHoliday(day,db)
private fun isSickCountable(day: WorkDay, db: WorkDb): Boolean =
    hasDayStatus(day,"استعلاجی") && !isExcludedLeaveHoliday(day,db)
private fun periodLeaveStats(days: List<WorkDay>, db: WorkDb): Triple<Int,Int,Int> {
    val entitledCount = days.count { isEntitledCountable(it, db) }
    val sickCount = days.count { isSickCountable(it, db) }
    // Tourahi is a monthly deduction setting, never a daily status.
    return Triple(entitledCount, sickCount, 0)
}


private fun intervalMinutes(startText: String, endText: String): Int {
    val start = mins(startText) ?: return 0
    val end = mins(endText) ?: return 0
    return if (end >= start) end - start else (end + 24 * 60) - start
}

private fun holidayWorkDurationMinutes(day: WorkDay): Int =
    intervalMinutes(day.holidayIn, day.holidayOut) + intervalMinutes(day.holidayIn2, day.holidayOut2)

private fun overtimeMinutes(day: WorkDay, db: WorkDb): Int {
    val override = mins(day.overtimeOverride)
    if (override != null) return override
    if (isHolidayWorkDay(day)) return holidayWorkDurationMinutes(day)
    if (!hasDayStatus(day,"کاری")) return 0
    val target = dailyRequiredMinutes(day, db)
    if (day.scheduleMode == "ثابت") {
        val split = fixedAttendanceSplit(day, db) ?: return 0
        val outsideSchedule = (split.totalMinutes - split.insideScheduleMinutes).coerceAtLeast(0)
        val excessInside = (split.insideScheduleMinutes - target).coerceAtLeast(0)
        return outsideSchedule + excessInside
    }
    // In floating mode, hourly leave is deducted from total attendance first;
    // overtime is therefore consumed before mandatory attendance is reduced.
    return (duration(day, db) - target).coerceAtLeast(0)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KarkardApp(db: WorkDb, systemDate: LocalDate) {
    val context = LocalContext.current
    var screen by remember { mutableStateOf("home") }
    val nowJalali = remember(systemDate) { gregorianToJalali(systemDate) }
    var jalaliYear by remember { mutableIntStateOf(nowJalali.first) }
    var jalaliMonth by remember { mutableIntStateOf(nowJalali.second) }
    var date by remember { mutableStateOf("%04d-%02d-%02d".format(nowJalali.first, nowJalali.second, nowJalali.third)) }
    var lastObservedSystemDate by remember { mutableStateOf(systemDate) }
    LaunchedEffect(systemDate) {
        val previousDeviceDate = jalaliDateString(lastObservedSystemDate)
        val currentDeviceDate = jalaliDateString(systemDate)
        // Update automatically if the user is still on the previous phone-today date.
        // A deliberately selected earlier/later day is left alone.
        if (date == previousDeviceDate) {
            date = currentDeviceDate
            val parts = currentDeviceDate.split("-")
            if (parts.size == 3) {
                jalaliYear = parts[0].toIntOrNull() ?: jalaliYear
                jalaliMonth = parts[1].toIntOrNull() ?: jalaliMonth
            }
        }
        lastObservedSystemDate = systemDate
    }
    var refresh by remember { mutableIntStateOf(0) }
    var workRevision by remember { mutableIntStateOf(0) }
    // One editor state for the lifetime of the screen. A keyed remember(date)
    // would recreate the mutable state during date navigation and could replace
    // the just-reloaded record with a stale frame's values.
    var day by remember {
        mutableStateOf(applyCalendarHoliday(db.getDay(date).let { if (db.hasWorkDay(date)) it else freshWorkDay(date, db) }, db))
    }
    // Every persisted edit increments workRevision; this read is the display's
    // source of truth when returning to any date, without restarting the app.
    val persistedDay = remember(date, refresh, workRevision) {
        applyCalendarHoliday(db.getDay(date).let { if (db.hasWorkDay(date)) it else freshWorkDay(date, db) }, db)
    }
    var holidaySyncing by remember { mutableStateOf(false) }
    var holidaySyncMessage by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()
    val syncOfficialHolidays: (Int, Boolean) -> Unit = { yearToSync, force ->
        if (!holidaySyncing && (force || db.shouldSyncOfficialHolidays(yearToSync))) {
            holidaySyncing = true
            holidaySyncMessage = "در حال دریافت تعطیلات سال $yearToSync…"
            coroutineScope.launch {
                try {
                    val synced = withContext(Dispatchers.IO) {
                        val calendarData = fetchCalendarData(yearToSync)
                        db.replaceCalendarData(yearToSync, calendarData.holidays, calendarData.events)
                        db.setSettingText("calendar_last_online_$yearToSync", System.currentTimeMillis().toString())
                        calendarData.events.size
                    }
                    holidaySyncMessage = "تقویم سال $yearToSync به‌روزرسانی شد؛ $synced روز دارای مناسبت و ${db.officialHolidays(yearToSync).size} روز تعطیل رسمی ذخیره شد. پس از ذخیره، آفلاین هم در دسترس است."
                    refresh++
                } catch (e: Exception) {
                    val reason = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName
                    holidaySyncMessage = "به‌روزرسانی انجام نشد ($reason)؛ اطلاعات ذخیره‌شده حفظ شد. اینترنت را بررسی و دوباره تلاش کن."
                } finally {
                    holidaySyncing = false
                }
            }
        }
    }
    LaunchedEffect(jalaliYear) {
        syncOfficialHolidays(jalaliYear, false)
    }

    var lastBackPressed by remember { mutableLongStateOf(0L) }
    BackHandler {
        if (screen != "home") screen = "home"
        else {
            val now = android.os.SystemClock.elapsedRealtime()
            if (now - lastBackPressed < 2200L) (context as? MainActivity)?.finish()
            else {
                lastBackPressed = now
                android.widget.Toast.makeText(context, "برای خروج دوباره بازگشت را بزنید", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = AppPalette.Primary,
            onPrimary = Color.White,
            primaryContainer = AppPalette.PrimarySoft,
            onPrimaryContainer = AppPalette.Ink,
            secondary = AppPalette.Primary,
            onSecondary = Color.White,
            tertiary = AppPalette.Muted,
            onTertiary = Color.White,
            background = AppPalette.Background,
            onBackground = AppPalette.Ink,
            surface = AppPalette.Surface,
            onSurface = AppPalette.Ink,
            surfaceVariant = AppPalette.SurfaceAlt,
            onSurfaceVariant = AppPalette.Muted,
            outline = AppPalette.Border,
            outlineVariant = AppPalette.Border,
            error = AppPalette.Error,
            onError = Color.White,
            errorContainer = AppPalette.ErrorSoft,
            onErrorContainer = AppPalette.Error
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = MaterialTheme.colorScheme.background,
                topBar = {
                    // The title is centered against the entire screen, not the area left beside an action button.
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White)
                            // Respect Android status-bar and camera-cutout safe areas.
                            // Insets adapt automatically to each phone instead of using a fixed offset.
                            .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Top))
                            .height(48.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        IconButton(onClick = { screen = "settings" }, modifier = Modifier.align(Alignment.CenterStart).padding(start = 4.dp).size(44.dp)) {
                            Icon(painter = painterResource(R.drawable.nav_settings), contentDescription = "تنظیمات", tint = AppPalette.Primary, modifier = Modifier.size(22.dp))
                        }
                        IconButton(onClick = { screen = "prayer" }, modifier = Modifier.align(Alignment.CenterEnd).padding(end = 4.dp).size(44.dp)) {
                            Icon(painter = painterResource(R.drawable.nav_prayer), contentDescription = "اوقات شرعی و اذان", tint = AppPalette.Primary, modifier = Modifier.size(22.dp))
                        }
                        PersianText(
                            when (screen) {
                                "home" -> "ثبت کارکرد"
                                "calendar" -> "تقویم"
                                "report-monthly" -> "گزارش ماه"
                                "report-annual" -> "گزارش سال"
                                "settings" -> "تنظیمات"
                                "help" -> "راهنما"
                                "reminders" -> "یادآور اقساط و جلسات"
                                "prayer" -> "اوقات شرعی و اذان‌گو"
                                else -> "مورخ"
                            },
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 60.dp),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = AppPalette.Ink,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                bottomBar = {
                    NavigationBar(
                        containerColor = Color.White,
                        tonalElevation = 2.dp,
                        // Use Material 3 NavigationBar standard height and its built-in window insets;
                        // a fixed 84dp height clipped labels on some Android versions.
                    ) {
                        // In RTL order: annual report, monthly report, work entry (center), calendar, reminders.
                        listOf(
                            Triple("report-annual", "گزارش سال", R.drawable.nav_report_year),
                            Triple("report-monthly", "گزارش ماه", R.drawable.nav_report_month),
                            Triple("home", "ثبت کارکرد", R.drawable.nav_home),
                            Triple("calendar", "تقویم", R.drawable.nav_calendar),
                            Triple("reminders", "یادآور", R.drawable.nav_reminder)
                        ).forEach { (target, label, iconRes) ->
                            val selected = screen == target
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    if (target == "calendar") {
                                        val now = gregorianToJalali(LocalDate.now())
                                        jalaliYear = now.first; jalaliMonth = now.second
                                    }
                                    screen = target
                                },
                                icon = {
                                    Box(
                                        modifier = Modifier
                                            .size(if (target == "home") 34.dp else 28.dp)
                                            .clip(RoundedCornerShape(50))
                                            .background(if (selected) AppPalette.PrimarySoft else Color.Transparent),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            painter = painterResource(iconRes),
                                            contentDescription = label,
                                            modifier = Modifier.size(if (target == "home") 21.dp else 19.dp),
                                            tint = if (selected) AppPalette.Primary else AppPalette.Muted
                                        )
                                    }
                                },
                                label = { PersianText(label, fontSize = 8.sp, maxLines = 1, textAlign = TextAlign.Center, color = if (selected) AppPalette.Primary else AppPalette.Muted, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) },
                                alwaysShowLabel = true,
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = AppPalette.PrimarySoft,
                                    selectedIconColor = AppPalette.Primary,
                                    unselectedIconColor = AppPalette.Muted,
                                    selectedTextColor = AppPalette.Primary,
                                    unselectedTextColor = AppPalette.Muted
                                )
                            )
                        }
                    }
                }
            ) { padding ->
                when (screen) {
                    "settings" -> SettingsScreen(
                        db = db, modifier = Modifier.padding(padding),
                        onBackup = { (context as? MainActivity)?.createExcelBackup() },
                        onRestore = { (context as? MainActivity)?.chooseExcelRestore() },
                        onCsvBackup = { (context as? MainActivity)?.createCsvBackup() },
                        onCsvRestore = { (context as? MainActivity)?.chooseCsvRestore() },
                        onSyncHolidays = { selectedYear -> syncOfficialHolidays(selectedYear, true) },
                        syncYear = jalaliYear,
                        holidaySyncing = holidaySyncing,
                        holidaySyncMessage = holidaySyncMessage,
                        onHelp = { screen = "help" },
                        onScheduleSettingsChanged = {
                            if (!db.hasWorkDay(date)) day = freshWorkDay(date, db)
                            refresh++
                            workRevision++
                        }
                    )
                    "help" -> HelpScreen(Modifier.padding(padding))
                    "reminders" -> RemindersScreen(
                        modifier = Modifier.padding(padding),
                        onPickRingtone = { fromFile -> (context as? MainActivity)?.selectAlertSound(false,fromFile) }
                    )
                    "prayer" -> PrayerTimesScreen(
                        modifier = Modifier.padding(padding),
                        onPickRingtone = { fromFile -> (context as? MainActivity)?.selectAlertSound(true,fromFile) }
                    )
                    "calendar" -> JalaliCalendarScreen(
                        year = jalaliYear, month = jalaliMonth, selectedDate = jalaliDateString(LocalDate.now()),
                        onMonthChange = { y,m -> jalaliYear = y; jalaliMonth = m },
                        onSelectDate = { selected ->
                            date = selected
                            day = applyCalendarHoliday(db.getDay(selected).let { if (db.hasWorkDay(selected)) it else freshWorkDay(selected, db) }, db)
                            val parts = selected.split("-")
                            if (parts.size == 3) { jalaliYear = parts[0].toInt(); jalaliMonth = parts[1].toInt() }
                            screen = "home"
                        },
                        modifier = Modifier.padding(padding),
                        holidays = remember(refresh, jalaliYear, jalaliMonth) {
                            (officialJalaliHolidays(jalaliYear) + db.officialHolidays(jalaliYear) + db.allHolidays()).toMap()
                        },
                        events = remember(refresh, jalaliYear, jalaliMonth) { db.calendarEvents(jalaliYear).toMap() },
                        hijriDayOffset = 0
                    )
                    "report-monthly" -> ReportScreen(
                        db = db, year = jalaliYear, monthNumber = jalaliMonth, refresh = refresh + workRevision,
                        modifier = Modifier.padding(padding), annual = false,
                        onPeriodChange = { y, m -> jalaliYear = y; jalaliMonth = m },
                        export = { a, notes -> (context as? MainActivity)?.createReportExcel(jalaliYear, jalaliMonth, a, notes) },
                        exportPdf = { a, notes -> (context as? MainActivity)?.createReportPdf(jalaliYear, jalaliMonth, a, notes) },
                        exportSummaryExcel = { notes -> (context as? MainActivity)?.createReportExcel(jalaliYear, jalaliMonth, true, notes, true) },
                        exportSummaryPdf = { notes -> (context as? MainActivity)?.createReportPdf(jalaliYear, jalaliMonth, true, notes, true) },
                        onOpenDay = { selected ->
                            date = selected
                            day = applyCalendarHoliday(db.getDay(selected).let { if (db.hasWorkDay(selected)) it else freshWorkDay(selected, db) }, db)
                            screen = "home"
                            workRevision++
                        }
                    )
                    "report-annual" -> ReportScreen(
                        db = db, year = jalaliYear, monthNumber = jalaliMonth, refresh = refresh + workRevision,
                        modifier = Modifier.padding(padding), annual = true,
                        onPeriodChange = { y, m -> jalaliYear = y; jalaliMonth = m },
                        export = { a, notes -> (context as? MainActivity)?.createReportExcel(jalaliYear, jalaliMonth, a, notes) },
                        exportPdf = { a, notes -> (context as? MainActivity)?.createReportPdf(jalaliYear, jalaliMonth, a, notes) },
                        exportSummaryExcel = { notes -> (context as? MainActivity)?.createReportExcel(jalaliYear, jalaliMonth, true, notes, true) },
                        exportSummaryPdf = { notes -> (context as? MainActivity)?.createReportPdf(jalaliYear, jalaliMonth, true, notes, true) }
                    )
                    else -> key(date, refresh) { HomeDashboard(
                        modifier = Modifier.padding(padding), date = date, rawDay = persistedDay,
                        jalaliYear = jalaliYear, jalaliMonth = jalaliMonth, db = db, refresh = refresh,
                        onDateChange = { newDate ->
                            if (newDate != date && parsedJalaliDate(newDate) != null) {
                                // Writes are performed on each edit. Reload the destination explicitly,
                                // so returning to a visited date never shows a stale editor snapshot.
                                val destination = applyCalendarHoliday(db.getDay(newDate).let {
                                    if (db.hasWorkDay(newDate)) it else freshWorkDay(newDate, db)
                                }, db)
                                day = destination
                                date = newDate
                                workRevision++
                                val p = newDate.split("-")
                                if (p.size == 3) {
                                    jalaliYear = p[0].toIntOrNull() ?: jalaliYear
                                    jalaliMonth = p[1].toIntOrNull() ?: jalaliMonth
                                }
                            }
                        },
                        onDayChange = { updated ->
                            // Fixed-mode hourly leave cannot be outside the saved work window.
                            val candidate = applyCalendarHoliday(updated.copy(date = date), db)
                            if (hasInvalidFixedLeave(candidate, db)) {
                                android.widget.Toast.makeText(context, "در حالت ثابت، مرخصی ساعتی باید داخل ساعت موظفی همان روز باشد.", android.widget.Toast.LENGTH_LONG).show()
                            } else {
                                // Save every valid edit immediately, so navigating to another date does not discard it.
                                val saved = if (isOfficialCalendarHoliday(date, db)) {
                                    candidate.copy(dayType = "تعطیل رسمی", extraDayTypes = if (normalizedAttendance(candidate) == "عادی") "" else candidate.extraDayTypes)
                                } else candidate
                                val previousType = day.dayType
                                day = saved
                                db.saveDay(saved)
                                workRevision++
                                if (previousType == "تعطیل مناسبتی" && !hasDayStatus(saved,"تعطیل مناسبتی")) {
                                    db.removeHoliday(date)
                                }
                            }
                        },
                        onSaved = { saved -> day = saved; date = saved.date; refresh++; workRevision++ },
                        onDayDeleted = {
                            val reset = freshWorkDay(date, db)
                            day = reset
                            workRevision++
                            refresh++
                        },
                        onOpenCalendar = {
                            val now = gregorianToJalali(LocalDate.now())
                            jalaliYear = now.first; jalaliMonth = now.second
                            screen = "calendar"
                        }
                    ) }
                }
            }
        }
    }
}

@Composable
private fun HomeDashboard(
    modifier: Modifier,
    date: String,
    rawDay: WorkDay,
    jalaliYear: Int,
    jalaliMonth: Int,
    db: WorkDb,
    refresh: Int,
    onDateChange: (String) -> Unit,
    onDayChange: (WorkDay) -> Unit,
    onSaved: (WorkDay) -> Unit,
    onDayDeleted: () -> Unit,
    onOpenCalendar: () -> Unit
) {
    val context = LocalContext.current
    val day = applyCalendarHoliday(rawDay, db)
    val calendarTitle = remember(date, refresh) { db.displayHolidayTitle(date) ?: officialJalaliHolidays(date.take(4).toIntOrNull() ?: jalaliYear).toMap()[date] }
    val monthDays = remember(jalaliYear, jalaliMonth) { (1..31).filter { isValidJalali(jalaliYear, jalaliMonth, it) } }
    val dateParts = date.split("-").mapNotNull { it.toIntOrNull() }
    val dateDay = dateParts.getOrElse(2) { 1 }
    val weekday = jalaliWeekday(date)?.let { JalaliWeekdayNames.getOrNull(it) }.orEmpty()
    // Re-read on date change and when returning from the reminders page.
    // The HomeDashboard composable leaves composition while that page is open.
    val dayReminders = remember(date) { ReminderStore(context).forJalaliDay(date) }
    var holidayReason by remember(date, refresh) { mutableStateOf(db.holidayTitle(date).orEmpty()) }
    var confirmDayDeletion by remember(date) { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier.fillMaxSize()
            .pointerInput(date) {
                var drag = 0f
                detectHorizontalDragGestures(
                    onHorizontalDrag = { _, amount -> drag += amount },
                    onDragEnd = {
                        if (kotlin.math.abs(drag) > 65f) {
                            val target = if (drag < 0) parsedJalaliDate(date)?.minusDays(1)
                                         else parsedJalaliDate(date)?.plusDays(1)
                            target?.let { onDateChange(jalaliDateString(it)) }
                        }
                        drag = 0f
                    }
                )
            }
            .padding(horizontal = 8.dp, vertical = 5.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        contentPadding = PaddingValues(bottom = 8.dp)
    ) {
        item(key = "daily_card_$date") {
            Column(Modifier.fillMaxWidth()
                .border(2.dp, Color(0xFFC7A24A), RoundedCornerShape(16.dp)).padding(3.dp)
                .border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(13.dp)).padding(5.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Box(Modifier.fillMaxWidth().border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(7.dp)).padding(vertical = 5.dp), contentAlignment = Alignment.Center) {
                    PersianText("کارت روز", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AppPalette.Ink, textAlign = TextAlign.Center)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    Surface(color = AppPalette.PrimarySoft, shape = RoundedCornerShape(14.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFC7A24A))) {
                        PersianText("حالت ثبت ساعت کار: ${day.scheduleMode}", modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = AppPalette.Ink)
                    }
                }
                ReportDayCard(day, db, calendarTitle)
            }
        }
        // Show actual saved reminders for this date immediately below the day/date card.
        // Several reminders on the same date are all visible; past one-off entries
        // are not silently hidden, and monthly reminders follow their Jalali due day.
        if (dayReminders.isNotEmpty()) {
            item(key = "day_reminders_$date") {
                Card(
                    colors = CardDefaults.cardColors(containerColor = AppPalette.SurfaceAlt),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(12.dp))
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        PersianText("یادآورهای این روز", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AppPalette.Primary)
                        dayReminders.forEachIndexed { index, reminder ->
                            if (index > 0) Divider(color = AppPalette.PrimarySoft)
                            val reminderTime = java.time.Instant.ofEpochMilli(reminder.whenMillis)
                                .atZone(java.time.ZoneId.systemDefault()).toLocalTime()
                                .format(DateTimeFormatter.ofPattern("HH:mm", Locale.ROOT))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(9.dp)
                            ) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    PersianText(
                                        "${reminder.kind}: ${reminder.title}",
                                        fontSize = 13.sp,
                                        color = AppPalette.Ink,
                                        lineHeight = 18.sp
                                    )
                                    if (reminder.monthly) {
                                        PersianText("تکرار ماهانه", fontSize = 10.sp, color = AppPalette.Muted)
                                    }
                                }
                                PersianText(
                                    "ساعت ${reminderTime}",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AppPalette.Primary,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
        if (!calendarTitle.isNullOrBlank()) {
            item {
                val isOfficialCalendarHoliday = db.officialHolidayTitle(date) != null || officialJalaliHolidays(jalaliYear).toMap().containsKey(date)
                Card(
                    colors = CardDefaults.cardColors(containerColor = if (isOfficialCalendarHoliday) AppPalette.ErrorSoft else AppPalette.SurfaceAlt),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, if (isOfficialCalendarHoliday) AppPalette.ErrorBorder else Color(0xFFC7A24A), RoundedCornerShape(10.dp))
                ) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        PersianText(if (isOfficialCalendarHoliday) "تعطیل رسمی" else "مناسبت تقویم", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (isOfficialCalendarHoliday) AppPalette.Error else AppPalette.Primary)
                        PersianText(calendarTitle, fontSize = 12.sp, color = if (isOfficialCalendarHoliday) AppPalette.Error else AppPalette.Ink)
                    }
                }
            }
        }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AppPalette.PrimarySoft),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(12.dp))
            ) {
                Column(Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    PersianText("نوع روز", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AppPalette.Primary)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        val officialCalendarHoliday = isOfficialCalendarHoliday(date, db)
                        val friday = jalaliWeekday(date) == 5
                        listOf("کاری" to "◷", "تعطیل رسمی" to "♜", "تعطیل مناسبتی" to "▦").forEach { (type, symbol) ->
                            val selected = normalizedDayCategory(day) == type && !(type == "کاری" && (officialCalendarHoliday || friday))
                            // Official holidays lock the day category to "تعطیل رسمی".
                            // Fridays always keep "کاری" unavailable, while still allowing
                            // the user to distinguish a special closure if needed.
                            val disabledByCalendar = (officialCalendarHoliday && type != "تعطیل رسمی") || (friday && type == "کاری")
                            Card(
                                modifier = Modifier.weight(1f).height(58.dp).border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(10.dp)),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = when { selected -> AppPalette.Primary; disabledByCalendar -> AppPalette.Border; else -> AppPalette.SurfaceAlt }),
                                onClick = { if (!disabledByCalendar) onDayChange(toggleDayStatus(day, type)) }
                            ) {
                                Column(Modifier.fillMaxSize().padding(3.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                    PersianText(symbol, fontSize = 18.sp, color = if (selected) Color.White else if (disabledByCalendar) AppPalette.Muted else AppPalette.Ink)
                                    PersianText(type, fontSize = 10.sp, color = if (selected) Color.White else if (disabledByCalendar) AppPalette.Muted else AppPalette.Ink, textAlign = TextAlign.Center, maxLines = 2)
                                }
                            }
                        }
                    }
                    Divider(color = AppPalette.PrimarySoft)
                    PersianText("وضعیت حضور", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AppPalette.Primary)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("عادی" to "◉", "استحقاقی" to "☼", "استعلاجی" to "✚", "مأموریت" to "✈").forEach { (type, symbol) ->
                            val selected = normalizedAttendance(day) == type
                            val disabled = type == "عادی" && normalizedDayCategory(day) in workHolidayStatuses
                            Card(
                                modifier = Modifier.weight(1f).height(59.dp).border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(10.dp)),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = when { disabled -> AppPalette.SurfaceAlt; selected -> AppPalette.Primary; else -> AppPalette.SurfaceAlt }),
                                onClick = { if (!disabled) onDayChange(toggleDayStatus(day, type)) }
                            ) {
                                Column(Modifier.fillMaxSize().padding(2.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                    PersianText(symbol, fontSize = 17.sp, color = if (disabled) Color.LightGray else if (selected) Color.White else Color.Black)
                                    PersianText(type, fontSize = 9.sp, color = if (disabled) Color.LightGray else if (selected) Color.White else Color.Black, textAlign = TextAlign.Center, maxLines = 2)
                                }
                            }
                        }
                    }
                }
            }
        }
        if (hasDayStatus(day,"تعطیل مناسبتی")) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = AppPalette.SurfaceAlt), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(10.dp))) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        PersianText("علت تعطیلی (اختیاری)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.Black)
                        OutlinedTextField(
                            value = holidayReason.toPersianDigits(),
                            onValueChange = {
                                holidayReason = it
                                // Persist the title while typing; changing dates will not lose it.
                                if (hasDayStatus(day,"تعطیل مناسبتی")) {
                                    if (it.isBlank()) db.removeHoliday(date)
                                    else db.saveHoliday(date, it.trim())
                                }
                            },
                            placeholder = { PersianText("علت تعطیلی را وارد کنید", fontSize = 12.sp, color = Color.DarkGray) },
                            leadingIcon = { PersianText("✎", fontSize = 18.sp) },
                            modifier = Modifier.fillMaxWidth(), singleLine = true,
                            textStyle = TextStyle(fontSize = 12.sp, color = Color.Black, textAlign = TextAlign.Start),
                        )
                    }
                }
            }
        }
        if (isHolidayWorkDay(day)) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = AppPalette.SuccessSoft),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(12.dp))
                ) {
                    Column(Modifier.fillMaxWidth().padding(bottom = 7.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth().background(AppPalette.SuccessSoft).padding(horizontal = 8.dp, vertical = 6.dp)) {
                            PersianText(if (dayStatuses(day).any { it in workLeaveStatuses }) "ثبت اضافه‌کاری در روز مرخصی" else "ساعت کار در روز تعطیل", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                        }
                        Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        PersianText("زمان ثبت‌شده در این بخش، تماماً اضافه‌کاری محاسبه می‌شود.", fontSize = 10.sp, color = Color.Black)
                        CompactTimePairRow("۱", "ورود", day.holidayIn, "خروج", day.holidayOut,
                            { onDayChange(day.copy(holidayIn = it)) },
                            { onDayChange(day.copy(holidayOut = it)) }, fieldFontSize = 13)
                        Divider(color = AppPalette.Border)
                        CompactTimePairRow("۲", "ورود", day.holidayIn2, "خروج", day.holidayOut2,
                            { onDayChange(day.copy(holidayIn2 = it)) },
                            { onDayChange(day.copy(holidayOut2 = it)) }, fieldFontSize = 13)
                        PersianText("اضافه‌کاری تعطیل: ${hm(holidayWorkDurationMinutes(day))}", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.Black)
                        }
                    }
                }
            }
        } else {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = AppPalette.Surface), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(12.dp))) {
                    Column(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Row(Modifier.fillMaxWidth().background(AppPalette.Surface).padding(horizontal = 8.dp, vertical = 6.dp)) {
                            PersianText("ساعت کار روزانه", modifier = Modifier.fillMaxWidth(), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black, textAlign = TextAlign.Start)
                        }
                        Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Divider(color = AppPalette.Border)
                        CompactTimePairRow("۱", "ورود", day.in1, "خروج", day.out1, { onDayChange(day.copy(in1=it)) }, { onDayChange(day.copy(out1=it)) }, fieldFontSize = 13)
                        Divider(color = AppPalette.SuccessBorder)
                        CompactTimePairRow("۲", "ورود", day.in2, "خروج", day.out2, { onDayChange(day.copy(in2=it)) }, { onDayChange(day.copy(out2=it)) }, fieldFontSize = 13)
                        Divider(color = AppPalette.Border)
                        CompactTimePairRow("۳", "ورود", day.in3, "خروج", day.out3, { onDayChange(day.copy(in3=it)) }, { onDayChange(day.copy(out3=it)) }, fieldFontSize = 13)
                        }
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = AppPalette.SuccessSoft), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(12.dp))) {
                Column(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(Modifier.fillMaxWidth().background(AppPalette.SuccessSoft).padding(horizontal = 8.dp, vertical = 6.dp)) {
                        PersianText("مرخصی ساعتی", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.Black)
                    }
                    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Divider(color = AppPalette.SuccessBorder)
                    if (day.scheduleMode == "ثابت") {
                        PersianText("در حالت ثابت فقط مرخصی داخل ساعت حضور موظفی مجاز است.", fontSize = 10.sp, color = AppPalette.Ink)
                    } else {
                        PersianText("در حالت شناور، مرخصی ساعتی از اضافه‌کاری روز کسر می‌شود.", fontSize = 10.sp, color = AppPalette.Ink)
                    }
                    CompactTimePairRow("۱", "از ساعت", day.leave1Start, "الی ساعت", day.leave1End, { onDayChange(day.copy(leave1Start=it, hourlyLeaveEnabled=true)) }, { onDayChange(day.copy(leave1End=it, hourlyLeaveEnabled=true)) })
                    Divider(color = AppPalette.Border)
                    CompactTimePairRow("۲", "از ساعت", day.leave2Start, "الی ساعت", day.leave2End, { onDayChange(day.copy(leave2Start=it, hourlyLeaveEnabled=true)) }, { onDayChange(day.copy(leave2End=it, hourlyLeaveEnabled=true)) })
                    Divider(color = AppPalette.Border)
                    CompactTimePairRow("۳", "از ساعت", day.leave3Start, "الی ساعت", day.leave3End, { onDayChange(day.copy(leave3Start=it, hourlyLeaveEnabled=true)) }, { onDayChange(day.copy(leave3End=it, hourlyLeaveEnabled=true)) })
                    PersianText("مجموع مرخصی ساعتی: ${hm(hourlyLeaveMinutes(day, db))}", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = AppPalette.Ink)
                    if (hasInvalidFixedLeave(day, db)) PersianText("بازه مرخصی خارج از ساعت موظفی است؛ آن را اصلاح کن تا ذخیره شود.", fontSize = 10.sp, color = AppPalette.Error)
                    }
                }
            }
        }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AppPalette.SurfaceAlt),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, AppPalette.Border, RoundedCornerShape(12.dp))
            ) {
                Column(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().background(AppPalette.SurfaceAlt).padding(horizontal = 9.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
                        PersianText("☼", fontSize = 21.sp, color = Color(0xFFE9A600))
                        Spacer(Modifier.width(6.dp))
                        PersianText("شیفت کاری", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = AppPalette.Primary)
                        Spacer(Modifier.weight(1f))
                        Switch(checked = day.shiftEnabled, onCheckedChange = { enabled ->
                            val start = day.shiftStartDate.ifBlank { date }
                            onDayChange(day.copy(
                                shiftEnabled = enabled,
                                shiftStart = if (enabled && day.shiftStart.isBlank()) "17:00" else day.shiftStart,
                                shiftEnd = if (enabled && day.shiftEnd.isBlank()) "07:00" else day.shiftEnd,
                                shiftStartDate = if (enabled && day.shiftStartDate.isBlank()) date else day.shiftStartDate,
                                shiftEndDate = if (enabled && day.shiftEndDate.isBlank()) defaultShiftEndDate(start, "17:00", "07:00") else day.shiftEndDate
                            ))
                        })
                    }
                    if (day.shiftEnabled) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 5.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        // Row 1: shift dates
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Top) {
                            CompactShiftField("تاریخ شروع", jalaliDisplayDate(day.shiftStartDate.ifBlank { date }), Modifier.weight(1f), true) {
                                // SplitDateField already owns year/month/day separators.
                                // Preserve partially edited segments; never merge them back
                                // into a new 8-digit stream while the user is typing.
                                val newStartDate = it
                                val oldStartDate = day.shiftStartDate.ifBlank { date }
                                val oldAutomaticEndDate = defaultShiftEndDate(oldStartDate, day.shiftStart, day.shiftEnd)
                                val endDateWasAutomatic = day.shiftEndDate.isBlank() || day.shiftEndDate == oldStartDate || day.shiftEndDate == oldAutomaticEndDate
                                val computedEnd = if (endDateWasAutomatic && parsedJalaliDate(newStartDate) != null)
                                    defaultShiftEndDate(newStartDate, day.shiftStart, day.shiftEnd) else day.shiftEndDate
                                onDayChange(day.copy(shiftStartDate = newStartDate, shiftEndDate = computedEnd))
                            }
                            CompactShiftField("تاریخ پایان", jalaliDisplayDate(day.shiftEndDate.ifBlank { defaultShiftEndDate(day.shiftStartDate.ifBlank { date }, day.shiftStart.ifBlank { "17:00" }, day.shiftEnd.ifBlank { "07:00" }) }), Modifier.weight(1f), true) { onDayChange(day.copy(shiftEndDate=it)) }
                        }
                        // Row 2: shift times
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Top) {
                            CompactShiftField("ساعت شروع", day.shiftStart.ifBlank { "17:00" }, Modifier.weight(1f), false) {
                                val startDate = day.shiftStartDate.ifBlank { date }
                                val oldAutomaticEndDate = defaultShiftEndDate(startDate, day.shiftStart, day.shiftEnd)
                                val endDateWasAutomatic = day.shiftEndDate.isBlank() || day.shiftEndDate == startDate || day.shiftEndDate == oldAutomaticEndDate
                                onDayChange(day.copy(shiftStart = it, shiftStartDate = startDate, shiftEndDate = if (endDateWasAutomatic) defaultShiftEndDate(startDate, it, day.shiftEnd) else day.shiftEndDate))
                            }
                            CompactShiftField("ساعت پایان", day.shiftEnd.ifBlank { "07:00" }, Modifier.weight(1f), false) {
                                val startDate = day.shiftStartDate.ifBlank { date }
                                val oldAutomaticEndDate = defaultShiftEndDate(startDate, day.shiftStart, day.shiftEnd)
                                val endDateWasAutomatic = day.shiftEndDate.isBlank() || day.shiftEndDate == startDate || day.shiftEndDate == oldAutomaticEndDate
                                onDayChange(day.copy(shiftEnd = it, shiftStartDate = startDate, shiftEndDate = if (endDateWasAutomatic) defaultShiftEndDate(startDate, day.shiftStart, it) else day.shiftEndDate))
                            }
                        }
                        }
                    }
                    PersianText("مدت شیفت: ${hm(shiftDurationMinutes(day, date))}", modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp), fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = AppPalette.Primary)
                    Spacer(Modifier.height(5.dp))
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = AppPalette.Surface), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(10.dp))) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PersianText("▤", fontSize = 20.sp, color = AppPalette.Primary)
                        Spacer(Modifier.width(6.dp))
                        PersianText("یادداشت روز", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = AppPalette.Primary)
                    }
                    OutlinedTextField(value = day.note.toPersianDigits(), onValueChange = { onDayChange(day.copy(note=it)) }, placeholder = { PersianText("یادداشت اختیاری…", fontSize = 11.sp, color = AppPalette.Muted) }, modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(8.dp)), minLines = 1, maxLines = Int.MAX_VALUE, textStyle = TextStyle(fontSize = 12.sp, color = AppPalette.Ink))

                }
            }
        }
        item {
            Button(
                onClick = {
                    val p = date.toLatinDigits().replace('/', '-').split("-").mapNotNull { it.toIntOrNull() }
                    if (p.size == 3 && isValidJalali(p[0], p[1], p[2])) {
                        val normalized = "%04d-%02d-%02d".format(p[0], p[1], p[2])
                        val startDate = day.shiftStartDate.ifBlank { normalized }
                        val endDate = day.shiftEndDate.ifBlank { defaultShiftEndDate(startDate, day.shiftStart, day.shiftEnd) }
                        val savedDay = day.copy(date=normalized, shiftStartDate=startDate, shiftEndDate=endDate)
                        if (savedDay.shiftEnabled && (parsedJalaliDate(startDate) == null || parsedJalaliDate(endDate) == null)) {
                            android.widget.Toast.makeText(context, "تاریخ شروع و پایان شیفت معتبر نیست.", android.widget.Toast.LENGTH_LONG).show()
                        } else if (savedDay.shiftEnabled && (mins(savedDay.shiftStart) == null || mins(savedDay.shiftEnd) == null)) {
                            android.widget.Toast.makeText(context, "ساعت شروع و پایان شیفت را درست وارد کنید.", android.widget.Toast.LENGTH_LONG).show()
                        } else if (hasInvalidFixedLeave(savedDay, db)) {
                            android.widget.Toast.makeText(context, "در حالت ثابت، مرخصی ساعتی باید کاملاً داخل ساعت موظفی همان روز باشد.", android.widget.Toast.LENGTH_LONG).show()
                        } else {
                            db.saveDay(savedDay)
                            if (hasDayStatus(savedDay,"تعطیل مناسبتی")) {
                                if (holidayReason.isNotBlank()) db.saveHoliday(normalized, holidayReason.trim()) else db.removeHoliday(normalized)
                            } else {
                                db.removeHoliday(normalized)
                            }
                            onSaved(savedDay)
                            android.widget.Toast.makeText(context, "اطلاعات روز ذخیره شد", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().heightIn(min = 38.dp),
                contentPadding = PaddingValues(vertical = 5.dp)
            ) { PersianText("ذخیره اطلاعات روز", fontSize = 13.sp) }
        }
        item {
            OutlinedButton(
                onClick = { confirmDayDeletion = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = AppPalette.Error)
            ) { PersianText("حذف اطلاعات روز", fontSize = 13.sp) }
        }
    }

    if (confirmDayDeletion) AlertDialog(
        onDismissRequest = { confirmDayDeletion = false },
        title = { PersianText("حذف تمام اطلاعات این روز", fontWeight = FontWeight.Bold) },
        text = { PersianText("تمام اطلاعات ثبت‌شدهٔ ${jalaliDisplayDate(date)}، شامل یادداشت، ساعت‌ها، شیفت، مرخصی، مأموریت و علت تعطیلی پاک می‌شود. آیا مطمئنی؟ آیا پشتیبان گرفته‌ای؟") },
        confirmButton = {
            TextButton(onClick = {
                db.deleteWorkRecord(date)
                confirmDayDeletion = false
                onDayDeleted()
                android.widget.Toast.makeText(context, "اطلاعات این روز حذف شد", android.widget.Toast.LENGTH_SHORT).show()
            }) { PersianText("بله، حذف شود", color = AppPalette.Error) }
        },
        dismissButton = {
            TextButton(onClick = { confirmDayDeletion = false }) { PersianText("لغو") }
        }
    )


}

@Composable
private fun CompactTimePairRow(index: String, label1: String, value1: String, label2: String, value2: String, onChange1: (String) -> Unit, onChange2: (String) -> Unit, fieldFontSize: Int = 17, labelColor: Color = Color.Black) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Box(Modifier.size(25.dp).background(AppPalette.SuccessSoft, RoundedCornerShape(50)), contentAlignment = Alignment.Center) { PersianText(index, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black) }
            CompactTimeTextField(label1, value1, onChange1, Modifier.weight(1f), fieldFontSize, labelColor)
            CompactTimeTextField(label2, value2, onChange2, Modifier.weight(1f), fieldFontSize, labelColor)
        }
    }
}

@Composable
private fun CompactTimeTextField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier, fieldFontSize: Int = 17, labelColor: Color = Color.Black) {
    SplitTimeField(label, value, onChange, modifier, fieldFontSize, labelColor)
}

@Composable
private fun CompactShiftField(label: String, value: String, modifier: Modifier, isDate: Boolean, onChange: (String) -> Unit) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        PersianText(label, fontSize = 8.sp, color = AppPalette.Primary, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 2, lineHeight = 9.sp)
        if (isDate) {
            SplitDateField(value, onChange, Modifier.fillMaxWidth(), boldPlaceholders = true)
        } else {
            SplitTimeField("", value, onChange, Modifier.fillMaxWidth(), 13, AppPalette.Primary, boldLabels = true)
        }
    }
}

/**
 * Extract what the user actually typed, excluding the old value that the IME
 * included in the editing event. Cursor moves/selection changes produce no digits.
 */
private fun insertedDigits(oldText: String, newText: String): String {
    val old = oldText.toLatinDigits()
    val new = newText.toLatinDigits()
    val commonPrefix = old.indices.takeWhile { it < new.length && old[it] == new[it] }.count()
    var oldEnd = old.length
    var newEnd = new.length
    while (oldEnd > commonPrefix && newEnd > commonPrefix && old[oldEnd - 1] == new[newEnd - 1]) {
        oldEnd--
        newEnd--
    }
    return new.substring(commonPrefix, newEnd).filter(Char::isDigit)
}

/**
 * Touching a field only arms replacement. The old digits remain visible and
 * unselected until the first new digit is actually entered. This also avoids
 * focus jumps caused by selection-only TextFieldValue updates.
 */
@Composable
private fun ReplaceableNumberField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier,
    maxDigits: Int,
    fontSize: TextUnit,
    imeAction: ImeAction,
    placeholder: String = "",
    placeholderBold: Boolean = false
) {
    var input by remember { mutableStateOf(TextFieldValue(value.toPersianDigits())) }
    var replaceOnNextDigit by remember { mutableStateOf(false) }
    SideEffect {
        if (input.text.toLatinDigits() != value.toLatinDigits()) {
            val shown = value.toPersianDigits()
            input = TextFieldValue(shown, selection = TextRange(shown.length))
        }
    }
    BasicTextField(
        value = input,
        onValueChange = { incoming ->
            if (incoming.text == input.text) {
                // Pure selection/caret movement: do not publish, do not auto-advance.
                input = incoming
            } else {
                val added = insertedDigits(input.text, incoming.text)
                val cleaned = if (replaceOnNextDigit && added.isNotEmpty()) {
                    replaceOnNextDigit = false
                    added.take(maxDigits)
                } else {
                    replaceOnNextDigit = false
                    incoming.text.toLatinDigits().filter(Char::isDigit).take(maxDigits)
                }
                val shown = cleaned.toPersianDigits()
                input = TextFieldValue(shown, selection = TextRange(shown.length))
                if (cleaned != value.toLatinDigits()) onValueChange(cleaned)
            }
        },
        modifier = modifier
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    replaceOnNextDigit = true
                    waitForUpOrCancellation()
                }
            }
            .onFocusChanged { focus ->
                if (focus.isFocused) replaceOnNextDigit = true
                else replaceOnNextDigit = false
            },
        singleLine = true,
        textStyle = TextStyle(fontSize = fontSize, textAlign = TextAlign.Center, color = Color.Black),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = imeAction),
        decorationBox = { innerTextField ->
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Row(
                    modifier = Modifier
                        .wrapContentWidth()
                        .background(AppPalette.SurfaceAlt, RoundedCornerShape(7.dp))
                        .border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(7.dp))
                        .padding(horizontal = 9.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        if (input.text.isEmpty() && placeholder.isNotBlank()) {
                            PersianText(placeholder, fontSize = 9.sp, color = AppPalette.Primary, fontWeight = if (placeholderBold) FontWeight.Bold else FontWeight.Normal)
                        }
                        innerTextField()
                    }
                }
            }
        }
    )
}

/** The same first-new-digit replacement rule for HH:MM settings values. */
@Composable
private fun ReplaceableSettingsTimeField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String
) {
    var input by remember { mutableStateOf(TextFieldValue(value.toPersianDigits())) }
    var replaceOnNextDigit by remember { mutableStateOf(false) }
    SideEffect {
        if (input.text.toLatinDigits() != value.toLatinDigits()) {
            val shown = value.toPersianDigits()
            input = TextFieldValue(shown, selection = TextRange(shown.length))
        }
    }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        PersianText(label, fontSize = 11.sp, color = AppPalette.Muted)
        BasicTextField(
            value = input,
            onValueChange = { incoming ->
                if (incoming.text == input.text) {
                    input = incoming
                } else {
                    val added = insertedDigits(input.text, incoming.text)
                    val normalized = if (replaceOnNextDigit && added.isNotEmpty()) {
                        replaceOnNextDigit = false
                        formatTimeInput(added)
                    } else {
                        replaceOnNextDigit = false
                        formatTimeInput(incoming.text)
                    }
                    val shown = normalized.toPersianDigits()
                    input = TextFieldValue(shown, selection = TextRange(shown.length))
                    if (normalized != value.toLatinDigits()) onValueChange(normalized)
                }
            },
            modifier = Modifier.fillMaxWidth().height(44.dp)
                .pointerInput(Unit) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                        replaceOnNextDigit = true
                        waitForUpOrCancellation()
                    }
                }
                .onFocusChanged { focus -> replaceOnNextDigit = focus.isFocused },
            singleLine = true,
            textStyle = TextStyle(fontSize = 16.sp, textAlign = TextAlign.Center, color = Color.Black),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
            decorationBox = { innerTextField ->
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Box(
                        Modifier.wrapContentWidth()
                            .background(AppPalette.SurfaceAlt, RoundedCornerShape(7.dp))
                            .border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(7.dp))
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        contentAlignment = Alignment.Center
                    ) { innerTextField() }
                }
            }
        )
    }
}

/**
 * Reminder-only field row with absolute LEFT-to-RIGHT screen coordinates.
 * Unlike a normal Row, its physical order is independent of the outer Persian
 * RTL layout direction: place() (not placeRelative()) is intentional.
 */
@Composable
private fun ReminderPhysicalLtrRow(
    weights: List<Float>,
    modifier: Modifier = Modifier,
    gap: Dp = 4.dp,
    content: @Composable () -> Unit
) {
    androidx.compose.ui.layout.Layout(content = content, modifier = modifier) { measurables, constraints ->
        require(measurables.size == weights.size) { "Every reminder field requires a width weight" }
        val gapPx = gap.roundToPx()
        val width = constraints.maxWidth
        val available = (width - gapPx * (measurables.size - 1)).coerceAtLeast(0)
        val sumWeights = weights.sum().coerceAtLeast(0.01f)
        var usedWidth = 0
        val placeables = measurables.mapIndexed { index, measurable ->
            val childWidth = if (index == measurables.lastIndex) {
                available - usedWidth
            } else {
                (available * weights[index] / sumWeights).toInt().coerceAtLeast(0)
            }
            usedWidth += childWidth
            measurable.measure(androidx.compose.ui.unit.Constraints(
                minWidth = childWidth,
                maxWidth = childWidth,
                minHeight = 0,
                maxHeight = constraints.maxHeight
            ))
        }
        val height = placeables.maxOfOrNull { it.height } ?: 0
        layout(width, height) {
            var x = 0
            placeables.forEach { item ->
                item.place(x, height - item.height)
                x += item.width + gapPx
            }
        }
    }
}

/** Persian reminder year/month/day, physically left to right on screen. */
@Composable
fun ReminderDateFieldLeftToRight(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val parts = value.toLatinDigits().replace('-', '/').split('/')
    val year = parts.getOrElse(0) { "" }.take(4)
    val month = parts.getOrElse(1) { "" }.take(2)
    val day = parts.getOrElse(2) { "" }.take(2)
    val monthFocus = remember { FocusRequester() }
    val dayFocus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    fun publish(y: String, m: String, d: String) {
        onChange(when {
            y.isBlank() && m.isBlank() && d.isBlank() -> ""
            else -> y + (if (m.isNotEmpty() || d.isNotEmpty()) "-" + m else "") + (if (d.isNotEmpty()) "-" + d else "")
        })
    }
    ReminderPhysicalLtrRow(listOf(1.15f, 0.85f, 0.85f), modifier.fillMaxWidth()) {
        ReplaceableNumberField(
            value = year,
            onValueChange = { y -> publish(y, month, day); if (y.length == 4) monthFocus.requestFocus() },
            modifier = Modifier.height(44.dp), maxDigits = 4, fontSize = 13.sp,
            placeholder = "سال", imeAction = ImeAction.Next
        )
        ReplaceableNumberField(
            value = month,
            onValueChange = { m -> publish(year, m, day); if (m.length == 2) dayFocus.requestFocus() },
            modifier = Modifier.height(44.dp).focusRequester(monthFocus), maxDigits = 2,
            fontSize = 13.sp, placeholder = "ماه", imeAction = ImeAction.Next, placeholderBold = true
        )
        ReplaceableNumberField(
            value = day,
            onValueChange = { d -> publish(year, month, d); if (d.length == 2) keyboard?.hide() },
            modifier = Modifier.height(44.dp).focusRequester(dayFocus), maxDigits = 2,
            fontSize = 13.sp, placeholder = "روز", imeAction = ImeAction.Done, placeholderBold = true
        )
    }
}

/** Persian reminder hour/minute, physically left to right on screen. */
@Composable
fun ReminderTimeFieldLeftToRight(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val parts = value.toLatinDigits().split(':')
    val hour = parts.getOrElse(0) { "" }.take(2)
    val minute = parts.getOrElse(1) { "" }.take(2)
    val minuteFocus = remember { FocusRequester() }
    ReminderPhysicalLtrRow(listOf(1f, 0.07f, 1f), modifier.fillMaxWidth(), 3.dp) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
            PersianText("ساعت", fontSize = 9.sp, maxLines = 1)
            ReplaceableNumberField(
                value = hour,
                onValueChange = { h ->
                    onChange(if (h.isBlank() && minute.isBlank()) "" else "$h:$minute")
                    if (h.length == 2) minuteFocus.requestFocus()
                },
                modifier = Modifier.fillMaxWidth().height(44.dp), maxDigits = 2,
                fontSize = 17.sp, imeAction = ImeAction.Next
            )
        }
        Box(Modifier.height(44.dp), contentAlignment = Alignment.Center) {
            PersianText(":", fontSize = 16.sp, maxLines = 1)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
            PersianText("دقیقه", fontSize = 9.sp, maxLines = 1)
            ReplaceableNumberField(
                value = minute,
                onValueChange = { m -> onChange(if (hour.isBlank() && m.isBlank()) "" else "$hour:$m") },
                modifier = Modifier.fillMaxWidth().height(44.dp).focusRequester(minuteFocus), maxDigits = 2,
                fontSize = 17.sp, imeAction = ImeAction.Done
            )
        }
    }
}

@Composable
fun SplitDateField(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, boldPlaceholders: Boolean = false) {
    val parts = value.toLatinDigits().replace('-', '/').split('/')
    val year = parts.getOrElse(0) { "" }.take(4)
    val month = parts.getOrElse(1) { "" }.take(2)
    val day = parts.getOrElse(2) { "" }.take(2)
    val monthFocus = remember { FocusRequester() }
    val dayFocus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    fun publish(y: String, m: String, d: String) {
        val out = when {
            y.isBlank() && m.isBlank() && d.isBlank() -> ""
            else -> y + (if (m.isNotEmpty() || d.isNotEmpty()) "-" + m else "") + (if (d.isNotEmpty()) "-" + d else "")
        }
        onChange(out)
    }
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
        ReplaceableNumberField(
            value = year,
            onValueChange = { y -> publish(y, month, day); if (y.length == 4) monthFocus.requestFocus() },
            modifier = Modifier.weight(1.15f).height(44.dp),
            maxDigits = 4, fontSize = 13.sp, placeholder = "سال", imeAction = ImeAction.Next, placeholderBold = boldPlaceholders
        )
        ReplaceableNumberField(
            value = month,
            onValueChange = { m -> publish(year, m, day); if (m.length == 2) dayFocus.requestFocus() },
            modifier = Modifier.weight(0.85f).height(44.dp).focusRequester(monthFocus),
            maxDigits = 2, fontSize = 13.sp, placeholder = "ماه", imeAction = ImeAction.Next
        )
        ReplaceableNumberField(
            value = day,
            onValueChange = { d -> publish(year, month, d); if (d.length == 2) keyboard?.hide() },
            modifier = Modifier.weight(0.85f).height(44.dp).focusRequester(dayFocus),
            maxDigits = 2, fontSize = 13.sp, placeholder = "روز", imeAction = ImeAction.Done
        )
    }
}

@Composable
private fun SummaryMiniTile(label: String, value: String, background: Color, foreground: Color, modifier: Modifier) {
    Card(modifier = modifier.border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(10.dp)), colors = CardDefaults.cardColors(containerColor = background), shape = RoundedCornerShape(10.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 3.dp, vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
            PersianText(label, fontSize = 10.sp, color = foreground, textAlign = TextAlign.Center, maxLines = 1)
            PersianText(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = foreground, maxLines = 1)
            PersianText("ساعت", fontSize = 8.sp, color = foreground)
        }
    }
}

@Composable
fun SplitTimeField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, fieldFontSize: Int = 17, labelColor: Color = AppPalette.Muted, boldLabels: Boolean = false) {
    // One controlled implementation for daily entry, hourly leave and work shifts.
    // Do not reset internal hour/minute state after every parent save/recomposition.
    val parts = value.toLatinDigits().split(":")
    val hour = parts.getOrElse(0) { "" }.take(2)
    val minute = parts.getOrElse(1) { "" }.take(2)
    val minuteFocus = remember { FocusRequester() }
    val stableClockFontSize = fieldFontSize.coerceIn(15, 17).sp
    Column(modifier, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        if (label.isNotBlank()) PersianText(label, fontSize = 10.sp, maxLines = 1, color = labelColor, fontWeight = if (boldLabels) FontWeight.Bold else FontWeight.Normal)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                PersianText("ساعت", fontSize = 9.sp, maxLines = 1, color = labelColor, fontWeight = if (boldLabels) FontWeight.Bold else FontWeight.Normal)
                ReplaceableNumberField(
                    value = hour,
                    onValueChange = { typedHour ->
                        onChange(if (typedHour.isBlank() && minute.isBlank()) "" else "$typedHour:$minute")
                        // A real edit reaches 2 digits; a mere tap/selection never calls this.
                        if (typedHour.length == 2) minuteFocus.requestFocus()
                    },
                    modifier = Modifier.fillMaxWidth().height(44.dp),
                    maxDigits = 2,
                    fontSize = stableClockFontSize,
                    imeAction = ImeAction.Next
                )
            }
            Box(Modifier.height(44.dp), contentAlignment = Alignment.Center) {
                PersianText(":", fontSize = 16.sp, maxLines = 1)
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                PersianText("دقیقه", fontSize = 9.sp, maxLines = 1, color = labelColor, fontWeight = if (boldLabels) FontWeight.Bold else FontWeight.Normal)
                ReplaceableNumberField(
                    value = minute,
                    onValueChange = { typedMinute ->
                        onChange(if (hour.isBlank() && typedMinute.isBlank()) "" else "$hour:$typedMinute")
                    },
                    modifier = Modifier.fillMaxWidth().height(44.dp).focusRequester(minuteFocus),
                    maxDigits = 2,
                    fontSize = stableClockFontSize,
                    imeAction = ImeAction.Done
                )
            }
        }
    }
}

@Composable
fun TimePair(label1: String, v1: String, label2: String, v2: String, c1: (String)->Unit, c2: (String)->Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        SplitTimeField(label1, v1, c1, Modifier.weight(1f))
        SplitTimeField(label2, v2, c2, Modifier.weight(1f))
    }
}

@Composable
fun SettingsScreen(
    db: WorkDb,
    modifier: Modifier = Modifier,
    onBackup: () -> Unit,
    onRestore: () -> Unit,
    onCsvBackup: () -> Unit,
    onCsvRestore: () -> Unit,
    onSyncHolidays: (Int) -> Unit,
    syncYear: Int,
    holidaySyncing: Boolean,
    holidaySyncMessage: String,
    onHelp: () -> Unit,
    onScheduleSettingsChanged: () -> Unit = {}
) {
    var tick by remember { mutableIntStateOf(0) }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = AppPalette.PrimarySoft), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(18.dp))) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                PersianText("مورخ", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = AppPalette.Primary)
                PersianText("تنظیمات، پشتیبان‌گیری و شخصی‌سازی برنامه", fontSize = 12.sp, color = AppPalette.Primary)
            }
        }
        PersianText("امکانات و تقویم", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = AppPalette.Ink)
        PersianText("تعطیلات و همهٔ مناسبت‌های تقویم ایران", style = MaterialTheme.typography.titleMedium)
        PersianText("سال شمسی را انتخاب کن تا تعطیلات رسمی و مناسبت‌های ملی، مذهبی، فرهنگی و جهانی همان سال دریافت و روی گوشی ذخیره شوند. پس از ذخیره، بدون اینترنت هم در دسترس‌اند. تاریخ قمری آینده ممکن است تا اعلام رسمی تخمینی باشد.", style = MaterialTheme.typography.bodySmall)
        var selectedCalendarYear by remember(syncYear) { mutableIntStateOf(syncYear) }
        var yearMenuExpanded by remember { mutableStateOf(false) }
        Box {
            OutlinedButton(onClick = { yearMenuExpanded = true }, modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(8.dp))) {
                PersianText("سال انتخاب‌شده: ${selectedCalendarYear.toString().toPersianDigits()}", fontWeight = FontWeight.Bold)
            }
            DropdownMenu(expanded = yearMenuExpanded, onDismissRequest = { yearMenuExpanded = false }) {
                (maxOf(1347, syncYear - 5)..minOf(1500, syncYear + 10)).forEach { optionYear ->
                    DropdownMenuItem(text = { PersianText(optionYear.toString().toPersianDigits()) }, onClick = {
                        selectedCalendarYear = optionYear
                        yearMenuExpanded = false
                    })
                }
            }
        }
        Button(onClick = { onSyncHolidays(selectedCalendarYear) }, enabled = !holidaySyncing, modifier = Modifier.fillMaxWidth()) {
            PersianText(if (holidaySyncing) "در حال دریافت تقویم…" else "دریافت مناسبت‌های سال انتخاب‌شده")
        }
        if (holidaySyncMessage.isNotBlank()) PersianText(holidaySyncMessage, style = MaterialTheme.typography.bodySmall, color = if (holidaySyncMessage.contains("نشد")) AppPalette.Error else AppPalette.Primary)
        val syncedAt = remember(selectedCalendarYear, tick, holidaySyncMessage) { db.getSettingText("calendar_last_online_$selectedCalendarYear", "0").toLongOrNull() ?: 0L }
        PersianText("آخرین به‌روزرسانی آنلاین تقویم: " + if (syncedAt == 0L) "هنوز انجام نشده" else formattedSyncStamp(syncedAt), fontSize = 11.sp, color = AppPalette.Muted)
        Divider()
        AlertManagementSettings()
        Divider()
        OutlinedButton(onClick = onHelp, modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(8.dp))) {
            PersianText("راهنمای جامع استفاده از مورخ", fontWeight = FontWeight.Bold)
        }
        Divider()
        PersianText("پشتیبان‌گیری و بازیابی", style = MaterialTheme.typography.titleMedium)
        Button(onClick = onBackup, modifier = Modifier.fillMaxWidth()) { PersianText("ساخت پشتیبان Excel (.xlsx)") }
        Button(onClick = onRestore, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = AppPalette.Primary, contentColor = Color.White)) { PersianText("بازیابی از فایل Excel", color = Color.White) }
        Button(onClick = onCsvBackup, modifier = Modifier.fillMaxWidth()) { PersianText("ساخت پشتیبان CSV (.csv)") }
        Button(onClick = onCsvRestore, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = AppPalette.Primary, contentColor = Color.White)) { PersianText("بازیابی از فایل CSV", color = Color.White) }
        PersianText("بازیابی پشتیبان کامل، اطلاعات فعلی را پس از تأیید جایگزین می‌کند.", style = MaterialTheme.typography.bodySmall)
        PersianText("دسترسی به فایل‌ها از طریق انتخابگر امن اندروید انجام می‌شود. هر بار که فایلی انتخاب کنی، اندروید مجوز همان فایل را به برنامه می‌دهد و نیازی به دسترسی کامل حافظه نیست.", fontSize = 11.sp, color = AppPalette.Muted)
        var scheduleMode by remember(tick) { mutableStateOf(db.getSettingText("work_schedule_mode", "شناور")) }
        var dailyHours by remember(tick) { mutableStateOf(db.getSettingText("workday_hours", "07:00")) }
        var thursdayHours by remember(tick) { mutableStateOf(db.getSettingText("thursday_hours_value", "05:00")) }
        var weekdayStart by remember(tick) { mutableStateOf(db.getSettingText("fixed_weekday_start", "07:00")) }
        var weekdayEnd by remember(tick) { mutableStateOf(db.getSettingText("fixed_weekday_end", "14:00")) }
        var thursdayStart by remember(tick) { mutableStateOf(db.getSettingText("fixed_thursday_start", "07:00")) }
        var thursdayEnd by remember(tick) { mutableStateOf(db.getSettingText("fixed_thursday_end", "12:00")) }
        var scheduleMessage by remember { mutableStateOf("") }
        Card(
            colors = CardDefaults.cardColors(containerColor = AppPalette.SurfaceAlt),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
                .border(2.dp, Color(0xFFC7A24A), RoundedCornerShape(14.dp))
                .padding(3.dp)
                .border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(11.dp))
        ) {
            Column(Modifier.fillMaxWidth().padding(11.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PersianText("ساعت کار موظفی", modifier = Modifier.fillMaxWidth(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = AppPalette.Ink, textAlign = TextAlign.Center)
                PersianText("فقط یکی از دو روش زیر فعال است؛ انتخاب هر روش، روش دیگر را غیرفعال می‌کند.", fontSize = 11.sp, color = AppPalette.Muted, textAlign = TextAlign.Center)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { scheduleMode = "ثابت" },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (scheduleMode == "ثابت") AppPalette.Primary else AppPalette.PrimarySoft,
                            contentColor = if (scheduleMode == "ثابت") Color.White else AppPalette.Ink
                        )
                    ) { PersianText("ثابت", color = if (scheduleMode == "ثابت") Color.White else AppPalette.Ink) }
                    Button(
                        onClick = { scheduleMode = "شناور" },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (scheduleMode == "شناور") AppPalette.Primary else AppPalette.PrimarySoft,
                            contentColor = if (scheduleMode == "شناور") Color.White else AppPalette.Ink
                        )
                    ) { PersianText("شناور", color = if (scheduleMode == "شناور") Color.White else AppPalette.Ink) }
                }
                Divider(color = Color(0xFFC7A24A))
                if (scheduleMode == "ثابت") {
                    PersianText("ساعت حضور ثابت شنبه تا چهارشنبه", fontWeight = FontWeight.SemiBold, color = AppPalette.Ink, fontSize = 13.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Box(Modifier.weight(1f)) { ReplaceableSettingsTimeField(weekdayStart, { weekdayStart = it }, "از ساعت") }
                        Box(Modifier.weight(1f)) { ReplaceableSettingsTimeField(weekdayEnd, { weekdayEnd = it }, "تا ساعت") }
                    }
                    PersianText("ساعت حضور ثابت پنجشنبه", fontWeight = FontWeight.SemiBold, color = AppPalette.Ink, fontSize = 13.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Box(Modifier.weight(1f)) { ReplaceableSettingsTimeField(thursdayStart, { thursdayStart = it }, "از ساعت") }
                        Box(Modifier.weight(1f)) { ReplaceableSettingsTimeField(thursdayEnd, { thursdayEnd = it }, "تا ساعت") }
                    }
                } else {
                    PersianText("میزان موظفی شناور", fontWeight = FontWeight.SemiBold, color = AppPalette.Ink, fontSize = 13.sp)
                    ReplaceableSettingsTimeField(dailyHours, { dailyHours = it }, "شنبه تا چهارشنبه (ساعت:دقیقه)")
                    ReplaceableSettingsTimeField(thursdayHours, { thursdayHours = it }, "پنجشنبه (ساعت:دقیقه)")
                }
                Button(onClick = {
                    val valid = if (scheduleMode == "ثابت") {
                        mins(weekdayStart) != null && mins(weekdayEnd) != null && timeRangeMinutes(weekdayStart, weekdayEnd) > 0 &&
                            mins(thursdayStart) != null && mins(thursdayEnd) != null && timeRangeMinutes(thursdayStart, thursdayEnd) > 0
                    } else mins(dailyHours) != null && mins(thursdayHours) != null
                    if (!valid) {
                        scheduleMessage = "ساعت‌ها معتبر نیستند؛ ابتدا هر چهار ساعتِ شروع و پایان را بررسی کن."
                    } else {
                        db.setSettingText("work_schedule_mode", scheduleMode)
                        db.setSettingText("workday_hours", dailyHours)
                        db.setSettingText("thursday_hours_value", thursdayHours)
                        db.setSettingText("fixed_weekday_start", weekdayStart)
                        db.setSettingText("fixed_weekday_end", weekdayEnd)
                        db.setSettingText("fixed_thursday_start", thursdayStart)
                        db.setSettingText("fixed_thursday_end", thursdayEnd)
                        scheduleMessage = "تنظیم ساعت کار موظفی ذخیره شد. روزهای ثبت‌شده، روش ثبت همان روز را حفظ می‌کنند."
                        tick++
                        onScheduleSettingsChanged()
                    }
                }, modifier = Modifier.fillMaxWidth()) { PersianText("ذخیره ساعت کار موظفی") }
                if (scheduleMessage.isNotBlank()) PersianText(scheduleMessage, fontSize = 11.sp, color = if (scheduleMessage.contains("معتبر نیست")) AppPalette.Error else AppPalette.Success)
            }
        }
        Divider()
        Spacer(Modifier.height(12.dp))
        PersianText("نسخهٔ برنامه: ۰.۶۶.۰", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 12.sp, color = AppPalette.Ink)
        PersianText("تهیه کننده: نواب", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AppPalette.Ink)
        Spacer(Modifier.height(8.dp))
        PersianText(
            "ثواب بهره‌برداری از این اثر نثار امام شهید و یاران او",
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp),
            textAlign = TextAlign.Center,
            fontSize = 15.sp, fontFamily = FontFamily(Font(R.font.aref_ruqaa_regular)),
            fontWeight = FontWeight.Normal, color = AppPalette.Ink, lineHeight = 25.sp
        )
    }
}



@Composable
fun SummaryTile(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier.border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(12.dp)), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 10.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            PersianText(value, style = MaterialTheme.typography.titleMedium)
            PersianText(label, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ReportScreen(
    db: WorkDb, year: Int, monthNumber: Int, refresh: Int,
    modifier: Modifier = Modifier, annual: Boolean,
    onPeriodChange: (Int, Int) -> Unit,
    export: (Boolean, Boolean) -> Unit, exportPdf: (Boolean, Boolean) -> Unit,
    exportSummaryExcel: (Boolean) -> Unit, exportSummaryPdf: (Boolean) -> Unit,
    onOpenDay: (String) -> Unit = {}
) {
    var monthMenuExpanded by remember { mutableStateOf(false) }
    var yearMenuExpanded by remember { mutableStateOf(false) }
    var includeReportNotes by remember { mutableStateOf(true) }
    var selectedCards by remember(annual, year, monthNumber) { mutableStateOf<Set<String>>(emptySet()) }
    var showDeleteSelectedDialog by remember { mutableStateOf(false) }
    var localDataRevision by remember { mutableIntStateOf(0) }
    BackHandler(enabled = selectedCards.isNotEmpty()) { selectedCards = emptySet() }
    val monthKey = "%04d-%02d".format(year, monthNumber)
    val deductionSettingKey = "tourahi_deduction_$monthKey"
    var savedTourahiDeduction by remember(monthKey, refresh) {
        mutableStateOf(db.getSettingText(deductionSettingKey, "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0)
    }
    var tourahiDeductionInput by remember(monthKey, refresh) { mutableStateOf(TextFieldValue("")) }
    val storedMonthDays = remember(monthKey, refresh, localDataRevision) { db.allDays(monthKey).associateBy { it.date } }
    val reportDays = remember(year, monthNumber, refresh, localDataRevision) { reportPeriodDays(db, year, monthNumber, false) }
    val yearDays = remember(year, refresh, localDataRevision) { reportPeriodDays(db, year, monthNumber, true) }
    val yearPrefix = "%04d-".format(year)
    val yearShiftMinutes = remember(year, refresh, localDataRevision) {
        db.allDaysForBackup().filter { it.shiftEnabled && (it.shiftStartDate.ifBlank { it.date }).startsWith(yearPrefix) }
            .sumOf { shiftDurationMinutes(it, it.date) }
    }
    val monthShiftDays = remember(monthKey, refresh, localDataRevision) {
        db.allDaysForBackup().filter { it.shiftEnabled && (it.shiftStartDate.ifBlank { it.date }).startsWith(monthKey) }
    }
    val selectedDays = if (annual) yearDays else reportDays
    val totalHourlyLeave = periodEffectiveHourlyLeaveMinutes(selectedDays, db)
    val totalRequired = periodRequiredMinutes(selectedDays, db)
    val totalRegistered = periodRegisteredMinutes(selectedDays, db)
    val totalOvertime = periodOvertimeMinutes(selectedDays, db)
    val totalShift = if (annual) yearShiftMinutes else monthShiftDays.sumOf { shiftDurationMinutes(it, it.date) }
    val totalWork = selectedDays.sumOf { duration(it, db) } + totalShift
    val shiftCount = if (annual) yearDays.count { it.shiftEnabled } else monthShiftDays.size
    val missionCount = selectedDays.count { hasDayStatus(it,"مأموریت") }
    val (rawEntitledCount, sickCount, _) = periodLeaveStats(selectedDays,db)
    val hourlyLeaveCredit = if (annual) (1..12).sumOf { m -> hourlyLeaveCreditDays(yearDays.filter { it.date.startsWith("%04d-%02d".format(year, m)) }, db) }
        else hourlyLeaveCreditDays(selectedDays, db)
    val savedDeductionTotal = if (annual) (1..12).sumOf { m ->
        db.getSettingText("tourahi_deduction_%04d-%02d".format(year, m), "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
    } else savedTourahiDeduction
    val effectiveDeductionTotal = if (annual) (1..12).sumOf { m ->
        val requested = db.getSettingText("tourahi_deduction_%04d-%02d".format(year, m), "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
        val prefix = "%04d-%02d".format(year, m)
        val monthEntitledRaw = yearDays.filter { it.date.startsWith(prefix) }.count { isEntitledCountable(it, db) }
        minOf(requested, monthEntitledRaw)
    } else minOf(savedTourahiDeduction, rawEntitledCount)
    val entitledCount = (rawEntitledCount + hourlyLeaveCredit - effectiveDeductionTotal).coerceAtLeast(0)
    val tourahiCount = savedDeductionTotal

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 5.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(bottom = 14.dp)
    ) {
        item {
            if (annual) {
                Box(Modifier.fillMaxWidth()) {
                    Button(onClick = { yearMenuExpanded = true }, modifier = Modifier.fillMaxWidth().border(1.dp, AppPalette.Primary, RoundedCornerShape(10.dp)).padding(2.dp).border(1.dp, AppPalette.Primary, RoundedCornerShape(8.dp)), shape = RoundedCornerShape(7.dp), colors = ButtonDefaults.buttonColors(containerColor = AppPalette.PrimarySoft, contentColor = AppPalette.Primary), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 9.dp)) {
                        PersianText("سال: ${persianDigits(year.toString())}  ⌄", fontSize = 13.sp, maxLines = 1, color = AppPalette.Primary, fontWeight = FontWeight.Bold)
                    }
                    DropdownMenu(expanded = yearMenuExpanded, onDismissRequest = { yearMenuExpanded = false }) {
                        ((year - 5)..(year + 1)).toList().reversed().forEach { y ->
                            DropdownMenuItem(text = { PersianText(persianDigits(y.toString())) }, onClick = { yearMenuExpanded = false; onPeriodChange(y, monthNumber) })
                        }
                    }
                }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f)) {
                        Button(onClick = { monthMenuExpanded = true }, modifier = Modifier.fillMaxWidth().border(1.dp, AppPalette.Primary, RoundedCornerShape(10.dp)).padding(2.dp).border(1.dp, AppPalette.Primary, RoundedCornerShape(8.dp)), shape = RoundedCornerShape(7.dp), colors = ButtonDefaults.buttonColors(containerColor = AppPalette.PrimarySoft, contentColor = AppPalette.Primary), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 9.dp)) {
                            PersianText("ماه: ${JalaliMonthNames.getOrElse(monthNumber - 1) { "ماه" }}  ⌄", fontSize = 13.sp, maxLines = 1, color = AppPalette.Primary, fontWeight = FontWeight.Bold)
                        }
                        DropdownMenu(expanded = monthMenuExpanded, onDismissRequest = { monthMenuExpanded = false }) {
                            JalaliMonthNames.forEachIndexed { index, name -> DropdownMenuItem(text = { PersianText(name) }, onClick = { monthMenuExpanded = false; onPeriodChange(year, index + 1) }) }
                        }
                    }
                    Box(Modifier.weight(1f)) {
                        Button(onClick = { yearMenuExpanded = true }, modifier = Modifier.fillMaxWidth().border(1.dp, AppPalette.Primary, RoundedCornerShape(10.dp)).padding(2.dp).border(1.dp, AppPalette.Primary, RoundedCornerShape(8.dp)), shape = RoundedCornerShape(7.dp), colors = ButtonDefaults.buttonColors(containerColor = AppPalette.PrimarySoft, contentColor = AppPalette.Primary), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 9.dp)) {
                            PersianText("سال: ${persianDigits(year.toString())}  ⌄", fontSize = 13.sp, maxLines = 1, color = AppPalette.Primary, fontWeight = FontWeight.Bold)
                        }
                        DropdownMenu(expanded = yearMenuExpanded, onDismissRequest = { yearMenuExpanded = false }) {
                            ((year - 5)..(year + 1)).toList().reversed().forEach { y -> DropdownMenuItem(text = { PersianText(persianDigits(y.toString())) }, onClick = { yearMenuExpanded = false; onPeriodChange(y, monthNumber) }) }
                        }
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = AppPalette.Surface), shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
                    .border(2.dp, Color(0xFFC7A24A), RoundedCornerShape(14.dp))
                    .padding(3.dp)
                    .border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(11.dp))) {
                Column(Modifier.fillMaxWidth().padding(7.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Box(Modifier.fillMaxWidth().border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(7.dp)).padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                        PersianText(if (annual) "کارکرد سال" else "کارکرد ماه", modifier = Modifier.fillMaxWidth(), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AppPalette.Ink, textAlign = TextAlign.Center)
                    }
                    Divider(color = Color(0xFFC7A24A))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        ReportMetricTile("کل کارکرد", hm(totalWork), "◷", AppPalette.Ink, Modifier.weight(1f))
                        ReportMetricTile("اضافه‌کار", hm(totalOvertime), "◴", AppPalette.Ink, Modifier.weight(1f))
                        ReportMetricTile("جمع مدت شیفت", hm(totalShift), "◷", Color.Black, Modifier.weight(1f))
                        ReportMetricTile("تعداد شیفت", shiftCount.toString(), "▦", Color.Black, Modifier.weight(1f))
                    }
                    Divider(color = AppPalette.Border)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        ReportMetricTile(
                            "مرخصی ساعتی", hm(totalHourlyLeave), "◷",
                            if (!annual && totalHourlyLeave > 8 * 60) AppPalette.Error else AppPalette.Ink,
                            Modifier.weight(1f),
                            background = if (!annual && totalHourlyLeave > 8 * 60) AppPalette.ErrorSoft else AppPalette.SurfaceAlt
                        )
                        ReportMetricTile("مأموریت", missionCount.toString(), "✈", Color.Black, Modifier.weight(1f))
                        ReportMetricTile("استحقاقی", entitledCount.toString(), "☼", Color.Black, Modifier.weight(1f))
                        ReportMetricTile("استعلاجی", sickCount.toString(), "✚", Color.Black, Modifier.weight(1f))
                        ReportMetricTile("توراهی", tourahiCount.toString(), "↗", Color.Black, Modifier.weight(1f))
                    }
                    Divider(color = Color(0xFFC7A24A))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ReportMetricTile("کل موظفی", hm(totalRequired), "⌚", AppPalette.Ink, Modifier.weight(1f))
                        ReportMetricTile("موظفی ثبتی", hm(totalRegistered), "✓", AppPalette.Ink, Modifier.weight(1f))
                    }
                }
            }
        }
        if (!annual && periodFloatingUnderworkMinutes(selectedDays, db) > 0) item {
            Card(colors = CardDefaults.cardColors(containerColor = AppPalette.PrimarySoft), shape = RoundedCornerShape(9.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(9.dp))) {
                PersianText(floatingUnderworkReminder(selectedDays, db), modifier = Modifier.fillMaxWidth().padding(9.dp), fontSize = 11.sp, color = AppPalette.Ink, lineHeight = 15.sp)
            }
        }
        if (!annual && hourlyLeaveCredit > 0) item {
            Card(colors = CardDefaults.cardColors(containerColor = AppPalette.ErrorSoft), shape = RoundedCornerShape(9.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(9.dp))) {
                PersianText(hourlyLeaveCreditReminder(selectedDays, db), modifier = Modifier.fillMaxWidth().padding(9.dp), fontSize = 11.sp, color = AppPalette.Error, lineHeight = 15.sp)
            }
        }
        if (!annual) item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AppPalette.PrimarySoft),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(10.dp))
            ) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 7.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    PersianText("توراهی", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        PersianText(
                            "میزان کسر توراهی از استحقاقی‌های ماه جاری",
                            modifier = Modifier.weight(1f), fontSize = 11.sp, color = Color.Black, lineHeight = 15.sp
                        )
                        BasicTextField(
                            value = tourahiDeductionInput.copy(text = tourahiDeductionInput.text.toPersianDigits()),
                            onValueChange = { edited ->
                                val digits = edited.text.toLatinDigits().filter { ch -> ch.isDigit() }.take(3)
                                tourahiDeductionInput = TextFieldValue(
                                    text = digits,
                                    selection = TextRange(edited.selection.start.coerceAtMost(digits.length), edited.selection.end.coerceAtMost(digits.length))
                                )
                            },
                            modifier = Modifier.width(76.dp).height(42.dp).onFocusChanged { state ->
                                if (state.isFocused) {
                                    tourahiDeductionInput = tourahiDeductionInput.copy(selection = TextRange(0, tourahiDeductionInput.text.length))
                                }
                            }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            textStyle = TextStyle(fontSize = 14.sp, textAlign = TextAlign.Center, color = Color.Black),
                            decorationBox = { innerTextField ->
                                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                    Box(Modifier.wrapContentWidth()
                                        .background(AppPalette.SurfaceAlt, RoundedCornerShape(7.dp))
                                        .border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(7.dp))
                                        .padding(horizontal = 9.dp, vertical = 5.dp), contentAlignment = Alignment.Center) {
                                        if (tourahiDeductionInput.text.isEmpty()) PersianText("روز", fontSize = 10.sp, color = AppPalette.Primary)
                                        innerTextField()
                                    }
                                }
                            }
                        )
                        Button(onClick = {
                            val amount = tourahiDeductionInput.text.toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
                            db.setSettingText(deductionSettingKey, amount.toString())
                            savedTourahiDeduction = amount
                            tourahiDeductionInput = TextFieldValue("")
                        }, colors = ButtonDefaults.buttonColors(containerColor = AppPalette.PrimarySoft, contentColor = AppPalette.Primary), modifier = Modifier.border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(8.dp)), contentPadding = PaddingValues(horizontal = 10.dp, vertical = 7.dp)) {
                            PersianText("ذخیره", fontSize = 11.sp, color = Color.Black)
                        }
                    }
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = includeReportNotes, onCheckedChange = { includeReportNotes = it })
                    PersianText("درج یادداشت‌ها در خروجی گزارش", fontSize = 12.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { export(annual, includeReportNotes) }, modifier = Modifier.weight(1f)) {
                        PersianText("خروجی Excel", fontSize = 12.sp)
                    }
                    Button(onClick = { exportPdf(annual, includeReportNotes) }, modifier = Modifier.weight(1f)) {
                        PersianText("خروجی PDF", fontSize = 12.sp)
                    }
                }
                if (annual) {
                    Spacer(Modifier.height(5.dp))
                    PersianText("گزارش جامع سالانه • یک صفحه A4", fontSize = 13.sp,
                        fontWeight = FontWeight.Bold, color = AppPalette.Primary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(onClick = { exportSummaryExcel(includeReportNotes) }, modifier = Modifier.weight(1f)) {
                            PersianText("خلاصه جامع Excel", fontSize = 12.sp)
                        }
                        Button(onClick = { exportSummaryPdf(includeReportNotes) }, modifier = Modifier.weight(1f)) {
                            PersianText("خلاصه جامع PDF A4", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        if (!annual) {
            item(key = "month_daily_summary") {
                Card(
                    colors = CardDefaults.cardColors(containerColor = AppPalette.Surface),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                        .border(2.dp, Color(0xFFC7A24A), RoundedCornerShape(16.dp))
                        .padding(3.dp)
                        .border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(13.dp))
                ) {
                    Column(Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Box(Modifier.fillMaxWidth().border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(7.dp)).padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                            PersianText(
                                "کارت روز",
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = AppPalette.Primary
                            )
                        }
                        Divider(color = Color(0xFFC7A24A))
                        reportDays.forEach { reportDay ->
                            // Read the independent saved workday for each date.
                            val saved = if (db.hasWorkDay(reportDay.date)) db.getDay(reportDay.date) else reportDay
                            ReportDayCard(
                                applyCalendarHoliday(saved, db), db,
                                db.displayHolidayTitle(reportDay.date) ?: officialJalaliHolidays(year).toMap()[reportDay.date],
                                selected = reportDay.date in selectedCards,
                                onClick = {
                                    if (selectedCards.isNotEmpty()) selectedCards = if (reportDay.date in selectedCards) selectedCards - reportDay.date else selectedCards + reportDay.date
                                    else onOpenDay(reportDay.date)
                                },
                                onLongClick = { selectedCards = selectedCards + reportDay.date }
                            )
                        }
                    }
                }
            }
        } else {
            item { PersianText("خلاصهٔ ماه‌به‌ماه سال ${persianDigits(year.toString())}", style = MaterialTheme.typography.titleMedium, color = AppPalette.Primary) }
            items((1..12).toList()) { m ->
                val monthDays = yearDays.filter { it.date.startsWith("%04d-%02d".format(year, m)) }
                val monthShift = db.allDaysForBackup().filter { it.shiftEnabled && (it.shiftStartDate.ifBlank { it.date }).startsWith("%04d-%02d".format(year, m)) }.sumOf { shiftDurationMinutes(it, it.date) }
                val monthCardKey = "%04d-%02d".format(year, m)
                val monthSelected = monthCardKey in selectedCards
                Card(colors = CardDefaults.cardColors(containerColor = if (monthSelected) AppPalette.PrimarySoft else AppPalette.SurfaceAlt), shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                        .border(if (monthSelected) 2.dp else 1.dp, if (monthSelected) AppPalette.Primary else Color(0xFFC7A24A), RoundedCornerShape(12.dp))
                        .combinedClickable(
                            onClick = { if (selectedCards.isNotEmpty()) selectedCards = if (monthSelected) selectedCards - monthCardKey else selectedCards + monthCardKey },
                            onLongClick = { selectedCards = selectedCards + monthCardKey }
                        )) {
                    Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.fillMaxWidth().border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(6.dp)).padding(vertical = 4.dp), contentAlignment = Alignment.Center) {
                            PersianText(JalaliMonthNames[m - 1], style = MaterialTheme.typography.titleSmall, color = AppPalette.Ink, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            if (monthSelected) PersianText("✓ انتخاب‌شده", fontSize = 11.sp, color = AppPalette.Primary, fontWeight = FontWeight.Bold)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            PersianText("کل کارکرد ${hm(monthDays.sumOf { duration(it, db) } + monthShift)}", fontSize = 11.sp, color = AppPalette.Ink)
                            PersianText("اضافه‌کار ${hm(periodOvertimeMinutes(monthDays, db))}", fontSize = 11.sp, color = AppPalette.Success)
                            PersianText("شیفت ${hm(monthShift)}", fontSize = 11.sp, color = AppPalette.Primary)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            PersianText("کل موظفی ${hm(periodRequiredMinutes(monthDays, db))}", fontSize = 11.sp, color = AppPalette.Ink)
                            PersianText("موظفی ثبتی ${hm(periodRegisteredMinutes(monthDays, db))}", fontSize = 11.sp, color = AppPalette.Ink)
                        }
                        val (rawMonthEntitled, monthSick, _) = periodLeaveStats(monthDays,db)
                        val monthDeduction = db.getSettingText("tourahi_deduction_%04d-%02d".format(year, m), "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
                        val monthCredit = hourlyLeaveCreditDays(monthDays, db)
                        val monthEntitled = (rawMonthEntitled + monthCredit - monthDeduction).coerceAtLeast(0)
                        val monthTravel = monthDeduction
                        PersianText("استحقاقی: ${monthEntitled.toString().toPersianDigits()} | استعلاجی: ${monthSick.toString().toPersianDigits()} | مأموریت: ${monthDays.count { hasDayStatus(it,"مأموریت") }.toString().toPersianDigits()} | توراهی: ${monthTravel.toString().toPersianDigits()}", fontSize = 11.sp)
                        val monthUnderwork = periodFloatingUnderworkMinutes(monthDays, db)
                        if (monthUnderwork > 0) PersianText("کم‌کاری ناشی از مرخصی شناور: ${hm(monthUnderwork)} از اضافه‌کاری شناور کسر شد.", fontSize = 10.sp, color = AppPalette.Primary)
                    }
                }
            }
        }
        item(key = "bulk_delete_footer") {
            Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                PersianText(
                    if (annual) "برای انتخاب ماه، انگشت را روی کارت ماه نگه دار؛ با دکمه بازگشت انتخاب‌ها لغو می‌شوند."
                    else "برای انتخاب روز، انگشت را روی کارت روز نگه دار؛ با دکمه بازگشت انتخاب‌ها لغو می‌شوند.",
                    fontSize = 11.sp, color = AppPalette.Muted, textAlign = TextAlign.Center
                )
                Button(
                    onClick = { showDeleteSelectedDialog = true },
                    enabled = selectedCards.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = AppPalette.Error),
                    contentPadding = PaddingValues(vertical = 10.dp)
                ) {
                    PersianText("حذف کارت‌های انتخاب‌شده (${selectedCards.size.toString().toPersianDigits()})", fontSize = 13.sp)
                }
            }
        }
    }
    if (showDeleteSelectedDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteSelectedDialog = false },
            title = { PersianText("تأیید حذف اطلاعات", fontWeight = FontWeight.Bold) },
            text = {
                PersianText(
                    if (annual) "اطلاعات کاری تمام روزهای ${selectedCards.size.toString().toPersianDigits()} ماه انتخاب‌شده حذف می‌شود. تعطیلات رسمی تقویم و تنظیمات عمومی برنامه باقی می‌مانند. این عملیات قابل بازگشت نیست. ادامه می‌دهی؟"
                    else "اطلاعات ${selectedCards.size.toString().toPersianDigits()} روز انتخاب‌شده حذف می‌شود. تعطیلات رسمی تقویم و تنظیمات عمومی برنامه باقی می‌مانند. این عملیات قابل بازگشت نیست. ادامه می‌دهی؟"
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val targets = selectedCards.toList()
                    if (annual) targets.forEach { key ->
                        val parts = key.split("-")
                        if (parts.size == 2) db.deleteWorkRecordsForMonth(parts[0].toIntOrNull() ?: year, parts[1].toIntOrNull() ?: 0)
                    } else targets.forEach(db::deleteWorkRecord)
                    selectedCards = emptySet()
                    showDeleteSelectedDialog = false
                    localDataRevision++
                }) { PersianText("حذف اطلاعات", color = AppPalette.Error) }
            },
            dismissButton = { TextButton(onClick = { showDeleteSelectedDialog = false }) { PersianText("انصراف") } }
        )
    }
}

@Composable
private fun ReportMetricTile(title: String, value: String, symbol: String, valueColor: Color, modifier: Modifier = Modifier, background: Color = AppPalette.SurfaceAlt) {
    Column(modifier = modifier.heightIn(min = 86.dp).background(background, RoundedCornerShape(9.dp)).border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(9.dp)).padding(horizontal = 3.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        PersianText(title, fontSize = 10.sp, color = AppPalette.Ink, textAlign = TextAlign.Center, maxLines = 2, lineHeight = 12.sp)
        Spacer(Modifier.height(2.dp))
        PersianText(symbol, fontSize = 17.sp, color = valueColor, maxLines = 1)
        PersianText(value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = valueColor, maxLines = 1)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ReportDayCard(day: WorkDay, db: WorkDb, holidayTitle: String?, onClick: (() -> Unit)? = null, onLongClick: (() -> Unit)? = null, selected: Boolean = false) {
    val weekDay = jalaliWeekday(day.date)?.let { JalaliWeekdayNames.getOrNull(it) }.orEmpty()
    val holidayEntryExists = isHolidayWorkDay(day)

    // Only include entry/exit values that the user actually entered.
    // Keep the original order: entry 1, exit 1, entry 2, exit 2, entry 3, exit 3.
    val timeEntries: List<Pair<String, String>> = if (holidayEntryExists) {
        buildList {
            if (day.holidayIn.isNotBlank()) add("ورود" to day.holidayIn)
            if (day.holidayOut.isNotBlank()) add("خروج" to day.holidayOut)
            if (day.holidayIn2.isNotBlank()) add("ورود" to day.holidayIn2)
            if (day.holidayOut2.isNotBlank()) add("خروج" to day.holidayOut2)
        }
    } else {
        buildList {
            if (day.in1.isNotBlank()) add("ورود" to day.in1)
            if (day.out1.isNotBlank()) add("خروج" to day.out1)
            if (day.in2.isNotBlank()) add("ورود" to day.in2)
            if (day.out2.isNotBlank()) add("خروج" to day.out2)
            if (day.in3.isNotBlank()) add("ورود" to day.in3)
            if (day.out3.isNotBlank()) add("خروج" to day.out3)
        }
    }

    val shiftDuration = if (day.shiftEnabled) shiftDurationMinutes(day, day.date) else 0

    // Holiday cards are distinguished with a soft red fill and red outline.
    // Friday is detected by the Jalali weekday index used in this project (5 = Friday).
    val isHolidayCard = jalaliWeekday(day.date) == 5 ||
        dayStatuses(day).any { it in workHolidayStatuses } ||
        db.officialHolidayTitle(day.date) != null || db.holidayTitle(day.date) != null ||
        officialJalaliHolidays(day.date.take(4).toIntOrNull() ?: 0).toMap().containsKey(day.date)
    val holidayCardBackground = if (isHolidayCard) AppPalette.ErrorSoft else AppPalette.SurfaceAlt
    val holidayCardBorder = if (isHolidayCard) AppPalette.ErrorBorder else Color(0xFFC7A24A)
    val holidayHeaderColor = if (isHolidayCard) AppPalette.Error else AppPalette.Primary

    // Show only the selected day category, rather than all available categories.
    val statusItems = buildList {
        add(normalizedDayCategory(day))
        normalizedAttendance(day).takeIf { it.isNotBlank() }?.let(::add)
        if (day.shiftEnabled) add("شیفت")
        add("حالت ${day.scheduleMode}")
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = holidayCardBackground),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
            .border(2.dp, Color(0xFFC7A24A), RoundedCornerShape(14.dp))
            .padding(3.dp)
            .border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(11.dp))
            .border(if (selected) 1.5.dp else 0.5.dp, if (selected) AppPalette.Primary else holidayCardBorder, RoundedCornerShape(11.dp))
            .then(if (onClick != null || onLongClick != null) Modifier.combinedClickable(
                onClick = { onClick?.invoke() },
                onLongClick = { onLongClick?.invoke() }
            ) else Modifier)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(7.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                PersianText(
                    "${weekDay} ${jalaliDisplayDate(day.date)}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = holidayHeaderColor
                )
                PersianText(if (selected) "✓" else "▦", fontSize = 20.sp, color = if (selected) AppPalette.Primary else if (isHolidayCard) AppPalette.Error else AppPalette.Muted)
            }

            Divider(color = if (isHolidayCard) Color(0xFFF0B4B4) else Color(0xFFD9E8F8))

            if (timeEntries.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    timeEntries.forEach { (label, time) ->
                        Column(
                            Modifier.weight(1f)
                                .defaultMinSize(minHeight = 55.dp)
                                .background(AppPalette.SurfaceAlt, RoundedCornerShape(8.dp))
                                .border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(8.dp))
                                .padding(horizontal = 2.dp, vertical = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            PersianText(label, fontSize = 9.sp, color = Color.Black, maxLines = 1)
                            PersianText(
                                time.toPersianDigits(),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black,
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            if (statusItems.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    statusItems.forEach { status ->
                        val isShift = status == "شیفت"
                        val bg = when {
                            isShift -> AppPalette.SurfaceAlt
                            status == "تعطیل مناسبتی" -> AppPalette.SuccessSoft
                            status.startsWith("حالت ") -> AppPalette.PrimarySoft
                            else -> AppPalette.Primary
                        }
                        val foreground = when {
                            isShift -> AppPalette.Primary
                            status == "تعطیل مناسبتی" -> AppPalette.Success
                            status.startsWith("حالت ") -> AppPalette.Ink
                            else -> Color.White
                        }
                        Surface(
                            modifier = Modifier.weight(1f).heightIn(min = 52.dp),
                            shape = RoundedCornerShape(8.dp),
                            color = bg,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                Color(0xFFC7A24A)
                            )
                        ) {
                            Box(
                                Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 5.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                PersianText(
                                    status,
                                    fontSize = 10.sp,
                                    color = foreground,
                                    textAlign = TextAlign.Center,
                                    maxLines = 2,
                                    lineHeight = 12.sp
                                )
                            }
                        }
                    }
                }
            }

            if (hasDayStatus(day,"تعطیل مناسبتی") || !holidayTitle.isNullOrBlank()) {
                Row(
                    Modifier.fillMaxWidth()
                        .border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(8.dp))
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PersianText("✎", fontSize = 17.sp, color = if (isHolidayCard) AppPalette.Primary else AppPalette.Primary)
                    PersianText("مناسبت / عنوان تعطیلی:", fontSize = 11.sp, color = if (isHolidayCard) AppPalette.Primary else AppPalette.Primary)
                    PersianText(
                        holidayTitle ?: "—",
                        modifier = Modifier.weight(1f),
                        fontSize = 11.sp,
                        color = AppPalette.Primary,
                        maxLines = 3,
                        lineHeight = 14.sp
                    )
                }
            }

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                ReportValueTile("کل کار", hm(duration(day, db)), AppPalette.SurfaceAlt, AppPalette.Ink, Modifier.weight(1f))
                ReportValueTile("مدت شیفت", hm(shiftDuration), AppPalette.SurfaceAlt, AppPalette.Ink, Modifier.weight(1f))
                ReportValueTile("مرخصی ساعتی", hm(hourlyLeaveMinutes(day, db)), AppPalette.SurfaceAlt, AppPalette.Ink, Modifier.weight(1f))
                ReportValueTile("اضافه‌کار", hm(overtimeMinutes(day, db)), AppPalette.SurfaceAlt, AppPalette.Ink, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                ReportValueTile("موظفی ثبتی", hm(registeredMandatoryMinutes(day, db)), AppPalette.PrimarySoft, AppPalette.Ink, Modifier.weight(1f))
                val remaining = remainingMandatoryMinutes(day, db)
                ReportValueTile("مانده موظفی", hm(remaining), if (remaining > 0) AppPalette.ErrorSoft else AppPalette.SurfaceAlt, if (remaining > 0) AppPalette.Error else AppPalette.Ink, Modifier.weight(1f))
            }
            if (hasInvalidFixedLeave(day, db)) {
                PersianText("در حالت ثابت، مرخصی ساعتی فقط در بازه ساعت حضور مجاز است؛ بازه خارج از این ساعت‌ها در محاسبه منظور نمی‌شود.", fontSize = 10.sp, color = AppPalette.Error, lineHeight = 13.sp)
            }

            // The note wraps to as many lines as necessary; the card grows with the text.
            Row(
                Modifier.fillMaxWidth()
                    .border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(8.dp))
                    .padding(8.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PersianText("▤", fontSize = 17.sp, color = if (isHolidayCard) AppPalette.Primary else AppPalette.Primary)
                PersianText("یادداشت روز:", fontSize = 11.sp, color = AppPalette.Primary)
                PersianText(
                    day.note.ifBlank { "—" }.toPersianDigits(),
                    modifier = Modifier.weight(1f),
                    fontSize = 12.sp,
                    color = if (isHolidayCard) AppPalette.Muted else AppPalette.Ink,
                    lineHeight = 16.sp,
                    maxLines = Int.MAX_VALUE,
                    softWrap = true
                )
            }

        }
    }
}

@Composable
private fun ReportValueTile(title: String, value: String, background: Color, foreground: Color, modifier: Modifier = Modifier) {
    Column(modifier = modifier.background(background, RoundedCornerShape(9.dp)).border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(9.dp)).padding(horizontal = 5.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        PersianText(title, fontSize = 11.sp, color = foreground, textAlign = TextAlign.Center, maxLines = 1)
        PersianText(value, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = foreground, maxLines = 1)
    }
}

/** Report creation time uses the phone's local timezone and Jalali calendar. */
private fun reportCreatedAt(): String {
    val current = java.time.LocalDateTime.now()
    val (y, m, d) = gregorianToJalali(current.toLocalDate())
    return "%04d/%02d/%02d  %02d:%02d".format(Locale.ROOT, y, m, d, current.hour, current.minute).toPersianDigits()
}

private data class AnnualReportStats(
    val workedMinutes: Int = 0,
    val overtimeMinutes: Int = 0,
    val shiftMinutes: Int = 0,
    val shifts: Int = 0,
    val entitled: Int = 0,
    val sick: Int = 0,
    val missions: Int = 0,
    val travel: Int = 0,
    val hourlyLeave: Int = 0,
    val workedDays: Int = 0,
    val holidayDays: Int = 0,
    val requiredMinutes: Int = 0,
    val registeredMinutes: Int = 0
) {
    operator fun plus(other: AnnualReportStats) = AnnualReportStats(
        workedMinutes + other.workedMinutes,
        overtimeMinutes + other.overtimeMinutes,
        shiftMinutes + other.shiftMinutes,
        shifts + other.shifts,
        entitled + other.entitled,
        sick + other.sick,
        missions + other.missions,
        travel + other.travel,
        hourlyLeave + other.hourlyLeave,
        workedDays + other.workedDays,
        holidayDays + other.holidayDays,
        requiredMinutes + other.requiredMinutes,
        registeredMinutes + other.registeredMinutes
    )
    fun values(): List<String> = listOf(
        hm(workedMinutes), hm(overtimeMinutes), hm(shiftMinutes), shifts.toString(),
        entitled.toString(), sick.toString(), missions.toString(), travel.toString(),
        hm(hourlyLeave), workedDays.toString(), holidayDays.toString(),
        hm(requiredMinutes), hm(registeredMinutes)
    )
}

private val annualReportHeadings = listOf(
    "ماه", "کل کارکرد", "اضافه‌کار", "مدت شیفت", "تعداد شیفت", "استحقاقی", "استعلاجی",
    "مأموریت", "توراهی", "مرخصی ساعتی", "روز کارکرد", "روز تعطیل", "کل موظفی", "موظفی ثبتی"
)

private fun annualMonthStats(db: WorkDb, year: Int, month: Int): AnnualReportStats {
    val days = reportPeriodDays(db, year, month, false)
    val prefix = "%04d-%02d".format(Locale.ROOT,year,month)
    // Shifts belong to the month in which they began, even across month boundaries.
    val shifts = db.allDaysForBackup().filter { it.shiftEnabled && (it.shiftStartDate.ifBlank { it.date }).startsWith(prefix) }
    val (rawEntitled, sick, _) = periodLeaveStats(days, db)
    val deduction = db.getSettingText("tourahi_deduction_$prefix", "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
    val creditDays = hourlyLeaveCreditDays(days, db)
    val entitled = (rawEntitled + creditDays - deduction).coerceAtLeast(0)
    val travel = deduction
    return AnnualReportStats(
        workedMinutes = days.sumOf { duration(it, db) } + shifts.sumOf { shiftDurationMinutes(it, it.date) },
        overtimeMinutes = periodOvertimeMinutes(days, db),
        shiftMinutes = shifts.sumOf { shiftDurationMinutes(it,it.date) },
        shifts = shifts.size, entitled = entitled, sick = sick,
        missions = days.count { hasDayStatus(it,"مأموریت") }, travel = travel,
        hourlyLeave = periodEffectiveHourlyLeaveMinutes(days, db),
        workedDays = days.count { duration(it, db) > 0 },
        holidayDays = days.count {
            jalaliWeekday(it.date) == 5 || dayStatuses(it).any { status -> status in workHolidayStatuses } ||
                db.officialHolidayTitle(it.date) != null ||
                officialJalaliHolidays(year).any { holiday -> holiday.first == it.date }
        },
        requiredMinutes = periodRequiredMinutes(days, db),
        registeredMinutes = periodRegisteredMinutes(days, db)
    )
}

private fun annualSummarySheetXml(db: WorkDb, year: Int, createdAt: String): String {
    val months = (1..12).map { annualMonthStats(db,year,it) }
    val total = months.fold(AnnualReportStats()) { acc, item -> acc + item }
    val first = MutableList(14) { "" }
    first[0] = "مورخ | گزارش جامع سالانه ${year.toString().toPersianDigits()}"
    first[12] = "تهیه: $createdAt"
    val rows = mutableListOf<List<String>>(
        first,
        listOf("خلاصه کل سال و آمار تفکیکی ۱۲ ماه • هر زمان با ساعت:دقیقه، هر تعداد با روز یا نوبت"),
        listOf("واحد: ساعت:دقیقه برای کارکرد، اضافه‌کار، شیفت و مرخصی ساعتی؛ سایر مقادیر تعداد هستند"),
        annualReportHeadings,
        listOf("جمع کل سال") + total.values()
    )
    months.forEachIndexed { index, s -> rows.add(listOf(JalaliMonthNames[index]) + s.values()) }
    val annualHourlyLeaveCredit = (1..12).sumOf { m ->
        hourlyLeaveCreditDays(reportPeriodDays(db, year, m, false), db)
    }
    val annualFloatingUnderwork = (1..12).sumOf { m -> periodFloatingUnderworkMinutes(reportPeriodDays(db, year, m, false), db) }
    val annualNoteParts = mutableListOf<String>()
    if (annualHourlyLeaveCredit > 0) annualNoteParts += "یادآوری: $annualHourlyLeaveCredit روز مرخصی استحقاقی به علت عبور مرخصی ساعتی مؤثر از سقف ۸ ساعت در ماه‌های مربوط افزوده شد."
    if (annualFloatingUnderwork > 0) annualNoteParts += "کم‌کاری ناشی از مرخصی شناور به میزان ${hm(annualFloatingUnderwork)} از اضافه‌کاری شناور ماه‌های مربوط کسر شد؛ اضافه‌کاری ثابت مستقل ماند."
    annualNoteParts += "استحقاقی پس از کسر توراهی نمایش داده شده است؛ توراهی مستقل گزارش می‌شود و دوباره‌شماری ندارد."
    val annualNote = annualNoteParts.joinToString(" ")
    rows.add(listOf(annualNote))
    val widths = listOf(18,15,15,15,15,14,14,14,12,17,13,13,15,15)
    val cols = widths.mapIndexed { i,width -> "<col min=\"${i+1}\" max=\"${i+1}\" width=\"$width\" customWidth=\"1\"/>" }.joinToString("")
    val body = rows.mapIndexed { ri,row ->
        val cells = row.mapIndexed { ci,value ->
            val style = when { ri == 0 -> if(ci==12) 5 else 2; ri == 3 -> 1; ri == 4 -> 5; ri in 5..16 && ci==0 -> 5; ri in 5..16 -> 4; else -> 6 }
            "<c r=\"${colName(ci+1)}${ri+1}\" s=\"$style\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${xmlEscape(value.toPersianDigits())}</t></is></c>"
        }.joinToString("")
        val height = when(ri) { 0->34; 1,2->27; 3->44; 4->34; 17->30; else->29 }
        "<row r=\"${ri+1}\" ht=\"$height\" customHeight=\"1\">$cells</row>"
    }.joinToString("")
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><sheetViews><sheetView workbookViewId="0" rightToLeft="1"><pane ySplit="4" topLeftCell="A5" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>$cols</cols><sheetData>$body</sheetData><mergeCells count="5"><mergeCell ref="A1:L1"/><mergeCell ref="M1:N1"/><mergeCell ref="A2:N2"/><mergeCell ref="A3:N3"/><mergeCell ref="A18:N18"/></mergeCells><printOptions horizontalCentered="1"/><pageMargins left="0.18" right="0.18" top="0.28" bottom="0.28" header="0.1" footer="0.1"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="1"/></worksheet>"""
}

fun buildReportXlsx(db: WorkDb, year: Int, month: Int, annual: Boolean, includeNotes: Boolean = true, summaryOnly: Boolean = false): ByteArray {
    // Two hidden, lossless import sheets contain ONLY the selected reporting period.
    // This avoids leaking unrelated private records when a report is shared.
    val months = if (annual) (1..12).toList() else listOf(month)
    val allowedPrefixes = months.map { "%04d-%02d".format(year,it) }
    val recordedDays = db.allDaysForBackup().filter { day -> allowedPrefixes.any { day.date.startsWith(it) } }
    val raw = mutableListOf(listOf("date","dayType","in1","out1","in2","out2","in3","out3","duration","overtimeOverride","note","shiftEnabled","shiftStart","shiftEnd","shiftStartDate","shiftEndDate","holidayIn","holidayOut","leave1Start","leave1End","leave2Start","leave2End","leave3Start","leave3End","hourlyLeaveEnabled","extraDayTypes","holidayIn2","holidayOut2","scheduleMode"))
    recordedDays.forEach { d -> raw.add(listOf(d.date,d.dayType,d.in1,d.out1,d.in2,d.out2,d.in3,d.out3,hm(duration(d, db)),d.overtimeOverride,if (includeNotes) d.note else "",d.shiftEnabled.toString(),d.shiftStart,d.shiftEnd,d.shiftStartDate,d.shiftEndDate,d.holidayIn,d.holidayOut,d.leave1Start,d.leave1End,d.leave2Start,d.leave2End,d.leave3Start,d.leave3End,d.hourlyLeaveEnabled.toString(),d.extraDayTypes,d.holidayIn2,d.holidayOut2,d.scheduleMode)) }
    val metadata = mutableListOf(listOf("key","value"),listOf("export_format","period_report_v1"),listOf("period",if(annual) "%04d".format(year) else "%04d-%02d".format(year,month)))

    val createdAt = reportCreatedAt()
    val sheets = mutableListOf<Pair<String,String>>()
    sheets.add("داده‌های بازیابی" to sheetXml(raw))
    sheets.add("اطلاعات فایل" to sheetXml(metadata))
    if (annual && summaryOnly) {
        sheets.add("خلاصه جامع سالانه" to annualSummarySheetXml(db, year, createdAt))
    } else {
        months.forEach { m -> sheets.add(JalaliMonthNames[m-1] to monthReportSheetXml(db,year,m,includeNotes,createdAt)) }
    }
    val content = linkedMapOf<String,String>()
    content["[Content_Types].xml"] = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.indices.joinToString("") { "<Override PartName=\"/xl/worksheets/sheet${it+1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" }}</Types>"""
    content["_rels/.rels"] = """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>"""
    val sheetDefs = sheets.mapIndexed { i,pair -> "<sheet name=\"${xmlEscape(pair.first)}\" sheetId=\"${i+1}\" r:id=\"rId${i+1}\"${if(i<2) " state=\"hidden\"" else ""}/>" }.joinToString("")
    content["xl/workbook.xml"] = """<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="2" firstSheet="2"/></bookViews><sheets>$sheetDefs</sheets></workbook>"""
    val relationships = sheets.indices.joinToString("") { i -> "<Relationship Id=\"rId${i+1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet${i+1}.xml\"/>" }
    content["xl/_rels/workbook.xml.rels"] = """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">$relationships<Relationship Id="rId${sheets.size+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>"""
    content["xl/styles.xml"] = reportStylesXml()
    sheets.forEachIndexed { i,pair -> content["xl/worksheets/sheet${i+1}.xml"] = pair.second }
    val output = java.io.ByteArrayOutputStream()
    java.util.zip.ZipOutputStream(output).use { zip -> content.forEach { (name,value) ->
        zip.putNextEntry(java.util.zip.ZipEntry(name));zip.write(value.toByteArray(Charsets.UTF_8));zip.closeEntry()
    } }
    return output.toByteArray()
}

/** Display columns for each of the three work intervals (one value per cell).
 * Holiday overtime is shown in the first pair; the other pairs remain separate and empty.
 */
private fun hasSecondEntryExit(days: List<WorkDay>): Boolean = days.any { it.in2.isNotBlank() || it.out2.isNotBlank() || it.holidayIn2.isNotBlank() || it.holidayOut2.isNotBlank() }
private fun hasThirdEntryExit(days: List<WorkDay>): Boolean = days.any { it.in3.isNotBlank() || it.out3.isNotBlank() }

private fun dayEntryExitColumns(day: WorkDay, includeSecond: Boolean, includeThird: Boolean): List<String> {
    val holidayMode = isHolidayWorkDay(day) && listOf(day.holidayIn, day.holidayOut, day.holidayIn2, day.holidayOut2).any { it.isNotBlank() }
    val firstPair = if (holidayMode) listOf(day.holidayIn, day.holidayOut) else listOf(day.in1, day.out1)
    val pairs = mutableListOf<String>().apply {
        addAll(firstPair)
        if (includeSecond) addAll(if (holidayMode) listOf(day.holidayIn2, day.holidayOut2) else listOf(day.in2, day.out2))
        if (includeThird) addAll(if (holidayMode) listOf("", "") else listOf(day.in3, day.out3))
    }
    return pairs.map { it.ifBlank { "—" } }
}

private fun reportHeadings(includeSecond: Boolean, includeThird: Boolean): List<String> = buildList {
    addAll(listOf("روز هفته", "تاریخ", "ثابت", "شناور", "وضعیت", "ورود ۱", "خروج ۱"))
    if (includeSecond) addAll(listOf("ورود ۲", "خروج ۲"))
    if (includeThird) addAll(listOf("ورود ۳", "خروج ۳"))
    addAll(listOf("کارکرد", "اضافه‌کار", "شیفت", "مرخصی ساعتی", "یادداشت"))
}

/** Combines a day's note with its occasion-holiday reason in report exports. */
private fun dayScheduleModeFlags(day: WorkDay, hasRecordedWork: Boolean): List<String> = if (!hasRecordedWork) listOf("", "") else listOf(
    if (day.scheduleMode == "ثابت") "*" else "",
    if (day.scheduleMode != "ثابت") "*" else ""
)

private fun reportNoteWithHolidayReason(day: WorkDay, db: WorkDb): String {
    val note = day.note.trim()
    val reason = if (hasDayStatus(day, "تعطیل مناسبتی")) db.holidayTitle(day.date)?.trim().orEmpty() else ""
    if (reason.isBlank()) return note
    val suffix = "+ علت تعطیلی: $reason"
    return listOf(note, suffix).filter { it.isNotBlank() }.joinToString(" ")
}

private fun monthReportSheetXml(db: WorkDb, year: Int, month: Int, includeNotes: Boolean, createdAt: String): String {
    val days = reportPeriodDays(db, year, month, false)
    val includeSecond = hasSecondEntryExit(days)
    val includeThird = hasThirdEntryExit(days)
    val headings = reportHeadings(includeSecond, includeThird)
    val shifts = db.allDaysForBackup().filter {
        it.shiftEnabled && (it.shiftStartDate.ifBlank { it.date }).startsWith("%04d-%02d".format(year,month))
    }
    val (rawEntitledDays,sickDays,_) = periodLeaveStats(days,db)
    val deduction = db.getSettingText("tourahi_deduction_%04d-%02d".format(year, month), "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
    val monthlyLeaveCredit = hourlyLeaveCreditDays(days, db)
    val entitledDays = (rawEntitledDays + monthlyLeaveCredit - deduction).coerceAtLeast(0)
    val travelDays = deduction
    val title = "مورخ | گزارش ${JalaliMonthNames[month-1]} ${year.toString().toPersianDigits()}"
    val totalShiftForSummary = shifts.sumOf { shiftDurationMinutes(it, it.date) }
    val summary = "کل کارکرد: ${hm(days.sumOf { duration(it, db) } + totalShiftForSummary)} | کل موظفی: ${hm(periodRequiredMinutes(days, db))} | موظفی ثبتی: ${hm(periodRegisteredMinutes(days, db))} | اضافه‌کاری: ${hm(periodOvertimeMinutes(days, db))} | مرخصی ساعتی: ${hm(periodEffectiveHourlyLeaveMinutes(days, db))}"
    val creditReminder = if (monthlyLeaveCredit > 0) " | یادآوری: $monthlyLeaveCredit روز استحقاقی به علت عبور مرخصی ساعتی مؤثر از سقف ۸ ساعت افزوده شد" else ""
    val underworkReminder = floatingUnderworkReminder(days, db).takeIf { it.isNotBlank() }?.let { " | $it" }.orEmpty()
    val summary2 = "شیفت: ${hm(shifts.sumOf { shiftDurationMinutes(it,it.date) })} | تعداد شیفت: ${shifts.size} | استحقاقی: $entitledDays | استعلاجی: $sickDays | توراهی: $travelDays | مأموریت: ${days.count { hasDayStatus(it,"مأموریت") }}$creditReminder$underworkReminder"
    val stampRow = MutableList(headings.size) { "" }
    stampRow[0] = title
    stampRow[headings.size - 3] = "تهیه: $createdAt"
    val rows = mutableListOf<List<String>>(
        stampRow,
        listOf("گزارش ماهانه • چاپ یک صفحه A4 افقی"),
        listOf(summary),
        listOf(summary2),
        headings.map { if (!includeNotes && it == "یادداشت") "بدون یادداشت" else it }
    )
    days.forEach { day ->
        val weekday = jalaliWeekday(day.date)?.let { JalaliWeekdayNames.getOrNull(it) }.orEmpty()
        val values = listOf(hm(duration(day, db)), hm(overtimeMinutes(day,db)),
            if (day.shiftEnabled) hm(shiftDurationMinutes(day,day.date)) else "—",
            hm(hourlyLeaveMinutes(day, db)), if (includeNotes) reportNoteWithHolidayReason(day, db) else "")
        rows.add(listOf(weekday,day.date.replace('-', '/')) + dayScheduleModeFlags(day, db.hasWorkDay(day.date)) + listOf(reportDayStatusText(day,db)) +
            dayEntryExitColumns(day, includeSecond, includeThird) + values)
    }
    val widths = buildList {
        addAll(listOf(13,16,7,7,22,12,12))
        if (includeSecond) addAll(listOf(12,12))
        if (includeThird) addAll(listOf(12,12))
        addAll(listOf(14,15,14,18,42))
    }
    val cols = widths.mapIndexed { i,width -> """<col min="${i+1}" max="${i+1}" width="$width" customWidth="1"/>""" }.joinToString("")
    val lastCol = colName(headings.size)
    val leftStampEnd = colName((headings.size - 3).coerceAtLeast(1))
    val rightStampStart = colName((headings.size - 2).coerceAtLeast(1))
    val body = rows.mapIndexed { ri,row ->
        val cells = row.mapIndexed { j,v ->
            val style = when {
                ri == 0 -> if (j == headings.size - 3) 5 else 2
                ri == 4 -> 1
                ri in 1..3 -> 6
                j == headings.lastIndex -> 6
                else -> 3
            }
            """<c r="${colName(j+1)}${ri+1}" s="$style" t="inlineStr"><is><t xml:space="preserve">${xmlEscape(v.toPersianDigits())}</t></is></c>"""
        }.joinToString("")
        val height = when(ri) { 0->34; 1,2,3->25; 4->34; else->if(includeNotes) 33 else 23 }
        """<row r="${ri+1}" ht="$height" customHeight="1">$cells</row>"""
    }.joinToString("")
    val mergeItems = mutableListOf(
        "<mergeCell ref=\"A1:${leftStampEnd}1\"/>",
        "<mergeCell ref=\"${rightStampStart}1:${lastCol}1\"/>",
        "<mergeCell ref=\"A2:${lastCol}2\"/>",
        "<mergeCell ref=\"A3:${lastCol}3\"/>",
        "<mergeCell ref=\"A4:${lastCol}4\"/>"
    )
    val merges = mergeItems.joinToString("")
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><sheetViews><sheetView workbookViewId="0" rightToLeft="1"><pane ySplit="5" topLeftCell="A6" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>$cols</cols><sheetData>$body</sheetData><mergeCells count="5">$merges</mergeCells><printOptions horizontalCentered="1"/><pageMargins left="0.17" right="0.17" top="0.28" bottom="0.28" header="0.1" footer="0.1"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="1"/></worksheet>"""
}

fun buildReportPdf(db: WorkDb, year: Int, month: Int, annual: Boolean, includeNotes: Boolean = true, summaryOnly: Boolean = false): ByteArray {
    if (annual && summaryOnly) return buildAnnualSummaryPdf(db,year)
    val createdAt = reportCreatedAt()
    val pdf=android.graphics.pdf.PdfDocument()
    val months=if(annual) (1..12).toList() else listOf(month)
    val pageWidth=842;val pageHeight=595;val left=24f;val right=818f
    val navy=android.graphics.Color.rgb(21,54,93)
    val teal=android.graphics.Color.rgb(0,125,129)
    val gold=android.graphics.Color.rgb(195,150,58)
    val muted=android.graphics.Color.rgb(90,115,141)
    val soft=android.graphics.Color.rgb(239,246,253)
    val white=android.graphics.Color.WHITE
    val p=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    fun rect(canvas:android.graphics.Canvas,l:Float,t:Float,r:Float,b:Float,color:Int,radius:Float=0f) {
        p.color=color;p.style=android.graphics.Paint.Style.FILL
        if(radius>0f) canvas.drawRoundRect(l,t,r,b,radius,radius,p) else canvas.drawRect(l,t,r,b,p)
    }
    fun rtl(canvas:android.graphics.Canvas,value:String,xRight:Float,yTop:Float,width:Int,size:Float,color:Int,bold:Boolean=false,lines:Int=1,center:Boolean=false) {
        val str=value.toPersianDigits()
        val paint=android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textSize=size;this.color=color;typeface=android.graphics.Typeface.create("sans-serif",if(bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        }
        val layout=android.text.StaticLayout.Builder.obtain(str,0,str.length,paint,width.coerceAtLeast(1))
            .setTextDirection(android.text.TextDirectionHeuristics.RTL)
            .setAlignment(if (center) android.text.Layout.Alignment.ALIGN_CENTER else android.text.Layout.Alignment.ALIGN_OPPOSITE)
            .setIncludePad(false).setMaxLines(lines)
            .setEllipsize(android.text.TextUtils.TruncateAt.END).build()
        canvas.save();canvas.translate(xRight-width,yTop);layout.draw(canvas);canvas.restore()
    }
    months.forEachIndexed { index,m ->
        val page=pdf.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth,pageHeight,index+1).create())
        val canvas=page.canvas
        rect(canvas,0f,0f,pageWidth.toFloat(),pageHeight.toFloat(),white)
        rect(canvas,0f,0f,pageWidth.toFloat(),7f,gold)
        rect(canvas,left,18f,right,69f,navy,10f)
        rtl(canvas,"مورخ",right-14,27f,145,16f,white,true)
        rtl(canvas,"گزارش ماهانه ${JalaliMonthNames[m-1]} ${year}",right-178,27f,350,15f,white,true)
        rtl(canvas,"تهیه: $createdAt",left+195,38f,185,9.5f,white,true)
        rtl(canvas,"برگه ${index+1} از ${months.size}",left+148,23f,140,9f,android.graphics.Color.rgb(222,237,249))

        val days=reportPeriodDays(db,year,m,false)
        val includeSecond = hasSecondEntryExit(days)
        val includeThird = hasThirdEntryExit(days)
        val reportCols = reportHeadings(includeSecond, includeThird)
        val shiftList=db.allDaysForBackup().filter { it.shiftEnabled && (it.shiftStartDate.ifBlank { it.date }).startsWith("%04d-%02d".format(year,m)) }
        val (rawEntitledCount,sickCount,_) = periodLeaveStats(days,db)
        val monthDeduction = db.getSettingText("tourahi_deduction_%04d-%02d".format(year, m), "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
        val monthlyLeaveCredit = hourlyLeaveCreditDays(days, db)
        val entitledCount = (rawEntitledCount + monthlyLeaveCredit - monthDeduction).coerceAtLeast(0)
        val travelCount = monthDeduction
        val metrics=listOf(
            "کل کارکرد" to hm(days.sumOf { duration(it, db) } + shiftList.sumOf { shiftDurationMinutes(it, it.date) }),
            "کل موظفی" to hm(periodRequiredMinutes(days, db)),
            "موظفی ثبتی" to hm(periodRegisteredMinutes(days, db)),
            "اضافه‌کاری" to hm(periodOvertimeMinutes(days, db)),
            "مرخصی ساعتی" to hm(periodEffectiveHourlyLeaveMinutes(days, db)),
            "شیفت" to hm(shiftList.sumOf { shiftDurationMinutes(it,it.date) }),
            "تعداد شیفت" to shiftList.size.toString(),
            "استحقاقی" to entitledCount.toString(),
            "استعلاجی" to sickCount.toString(),
            "توراهی" to travelCount.toString(),
            "مأموریت" to days.count { hasDayStatus(it,"مأموریت") }.toString()
        )
        val gap=6f;val tileWidth=(right-left-gap*(metrics.size-1))/metrics.size
        metrics.forEachIndexed { i,metric ->
            val l=left+(tileWidth+gap)*i
            rect(canvas,l,78f,l+tileWidth,125f,soft,6f)
            rtl(canvas,metric.first,l+tileWidth-6,84f,(tileWidth-12).toInt(),9f,muted)
            rtl(canvas,metric.second,l+tileWidth-6,103f,(tileWidth-12).toInt(),13f,if(i==1)teal else navy,true)
        }
        // A4 landscape: explicit entry/exit columns for each of the three intervals.
        // Widths sum to 794pt; every column has its own visible border.
        val rawWidths = buildList {
            addAll(listOf(42f,56f,16f,16f,68f,35f,35f))
            if (includeSecond) addAll(listOf(35f,35f))
            if (includeThird) addAll(listOf(35f,35f))
            addAll(listOf(45f,50f,42f,48f,100f))
        }
        val widthScale=(right-left)/rawWidths.sum()
        val widths=rawWidths.map { it*widthScale }
        val headers=reportCols.map { if (!includeNotes && it == "یادداشت") "بدون یادداشت" else it }
        val tableTop=137f;val headerHeight=24f;val rowHeight=12.5f
        rect(canvas,left,tableTop,right,tableTop+headerHeight,navy,5f)
        var x=right
        headers.forEachIndexed { i,heading ->
            rtl(canvas,heading,x-3.5f,tableTop+6f,(widths[i]-7).toInt(),
                if(i >= headers.size - 2) 8f else 7.1f,white,true,1,true)
            x-=widths[i]
            if(i < headers.lastIndex) rect(canvas,x-0.45f,tableTop,x+0.45f,tableTop+headerHeight,android.graphics.Color.rgb(183,207,231))
        }
        days.forEachIndexed { i,d ->
            val top=tableTop+headerHeight+i*rowHeight
            val highlight=jalaliWeekday(d.date)==5 || dayStatuses(d).any { it in workHolidayStatuses }
            val color=when {highlight -> android.graphics.Color.rgb(255,239,239);i%2==0 -> android.graphics.Color.rgb(248,251,255);else -> white}
            rect(canvas,left,top,right,top+rowHeight,color)
            x=right
            val weekName=jalaliWeekday(d.date)?.let { JalaliWeekdayNames.getOrNull(it) }.orEmpty()
            val cellValues=listOf(weekName,d.date.replace('-', '/'))+dayScheduleModeFlags(d, db.hasWorkDay(d.date))+listOf(reportDayStatusText(d,db))+
                dayEntryExitColumns(d, includeSecond, includeThird)+
                listOf(hm(duration(d, db)),hm(overtimeMinutes(d,db)),
                    if(d.shiftEnabled) hm(shiftDurationMinutes(d,d.date)) else "—",
                    hm(hourlyLeaveMinutes(d, db)),if (includeNotes) reportNoteWithHolidayReason(d, db) else "")
            cellValues.forEachIndexed { j,value ->
                val noteCell = j == cellValues.lastIndex
                rtl(canvas,value,x-3.5f,top+0.6f,(widths[j]-7).toInt(),
                    if(noteCell) 5.7f else if(j==2) 6.2f else 7.2f,
                    if(highlight && (j==0 || j==1)) android.graphics.Color.rgb(170,41,45) else navy,
                    j==0 || j==1,if(noteCell && includeNotes) 2 else 1,true)
                x-=widths[j]
                if(j < cellValues.lastIndex) rect(canvas,x-0.35f,top,x+0.35f,top+rowHeight,android.graphics.Color.rgb(210,225,240))
            }
            rect(canvas,left,top+rowHeight-0.4f,right,top+rowHeight,android.graphics.Color.rgb(210,225,240))
        }
        val footerY=tableTop+headerHeight+days.size*rowHeight+12f
        val footerParts = mutableListOf<String>()
        if (monthlyLeaveCredit > 0) footerParts += "یادآوری: $monthlyLeaveCredit روز استحقاقی بابت عبور مرخصی ساعتی مؤثر از سقف ۸ ساعت افزوده شد."
        floatingUnderworkReminder(days, db).takeIf { it.isNotBlank() }?.let(footerParts::add)
        val footerText = footerParts.joinToString(" • ").ifBlank {
            "برای بازیابی اطلاعات، فایل Excel گزارش را نگه دارید؛ ورود و خروج‌های ثبت‌شده در ستون‌های مستقل قرار دارند."
        }
        rtl(canvas,footerText,right,footerY,(right-left).toInt(),8.4f,muted)
        rect(canvas,left,footerY+20,right,footerY+22,gold)
        pdf.finishPage(page)
    }
    val out=java.io.ByteArrayOutputStream();pdf.writeTo(out);pdf.close();return out.toByteArray()
}

/** One A4 landscape page: year totals above an independently bordered 12-month matrix. */
private fun buildAnnualSummaryPdf(db: WorkDb, year: Int): ByteArray {
    val document = android.graphics.pdf.PdfDocument()
    val width = 842; val height = 595 // A4 landscape at 72 dpi.
    val page = document.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(width,height,1).create())
    val c = page.canvas
    val navy = android.graphics.Color.rgb(21,54,93)
    val blue = android.graphics.Color.rgb(36,90,141)
    val teal = android.graphics.Color.rgb(0,118,114)
    val gold = android.graphics.Color.rgb(208,165,75)
    val grey = android.graphics.Color.rgb(100,121,145)
    val pale = android.graphics.Color.rgb(239,247,253)
    val line = android.graphics.Color.rgb(192,213,235)
    val white = android.graphics.Color.WHITE
    val brush = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    fun fill(l: Float,t:Float,r:Float,b:Float,color:Int) {
        brush.color=color; brush.style=android.graphics.Paint.Style.FILL
        c.drawRect(l,t,r,b,brush)
    }
    fun cell(l:Float,t:Float,r:Float,b:Float,color:Int,border:Int=line) {
        fill(l,t,r,b,color)
        brush.color=border; brush.style=android.graphics.Paint.Style.STROKE; brush.strokeWidth=0.8f
        c.drawRect(l,t,r,b,brush); brush.style=android.graphics.Paint.Style.FILL
    }
    fun label(value:String,xRight:Float,top:Float,maxWidth:Int,fontSize:Float=9f,
              ink:Int=navy,bold:Boolean=false,maxLines:Int=1,center:Boolean=false) {
        val rendered=value.toPersianDigits()
        val tp=android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textSize=fontSize; color=ink
            typeface=android.graphics.Typeface.create("sans-serif",if(bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        }
        val layout=android.text.StaticLayout.Builder.obtain(rendered,0,rendered.length,tp,maxWidth.coerceAtLeast(1))
            .setTextDirection(android.text.TextDirectionHeuristics.RTL)
            .setAlignment(if (center) android.text.Layout.Alignment.ALIGN_CENTER else android.text.Layout.Alignment.ALIGN_OPPOSITE)
            .setIncludePad(false).setMaxLines(maxLines)
            .setEllipsize(android.text.TextUtils.TruncateAt.END).build()
        c.save();c.translate(xRight-maxWidth,top);layout.draw(c);c.restore()
    }
    val left=24f; val right=818f
    fill(0f,0f,842f,7f,gold)
    cell(left,18f,right,75f,navy,navy)
    label("مورخ",right-15,26f,135,18f,white,true)
    label("خلاصهٔ جامع عملکرد سال ${year.toString().toPersianDigits()}",right-162,27f,380,15f,white,true)
    label("تهیه: ${reportCreatedAt()}",left+206,43f,198,10f,white,true)
    val perMonth=(1..12).map { annualMonthStats(db,year,it) }
    val total=perMonth.fold(AnnualReportStats()) { acc,item -> acc+item }
    val headline=listOf(
        "کل کارکرد" to hm(total.workedMinutes),
        "اضافه‌کاری" to hm(total.overtimeMinutes),
        "مدت شیفت" to hm(total.shiftMinutes),
        "تعداد شیفت" to total.shifts.toString(),
        "مرخصی ساعتی" to hm(total.hourlyLeave),
        "استحقاقی" to total.entitled.toString(),
        "استعلاجی" to total.sick.toString(),
        "مأموریت" to total.missions.toString(),
        "توراهی" to total.travel.toString(),
        "کل موظفی" to hm(total.requiredMinutes),
        "موظفی ثبتی" to hm(total.registeredMinutes),
    )
    val cardGap=6f; val cardW=(right-left-4*cardGap)/5f
    headline.forEachIndexed { i,metric ->
        val row=i/5;val col=i%5
        val x=left+col*(cardW+cardGap)
        val y=84f+row*47f
        cell(x,y,x+cardW,y+41f,if(row==0) pale else android.graphics.Color.rgb(246,250,254))
        label(metric.first,x+cardW-7f,y+5f,(cardW-14f).toInt(),10f,grey)
        label(metric.second,x+cardW-7f,y+22f,(cardW-14f).toInt(),13f,if(i==1) teal else blue,true)
    }
    label("خلاصهٔ ماه‌به‌ماه • ساعت‌ها به صورت ساعت:دقیقه، سایر ستون‌ها تعداد",right,226f,680,10f,navy,true)
    val baseColumns=listOf(75f,58f,58f,54f,52f,48f,48f,50f,46f,58f,58f,45f,52f,52f)
    val columnScale=(right-left)/baseColumns.sum()
    val columns=baseColumns.map { it*columnScale }
    val headerTop=246f; val headerH=27f; val rowH=18f
    var edge=right
    annualReportHeadings.forEachIndexed { index,title ->
        val w=columns[index]
        cell(edge-w,headerTop,edge,headerTop+headerH,navy,android.graphics.Color.rgb(105,148,186))
        label(title,edge-3f,headerTop+8f,(w-6).toInt(),7.8f,white,true,2,true)
        edge-=w
    }
    val allRows=listOf("کل سال" to total)+ (1..12).map { JalaliMonthNames[it-1] to perMonth[it-1] }
    allRows.forEachIndexed { i,(monthName,stats) ->
        val y=headerTop+headerH+rowH*i
        edge=right
        val values=listOf(monthName)+stats.values()
        values.forEachIndexed { j,value ->
            val w=columns[j]
            val bg=when { i==0 -> android.graphics.Color.rgb(222,240,247)
                i%2==0 -> android.graphics.Color.rgb(246,250,254)
                else -> white }
            cell(edge-w,y,edge,y+rowH,bg)
            label(value,edge-3.4f,y+5f,(w-6).toInt(),if(j==0) 9.1f else 8.8f,
                if(i==0) navy else if(j==2) teal else blue, i==0 || j==0,1,true)
            edge-=w
        }
    }
    val footer=headerTop+headerH+rowH*allRows.size+12f
    val annualHourlyLeaveCredit = (1..12).sumOf { m ->
        hourlyLeaveCreditDays(reportPeriodDays(db, year, m, false), db)
    }
    val annualFloatingUnderwork = (1..12).sumOf { m -> periodFloatingUnderworkMinutes(reportPeriodDays(db, year, m, false), db) }
    val annualFooterParts = mutableListOf<String>()
    if (annualHourlyLeaveCredit > 0) annualFooterParts += "یادآوری: $annualHourlyLeaveCredit روز استحقاقی بابت عبور مرخصی ساعتی مؤثر از سقف ۸ ساعت افزوده شد"
    if (annualFloatingUnderwork > 0) annualFooterParts += "کم‌کاری ناشی از مرخصی شناور ${hm(annualFloatingUnderwork)} از اضافه‌کاری شناور کسر شد"
    if (annualFooterParts.isEmpty()) annualFooterParts += "مبنای استحقاقی: پس از کسر توراهی و احتساب اعتبار مرخصی ساعتی"
    annualFooterParts += "شیفت‌ها بر اساس ماه شروع"
    val annualFooter = annualFooterParts.joinToString(" • ")
    label(annualFooter,right,footer,(right-left).toInt(),9.0f,grey)
    fill(left,footer+20f,right,footer+22f,gold)
    document.finishPage(page)
    val bytes=java.io.ByteArrayOutputStream()
    document.writeTo(bytes);document.close()
    return bytes.toByteArray()
}

private fun xmlEscape(v: String): String = v.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;")
private fun colName(n: Int): String {
    var x=n; var out=""
    while(x>0){ val r=(x-1)%26; out=(('A'.code+r).toChar())+out; x=(x-1)/26 }
    return out
}
private fun reportStylesXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="4">
<font><sz val="10"/><name val="Arial"/><family val="2"/></font>
<font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Arial"/></font>
<font><b/><sz val="14"/><color rgb="FF15365D"/><name val="Arial"/></font>
<font><b/><sz val="10"/><color rgb="FF15365D"/><name val="Arial"/></font>
</fonts>
<fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF28588A"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFE5F4FB"/><bgColor indexed="64"/></patternFill></fill></fills>
<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>
<border><left style="thin"><color rgb="FFB7CCE0"/></left><right style="thin"><color rgb="FFB7CCE0"/></right><top style="thin"><color rgb="FFB7CCE0"/></top><bottom style="thin"><color rgb="FFB7CCE0"/></bottom><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="7">
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" applyBorder="1"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="1" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="2" fillId="0" borderId="1" applyFont="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="3" fillId="3" borderId="1" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>"""
private fun sheetXml(rows: List<List<String>>): String {
    val maxCols = rows.maxOfOrNull { it.size } ?: 1
    val cols = (1..maxCols).joinToString("") { i ->
        val width = when { i == 1 -> 17; i == 2 -> 18; i == 3 -> 30; else -> 15 }
        "<col min=\"$i\" max=\"$i\" width=\"$width\" customWidth=\"1\"/>"
    }
    val body = rows.mapIndexed { ri,row ->
        val cells = row.mapIndexed { ci,value ->
            val ref = colName(ci+1)+(ri+1)
            val style = if (ri == 0) 1 else if (ci == 0 && ri < 4) 2 else 3
            "<c r=\"$ref\" s=\"$style\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${xmlEscape(value.toPersianDigits())}</t></is></c>"
        }.joinToString("")
        "<row r=\"${ri+1}\" ht=\"${if (ri==0) 30 else 24}\" customHeight=\"1\">$cells</row>"
    }.joinToString("")
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0" rightToLeft="1"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>$cols</cols><sheetData>$body</sheetData><pageMargins left="0.25" right="0.25" top="0.45" bottom="0.45" header="0.2" footer="0.2"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/><printOptions horizontalCentered="1"/><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr></worksheet>"""
}

fun buildBackupXlsx(db: WorkDb): ByteArray {
    val workRows = mutableListOf(listOf("date","dayType","in1","out1","in2","out2","in3","out3","duration","overtimeOverride","note","shiftEnabled","shiftStart","shiftEnd","shiftStartDate","shiftEndDate","holidayIn","holidayOut","leave1Start","leave1End","leave2Start","leave2End","leave3Start","leave3End","hourlyLeaveEnabled","extraDayTypes","holidayIn2","holidayOut2","scheduleMode"))
    db.allDaysForBackup().forEach { d ->
        workRows.add(listOf(d.date,d.dayType,d.in1,d.out1,d.in2,d.out2,d.in3,d.out3,hm(duration(d, db)),d.overtimeOverride,d.note,d.shiftEnabled.toString(),d.shiftStart,d.shiftEnd,d.shiftStartDate,d.shiftEndDate,d.holidayIn,d.holidayOut,d.leave1Start,d.leave1End,d.leave2Start,d.leave2End,d.leave3Start,d.leave3End,d.hourlyLeaveEnabled.toString(),d.extraDayTypes,d.holidayIn2,d.holidayOut2,d.scheduleMode))
    }
    val settingsRows = mutableListOf(listOf("key","value"))
    db.allSettings().forEach { settingsRows.add(listOf(it.first,it.second)) }
    val entries = linkedMapOf(
        "[Content_Types].xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""",
        "_rels/.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""",
        "xl/workbook.xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Workdays" sheetId="1" r:id="rId1"/><sheet name="Settings" sheetId="2" r:id="rId2"/></sheets></workbook>""",
        "xl/_rels/workbook.xml.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/></Relationships>""",
        "xl/worksheets/sheet1.xml" to sheetXml(workRows),
        "xl/worksheets/sheet2.xml" to sheetXml(settingsRows)
    )
    val output = java.io.ByteArrayOutputStream()
    java.util.zip.ZipOutputStream(output).use { zip ->
        entries.forEach { (name,content) ->
            zip.putNextEntry(java.util.zip.ZipEntry(name))
            zip.write(content.toByteArray(Charsets.UTF_8))
            zip.closeEntry()
        }
    }
    return output.toByteArray()
}
private fun csvEscape(value: String): String = "\"" + value.replace("\"", "\"\"") + "\""

fun buildBackupCsv(db: WorkDb): String {
    val out = StringBuilder()
    fun row(values: List<String>) { out.append(values.joinToString(",") { csvEscape(it) }).append("\r\n") }
    row(listOf("MORAKH_BACKUP", "1"))
    row(listOf("WORKDAYS"))
    row(listOf("date","dayType","in1","out1","in2","out2","in3","out3","duration","overtimeOverride","note","shiftEnabled","shiftStart","shiftEnd","shiftStartDate","shiftEndDate","holidayIn","holidayOut","leave1Start","leave1End","leave2Start","leave2End","leave3Start","leave3End","hourlyLeaveEnabled","extraDayTypes","holidayIn2","holidayOut2","scheduleMode"))
    db.allDaysForBackup().forEach { d ->
        row(listOf(d.date,d.dayType,d.in1,d.out1,d.in2,d.out2,d.in3,d.out3,hm(duration(d, db)),d.overtimeOverride,d.note,d.shiftEnabled.toString(),d.shiftStart,d.shiftEnd,d.shiftStartDate,d.shiftEndDate,d.holidayIn,d.holidayOut,d.leave1Start,d.leave1End,d.leave2Start,d.leave2End,d.leave3Start,d.leave3End,d.hourlyLeaveEnabled.toString(),d.extraDayTypes,d.holidayIn2,d.holidayOut2,d.scheduleMode))
    }
    row(listOf("SETTINGS"))
    row(listOf("key", "value"))
    db.allSettings().forEach { row(listOf(it.first, it.second)) }
    return "\uFEFF" + out.toString()
}

private fun parseCsvRecords(source: String): List<List<String>> {
    val text = source.removePrefix("\uFEFF")
    val records = mutableListOf<List<String>>()
    var row = mutableListOf<String>()
    val field = StringBuilder()
    var quoted = false
    var i = 0
    while (i < text.length) {
        val ch = text[i]
        when {
            quoted && ch == '"' && i + 1 < text.length && text[i + 1] == '"' -> { field.append('"'); i++ }
            ch == '"' -> quoted = !quoted
            !quoted && ch == ',' -> { row.add(field.toString()); field.setLength(0) }
            !quoted && (ch == '\n' || ch == '\r') -> {
                if (ch == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                row.add(field.toString()); field.setLength(0)
                if (row.any { it.isNotEmpty() }) records.add(row)
                row = mutableListOf()
            }
            else -> field.append(ch)
        }
        i++
    }
    if (field.isNotEmpty() || row.isNotEmpty()) { row.add(field.toString()); records.add(row) }
    require(!quoted) { "ساختار CSV ناقص است" }
    return records
}

private fun readBackupCsv(source: String): Pair<List<WorkDay>,List<Pair<String,String>>> {
    val records = parseCsvRecords(source)
    require(records.firstOrNull()?.take(2) == listOf("MORAKH_BACKUP", "1")) { "این فایل، پشتیبان CSV مورخ نیست" }
    val workStart = records.indexOfFirst { it.firstOrNull() == "WORKDAYS" }
    val settingsStart = records.indexOfFirst { it.firstOrNull() == "SETTINGS" }
    require(workStart >= 0 && settingsStart > workStart) { "بخش‌های پشتیبان پیدا نشد" }
    val workRows = records.subList(workStart + 1, settingsStart)
    require(workRows.firstOrNull()?.firstOrNull() == "date") { "ساختار اطلاعات روزانه معتبر نیست" }
    val days = workRows.drop(1).map { it.map(String::toLatinDigits) }
        .filter { it.size >= 11 && it[0].matches(Regex("\\d{4}-\\d{2}-\\d{2}")) }.map { r ->
            WorkDay(r[0],r[2],r[3],r[4],r[5],r[6],r[7],r[10],r[1].ifBlank { "کاری" },r[9],
                r.getOrNull(11)?.toBoolean() ?: false,r.getOrNull(12) ?: "",r.getOrNull(13) ?: "",r.getOrNull(14) ?: "",r.getOrNull(15) ?: "",
                r.getOrNull(16) ?: "",r.getOrNull(17) ?: "",r.getOrNull(18) ?: "",r.getOrNull(19) ?: "",r.getOrNull(20) ?: "",r.getOrNull(21) ?: "",
                if ("leave3Start" in workRows.first()) r.getOrNull(24)?.toBoolean() ?: false else r.getOrNull(22)?.toBoolean() ?: listOf(18,19,20,21).any { !r.getOrNull(it).isNullOrBlank() },
                if ("leave3Start" in workRows.first()) r.getOrNull(25) ?: "" else r.getOrNull(23) ?: "",
                if ("leave3Start" in workRows.first()) r.getOrNull(22) ?: "" else "",
                if ("leave3Start" in workRows.first()) r.getOrNull(23) ?: "" else "",
                r.getOrNull(workRows.first().indexOf("holidayIn2")) ?: "", r.getOrNull(workRows.first().indexOf("holidayOut2")) ?: "",
                r.getOrNull(workRows.first().indexOf("scheduleMode"))?.takeIf { it == "ثابت" || it == "شناور" } ?: "شناور")
        }
    val settingRows = records.drop(settingsStart + 1)
    require(settingRows.firstOrNull()?.take(2) == listOf("key", "value")) { "ساختار تنظیمات معتبر نیست" }
    val settings = settingRows.drop(1).filter { it.size >= 2 }.map { it[0] to it[1].toLatinDigits() }
    return days to settings
}

private fun readBackupXlsx(bytes: ByteArray): Pair<List<WorkDay>,List<Pair<String,String>>> {
    val entries = mutableMapOf<String,ByteArray>()
    java.util.zip.ZipInputStream(bytes.inputStream()).use { zip ->
        while(true) {
            val e = zip.nextEntry ?: break
            if (e.name == "xl/worksheets/sheet1.xml" || e.name == "xl/worksheets/sheet2.xml") {
                entries[e.name] = zip.readBytes()
            }
            zip.closeEntry()
        }
    }
    fun parseSheet(xmlBytes: ByteArray?): List<List<String>> {
        if(xmlBytes == null) return emptyList()
        val parser = android.util.Xml.newPullParser()
        parser.setInput(xmlBytes.inputStream(), "UTF-8")
        val rows = mutableListOf<List<String>>()
        var row: MutableList<String>? = null
        var cellText = StringBuilder()
        var inCell = false
        var event = parser.eventType
        while(event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
            when(event) {
                org.xmlpull.v1.XmlPullParser.START_TAG -> when(parser.name) {
                    "row" -> row = mutableListOf()
                    "c" -> { inCell = true; cellText = StringBuilder() }
                    "t" -> if(inCell) { }
                }
                org.xmlpull.v1.XmlPullParser.TEXT -> if(inCell) cellText.append(parser.text)
                org.xmlpull.v1.XmlPullParser.END_TAG -> when(parser.name) {
                    "c" -> { row?.add(cellText.toString()); inCell = false }
                    "row" -> { row?.let { rows.add(it) }; row = null }
                }
            }
            event = parser.next()
        }
        return rows
    }
    val workRows = parseSheet(entries["xl/worksheets/sheet1.xml"])
    val settingsRows = parseSheet(entries["xl/worksheets/sheet2.xml"])
    require(workRows.isNotEmpty() && workRows.first().firstOrNull() == "date") { "ساختار فایل پشتیبان معتبر نیست" }
    val days = workRows.drop(1).map { row -> row.map { it.toLatinDigits() } }
        .filter { it.size >= 11 && it[0].matches(Regex("\\d{4}-\\d{2}-\\d{2}")) }.map { r ->
        WorkDay(r[0],r[2],r[3],r[4],r[5],r[6],r[7],r[10],r[1].ifBlank{"کاری"},r[9], r.getOrNull(11)?.toBoolean() ?: false, r.getOrNull(12) ?: "", r.getOrNull(13) ?: "", r.getOrNull(14) ?: "", r.getOrNull(15) ?: "", r.getOrNull(16) ?: "", r.getOrNull(17) ?: "",
            r.getOrNull(18) ?: "", r.getOrNull(19) ?: "", r.getOrNull(20) ?: "", r.getOrNull(21) ?: "",
            if ("leave3Start" in workRows.first()) r.getOrNull(24)?.toBoolean() ?: false else r.getOrNull(22)?.toBoolean() ?: listOf(18,19,20,21).any { !r.getOrNull(it).isNullOrBlank() },
            if ("leave3Start" in workRows.first()) r.getOrNull(25) ?: "" else r.getOrNull(23) ?: "",
            if ("leave3Start" in workRows.first()) r.getOrNull(22) ?: "" else "",
            if ("leave3Start" in workRows.first()) r.getOrNull(23) ?: "" else "",
            r.getOrNull(workRows.first().indexOf("holidayIn2")) ?: "", r.getOrNull(workRows.first().indexOf("holidayOut2")) ?: "",
                r.getOrNull(workRows.first().indexOf("scheduleMode"))?.takeIf { it == "ثابت" || it == "شناور" } ?: "شناور")
    }
    val settings = settingsRows.drop(1).filter { it.size >= 2 }.map { it[0] to it[1].toLatinDigits() }
    return days to settings
}


@Composable
private fun HelpScreen(modifier: Modifier = Modifier) {
    val gold = Color(0xFFC7A24A)
    val helpGroups = linkedMapOf(
        "آشنایی و ثبت روزانه" to listOf(
            "شروع کار و انتخاب تاریخ" to "در صفحهٔ ثبت کارکرد، تاریخ روز جاری نمایش داده می‌شود. با دکمه‌های روز قبل و روز بعد یا انتخاب از تقویم می‌توانی به تاریخ دیگری بروی. اطلاعات هر تاریخ مستقل است و ویرایش یک روز نباید اطلاعات روزهای دیگر را تغییر دهد. برنامه ویرایش‌های معتبر را هنگام ثبت فیلدها نگه می‌دارد و دکمهٔ «ذخیره اطلاعات روز» برای تأیید نهایی همان روز است. حذف روز پس از نمایش پیام تأیید انجام می‌شود.",
            "نوع روز، جمعه و تعطیلات رسمی" to "نوع روز سه انتخاب دارد: کاری، تعطیل رسمی و تعطیل مناسبتی. تعطیلات رسمی از تقویم رسمی برنامه خوانده می‌شوند و قابل تبدیل به روز کاری نیستند. روز جمعه نیز روز غیرکاری است و گزینهٔ کاری برای آن خاموش می‌ماند. تعطیل مناسبتی برای روزهایی است که کاربر به‌صورت موردی تعطیل اعلام می‌کند. مناسبت‌های غیرتعطیل به‌تنهایی روز را تعطیل نمی‌کنند.",
            "وضعیت حضور" to "وضعیت حضور از نوع روز جداست. وضعیت‌های قابل ثبت شامل عادی، استحقاقی، استعلاجی و مأموریت هستند. وضعیت عادی با روز تعطیل هم‌زمان نمی‌شود. در صورت ثبت وضعیت مرخصی یا مأموریت، عنوان آن در کارت روز و گزارش‌ها منعکس می‌شود. تعطیلات رسمی تقویم و جمعه‌ها از محاسبهٔ ماندهٔ مرخصی استحقاقی قابل شمارش کنار گذاشته می‌شوند.",
            "ثبت ساعت‌های ورود و خروج" to "در بخش ساعت کار روزانه سه ردیف مستقل ورود و خروج وجود دارد. هر ردیف را فقط در صورت استفاده پر کن؛ خانه‌های خالی به‌عنوان زمان ثبت‌شده محاسبه نمی‌شوند. اگر کاربر در یک روز چند نوبت کاری دارد، زمان هر نوبت را در ردیف جدا ثبت کند. اعداد ساعت را با قالب ساعت و دقیقه وارد کن و ترتیب زمانی هر بازه را بررسی کن.",
            "یادداشت روز و ذخیره اطلاعات" to "یادداشت به همان تاریخ وابسته است و در کارت روز و گزارش‌ها نمایش داده می‌شود. هنگام گرفتن خروجی می‌توانی درج یادداشت‌ها را روشن یا خاموش کنی. پیش از حذف اطلاعات یا بازیابی پشتیبان، بهتر است از داده‌های فعلی نسخهٔ پشتیبان تهیه کنی."
        ),
        "قوانین ساعت کار و مرخصی ساعتی" to listOf(
            "انتخاب حالت ثابت یا شناور" to "در تنظیمات، قسمت «ساعت کار موظفی»، فقط یکی از دو حالت ثابت یا شناور فعال می‌شود. حالت انتخاب‌شده در زمان ثبت روز در همان رکورد ذخیره می‌شود؛ بنابراین تغییر تنظیمات پیش‌فرض، حالت روزهای قبلاً ثبت‌شده را عوض نمی‌کند. حالت هر روز در کارت روز و گزارش تفصیلی خروجی با علامت ستاره در ستون مربوط مشخص می‌شود.",
            "ساعت کار ثابت" to "در حالت ثابت، بازهٔ شروع و پایان شنبه تا چهارشنبه جدا از پنجشنبه تنظیم می‌شود. ساعات موظفی هر روز داخل همان بازه است. مرخصی ساعتی فقط در محدودهٔ ساعت موظفی همان روز مجاز است و از موظفی/حضور ثبتی آن روز کسر می‌شود. مرخصی روز ثابت از اضافه‌کاری آن روز کم نمی‌شود و اضافه‌کاری ثابت مستقل باقی می‌ماند.",
            "ساعت کار شناور" to "در حالت شناور، میزان ساعت موظفی شنبه تا چهارشنبه و پنجشنبه به‌صورت جداگانه تعیین می‌شود و الزام به بازهٔ ثابت شروع و پایان وجود ندارد. مرخصی ساعتی ابتدا از اضافه‌کاری همان روز کم می‌شود. اگر مرخصی از اضافه‌کاری همان روز بیشتر شود، باقیمانده به‌عنوان کم‌کاری شناور ماهانه محاسبه می‌شود و از مجموع اضافه‌کاری شناور همان ماه کسر خواهد شد؛ اضافه‌کاری روزهای ثابت وارد این کسر نمی‌شود.",
            "تجمیع کم‌کاری شناور در ماه" to "کم‌کاری شناور به یک کارت روز خاص منتقل نمی‌شود؛ فقط در جمع ماه گزارش می‌شود. مجموع کم‌کاری‌های شناور از مجموع اضافه‌کاری روزهای شناور همان ماه کسر می‌شود. اگر کم‌کاری شناور بیشتر از اضافه‌کاری شناور ماه باشد، فقط مازاد پوشش‌داده‌نشده به مرخصی ساعتی مؤثر ماه اضافه می‌شود. یادآوری این رویداد فقط وقتی نمایش داده می‌شود که کم‌کاری شناور بدون پوشش باقی بماند.",
            "سقف ۸ ساعت مرخصی ساعتی" to "برای هر ماه، ۸ ساعت مرخصی ساعتی مؤثر به‌عنوان سقف پایه در نظر گرفته می‌شود. بخش مازاد بر ۸ ساعت به تعداد بازه‌های ۸ ساعته، با گرد کردن رو به بالا، به مرخصی استحقاقی اضافه می‌شود؛ برای نمونه ۸ ساعت و ۱ دقیقه تا ۱۶ ساعت مازاد، یک روز و ۱۶ ساعت و ۱ دقیقه مازاد، دو روز استحقاقی ایجاد می‌کند. مرخصی ساعتی روزهای ثابت و مازاد کم‌کاریِ پوشش‌داده‌نشدهٔ روزهای شناور در محاسبهٔ مرخصی مؤثر ماه لحاظ می‌شوند.",
            "معنای شاخص‌های موظفی در گزارش" to "«کل موظفی» جمع ساعات اجباری حضور در روزهای کاری ماه بر پایهٔ تنظیم موظفی است. «موظفی ثبتی» مجموع کارکرد ثبت‌شده‌ای است که از ورود و خروج‌های عادی به دست می‌آید و اضافه‌کاری، شیفت و مرخصی ساعتی به آن اضافه نمی‌شوند. «کل کارکرد» شاخص جامع کارکرد است و با موظفی ثبتی یکسان نیست. رنگ متفاوت مقدار کسری موظفی به معنی کامل نشدن ساعات موردنیاز است."
        ),
        "تقویم و گزارش‌ها" to listOf(
            "کار با تقویم شمسی" to "تقویم ماهانه از شنبه تا جمعه چیده شده است. تعطیلات رسمی و مناسبت‌ها از داده‌های تقویم نمایش داده می‌شوند. با انتخاب روز، اطلاعات همان تاریخ در کارت پیش‌نمایش نشان داده می‌شود و دکمهٔ «مشاهده کارت این روز» به ثبت کارکرد همان تاریخ می‌رود. جابه‌جایی در تقویم نباید تاریخ انتخابی صفحهٔ ثبت کارکرد را بی‌دلیل تغییر دهد.",
            "گزارش ماه" to "در گزارش ماه، ماه و سال را انتخاب کن. کارت خلاصه شاخص‌های کل کارکرد، کل موظفی، موظفی ثبتی، اضافه‌کاری، مرخصی‌ها، شیفت و موارد دیگر را نشان می‌دهد. کارت‌های روز جزئیات همان تاریخ را نمایش می‌دهند. یادآوری کم‌کاری شناور یا تبدیل مرخصی ساعتی به استحقاقی فقط در صورت رخ دادن این رویدادها زیر خلاصهٔ ماه ظاهر می‌شود.",
            "گزارش سال" to "گزارش سال، جمع‌های سال و خلاصهٔ ماه‌های آن را نمایش می‌دهد. اعداد سالانه از داده‌های روزانه و جمع‌های ماهانه محاسبه می‌شوند. در گزارش سال، تعطیلات رسمی هر ماه جداگانه نمایش داده می‌شوند. با انتخاب کارت ماه می‌توان جزئیات همان ماه را بررسی کرد.",
            "خروجی Excel و PDF" to "از گزارش ماه یا سال می‌توان خروجی Excel و PDF گرفت. پیش از خروجی، مشخص کن یادداشت‌ها در فایل درج شوند یا نه. گزارش تفصیلی، داده‌های روزانه و ساعت‌ها را در ستون‌های جدا ارائه می‌کند؛ گزارش جامع سالانه برای مرور یک‌صفحه‌ای شاخص‌های سال است و جای گزارش تفصیلی را نمی‌گیرد. در ستون‌های حالت کاری، ستاره نشان می‌دهد آن روز با حالت ثابت یا شناور ثبت شده است."
        ),
        "یادآورها و اوقات شرعی" to listOf(
            "ساخت یادآور تازه" to "در صفحهٔ یادآورها نوع قسط یا جلسه، عنوان، تاریخ شمسی و ساعت را وارد کن. تاریخ و ساعت را رقم‌به‌رقم وارد کن. در صورت نیاز تکرار ماهانه را فعال کن. یادآورهای ثبت‌شده از همین صفحه قابل مشاهده، ویرایش و حذف هستند. اگر یادآوری برای تاریخ انتخاب‌شده وجود داشته باشد، در صفحهٔ ثبت کارکرد زیر کارت روز دیده می‌شود.",
            "صدای هشدار" to "صدای یادآور می‌تواند از زنگ‌های گوشی یا فایل صوتی انتخاب شود. هنگام ویرایش یک یادآور، صدای قبلی حفظ می‌شود مگر اینکه صدای تازه‌ای انتخاب کنی. یادآور مربوط به زمان گذشته ذخیره می‌شود، اما هشدار آن در گذشته پخش نخواهد شد.",
            "اوقات شرعی و انتخاب شهر" to "در صفحهٔ اوقات شرعی، شهر را از فهرست شهرهای ایران انتخاب کن. شش زمان اصلی صبح، طلوع، ظهر، غروب، مغرب و نیمه‌شب نمایش داده می‌شوند. برنامه در صورت داشتن دادهٔ ذخیره‌شده، همان را آفلاین نشان می‌دهد؛ به‌روزرسانی آنلاین فقط با فشردن دکمهٔ دریافت تازه انجام می‌شود.",
            "مدیریت هشدار اذان" to "هشدار اذان از صفحهٔ اوقات شرعی روشن یا خاموش می‌شود و هشدارهای صبح، ظهر و مغرب کلیدهای جداگانه دارند. می‌توانی صدای اذان را از بانک موجود انتخاب کنی، فایل را دانلود و پیش‌شنوی کنی و سپس آن را به‌عنوان صدای منتخب قرار دهی. تنظیم مجوز هشدار دقیق و اعلان‌ها از تنظیمات گوشی و بخش مدیریت اعلان‌ها انجام می‌شود."
        ),
        "تنظیمات و نگهداری اطلاعات" to listOf(
            "مدیریت اعلان‌ها و مجوزها" to "در تنظیمات، کلید فعال‌سازی کلی اعلان‌ها تمام اعلان‌ها و هشدارهای برنامه را کنترل می‌کند. کلیدهای اعلان تاریخ، اذان، قسط و جلسه تنظیمات مستقل دارند، اما فقط وقتی کلید اصلی روشن باشد اجرا می‌شوند. مجوز اعلان و هشدار دقیق را از گزینهٔ مجوز هشدار در تنظیمات اندروید مدیریت کن. محل دقیق نمایش اعلان را سیستم‌عامل تعیین می‌کند.",
            "تنظیم ساعت کار موظفی" to "در بخش ساعت کار موظفی، یکی از دو حالت ثابت یا شناور را انتخاب و ساعت‌ها را تنظیم کن. در حالت ثابت، شروع و پایان روزهای شنبه تا چهارشنبه و پنجشنبه جدا هستند. در حالت شناور، میزان موظفی این دو گروه روز جداگانه وارد می‌شود. پس از کنترل معتبر بودن ساعت‌ها، دکمهٔ ذخیره را بزن. روزهای قبلی روش ثبت خود را حفظ می‌کنند.",
            "دریافت تقویم رسمی" to "در تنظیمات سال شمسی موردنظر را انتخاب کن و دکمهٔ دریافت مناسبت‌های سال انتخاب‌شده را بزن. اطلاعات دریافت‌شده روی گوشی ذخیره می‌شود تا در مراجعهٔ بعدی بدون اینترنت در دسترس باشد. در صورت خطای شبکه، اطلاعات ذخیره‌شدهٔ قبلی حفظ می‌شوند.",
            "پشتیبان‌گیری و بازیابی" to "پیش از تغییرات مهم، از تنظیمات یک پشتیبان کامل Excel یا CSV تهیه کن. بازیابی پشتیبان کامل پس از تأیید، داده‌های روزانهٔ فعلی را جایگزین می‌کند. فایل گزارش دوره‌ای با پشتیبان کامل فرق دارد؛ بازیابی گزارش دوره‌ای فقط رکوردهای دورهٔ داخل فایل را وارد یا به‌روزرسانی می‌کند. PDF برای مشاهده و چاپ است و فایل پشتیبان قابل بازیابی محسوب نمی‌شود.",
            "نصب نسخهٔ جدید" to "برای نصب نسخهٔ جدید، versionCode باید از نسخهٔ نصب‌شده بالاتر باشد. برای نگهداری اطلاعات، برنامهٔ قبلی را حذف نکن؛ APK جدید را روی همان برنامه نصب کن. پیش از نصب، پشتیبان کامل تهیه کن و فایل پشتیبان را در محل امن نگه دار."
        )
    )

    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var selectedTopic by remember { mutableStateOf<Pair<String, String>?>(null) }
    BackHandler(enabled = selectedCategory != null) {
        if (selectedTopic != null) selectedTopic = null else selectedCategory = null
    }
    val helpListState = rememberLazyListState()
    LaunchedEffect(selectedCategory, selectedTopic) { helpListState.scrollToItem(0) }

    LazyColumn(state = helpListState, modifier = modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
        item {
            when {
                selectedTopic != null -> {
                    OutlinedButton(onClick = { selectedTopic = null }, modifier = Modifier.fillMaxWidth().border(1.dp, gold, RoundedCornerShape(9.dp))) {
                        PersianText("بازگشت به موضوعات", fontWeight = FontWeight.Bold)
                    }
                }
                selectedCategory != null -> {
                    OutlinedButton(onClick = { selectedCategory = null }, modifier = Modifier.fillMaxWidth().border(1.dp, gold, RoundedCornerShape(9.dp))) {
                        PersianText("بازگشت به دسته‌بندی‌ها", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        if (selectedCategory == null) {
            item {
                PersianText("راهنمای جامع مورخ", modifier = Modifier.fillMaxWidth(), fontSize = 17.sp, fontWeight = FontWeight.Bold, color = AppPalette.Ink, textAlign = TextAlign.Center)
                PersianText("برای دیدن راهنما، ابتدا یک دسته را انتخاب کن.", modifier = Modifier.fillMaxWidth(), fontSize = 12.sp, color = AppPalette.Muted, textAlign = TextAlign.Center)
            }
            items(helpGroups.keys.toList()) { category ->
                Card(colors = CardDefaults.cardColors(containerColor = AppPalette.Surface), shape = RoundedCornerShape(13.dp), modifier = Modifier.fillMaxWidth().border(1.dp, gold, RoundedCornerShape(13.dp)).clickable { selectedCategory = category }) {
                    Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        PersianText(category, modifier = Modifier.weight(1f), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AppPalette.Primary)
                        PersianText("‹", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = AppPalette.Primary)
                    }
                }
            }
        } else if (selectedTopic == null) {
            item { PersianText(selectedCategory!!, modifier = Modifier.fillMaxWidth(), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = AppPalette.Ink, textAlign = TextAlign.Center) }
            items(helpGroups[selectedCategory!!].orEmpty()) { topic ->
                Card(colors = CardDefaults.cardColors(containerColor = AppPalette.Surface), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().border(1.dp, gold, RoundedCornerShape(12.dp)).clickable { selectedTopic = topic }) {
                    Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        PersianText(topic.first, modifier = Modifier.weight(1f), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = AppPalette.Ink)
                        PersianText("‹", fontSize = 20.sp, color = AppPalette.Primary)
                    }
                }
            }
        } else {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = AppPalette.Surface), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().border(1.dp, gold, RoundedCornerShape(14.dp))) {
                    Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        PersianText(selectedTopic!!.first, modifier = Modifier.fillMaxWidth(), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = AppPalette.Primary, textAlign = TextAlign.Center)
                        Divider(color = gold)
                        PersianText(selectedTopic!!.second, fontSize = 13.sp, color = AppPalette.Ink, lineHeight = 23.sp)
                    }
                }
            }
        }
    }
}
