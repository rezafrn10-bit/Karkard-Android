package ir.karkard.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


private val ShiftYellow = Color(0xFFFFF0B3)
private val ShiftYellowText = Color(0xFF795500)
private val OvertimeGreen = Color(0xFFD9F2D9)
private val OvertimeGreenText = Color(0xFF176B36)

private fun String.toLatinDigits(): String = map { ch ->
    when (ch) {
        '۰' -> '0'; '۱' -> '1'; '۲' -> '2'; '۳' -> '3'; '۴' -> '4'
        '۵' -> '5'; '۶' -> '6'; '۷' -> '7'; '۸' -> '8'; '۹' -> '9'
        '٠' -> '0'; '١' -> '1'; '٢' -> '2'; '٣' -> '3'; '٤' -> '4'
        '٥' -> '5'; '٦' -> '6'; '٧' -> '7'; '٨' -> '8'; '٩' -> '9'
        else -> ch
    }
}.joinToString("")

private val JalaliMonthNames = listOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
private val JalaliWeekdayNames = listOf("یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه")
private fun jalaliDisplayDate(value: String): String = value.replace('-', '/').toPersianDigits()

private fun String.toPersianDigits(): String = map { ch ->
    when (ch) {
        '0' -> '۰'; '1' -> '۱'; '2' -> '۲'; '3' -> '۳'; '4' -> '۴'
        '5' -> '۵'; '6' -> '۶'; '7' -> '۷'; '8' -> '۸'; '9' -> '۹'
        else -> ch
    }
}.joinToString("")

@Composable
private fun PersianText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = FontFamily.SansSerif,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    textDecoration: TextDecoration? = null,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    style: TextStyle = LocalTextStyle.current
) {
    androidx.compose.material3.Text(
        text = text.toPersianDigits(),
        modifier = modifier,
        color = color,
        fontSize = fontSize,
        fontStyle = fontStyle,
        fontWeight = fontWeight,
        fontFamily = fontFamily,
        letterSpacing = letterSpacing,
        textDecoration = textDecoration,
        textAlign = textAlign,
        lineHeight = lineHeight,
        overflow = overflow,
        softWrap = softWrap,
        maxLines = maxLines,
        minLines = minLines,
        style = style
    )
}

data class WorkSession(
    val id: Long = 0L,
    val startDate: String,
    val startTime: String,
    val endDate: String,
    val endTime: String,
    val note: String = ""
)

data class WorkDay(
    val date: String,
    val in1: String = "", val out1: String = "",
    val in2: String = "", val out2: String = "",
    val in3: String = "", val out3: String = "",
    val note: String = "",
    val dayType: String = "کاری",
    val overtimeOverride: String = "",
    val shiftEnabled: Boolean = false,
    val shiftStart: String = "",
    val shiftEnd: String = "",
    val shiftStartDate: String = "",
    val shiftEndDate: String = "",
    val holidayIn: String = "",
    val holidayOut: String = "",
    val leave1Start: String = "", val leave1End: String = "",
    val leave2Start: String = "", val leave2End: String = "",
    val hourlyLeaveEnabled: Boolean = false,
    val extraDayTypes: String = "", // pipe-separated second status; primary dayType remains compatible
    val in4: String = "", val out4: String = "",
    val leave3Start: String = "", val leave3End: String = "",
    val leave4Start: String = "", val leave4End: String = "",
    val fixedHoursMode: Boolean = true
)

private val workHolidayStatuses = setOf("تعطیل رسمی", "تعطیل مناسبتی")
private val workLeaveStatuses = setOf("مرخصی", "استعلاجی")
private val workSecondStatuses = workLeaveStatuses + "مأموریت"

/** Day statuses use one primary type plus an optional second type for old-record compatibility. */
private fun dayStatuses(day: WorkDay): Set<String> = buildSet {
    if (day.dayType.isNotBlank()) add(if (day.dayType == "تعطیل") "تعطیل رسمی" else day.dayType)
    day.extraDayTypes.split('|').filter { it.isNotBlank() }.forEach { add(it) }
}
private fun hasDayStatus(day: WorkDay, status: String) = status in dayStatuses(day)

private fun toggleDayStatus(day: WorkDay, selected: String): WorkDay {
    val current = dayStatuses(day)
    val next = if (selected in current) current - selected else {
        when {
            selected in workHolidayStatuses -> (current - workHolidayStatuses - "کاری") + selected
            selected in workSecondStatuses -> {
                // One secondary status only; allow it with one holiday or with work+mission.
                val base = current.intersect(workHolidayStatuses).firstOrNull()
                    ?: if (selected == "مأموریت" && "کاری" in current) "کاری" else null
                (if (base == null) emptySet() else setOf(base)) + selected
            }
            selected == "کاری" -> if ("مأموریت" in current) setOf("کاری", "مأموریت") else setOf("کاری")
            else -> setOf(selected)
        }
    }
    val primary = next.firstOrNull { it in workHolidayStatuses }
        ?: next.firstOrNull { it == "کاری" }
        ?: next.firstOrNull().orEmpty()
    return day.copy(dayType = primary, extraDayTypes = (next - primary).joinToString("|"))
}

class WorkDb(context: Context) : SQLiteOpenHelper(context, "karkard.db", null, 19) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE workdays(
            date TEXT PRIMARY KEY, in1 TEXT, out1 TEXT, in2 TEXT, out2 TEXT,
            in3 TEXT, out3 TEXT, note TEXT, day_type TEXT DEFAULT 'کاری',
            overtime_override TEXT DEFAULT '', shift_enabled INTEGER DEFAULT 0, shift_start TEXT DEFAULT '', shift_end TEXT DEFAULT '', shift_start_date TEXT DEFAULT '', shift_end_date TEXT DEFAULT '', holiday_in TEXT DEFAULT '', holiday_out TEXT DEFAULT '', leave1_start TEXT DEFAULT '', leave1_end TEXT DEFAULT '', leave2_start TEXT DEFAULT '', leave2_end TEXT DEFAULT '', leave_enabled INTEGER DEFAULT 0, extra_day_types TEXT DEFAULT '',
            in4 TEXT DEFAULT '', out4 TEXT DEFAULT '', leave3_start TEXT DEFAULT '', leave3_end TEXT DEFAULT '', leave4_start TEXT DEFAULT '', leave4_end TEXT DEFAULT '', fixed_hours_mode INTEGER DEFAULT 1)""")
        db.execSQL("CREATE TABLE holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL)")
        db.execSQL("CREATE TABLE official_holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL, year INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE holiday_sync(year INTEGER PRIMARY KEY, synced_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE calendar_events(date TEXT PRIMARY KEY, title TEXT NOT NULL, year INTEGER NOT NULL)")
        db.execSQL("""CREATE TABLE work_sessions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            start_date TEXT NOT NULL, start_time TEXT NOT NULL,
            end_date TEXT NOT NULL, end_time TEXT NOT NULL,
            note TEXT NOT NULL DEFAULT '')""")
        db.execSQL("""CREATE TABLE settings(
            key TEXT PRIMARY KEY, value TEXT NOT NULL)""")
        val defaults = mapOf(
            "workday_hours" to "07:00", "thursday_hours_value" to "05:00",
            "fixed_hours_enabled" to "1",
            "fixed_weekday_start" to "07:00", "fixed_weekday_end" to "14:00",
            "fixed_thursday_start" to "07:00", "fixed_thursday_end" to "12:00"
        )
        defaults.forEach { (k,v) ->
            val cv = ContentValues().apply { put("key", k); put("value", v) }
            db.insert("settings", null, cv)
        }
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN day_type TEXT DEFAULT 'کاری'")
            db.execSQL("ALTER TABLE workdays ADD COLUMN overtime_override TEXT DEFAULT ''")
            val defaults = mapOf("workday_hours" to "07:00", "thursday_hours_value" to "05:00")
            defaults.forEach { (k,v) ->
                val cv = ContentValues().apply { put("key",k); put("value",v) }
                db.insertWithOnConflict("settings", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
            }
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_enabled INTEGER DEFAULT 0")
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_start TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_end TEXT DEFAULT ''")
        }
        if (oldVersion < 4) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_start_date TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_end_date TEXT DEFAULT ''")
            db.execSQL("DELETE FROM settings WHERE key='shift_hours'")
        }
        if (oldVersion < 5) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN holiday_in TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN holiday_out TEXT DEFAULT ''")
        }
        if (oldVersion < 11) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave1_start TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave1_end TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave2_start TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave2_end TEXT DEFAULT ''")
        }
        if (oldVersion < 12) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave_enabled INTEGER DEFAULT 0")
            // Existing leave entries must remain active after an upgrade.
            db.execSQL("""UPDATE workdays SET leave_enabled=1 WHERE
                COALESCE(leave1_start,'')<>'' OR COALESCE(leave1_end,'')<>'' OR
                COALESCE(leave2_start,'')<>'' OR COALESCE(leave2_end,'')<>''""")
        }
        if (oldVersion < 13) {
            // Migrate factory defaults from prior versions, without overriding other custom choices.
            db.execSQL("UPDATE settings SET value='07:00' WHERE key='workday_hours' AND value='08:00'")
            db.execSQL("UPDATE settings SET value='05:00' WHERE key='thursday_hours_value' AND value='04:00'")
            db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('workday_hours','07:00')")
            db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('thursday_hours_value','05:00')")
        }
        if (oldVersion < 14) {
            // Older versions stored Fridays as the legacy 'تعطیل' status.
            db.execSQL("UPDATE workdays SET day_type='تعطیل رسمی' WHERE day_type='تعطیل'")
        }
        if (oldVersion < 15) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN extra_day_types TEXT DEFAULT ''")
        }
        if (oldVersion < 17) db.execSQL("DROP TABLE IF EXISTS long_leave_days")
        if (oldVersion < 18) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN in4 TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN out4 TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave3_start TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave3_end TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave4_start TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave4_end TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN fixed_hours_mode INTEGER DEFAULT 1")
            db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('fixed_hours_enabled','1')")
        }
        if (oldVersion < 19) {
            // Version 0.63 replaces the embedded one-shift-per-day design with independent activity rows.
            // Previous shift records were test data and are deliberately not migrated into the new model.
            db.execSQL("UPDATE workdays SET shift_enabled=0, shift_start='', shift_end='', shift_start_date='', shift_end_date=''")
            db.execSQL("CREATE TABLE IF NOT EXISTS work_sessions(id INTEGER PRIMARY KEY AUTOINCREMENT, start_date TEXT NOT NULL, start_time TEXT NOT NULL, end_date TEXT NOT NULL, end_time TEXT NOT NULL, note TEXT NOT NULL DEFAULT '')")
            db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('fixed_weekday_start','07:00')")
            db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('fixed_weekday_end','14:00')")
            db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('fixed_thursday_start','07:00')")
            db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('fixed_thursday_end','12:00')")
        }
        db.execSQL("CREATE TABLE IF NOT EXISTS work_sessions(id INTEGER PRIMARY KEY AUTOINCREMENT, start_date TEXT NOT NULL, start_time TEXT NOT NULL, end_date TEXT NOT NULL, end_time TEXT NOT NULL, note TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE IF NOT EXISTS holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS official_holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL, year INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS holiday_sync(year INTEGER PRIMARY KEY, synced_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS calendar_events(date TEXT PRIMARY KEY, title TEXT NOT NULL, year INTEGER NOT NULL)")
        db.execSQL("DELETE FROM settings WHERE key='shift_hours'")
        if (oldVersion < 10) {
            // Force a fresh calendar download after holiday parser improvements.
            // Existing work records and saved calendar data are retained.
            db.delete("holiday_sync", null, null)
        }
    }

    fun hasWorkDay(date: String): Boolean = readableDatabase.rawQuery(
        "SELECT 1 FROM workdays WHERE date=? LIMIT 1", arrayOf(date)
    ).use { it.moveToFirst() }

    fun getDay(date: String): WorkDay {
        readableDatabase.rawQuery("SELECT * FROM workdays WHERE date=?", arrayOf(date)).use { c ->
            if (c.moveToFirst()) return WorkDay(
                c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "",
                c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "",
                c.getString(6) ?: "", c.getString(7) ?: "",
                if (c.columnCount > 8) c.getString(8) ?: "کاری" else "کاری",
                if (c.columnCount > 9) c.getString(9) ?: "" else "",
                if (c.columnCount > 10) c.getInt(10) == 1 else false,
                if (c.columnCount > 11) c.getString(11) ?: "" else "",
                if (c.columnCount > 12) c.getString(12) ?: "" else "",
                if (c.columnCount > 13) c.getString(13) ?: "" else "",
                if (c.columnCount > 14) c.getString(14) ?: "" else "",
                if (c.columnCount > 15) c.getString(15) ?: "" else "",
                if (c.columnCount > 16) c.getString(16) ?: "" else "",
                if (c.columnCount > 17) c.getString(17) ?: "" else "", if (c.columnCount > 18) c.getString(18) ?: "" else "",
                if (c.columnCount > 19) c.getString(19) ?: "" else "", if (c.columnCount > 20) c.getString(20) ?: "" else "",
                if (c.columnCount > 21) c.getInt(21) == 1 else listOf(17,18,19,20).any { i -> i < c.columnCount && !c.getString(i).isNullOrBlank() },
                if (c.columnCount > 22) c.getString(22) ?: "" else "",
                if (c.columnCount > 23) c.getString(23) ?: "" else "",
                if (c.columnCount > 24) c.getString(24) ?: "" else "",
                if (c.columnCount > 25) c.getString(25) ?: "" else "",
                if (c.columnCount > 26) c.getString(26) ?: "" else "",
                if (c.columnCount > 27) c.getString(27) ?: "" else "",
                if (c.columnCount > 28) c.getString(28) ?: "" else "",
                if (c.columnCount > 29) c.getInt(29) == 1 else isFixedHoursEnabled()
            )
        }
        return WorkDay(date, fixedHoursMode = isFixedHoursEnabled())
    }
    fun calendarSyncTime(year: Int): Long = readableDatabase.rawQuery(
        "SELECT synced_at FROM holiday_sync WHERE year=?", arrayOf(year.toString())
    ).use { if (it.moveToFirst()) it.getLong(0) else 0L }

    /** Deletes one or more selected report cards without touching calendar baselines or reminders.
     * Rows are selected by their normalized Jalali date. If a shift stored on another row starts
     * inside the deleted period, only that shift is cleared and the other row's daily data remains.
     */
    private fun deleteReportDates(dateKeys: Set<String>, tourahiMonthKeys: Set<String> = emptySet()): Int {
        val targets = dateKeys.mapNotNull(::normalizedJalaliDateKey).toSet()
        if (targets.isEmpty()) return 0
        val database = writableDatabase
        database.beginTransaction()
        try {
            val allRows = allDaysForBackup()
            val rowsToDelete = allRows.filter { normalizedJalaliDateKey(it.date)?.let(targets::contains) == true }
            val rowsWithShiftToClear = allRows.filter { row ->
                normalizedJalaliDateKey(row.date)?.let(targets::contains) != true && row.shiftEnabled &&
                    normalizedJalaliDateKey(row.shiftStartDate.ifBlank { row.date })?.let(targets::contains) == true
            }
            rowsToDelete.forEach { row ->
                database.delete("workdays", "date=?", arrayOf(row.date))
            }
            rowsWithShiftToClear.forEach { row ->
                val values = ContentValues().apply {
                    put("shift_enabled", 0)
                    put("shift_start", "")
                    put("shift_end", "")
                    put("shift_start_date", "")
                    put("shift_end_date", "")
                }
                database.update("workdays", values, "date=?", arrayOf(row.date))
            }
            allWorkSessions().filter { normalizedJalaliDateKey(it.startDate)?.let(targets::contains) == true }
                .forEach { session -> database.delete("work_sessions", "id=?", arrayOf(session.id.toString())) }
            val manualHolidayRows = allHolidays().filter { normalizedJalaliDateKey(it.first)?.let(targets::contains) == true }
            manualHolidayRows.forEach { (rawDate, _) ->
                database.delete("holidays", "date=?", arrayOf(rawDate))
            }
            tourahiMonthKeys.forEach { monthKey ->
                database.delete("settings", "key=?", arrayOf("tourahi_deduction_$monthKey"))
            }
            database.setTransactionSuccessful()
            return rowsToDelete.size + rowsWithShiftToClear.size + manualHolidayRows.size
        } finally {
            database.endTransaction()
        }
    }

    /** Deletes every saved field on the selected day, including a manual holiday reason. */
    fun deleteDay(date: String): Int {
        val normalized = normalizedJalaliDateKey(date) ?: throw IllegalArgumentException("Invalid date")
        return deleteReportDates(setOf(normalized))
    }

    /** Deletes selected month cards and their related manual توراهی deduction settings. */
    fun deleteReportMonths(year: Int, months: Set<Int>): Int {
        val validMonths = months.filter { it in 1..12 }.toSet()
        if (validMonths.isEmpty()) return 0
        val dates = validMonths.flatMap { month ->
            (1..jalaliMonthLength(year, month)).map { day ->
                "%04d-%02d-%02d".format(Locale.ROOT, year, month, day)
            }
        }.toSet()
        val monthKeys = validMonths.map { "%04d-%02d".format(Locale.ROOT, year, it) }.toSet()
        return deleteReportDates(dates, monthKeys)
    }

    /** Deletes all daily records represented by the selected cards in a monthly report. */
    fun deleteReportDays(dates: Set<String>): Int = deleteReportDates(dates)

    fun saveDayAndHoliday(d: WorkDay, holidayReason: String?) {
        val database = writableDatabase
        database.beginTransaction()
        try {
            saveDay(d)
            if (holidayReason.isNullOrBlank()) removeHoliday(d.date)
            else saveHoliday(d.date, holidayReason.trim())
            database.setTransactionSuccessful()
        } finally {
            database.endTransaction()
        }
    }

    fun saveDay(d: WorkDay) {
        val v = ContentValues().apply {
            put("date", d.date); put("in1",d.in1); put("out1",d.out1)
            put("in2",d.in2); put("out2",d.out2); put("in3",d.in3); put("out3",d.out3)
            put("note",d.note); put("day_type",d.dayType); put("overtime_override",d.overtimeOverride); put("shift_enabled", if(d.shiftEnabled) 1 else 0); put("shift_start",d.shiftStart); put("shift_end",d.shiftEnd); put("shift_start_date",d.shiftStartDate); put("shift_end_date",d.shiftEndDate)
            put("holiday_in", d.holidayIn); put("holiday_out", d.holidayOut); put("leave1_start", d.leave1Start); put("leave1_end", d.leave1End); put("leave2_start", d.leave2Start); put("leave2_end", d.leave2End); put("leave_enabled", if (d.hourlyLeaveEnabled) 1 else 0); put("extra_day_types", d.extraDayTypes)
            put("in4", d.in4); put("out4", d.out4)
            put("leave3_start", d.leave3Start); put("leave3_end", d.leave3End)
            put("leave4_start", d.leave4Start); put("leave4_end", d.leave4End)
            put("fixed_hours_mode", if (d.fixedHoursMode) 1 else 0)
        }
        writableDatabase.insertWithOnConflict("workdays", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun allDays(month: String): List<WorkDay> {
        val result = mutableListOf<WorkDay>()
        readableDatabase.rawQuery("SELECT * FROM workdays WHERE date LIKE ? ORDER BY date", arrayOf("$month%")).use { c ->
            while(c.moveToNext()) result.add(WorkDay(
                c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "",
                c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "",
                c.getString(6) ?: "", c.getString(7) ?: "",
                c.getString(8) ?: "کاری", c.getString(9) ?: "", c.getInt(10) == 1, c.getString(11) ?: "", c.getString(12) ?: "", c.getString(13) ?: "", c.getString(14) ?: "",
                if (c.columnCount > 15) c.getString(15) ?: "" else "", if (c.columnCount > 16) c.getString(16) ?: "" else "",
                if (c.columnCount > 17) c.getString(17) ?: "" else "", if (c.columnCount > 18) c.getString(18) ?: "" else "",
                if (c.columnCount > 19) c.getString(19) ?: "" else "", if (c.columnCount > 20) c.getString(20) ?: "" else "",
                if (c.columnCount > 21) c.getInt(21) == 1 else listOf(17,18,19,20).any { i -> i < c.columnCount && !c.getString(i).isNullOrBlank() },
                if (c.columnCount > 22) c.getString(22) ?: "" else "",
                if (c.columnCount > 23) c.getString(23) ?: "" else "",
                if (c.columnCount > 24) c.getString(24) ?: "" else "",
                if (c.columnCount > 25) c.getString(25) ?: "" else "",
                if (c.columnCount > 26) c.getString(26) ?: "" else "",
                if (c.columnCount > 27) c.getString(27) ?: "" else "",
                if (c.columnCount > 28) c.getString(28) ?: "" else "",
                if (c.columnCount > 29) c.getInt(29) == 1 else isFixedHoursEnabled()
            ))
        }
        return result
    }
    fun allDaysYear(year: Int): List<WorkDay> = allDaysForBackup().filter { it.date.startsWith("%04d-".format(year)) }
    fun officialHolidays(year: Int): List<Pair<String, String>> {
        val result = mutableListOf<Pair<String, String>>()
        readableDatabase.rawQuery(
            "SELECT date,title FROM official_holidays WHERE year=? ORDER BY date",
            arrayOf(year.toString())
        ).use { c -> while (c.moveToNext()) result.add(c.getString(0) to c.getString(1)) }
        return result
    }

    fun officialHolidayTitle(date: String): String? {
        readableDatabase.rawQuery("SELECT title FROM official_holidays WHERE date=?", arrayOf(date)).use { c ->
            return if (c.moveToFirst()) c.getString(0) else null
        }
    }

    fun calendarEventTitle(date: String): String? {
        readableDatabase.rawQuery("SELECT title FROM calendar_events WHERE date=?", arrayOf(date)).use { c ->
            return if (c.moveToFirst()) c.getString(0) else null
        }
    }

    fun displayHolidayTitle(date: String): String? {
        // Calendar display is intentionally independent from manual workday holiday reasons.
        val titles = listOfNotNull(officialHolidayTitle(date), calendarEventTitle(date))
            .flatMap { value -> value.split("،").map { title -> title.trim() } }
            .filter { it.isNotBlank() }.distinct()
        return titles.takeIf { it.isNotEmpty() }?.joinToString("، ")
    }

    /** One-time verified offline seed for 1405. User workdays and manual holidays stay untouched. */
    fun ensureBundled1405Calendar() {
        if (getSettingText("calendar_1405_seed", "") == "1405.1") return
        val storedHolidays = officialHolidays(1405)
        val storedEvents = calendarEvents(1405)
        // A complete remotely synchronized calendar already has more observances than the seed.
        if (storedHolidays.size < 20 || storedEvents.size < 100) {
            val verified = Calendar1405.holidays
            val titles = (storedEvents + Calendar1405.events + verified).groupBy({ it.first }, { it.second })
                .map { (date, list) -> date to list.distinct().joinToString("، ") }
            replaceCalendarData(1405, verified, titles)
        }
        setSettingText("calendar_1405_seed", "1405.1")
    }

    fun shouldSyncOfficialHolidays(year: Int, now: Long = System.currentTimeMillis()): Boolean {
        // Force a refresh of 1405 data if the previous app version saved a partial calendar
        // without the official Mab'ath holiday. This avoids the old 7-day cache hiding the fix.
        if (year == 1405 && officialHolidayTitle("1405-10-16").isNullOrBlank()) return true
        readableDatabase.rawQuery("SELECT synced_at FROM holiday_sync WHERE year=?", arrayOf(year.toString())).use { c ->
            if (!c.moveToFirst()) return true
            // Refresh at most once per week unless the user explicitly requests an update.
            return now - c.getLong(0) >= 7L * 24L * 60L * 60L * 1000L
        }
    }

    fun replaceOfficialHolidays(year: Int, holidays: List<Pair<String, String>>) {
        require(holidays.isNotEmpty()) { "فهرست تعطیلات خالی است؛ اطلاعات قبلی حفظ شد." }
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("official_holidays", "year=?", arrayOf(year.toString()))
            holidays.forEach { (date, title) ->
                val values = ContentValues().apply {
                    put("date", date); put("title", title); put("year", year)
                }
                db.insertWithOnConflict("official_holidays", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            val meta = ContentValues().apply { put("year", year); put("synced_at", System.currentTimeMillis()) }
            db.insertWithOnConflict("holiday_sync", null, meta, SQLiteDatabase.CONFLICT_REPLACE)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun calendarEvents(year: Int): List<Pair<String, String>> {
        val result = mutableListOf<Pair<String, String>>()
        readableDatabase.rawQuery("SELECT date,title FROM calendar_events WHERE year=? ORDER BY date", arrayOf(year.toString())).use { c ->
            while (c.moveToNext()) result.add(c.getString(0) to c.getString(1))
        }
        return result
    }

    fun replaceCalendarData(year: Int, holidays: List<Pair<String, String>>, events: List<Pair<String, String>>) {
        require(holidays.isNotEmpty()) { "فهرست تعطیلات خالی است؛ اطلاعات قبلی حفظ شد." }
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("official_holidays", "year=?", arrayOf(year.toString()))
            holidays.forEach { (date, title) ->
                val values = ContentValues().apply { put("date", date); put("title", title); put("year", year) }
                db.insertWithOnConflict("official_holidays", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.delete("calendar_events", "year=?", arrayOf(year.toString()))
            events.forEach { (date, title) ->
                val values = ContentValues().apply { put("date", date); put("title", title); put("year", year) }
                db.insertWithOnConflict("calendar_events", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            val meta = ContentValues().apply { put("year", year); put("synced_at", System.currentTimeMillis()) }
            db.insertWithOnConflict("holiday_sync", null, meta, SQLiteDatabase.CONFLICT_REPLACE)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun saveHoliday(date: String, title: String) {
        val v = ContentValues().apply { put("date", date); put("title", title) }
        writableDatabase.insertWithOnConflict("holidays", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun removeHoliday(date: String) { writableDatabase.delete("holidays", "date=?", arrayOf(date)) }
    fun allHolidays(): List<Pair<String,String>> {
        val out = mutableListOf<Pair<String,String>>()
        readableDatabase.rawQuery("SELECT date,title FROM holidays ORDER BY date", null).use { c -> while(c.moveToNext()) out.add(c.getString(0) to c.getString(1)) }
        return out
    }
    fun holidayTitle(date: String): String? {
        readableDatabase.rawQuery("SELECT title FROM holidays WHERE date=?", arrayOf(date)).use { c -> return if(c.moveToFirst()) c.getString(0) else null }
    }
    fun getSetting(key: String): Boolean {
        readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?", arrayOf(key)).use { c ->
            return c.moveToFirst() && c.getString(0) == "true"
        }
    }
    fun getSettingText(key: String, fallback: String = ""): String {
        readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?", arrayOf(key)).use { c ->
            return if (c.moveToFirst()) c.getString(0) else fallback
        }
    }
    fun isFixedHoursEnabled(): Boolean = getSettingText("fixed_hours_enabled", "1") !in setOf("0", "false", "off")
    fun setSettingText(key: String, value: String) {
        val v = ContentValues().apply { put("key",key); put("value",value) }
        writableDatabase.insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun setSetting(key: String, value: Boolean) {
        val v = ContentValues().apply { put("key",key); put("value",value.toString()) }
        writableDatabase.insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun allDaysForBackup(): List<WorkDay> {
        val result = mutableListOf<WorkDay>()
        readableDatabase.rawQuery("SELECT * FROM workdays ORDER BY date", null).use { c ->
            while(c.moveToNext()) result.add(WorkDay(
                c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "",
                c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "",
                c.getString(6) ?: "", c.getString(7) ?: "", c.getString(8) ?: "کاری",
                c.getString(9) ?: "", c.getInt(10) == 1, c.getString(11) ?: "", c.getString(12) ?: "", c.getString(13) ?: "", c.getString(14) ?: "",
                if (c.columnCount > 15) c.getString(15) ?: "" else "", if (c.columnCount > 16) c.getString(16) ?: "" else "",
                if (c.columnCount > 17) c.getString(17) ?: "" else "", if (c.columnCount > 18) c.getString(18) ?: "" else "",
                if (c.columnCount > 19) c.getString(19) ?: "" else "", if (c.columnCount > 20) c.getString(20) ?: "" else "",
                if (c.columnCount > 21) c.getInt(21) == 1 else listOf(17,18,19,20).any { i -> i < c.columnCount && !c.getString(i).isNullOrBlank() },
                if (c.columnCount > 22) c.getString(22) ?: "" else "",
                if (c.columnCount > 23) c.getString(23) ?: "" else "",
                if (c.columnCount > 24) c.getString(24) ?: "" else "",
                if (c.columnCount > 25) c.getString(25) ?: "" else "",
                if (c.columnCount > 26) c.getString(26) ?: "" else "",
                if (c.columnCount > 27) c.getString(27) ?: "" else "",
                if (c.columnCount > 28) c.getString(28) ?: "" else "",
                if (c.columnCount > 29) c.getInt(29) == 1 else isFixedHoursEnabled()
            ))
        }
        return result
    }
    fun saveWorkSession(session: WorkSession): Long {
        val values = ContentValues().apply {
            put("start_date", session.startDate)
            put("start_time", session.startTime)
            put("end_date", session.endDate)
            put("end_time", session.endTime)
            put("note", session.note)
        }
        return if (session.id > 0L) {
            writableDatabase.update("work_sessions", values, "id=?", arrayOf(session.id.toString()))
            session.id
        } else writableDatabase.insert("work_sessions", null, values)
    }

    fun deleteWorkSession(id: Long) { writableDatabase.delete("work_sessions", "id=?", arrayOf(id.toString())) }

    fun workSessionsStartingOn(date: String): List<WorkSession> = workSessionsInPeriod(date, date)

    fun workSessionsInPeriod(startDateInclusive: String, endDateInclusive: String): List<WorkSession> {
        val result = mutableListOf<WorkSession>()
        readableDatabase.rawQuery(
            "SELECT id,start_date,start_time,end_date,end_time,note FROM work_sessions WHERE start_date>=? AND start_date<=? ORDER BY start_date,start_time,id",
            arrayOf(startDateInclusive, endDateInclusive)
        ).use { c -> while (c.moveToNext()) result.add(WorkSession(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "")) }
        return result
    }

    fun allWorkSessions(): List<WorkSession> {
        val result = mutableListOf<WorkSession>()
        readableDatabase.rawQuery("SELECT id,start_date,start_time,end_date,end_time,note FROM work_sessions ORDER BY start_date,start_time,id", null).use { c ->
            while (c.moveToNext()) result.add(WorkSession(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: ""))
        }
        return result
    }

    fun allSettings(): List<Pair<String,String>> {
        val result = mutableListOf<Pair<String,String>>()
        readableDatabase.rawQuery("SELECT key,value FROM settings ORDER BY key", null).use { c ->
            while(c.moveToNext()) result.add(c.getString(0) to c.getString(1))
        }
        allHolidays().forEach { (date,title) -> result.add("holiday:$date" to title) }
        allWorkSessions().forEach { session ->
            val payload = org.json.JSONObject().apply {
                put("startDate", session.startDate); put("startTime", session.startTime)
                put("endDate", session.endDate); put("endTime", session.endTime); put("note", session.note)
            }.toString()
            result.add("work_session:${session.id}" to payload)
        }
        return result
    }
    fun restoreBackup(days: List<WorkDay>, settings: List<Pair<String,String>>) {
        writableDatabase.beginTransaction()
        try {
            writableDatabase.delete("workdays", null, null)
            writableDatabase.delete("holidays", null, null)
            writableDatabase.delete("work_sessions", null, null)
            // The full CSV contains all settings as well as workday and activity rows.
            // Clear them first so restoring a backup cannot leave stale options behind.
            writableDatabase.delete("settings", null, null)
            days.forEach { d ->
                val v = ContentValues().apply {
                    put("date",d.date); put("in1",d.in1); put("out1",d.out1)
                    put("in2",d.in2); put("out2",d.out2); put("in3",d.in3); put("out3",d.out3)
                    put("note",d.note); put("day_type",d.dayType); put("overtime_override",d.overtimeOverride); put("shift_enabled", if(d.shiftEnabled) 1 else 0); put("shift_start",d.shiftStart); put("shift_end",d.shiftEnd); put("shift_start_date",d.shiftStartDate); put("shift_end_date",d.shiftEndDate)
                    put("holiday_in", d.holidayIn); put("holiday_out", d.holidayOut); put("leave1_start", d.leave1Start); put("leave1_end", d.leave1End); put("leave2_start", d.leave2Start); put("leave2_end", d.leave2End); put("leave_enabled", if (d.hourlyLeaveEnabled) 1 else 0); put("extra_day_types", d.extraDayTypes)
                    put("in4", d.in4); put("out4", d.out4)
                    put("leave3_start", d.leave3Start); put("leave3_end", d.leave3End)
                    put("leave4_start", d.leave4Start); put("leave4_end", d.leave4End)
                    put("fixed_hours_mode", if (d.fixedHoursMode) 1 else 0)
                }
                writableDatabase.insertWithOnConflict("workdays",null,v,SQLiteDatabase.CONFLICT_REPLACE)
            }
            settings.forEach { (k,v) ->
                if (k.startsWith("holiday:")) {
                    val cv = ContentValues().apply { put("date",k.removePrefix("holiday:")); put("title",v) }
                    writableDatabase.insertWithOnConflict("holidays",null,cv,SQLiteDatabase.CONFLICT_REPLACE)
                } else if (k.startsWith("work_session:")) {
                    try {
                        val json = org.json.JSONObject(v)
                        val normalized = normalizeWorkSession(WorkSession(
                            startDate = json.optString("startDate"), startTime = json.optString("startTime"),
                            endDate = json.optString("endDate"), endTime = json.optString("endTime"),
                            note = json.optString("note")
                        ))
                        if (normalized != null) {
                            val cv = ContentValues().apply {
                                put("start_date", normalized.startDate); put("start_time", normalized.startTime)
                                put("end_date", normalized.endDate); put("end_time", normalized.endTime)
                                put("note", normalized.note)
                            }
                            writableDatabase.insert("work_sessions", null, cv)
                        }
                    } catch (_: Exception) { /* Ignore malformed optional activity rows without aborting other backup data. */ }
                } else if (!k.startsWith("continuousleave:")) {
                    val cv = ContentValues().apply { put("key",k); put("value",v) }
                    writableDatabase.insertWithOnConflict("settings",null,cv,SQLiteDatabase.CONFLICT_REPLACE)
                }
            }
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }
}

private data class DownloadedCalendarData(
    val holidays: List<Pair<String, String>>,
    val events: List<Pair<String, String>>
)

private fun fetchJson(url: String): org.json.JSONObject {
    val connection = java.net.URL(url).openConnection() as java.net.HttpURLConnection
    connection.requestMethod = "GET"
    connection.connectTimeout = 12_000
    connection.readTimeout = 18_000
    connection.setRequestProperty("Accept", "application/json")
    connection.setRequestProperty("User-Agent", "Morakh/0.30")
    try {
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        if (code !in 200..299) throw IllegalStateException("پاسخ سرویس تقویم: HTTP $code")
        return org.json.JSONObject(body)
    } finally { connection.disconnect() }
}

private fun fetchFarsiUiCalendarData(year: Int): DownloadedCalendarData? {
    // This source has an explicit, stable schema: items[].date, items[].title.fa,
    // and items[].isHoliday. It is the primary source to avoid schema drift in the
    // older Persian-Calendar API response.
    val base = "https://raw.githubusercontent.com/MiladJoodi/FarsiUI/main/calendar/years/$year"
    val holidayRoot = fetchJson("$base/holidays.json")
    if (holidayRoot.has("year") && holidayRoot.optInt("year", -1) != year) return null
    val holidayItems = holidayRoot.optJSONArray("items") ?: return null
    if (holidayItems.length() == 0) return null

    val holidays = linkedMapOf<String, MutableList<String>>()
    val allEvents = linkedMapOf<String, MutableList<String>>()
    fun add(target: MutableMap<String, MutableList<String>>, date: String, title: String) {
        val clean = title.trim()
        if (clean.isNotBlank()) {
            val list = target.getOrPut(date) { mutableListOf() }
            if (clean !in list) list.add(clean)
        }
    }
    fun parseItems(items: org.json.JSONArray, holidayOnly: Boolean) {
        for (i in 0 until items.length()) {
            val item = items.optJSONObject(i) ?: continue
            val date = item.optString("date")
            val parts = date.split("-").mapNotNull { it.toIntOrNull() }
            if (parts.size != 3 || parts[0] != year || parts[1] !in 1..12 || parts[2] !in 1..jalaliMonthLength(year, parts[1])) continue
            val titleObject = item.optJSONObject("title")
            val title = titleObject?.optString("fa").orEmpty().ifBlank { item.optString("title_fa") }
            if (title.isBlank()) continue
            if (!holidayOnly || item.optBoolean("isHoliday", item.optBoolean("is_holiday", false))) {
                if (item.optBoolean("isHoliday", item.optBoolean("is_holiday", false))) add(holidays, date, title)
            }
            add(allEvents, date, title)
        }
    }
    parseItems(holidayItems, holidayOnly = true)
    // Events file contains non-holiday observances, including non-holiday religious dates.
    val eventRoot = fetchJson("$base/events.json")
    if (eventRoot.has("year") && eventRoot.optInt("year", -1) != year) return null
    val eventItems = eventRoot.optJSONArray("items") ?: return null
    if (eventItems.length() == 0) return null
    parseItems(eventItems, holidayOnly = false)

    val holidayList = holidays.map { it.key to it.value.joinToString("، ") }
    val eventList = allEvents.map { it.key to it.value.joinToString("، ") }
    if (holidayList.isEmpty() || eventList.isEmpty()) return null
    return DownloadedCalendarData(holidayList, eventList)
}

private fun fetchCalendarData(year: Int): DownloadedCalendarData {
    require(year in 1347..1500) { "سال باید بین ۱۳۴۷ و ۱۵۰۰ باشد." }
    try {
        fetchFarsiUiCalendarData(year)?.let { return it }
    } catch (_: Exception) {
        // Use the documented Persian-Calendar API below as a fallback if this year
        // has not been published by FarsiUI or the static source is temporarily down.
    }
    val holidayRoot = try {
        fetchJson("https://www.persian-calendar.com/api/holidays?year=$year")
    } catch (e: Exception) {
        // No guessed lunar public holidays: preserve the previously saved calendar.
        throw e
    }
    if (holidayRoot.has("year") && holidayRoot.optInt("year", -1) != year) throw IllegalStateException("سال دریافت‌شده با سال درخواستی یکسان نیست.")
    val holidayDays = holidayRoot.optJSONArray("data") ?: throw IllegalStateException("فهرست تعطیلات معتبر نیست.")
    val holidays = linkedMapOf<String, MutableList<String>>()
    val allEvents = linkedMapOf<String, MutableList<String>>()

    fun addTitle(target: MutableMap<String, MutableList<String>>, date: String, title: String) {
        val cleaned = title.trim()
        if (cleaned.isNotBlank()) {
            val list = target.getOrPut(date) { mutableListOf() }
            if (cleaned !in list) list.add(cleaned)
        }
    }

    // The holidays endpoint is authoritative for days off and also supplies each holiday's title.
    for (i in 0 until holidayDays.length()) {
        val item = holidayDays.optJSONObject(i) ?: continue
        val month = item.optInt("month_sh", 0)
        val day = item.optInt("day_sh", 0)
        if (item.optInt("year_sh", year) != year || month !in 1..12 || day !in 1..jalaliMonthLength(year, month)) continue
        val date = "%04d-%02d-%02d".format(Locale.ROOT, year, month, day)
        val events = item.optJSONArray("events") ?: continue
        for (j in 0 until events.length()) {
            val event = events.optJSONObject(j) ?: continue
            val title = event.optString("title_fa").trim()
            if (event.optBoolean("is_holiday", false)) addTitle(holidays, date, title)
            // Put official holidays in the event list too, so their title is visible in every calendar view.
            addTitle(allEvents, date, title)
        }
    }

    // Fetch all other occasions month by month. A failed month must not discard the verified holiday list.
    for (month in 1..12) {
        try {
            val root = fetchJson("https://www.persian-calendar.com/api/events?year=$year&month_sh=$month")
            if (root.optInt("year", year) != year) continue
            val days = root.optJSONArray("data") ?: continue
            for (i in 0 until days.length()) {
                val item = days.optJSONObject(i) ?: continue
                val m = item.optInt("month_sh", month)
                val d = item.optInt("day_sh", 0)
                if (item.optInt("year_sh", year) != year || m !in 1..12 || d !in 1..jalaliMonthLength(year, m)) continue
                val date = "%04d-%02d-%02d".format(Locale.ROOT, year, m, d)
                // Current API returns one event per item; also accept nested event arrays for compatibility.
                val title = item.optString("title_fa").trim()
                if (title.isNotBlank()) addTitle(allEvents, date, title)
                val nested = item.optJSONArray("events")
                if (nested != null) for (j in 0 until nested.length()) {
                    val event = nested.optJSONObject(j) ?: continue
                    addTitle(allEvents, date, event.optString("title_fa"))
                    if (event.optBoolean("is_holiday", false)) addTitle(holidays, date, event.optString("title_fa"))
                }
            }
        } catch (_: Exception) {
            // Continue; official holiday data is still usable offline even if this month's occasions endpoint fails.
        }
    }

    // Do not mix calculated Hijri dates into an official holiday list. Iran's
    // announced lunar holiday dates can differ by a day from civil calculations.
    val holidayList = holidays.map { it.key to it.value.distinct().joinToString("، ") }
    val eventList = allEvents.map { it.key to it.value.distinct().joinToString("، ") }
    if (holidayList.isEmpty()) throw IllegalStateException("سرویس تعطیلات معتبری برنگرداند؛ اطلاعات قبلی حفظ شد.")
    if (eventList.isEmpty()) throw IllegalStateException("فهرست مناسبت‌ها خالی است؛ اطلاعات قبلی حفظ شد.")
    return DownloadedCalendarData(holidayList, eventList)
}

class MainActivity : ComponentActivity() {
    private lateinit var appDb: WorkDb
    private var systemDate by mutableStateOf(LocalDate.now())
    private var reportYear = 1405
    private var reportMonth = 1
    private var reportAnnual = false
    private var reportPdf = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        // Keep Android system status icons (time, signal, battery) visible.
        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN)
        // Match the system bars and the splash letterboxing to the warm ivory background
        // of the splash artwork, instead of showing dark teal strips.
        val splashIvory = android.graphics.Color.rgb(241, 246, 253)
        window.statusBarColor = splashIvory
        window.navigationBarColor = splashIvory
        window.decorView.systemUiVisibility =
            (window.decorView.systemUiVisibility and android.view.View.SYSTEM_UI_FLAG_FULLSCREEN.inv()) or
                android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val db = WorkDb(this)
        db.ensureBundled1405Calendar()
        appDb = db
        // Refresh enabled reminders and the optional date notification on every launch.
        CompanionAlerts.refresh(this)
        systemDate = LocalDate.now()
        setContent {
            var showIntro by remember { mutableStateOf(true) }
            LaunchedEffect(Unit) {
                kotlinx.coroutines.delay(1000)
                showIntro = false
            }
            if (showIntro) {
                // The splash artwork predates the brand rename and contains its
                // former title as pixels near the bottom. Cover just that section
                // and render the current product name as real Compose text.
                BoxWithConstraints(
                    modifier = Modifier.fillMaxSize().background(Color(0xFFFAFAF4)),
                    contentAlignment = Alignment.Center
                ) {
                    val artRatio = 940f / 1672f
                    val splashFrame = if (maxWidth / maxHeight <= artRatio) {
                        Modifier.fillMaxWidth().aspectRatio(artRatio)
                    } else {
                        Modifier.fillMaxHeight().aspectRatio(artRatio)
                    }
                    Box(modifier = splashFrame, contentAlignment = Alignment.Center) {
                        Image(
                            painter = painterResource(id = R.drawable.splash_vaghtnegar),
                            contentDescription = "مورخ",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.FillBounds
                        )
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .fillMaxHeight(0.22f)
                                .background(Color(0xFFFEFDF9)),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            PersianText(
                                "مورخ",
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Normal,
                                color = Color(0xFF087EAD)
                            )
                            Spacer(Modifier.height(7.dp))
                            PersianText(
                                "تقویم و مدیریت کارکرد",
                                fontSize = 17.sp,
                                color = Color(0xFF087EAD)
                            )
                        }
                    }
                }
            } else {
                KarkardApp(db, systemDate)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh the phone's local date whenever the app returns to the foreground.
        systemDate = LocalDate.now()
        CompanionAlerts.refresh(this)
        // Do not download prayer times automatically. Network refresh is intentionally
        // user-initiated via the dedicated "دریافت تازهٔ شهرها و اوقات شرعی" button.
    }

    fun selectAlertSound(prayer: Boolean, fileAudio: Boolean = false) {
        if (fileAudio) {
            val fileIntent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "audio/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(fileIntent,if(prayer) 5302 else 5301)
            return
        }
        val intent = Intent(android.media.RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TYPE, android.media.RingtoneManager.TYPE_ALL)
            putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
            putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TITLE, if(prayer) "صدای اذان" else "صدای یادآور")
            val selected = CompanionAlerts.ringtone(this@MainActivity,prayer)
            if(selected.isNotBlank()) putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,android.net.Uri.parse(selected))
        }
        startActivityForResult(intent,if(prayer) 5202 else 5201)
    }

    private var reportIncludeNotes: Boolean = true
    private var reportSummaryOnly: Boolean = false
    fun createReportExcel(year: Int, month: Int, annual: Boolean, includeNotes: Boolean = true, summaryOnly: Boolean = false) {
        reportIncludeNotes = includeNotes
        reportSummaryOnly = summaryOnly && annual
        reportYear = year; reportMonth = month; reportAnnual = annual; reportPdf = false
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            putExtra(Intent.EXTRA_TITLE, if (reportSummaryOnly) "مورخ_خلاصه_جامع_سال_$year.xlsx" else if (annual) "مورخ_گزارش_سالانه_$year.xlsx" else "مورخ_گزارش_ماهانه_${year}_$month.xlsx")
        }
        startActivityForResult(intent, 4103)
    }
    fun createReportPdf(year: Int, month: Int, annual: Boolean, includeNotes: Boolean = true, summaryOnly: Boolean = false) {
        reportIncludeNotes = includeNotes
        reportSummaryOnly = summaryOnly && annual
        reportYear = year; reportMonth = month; reportAnnual = annual; reportPdf = true
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"
            putExtra(Intent.EXTRA_TITLE, if (reportSummaryOnly) "مورخ_خلاصه_جامع_سال_$year.pdf" else if (annual) "مورخ_گزارش_سالانه_$year.pdf" else "مورخ_گزارش_ماهانه_${year}_$month.pdf")
        }
        startActivityForResult(intent, 4104)
    }
    fun chooseExcelRestore() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "text/csv", "text/comma-separated-values", "application/csv", "application/octet-stream"
            ))
        }
        startActivityForResult(intent, 4102)
    }
    fun createCsvBackup() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "پشتیبان_مورخ.csv")
        }
        startActivityForResult(intent, 4105)
    }
    fun createReminderCsvBackup() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "پشتیبان_یادآورهای_مورخ.csv")
        }
        startActivityForResult(intent, 4201)
    }
    fun createReminderExcelBackup() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            putExtra(Intent.EXTRA_TITLE, "پشتیبان_یادآورهای_مورخ.xlsx")
        }
        startActivityForResult(intent, 4202)
    }
    fun chooseReminderRestore() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "text/csv", "application/csv", "application/octet-stream"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, 4203)
    }
    fun createRemindersPdf() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"
            putExtra(Intent.EXTRA_TITLE, "یادآورهای_اقساط_و_جلسات_مورخ.pdf")
        }
        startActivityForResult(intent, 4204)
    }
    @Deprecated("Deprecated Android callback kept for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        if (requestCode == 5301 || requestCode == 5302) {
            data?.data?.let { audioUri ->
                try { contentResolver.takePersistableUriPermission(audioUri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                if (requestCode == 5302) {
                    AdhanSelection.setPending(this, audioUri.toString())
                    android.widget.Toast.makeText(this,"فایل اذان آمادهٔ پیش‌شنیدن و انتخاب است؛ صفحهٔ اذان را باز کن",android.widget.Toast.LENGTH_LONG).show()
                } else {
                    CompanionAlerts.saveRingtone(this,false,audioUri.toString())
                    android.widget.Toast.makeText(this,"آهنگ یادآور ذخیره شد",android.widget.Toast.LENGTH_SHORT).show()
                }
            }
            return
        }
        if (requestCode == 5201 || requestCode == 5202) {
            val ringtone = if (android.os.Build.VERSION.SDK_INT >= 33)
                data?.getParcelableExtra(android.media.RingtoneManager.EXTRA_RINGTONE_PICKED_URI,android.net.Uri::class.java)
            else data?.getParcelableExtra<android.net.Uri>(android.media.RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            ringtone?.let {
                CompanionAlerts.saveRingtone(this,requestCode == 5202,it.toString())
                android.widget.Toast.makeText(this,"صدای انتخاب‌شده ذخیره شد",android.widget.Toast.LENGTH_SHORT).show()
            }
            return
        }
        if (data?.data == null) return
        val uri = data.data!!
        try {
            if (requestCode == 4201) {
                val reminders = ReminderStore(this).all()
                contentResolver.openOutputStream(uri)?.use { it.write(buildReminderBackupCsv(reminders).toByteArray(Charsets.UTF_8)) } ?: error("فایل ذخیره نشد")
                android.widget.Toast.makeText(this, "پشتیبان CSV یادآورها ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
                return
            } else if (requestCode == 4202) {
                val reminders = ReminderStore(this).all()
                contentResolver.openOutputStream(uri)?.use { it.write(buildReminderBackupXlsx(reminders)) } ?: error("فایل ذخیره نشد")
                android.widget.Toast.makeText(this, "پشتیبان Excel یادآورها ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
                return
            } else if (requestCode == 4203) {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("فایل خوانده نشد")
                val reminders = if (bytes.size >= 2 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4b.toByte()) readReminderBackupXlsx(bytes)
                    else readReminderBackupCsv(String(bytes, Charsets.UTF_8).removePrefix("\uFEFF"))
                android.app.AlertDialog.Builder(this)
                    .setTitle("بازیابی پشتیبان یادآورها")
                    .setMessage("${reminders.size} یادآور در فایل پیدا شد. با ادامه، فهرست فعلی یادآورها با اطلاعات این فایل جایگزین می‌شود. ادامه می‌دهید؟")
                    .setNegativeButton("انصراف", null)
                    .setPositiveButton("بازیابی") { _, _ ->
                        try {
                            ReminderStore(this).replaceAll(reminders)
                            CompanionAlerts.refresh(this)
                            android.widget.Toast.makeText(this, "یادآورها با موفقیت بازیابی شدند", android.widget.Toast.LENGTH_LONG).show()
                        } catch (e: Exception) {
                            android.widget.Toast.makeText(this, "بازیابی یادآورها ناموفق بود: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                        }
                    }.show()
                return
            } else if (requestCode == 4204) {
                val reminders = ReminderStore(this).all()
                contentResolver.openOutputStream(uri)?.use { it.write(buildRemindersPdf(reminders)) } ?: error("فایل ذخیره نشد")
                android.widget.Toast.makeText(this, "خروجی PDF یادآورها ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
                return
            }
            if (requestCode == 4105) {
                val output = contentResolver.openOutputStream(uri) ?: error("فایل ذخیره نشد")
                output.use { it.write(buildBackupCsv(appDb).toByteArray(Charsets.UTF_8)) }
                android.widget.Toast.makeText(this, "فایل CSV پشتیبان ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
            } else if (requestCode == 4103) {
                contentResolver.openOutputStream(uri)?.use { it.write(buildReportXlsx(appDb, reportYear, reportMonth, reportAnnual, reportIncludeNotes, reportSummaryOnly)) }
                android.widget.Toast.makeText(this, "گزارش Excel ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
            } else if (requestCode == 4104) {
                contentResolver.openOutputStream(uri)?.use { it.write(buildReportPdf(appDb, reportYear, reportMonth, reportAnnual, reportIncludeNotes, reportSummaryOnly)) }
                android.widget.Toast.makeText(this, "گزارش PDF ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
            } else if (requestCode == 4102) {
                val input = contentResolver.openInputStream(uri) ?: error("فایل خوانده نشد")
                val bytes = input.use { it.readBytes() }
                val restored = if (bytes.size >= 2 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4b.toByte()) readBackupXlsx(bytes)
                    else readBackupCsv(String(bytes, Charsets.UTF_8).removePrefix("\uFEFF"))
                require(restored.first.isNotEmpty() || restored.second.isNotEmpty()) { "هیچ اطلاعات قابل بازیابی در فایل پیدا نشد" }
                val isReport = restored.second.any { it.first == "export_format" && it.second == "period_report_v1" }
                android.app.AlertDialog.Builder(this)
                    .setTitle(if(isReport) "ورود اطلاعات گزارش" else "بازیابی پشتیبان")
                    .setMessage(if(isReport) "فقط روزهای ثبت‌شدهٔ همین گزارش با داده‌های موجود ادغام می‌شوند؛ سایر ماه‌ها پاک نمی‌شوند. ادامه؟" else "با ادامه، اطلاعات فعلی جایگزین می‌شود. ادامه می‌دهید؟")
                    .setNegativeButton("انصراف", null)
                    .setPositiveButton("بازیابی") { _, _ ->
                        if(isReport) {
                            restored.first.forEach { appDb.saveDay(it) }
                            restored.second.filter { it.first.startsWith("period_activity_") }.forEach { (_, payload) ->
                                try {
                                    val json = org.json.JSONObject(payload)
                                    val candidate = normalizeWorkSession(WorkSession(
                                        startDate = json.optString("startDate"), startTime = json.optString("startTime"),
                                        endDate = json.optString("endDate"), endTime = json.optString("endTime"), note = json.optString("note")
                                    ))
                                    if (candidate != null) {
                                        val duplicate = appDb.allWorkSessions().any { old ->
                                            normalizedJalaliDateKey(old.startDate) == candidate.startDate &&
                                            mins(old.startTime) == mins(candidate.startTime) &&
                                            normalizedJalaliDateKey(old.endDate) == candidate.endDate &&
                                            mins(old.endTime) == mins(candidate.endTime) &&
                                            old.note == candidate.note
                                        }
                                        if (!duplicate) appDb.saveWorkSession(candidate)
                                    }
                                } catch (_: Exception) { }
                            }
                            restored.second.filter { it.first.startsWith("period_holiday_") }.forEach { (_, payload) ->
                                try {
                                    val json = org.json.JSONObject(payload)
                                    val holidayDate = normalizedJalaliDateKey(json.optString("date"))
                                    val title = json.optString("title").trim()
                                    if (holidayDate != null && title.isNotBlank()) appDb.saveHoliday(holidayDate, title)
                                } catch (_: Exception) { }
                            }
                            restored.second.filter { it.first.startsWith("setting_") }.forEach { (key, value) ->
                                val settingName = key.removePrefix("setting_")
                                if (settingName.startsWith("fixed_") || settingName in setOf("workday_hours", "thursday_hours_value")) {
                                    appDb.setSettingText(settingName, value)
                                }
                            }
                        } else appDb.restoreBackup(restored.first, restored.second)
                        android.widget.Toast.makeText(this, "بازیابی انجام شد", android.widget.Toast.LENGTH_LONG).show()
                        // Recreate the activity so Home and monthly/yearly report caches reload
                        // the restored SQLite records, including independent activities from CSV/Excel.
                        recreate()
                    }.show()
            }
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, "خطا در فایل پشتیبان Excel/CSV: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
        }
    }
}

private fun formatTimeInput(raw: String): String {
    val digits = raw.toLatinDigits().filter { it.isDigit() }.take(4)
    return when (digits.length) {
        0, 1 -> digits
        2 -> digits
        else -> digits.substring(0, 2) + ":" + digits.substring(2)
    }
}

private fun mins(time: String): Int? {
    // Older records and imported CSVs can contain Persian/Arabic numerals.
    // Normalize before parsing so valid saved shift times are not dropped from reports.
    val p = time.toLatinDigits().trim().replace('٫', ':').replace('：', ':').split(":")
    if (p.size != 2) return null
    val h = p[0].toIntOrNull() ?: return null
    val m = p[1].toIntOrNull() ?: return null
    if (h !in 0..23 || m !in 0..59) return null
    return h*60+m
}
private fun timeRangeMinutes(startText: String, endText: String): Int {
    val start = mins(startText) ?: return 0
    val end = mins(endText) ?: return 0
    return if (end >= start) end - start else end + 24 * 60 - start
}
private typealias MinuteInterval = WorkMinuteInterval

private data class DailyWorkStats(
    val workedMinutes: Int = 0,
    val requiredMinutes: Int = 0,
    val overtimeMinutes: Int = 0,
    val hourlyLeaveMinutes: Int = 0,
    val incomplete: Boolean = false,
    val recordedRequiredMinutes: Int = 0
)

private fun intervalFrom(startText: String, endText: String): MinuteInterval? {
    val start = mins(startText) ?: return null
    val end = mins(endText) ?: return null
    if (end <= start) return null // daily attendance/leave ranges do not cross midnight
    return MinuteInterval(start, end)
}

private fun mergeIntervals(intervals: List<MinuteInterval>): List<MinuteInterval> {
    if (intervals.isEmpty()) return emptyList()
    val sorted = intervals.sortedBy { it.start }
    val merged = mutableListOf<MinuteInterval>()
    sorted.forEach { current ->
        val last = merged.lastOrNull()
        if (last == null || current.start > last.end) merged.add(current)
        else merged[merged.lastIndex] = MinuteInterval(last.start, maxOf(last.end, current.end))
    }
    return merged
}

private fun unionMinutes(intervals: List<MinuteInterval>): Int = mergeIntervals(intervals).sumOf { it.durationMinutes }

private fun clippedUnionMinutes(intervals: List<MinuteInterval>, from: Int, until: Int): Int =
    unionMinutes(intervals.mapNotNull { interval ->
        val start = maxOf(interval.start, from)
        val end = minOf(interval.end, until)
        if (end > start) MinuteInterval(start, end) else null
    })

private fun overlapBetweenSetsMinutes(first: List<MinuteInterval>, second: List<MinuteInterval>): Int {
    val intersections = buildList {
        mergeIntervals(first).forEach { a ->
            mergeIntervals(second).forEach { b ->
                val start = maxOf(a.start, b.start)
                val end = minOf(a.end, b.end)
                if (end > start) add(MinuteInterval(start, end))
            }
        }
    }
    return unionMinutes(intersections)
}

private fun hasPartialPair(pairs: List<Pair<String, String>>): Boolean =
    pairs.any { (start, end) -> start.isBlank() xor end.isBlank() ||
        (start.isNotBlank() && end.isNotBlank() && intervalFrom(start, end) == null) }

private fun attendancePairs(day: WorkDay): List<Pair<String, String>> =
    if (day.fixedHoursMode) listOf(
        day.in1 to day.out1, day.in2 to day.out2, day.in3 to day.out3, day.in4 to day.out4
    ) else listOf(day.in1 to day.out1)

private fun hourlyLeavePairs(day: WorkDay): List<Pair<String, String>> =
    if (!day.hourlyLeaveEnabled) emptyList() else if (day.fixedHoursMode) listOf(
        day.leave1Start to day.leave1End, day.leave2Start to day.leave2End, day.leave3Start to day.leave3End
    ) else listOf(
        day.leave1Start to day.leave1End, day.leave2Start to day.leave2End,
        day.leave3Start to day.leave3End, day.leave4Start to day.leave4End
    )

private fun attendanceIntervals(day: WorkDay): List<MinuteInterval> =
    attendancePairs(day).mapNotNull { (start, end) -> intervalFrom(start, end) }

private fun leaveIntervals(day: WorkDay): List<MinuteInterval> =
    hourlyLeavePairs(day).mapNotNull { (start, end) -> intervalFrom(start, end) }

private fun hasIncompleteDailyInformation(day: WorkDay): Boolean {
    val workIncomplete = if (isHolidayWorkDay(day)) {
        hasPartialPair(listOf(day.holidayIn to day.holidayOut))
    } else hasPartialPair(attendancePairs(day))
    val leaveIncomplete = day.hourlyLeaveEnabled && hasPartialPair(hourlyLeavePairs(day))
    return workIncomplete || leaveIncomplete
}

private fun scheduledBaseMinutes(day: WorkDay, db: WorkDb): Int {
    if (isHolidayWorkDay(day)) return 0
    val statuses = dayStatuses(day)
    if (statuses.isEmpty() || ("کاری" !in statuses && "مأموریت" !in statuses)) return 0
    val weekday = jalaliWeekday(day.date)
    if (weekday == 5) return 0
    return if (day.fixedHoursMode) {
        val startKey = if (weekday == 4) "fixed_thursday_start" else "fixed_weekday_start"
        val endKey = if (weekday == 4) "fixed_thursday_end" else "fixed_weekday_end"
        val start = mins(db.getSettingText(startKey, if (weekday == 4) "07:00" else "07:00"))
        val end = mins(db.getSettingText(endKey, if (weekday == 4) "12:00" else "14:00"))
        if (start == null || end == null || end <= start) return if (weekday == 4) 300 else 420
        end - start
    } else {
        val configured = if (weekday == 4) db.getSettingText("thursday_hours_value") else db.getSettingText("workday_hours")
        mins(configured) ?: if (weekday == 4) 300 else 420
    }
}

private fun fixedWindowMinutes(day: WorkDay, db: WorkDb): Pair<Int, Int> {
    val thursday = jalaliWeekday(day.date) == 4
    val start = mins(db.getSettingText(if (thursday) "fixed_thursday_start" else "fixed_weekday_start", "07:00")) ?: 420
    val end = mins(db.getSettingText(if (thursday) "fixed_thursday_end" else "fixed_weekday_end", if (thursday) "12:00" else "14:00")) ?: if (thursday) 720 else 840
    return if (end > start) start to end else (if (thursday) 420 to 720 else 420 to 840)
}

/**
 * One source of truth for all daily calculations.
 * Fixed mode separates the statutory time window from overtime intervals; flexible mode
 * deducts hourly leave from total presence, capped at the configured daily requirement.
 */
private fun dailyWorkStats(day: WorkDay, db: WorkDb): DailyWorkStats {
    val target = scheduledBaseMinutes(day, db)
    val workPairs = if (isHolidayWorkDay(day)) listOf(day.holidayIn to day.holidayOut) else attendancePairs(day)
    val leavePairs = if (isHolidayWorkDay(day)) emptyList() else hourlyLeavePairs(day)
    val incomplete = hasPartialPair(workPairs) || hasPartialPair(leavePairs)
    val holidayWorkMinutes = if (isHolidayWorkDay(day)) {
        if (incomplete) 0 else holidayWorkDurationMinutes(day)
    } else null
    val (fixedStart, fixedEnd) = fixedWindowMinutes(day, db)
    val calculated = WorkCalculationEngine.calculate(
        WorkCalculationInput(
            attendance = if (isHolidayWorkDay(day)) emptyList() else attendanceIntervals(day),
            hourlyLeave = if (isHolidayWorkDay(day)) emptyList() else leaveIntervals(day),
            fixedMode = day.fixedHoursMode,
            targetMinutes = target,
            fixedStartMinute = fixedStart,
            fixedEndMinute = fixedEnd,
            hourlyLeaveEnabled = day.hourlyLeaveEnabled,
            incomplete = incomplete,
            holidayWorkMinutes = holidayWorkMinutes
        )
    )
    return DailyWorkStats(
        workedMinutes = calculated.workedMinutes,
        requiredMinutes = calculated.requiredMinutes,
        overtimeMinutes = calculated.overtimeMinutes,
        hourlyLeaveMinutes = calculated.hourlyLeaveMinutes,
        incomplete = calculated.incomplete,
        recordedRequiredMinutes = calculated.recordedRequiredMinutes
    )
}

private fun hourlyLeaveMinutes(day: WorkDay, db: WorkDb): Int = dailyWorkStats(day, db).hourlyLeaveMinutes
private fun duration(day: WorkDay, db: WorkDb): Int = dailyWorkStats(day, db).workedMinutes
private fun requiredMinutes(day: WorkDay, db: WorkDb): Int = dailyWorkStats(day, db).requiredMinutes
private fun recordedRequiredMinutes(day: WorkDay, db: WorkDb): Int = dailyWorkStats(day, db).recordedRequiredMinutes
private fun isIncompleteDay(day: WorkDay, db: WorkDb): Boolean = dailyWorkStats(day, db).incomplete

private fun normalizeDateInput(raw: String): String {
    val digits = raw.toLatinDigits().filter { it.isDigit() }.take(8)
    return when {
        digits.length <= 4 -> digits
        digits.length <= 6 -> digits.take(4) + "-" + digits.drop(4)
        else -> digits.take(4) + "-" + digits.substring(4, 6) + "-" + digits.drop(6)
    }
}

private fun parsedJalaliDate(value: String): LocalDate? {
    val normalized = value.toLatinDigits().trim().replace('/', '-').replace('٫', '-')
    val parts = normalized.split("-").mapNotNull { it.trim().toIntOrNull() }
    if (parts.size != 3 || !isValidJalali(parts[0], parts[1], parts[2])) return null
    return jalaliToGregorian(parts[0], parts[1], parts[2])
}

/** Canonical YYYY-MM-DD form used by report filtering, duplicate detection and deletion. */
private fun normalizedJalaliDateKey(value: String): String? {
    val parts = value.toLatinDigits().trim().replace('/', '-').replace('٫', '-').split('-')
    if (parts.size != 3) return null
    val year = parts[0].toIntOrNull() ?: return null
    val month = parts[1].toIntOrNull() ?: return null
    val day = parts[2].toIntOrNull() ?: return null
    if (!isValidJalali(year, month, day)) return null
    return "%04d-%02d-%02d".format(Locale.ROOT, year, month, day)
}

private fun jalaliDateString(date: LocalDate): String {
    val (y, m, d) = gregorianToJalali(date)
    return "%04d-%02d-%02d".format(Locale.ROOT, y, m, d)
}

private fun defaultShiftEndDate(startDate: String, startTime: String, endTime: String): String {
    val start = parsedJalaliDate(startDate) ?: return startDate
    val startMinutes = mins(startTime)
    val endMinutes = mins(endTime)
    val endDate = if (startMinutes != null && endMinutes != null && endMinutes <= startMinutes) start.plusDays(1) else start
    return jalaliDateString(endDate)
}

private fun hm(n: Int) = "%02d:%02d".format(Locale.ROOT, n/60, n%60)

private fun jalaliWeekday(date: String): Int? {
    val p = date.split("-").mapNotNull { it.toIntOrNull() }
    if (p.size != 3 || !isValidJalali(p[0],p[1],p[2])) return null
    return jalaliToGregorian(p[0],p[1],p[2]).dayOfWeek.value % 7
    // Java Sunday=0, Saturday=6
}
private fun officialJalaliHolidays(year: Int): List<Pair<String,String>> {
    val fixed = mutableListOf<Triple<Int,Int,String>>()
    for (d in 1..4) fixed.add(Triple(1, d, "تعطیل رسمی نوروز"))
    fixed.add(Triple(1, 12, "روز جمهوری اسلامی"))
    fixed.add(Triple(1, 13, "روز طبیعت"))
    fixed.add(Triple(3, 14, "رحلت امام خمینی"))
    fixed.add(Triple(3, 15, "قیام ۱۵ خرداد"))
    fixed.add(Triple(11, 22, "پیروزی انقلاب اسلامی"))
    fixed.add(Triple(12, 29, "روز ملی شدن صنعت نفت"))
    return fixed.map { (m,d,title) -> "%04d-%02d-%02d".format(year,m,d) to title }
}

private fun defaultDayType(date: String): String =
    if (jalaliWeekday(date) == 5) "تعطیل رسمی" else "کاری"

private fun applyCalendarHoliday(day: WorkDay, db: WorkDb): WorkDay {
    val fixedHoliday = officialJalaliHolidays(day.date.take(4).toIntOrNull() ?: 0).toMap()[day.date]
    val officialTitle = db.officialHolidayTitle(day.date) ?: fixedHoliday
    return when {
        !officialTitle.isNullOrBlank() && day.dayType in setOf("کاری", "تعطیل") && day.extraDayTypes.isBlank() -> day.copy(dayType = "تعطیل رسمی")
        else -> day
    }
}

/** Independent work activities are attributed to the report period of their start date. */
private fun reportSessions(db: WorkDb, year: Int, month: Int? = null): List<WorkSession> {
    val start = if (month == null) "%04d-01-01".format(Locale.ROOT, year) else "%04d-%02d-01".format(Locale.ROOT, year, month)
    val end = if (month == null) "%04d-12-31".format(Locale.ROOT, year) else "%04d-%02d-%02d".format(Locale.ROOT, year, month, jalaliMonthLength(year, month))
    // Normalize imported data before period filtering; do not let slash separators,
    // Persian digits or one-digit month/day forms silently drop a work activity.
    return db.allWorkSessions()
        .mapNotNull(::normalizeWorkSession)
        .filter { it.startDate >= start && it.startDate <= end }
}

private fun absoluteSessionInterval(session: WorkSession): MinuteInterval? {
    val startDate = parsedJalaliDate(session.startDate) ?: return null
    val endDateRaw = parsedJalaliDate(session.endDate) ?: return null
    val startTime = mins(session.startTime) ?: return null
    val endTime = mins(session.endTime) ?: return null
    var endDate = endDateRaw
    if (endDate == startDate && endTime <= startTime) endDate = startDate.plusDays(1)
    if (endDate.isBefore(startDate)) return null
    val startAbs = startDate.toEpochDay() * 1440L + startTime
    val endAbs = endDate.toEpochDay() * 1440L + endTime
    val duration = (endAbs - startAbs).coerceIn(0L, 31L * 1440L)
    if (duration <= 0L) return null
    return MinuteInterval(startAbs.toInt(), (startAbs + duration).toInt())
}

/** Canonicalize restored dates and times so database range filtering stays reliable. */
private fun normalizeWorkSession(session: WorkSession): WorkSession? {
    val startKey = normalizedJalaliDateKey(session.startDate) ?: return null
    var endKey = normalizedJalaliDateKey(session.endDate) ?: return null
    val startMinutes = mins(session.startTime) ?: return null
    val endMinutes = mins(session.endTime) ?: return null
    val startDate = parsedJalaliDate(startKey) ?: return null
    var endDate = parsedJalaliDate(endKey) ?: return null
    if (endDate == startDate && endMinutes <= startMinutes) {
        endDate = startDate.plusDays(1)
        endKey = jalaliDateString(endDate)
    }
    if (endDate.isBefore(startDate)) return null
    val duration = endDate.toEpochDay() * 1440L + endMinutes - (startDate.toEpochDay() * 1440L + startMinutes)
    if (duration <= 0L || duration > 31L * 1440L) return null
    return session.copy(
        startDate = startKey,
        startTime = "%02d:%02d".format(Locale.ROOT, startMinutes / 60, startMinutes % 60),
        endDate = endKey,
        endTime = "%02d:%02d".format(Locale.ROOT, endMinutes / 60, endMinutes % 60)
    )
}

private fun sessionDurationMinutes(session: WorkSession): Int = absoluteSessionInterval(session)?.duration ?: 0

/** Sum each saved activity's own duration for the activity metric. The total-work calculation
 * separately unions time ranges and subtracts overlap with attendance, so this metric can describe
 * recorded activities without inflating the employee's total worked time. */
private fun periodSessionMinutes(sessions: List<WorkSession>): Int =
    sessions.sumOf(::sessionDurationMinutes)

/** Convert one saved work-day's complete attendance intervals to a continuous epoch-minute axis. */
private fun absoluteAttendanceIntervals(day: WorkDay): List<MinuteInterval> {
    val date = parsedJalaliDate(day.date) ?: return emptyList()
    val base = date.toEpochDay() * 1440L
    val pairs = if (isHolidayWorkDay(day)) listOf(day.holidayIn to day.holidayOut) else attendancePairs(day)
    return pairs.mapNotNull { (start, end) ->
        val interval = intervalFrom(start, end) ?: return@mapNotNull null
        MinuteInterval((base + interval.start).toInt(), (base + interval.end).toInt())
    }
}

/**
 * Total work time for a reporting period. Independent work activities contribute only their
 * non-overlapping time beyond recorded attendance. Activity count and individual duration are
 * reported separately and attributed to the period containing each activity's start date.
 */
private fun periodWorkedMinutes(db: WorkDb, days: List<WorkDay>, sessions: List<WorkSession>): Int {
    val regularWork = days.sumOf { duration(it, db) }
    val completeDays = days.filter { !isIncompleteDay(it, db) }
    val dayBounds = completeDays.mapNotNull { day ->
        val date = parsedJalaliDate(day.date) ?: return@mapNotNull null
        val start = date.toEpochDay() * 1440L
        MinuteInterval(start.toInt(), (start + 1440L).toInt())
    }
    val periodAttendanceIntervals = completeDays.flatMap(::absoluteAttendanceIntervals)
    // Clip every independent activity to each complete day in the requested period. This
    // allocates the activity's actual contribution to the calendar day on which it occurs,
    // while the separate activity count/duration metric remains attributed to start date.
    val allActivityIntervals = db.allWorkSessions().mapNotNull(::absoluteSessionInterval)
    val activityInCompleteDays = buildList {
        allActivityIntervals.forEach { activity ->
            dayBounds.forEach { bounds ->
                val start = maxOf(activity.start, bounds.start)
                val end = minOf(activity.end, bounds.end)
                if (end > start) add(MinuteInterval(start, end))
            }
        }
    }
    val totalActivityMinutes = unionMinutes(activityInCompleteDays)
    val coveredByAttendance = overlapBetweenSetsMinutes(activityInCompleteDays, periodAttendanceIntervals)
    return (regularWork + totalActivityMinutes - coveredByAttendance).coerceAtLeast(0)
}

private fun sessionsStartingOnDate(db: WorkDb, rawDate: String): List<WorkSession> {
    val key = normalizedJalaliDateKey(rawDate) ?: return emptyList()
    return db.workSessionsStartingOn(key).filter { session ->
        normalizedJalaliDateKey(session.startDate) == key && absoluteSessionInterval(session) != null
    }
}

private fun sessionMinutesStartingOnDate(db: WorkDb, rawDate: String): Int =
    periodSessionMinutes(sessionsStartingOnDate(db, rawDate))

private fun dayReportedWorkMinutes(day: WorkDay, db: WorkDb): Int =
    periodWorkedMinutes(db, listOf(day), sessionsStartingOnDate(db, day.date))

private fun reportPeriodDays(db: WorkDb, year: Int, month: Int, annual: Boolean): List<WorkDay> {
    val stored = db.allDaysYear(year).associateBy { it.date }
    val months = if (annual) (1..12).toList() else listOf(month)
    return months.flatMap { m ->
        (1..jalaliMonthLength(year, m)).map { d ->
            val key = "%04d-%02d-%02d".format(year, m, d)
            val base = stored[key] ?: WorkDay(date = key, dayType = defaultDayType(key), fixedHoursMode = db.isFixedHoursEnabled())
            applyCalendarHoliday(base, db)
        }
    }
}

private fun isHolidayWorkDay(day: WorkDay): Boolean =
    dayStatuses(day).any { it in workHolidayStatuses || it in workLeaveStatuses } ||
        day.dayType == "تعطیل" || jalaliWeekday(day.date) == 5

/** All leave balances exclude Friday and official or individually marked holiday days. */
private fun isExcludedLeaveHoliday(day: WorkDay, db: WorkDb): Boolean =
    jalaliWeekday(day.date) == 5 || dayStatuses(day).any { it in workHolidayStatuses } ||
    db.officialHolidayTitle(day.date) != null ||
    officialJalaliHolidays(day.date.take(4).toIntOrNull() ?: 0).any { it.first == day.date } ||
    db.holidayTitle(day.date) != null

private fun reportDayStatusText(day: WorkDay, db: WorkDb): String {
    val selected = dayStatuses(day).filter { it != "توراهی" }
        .joinToString(" + ") { if (it == "مرخصی") "استحقاقی" else it }
    val status = selected.ifBlank { "—" }
    val mode = if (day.fixedHoursMode) "ثابت (ث)" else "شناور (ش)"
    val withMode = "$status • $mode"
    return if (isIncompleteDay(day, db)) "$withMode • اطلاعات ناقص است" else withMode
}

private fun isEntitledCountable(day: WorkDay, db: WorkDb): Boolean =
    hasDayStatus(day,"مرخصی") && !isExcludedLeaveHoliday(day,db)
private fun isSickCountable(day: WorkDay, db: WorkDb): Boolean =
    hasDayStatus(day,"استعلاجی") && !isExcludedLeaveHoliday(day,db)
private fun periodLeaveStats(days: List<WorkDay>, db: WorkDb): Triple<Int,Int,Int> {
    val entitledCount = days.count { isEntitledCountable(it, db) }
    val sickCount = days.count { isSickCountable(it, db) }
    // Tourahi is a monthly deduction setting, never a daily status.
    return Triple(entitledCount, sickCount, 0)
}


private fun holidayWorkDurationMinutes(day: WorkDay): Int {
    val start = mins(day.holidayIn)
    val end = mins(day.holidayOut)
    if (start == null || end == null) return 0
    return if (end >= start) end - start else (end + 24 * 60) - start
}

private fun overtimeMinutes(day: WorkDay, db: WorkDb): Int {
    val stats = dailyWorkStats(day, db)
    if (stats.incomplete) return 0
    val override = mins(day.overtimeOverride)
    if (override != null) return override
    return stats.overtimeMinutes
}


/** Returns a Persian validation message, or null when the day can be saved. */
private fun validateWorkDay(day: WorkDay, db: WorkDb): String? {
    fun validatePair(pair: Pair<String, String>, allowOpen: Boolean): String? {
        val (startText, endText) = pair
        if (startText.isBlank() && endText.isBlank()) return null
        if (startText.isBlank() && endText.isNotBlank()) return "برای ثبت ساعت خروج، ابتدا ساعت ورود را وارد کنید."
        val start = mins(startText) ?: return "یکی از ساعت‌های واردشده معتبر نیست."
        if (endText.isBlank()) return if (allowOpen) null else "ساعت خروج را وارد کنید."
        val end = mins(endText) ?: return "یکی از ساعت‌های واردشده معتبر نیست."
        if (end <= start) return "ساعت پایان هر بازه باید بعد از ساعت شروع همان بازه باشد."
        return null
    }
    if (isHolidayWorkDay(day)) return validatePair(day.holidayIn to day.holidayOut, allowOpen = true)

    val workPairs = attendancePairs(day)
    workPairs.forEachIndexed { index, pair ->
        // Only the first fixed-hours attendance pair may be saved before the exit is known.
        // Flexible mode and additional overtime intervals require complete start/end pairs.
        val mayRemainOpen = day.fixedHoursMode && index == 0
        validatePair(pair, allowOpen = mayRemainOpen)?.let { return it }
    }
    val completeWork = workPairs.mapNotNull { (a, b) -> intervalFrom(a, b) }
    if (unionMinutes(completeWork) != completeWork.sumOf { it.duration }) {
        return "بازه‌های ورود و خروج نباید با یکدیگر هم‌پوشانی داشته باشند."
    }

    val leavePairs = hourlyLeavePairs(day)
    // A leave interval is a deduction, so both ends must be known before saving it.
    leavePairs.forEach { pair -> validatePair(pair, allowOpen = false)?.let { return it } }
    val completeLeave = leavePairs.mapNotNull { (a, b) -> intervalFrom(a, b) }
    if (unionMinutes(completeLeave) != completeLeave.sumOf { it.duration }) {
        return "بازه‌های مرخصی ساعتی نباید با یکدیگر هم‌پوشانی داشته باشند."
    }

    if (day.fixedHoursMode) {
        val (startOfFixed, endOfFixed) = fixedWindowMinutes(day, db)
        val overtimePairs = listOf(day.in2 to day.out2, day.in3 to day.out3, day.in4 to day.out4)
        if (day.in3.isNotBlank() || day.out3.isNotBlank()) {
            if (day.in2.isBlank() || day.out2.isBlank()) return "برای ثبت ورود و خروج سوم، ابتدا بازه دوم را کامل کنید."
        }
        if (day.in4.isNotBlank() || day.out4.isNotBlank()) {
            if (day.in3.isBlank() || day.out3.isBlank()) return "برای ثبت ورود و خروج چهارم، ابتدا بازه سوم را کامل کنید."
        }
        if (overtimePairs.any { (a, b) -> a.isNotBlank() || b.isNotBlank() }) {
            if (day.in1.isBlank() || day.out1.isBlank()) return "برای ثبت بازه‌های اضافه‌کاری، ابتدا ورود و خروج اول را ثبت کنید."
            val firstEnd = mins(day.out1)
            if (firstEnd != null && firstEnd > endOfFixed) {
                return "وقتی ورود و خروج اضافه‌کاری ثبت می‌شود، خروج اول باید حداکثر پایان ساعت موظفی باشد."
            }
        }
        overtimePairs.forEachIndexed { index, (startText, endText) ->
            val start = mins(startText)
            val end = mins(endText)
            if (start != null && start < endOfFixed) return "ورودهای دوم تا چهارم فقط از پایان ساعت موظفی به بعد مجاز هستند."
            if (end != null && end < endOfFixed) return "خروج‌های دوم تا چهارم فقط در محدودهٔ اضافه‌کاری مجاز هستند."
            if (index > 0 && start != null) {
                val previousEnd = mins(overtimePairs[index - 1].second)
                if (previousEnd != null && start < previousEnd) return "ترتیب بازه‌های اضافه‌کاری باید از نظر زمانی رعایت شود."
            }
        }
        val firstStart = mins(day.in1)
        val firstEnd = mins(day.out1)
        val anyLeave = leavePairs.any { (a, b) -> a.isNotBlank() || b.isNotBlank() }
        if (anyLeave && firstStart == null) return "برای ثبت مرخصی ساعتی، ابتدا ساعت ورود اول را وارد کنید."
        leavePairs.forEach { (startText, endText) ->
            val start = mins(startText)
            val end = mins(endText)
            if (start != null && (start < startOfFixed || start >= endOfFixed)) return "مرخصی ساعتی فقط داخل بازهٔ ساعت کار ثابت مجاز است."
            if (end != null && (end <= startOfFixed || end > endOfFixed)) return "مرخصی ساعتی نباید از بازهٔ ساعت موظفی خارج شود."
            if (start != null && firstStart != null && start < firstStart) return "مرخصی ساعتی باید بعد از ساعت ورود اول باشد."
            if (end != null && firstEnd != null && end > firstEnd) return "مرخصی ساعتی باید پیش از ساعت خروج اول پایان یابد."
        }
    } else {
        val firstStart = mins(day.in1)
        val firstEnd = mins(day.out1)
        val anyLeave = leavePairs.any { (a, b) -> a.isNotBlank() || b.isNotBlank() }
        if (anyLeave && firstStart == null) return "برای ثبت مرخصی ساعتی، ابتدا ساعت ورود را وارد کنید."
        leavePairs.forEach { (startText, endText) ->
            val start = mins(startText)
            val end = mins(endText)
            if (start != null && firstStart != null && start < firstStart) return "مرخصی ساعتی نباید پیش از ساعت ورود ثبت شود."
            if (end != null && firstEnd != null && end > firstEnd) return "مرخصی ساعتی باید پیش از ساعت خروج پایان یابد."
        }
    }
    return null
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KarkardApp(db: WorkDb, systemDate: LocalDate) {
    val context = LocalContext.current
    var screen by remember { mutableStateOf("home") }
    val nowJalali = remember(systemDate) { gregorianToJalali(systemDate) }
    var jalaliYear by remember { mutableIntStateOf(nowJalali.first) }
    var jalaliMonth by remember { mutableIntStateOf(nowJalali.second) }
    var date by remember { mutableStateOf("%04d-%02d-%02d".format(nowJalali.first, nowJalali.second, nowJalali.third)) }
    var lastObservedSystemDate by remember { mutableStateOf(systemDate) }
    LaunchedEffect(systemDate) {
        val previousDeviceDate = jalaliDateString(lastObservedSystemDate)
        val currentDeviceDate = jalaliDateString(systemDate)
        // Update automatically if the user is still on the previous phone-today date.
        // A deliberately selected earlier/later day is left alone.
        if (date == previousDeviceDate) {
            date = currentDeviceDate
            val parts = currentDeviceDate.split("-")
            if (parts.size == 3) {
                jalaliYear = parts[0].toIntOrNull() ?: jalaliYear
                jalaliMonth = parts[1].toIntOrNull() ?: jalaliMonth
            }
        }
        lastObservedSystemDate = systemDate
    }
    var refresh by remember { mutableIntStateOf(0) }
    var workRevision by remember { mutableIntStateOf(0) }
    var dayDirty by remember { mutableStateOf(false) }
    // One editor state for the lifetime of the screen. A keyed remember(date)
    // would recreate the mutable state during date navigation and could replace
    // the just-reloaded record with a stale frame's values.
    var day by remember {
        mutableStateOf(applyCalendarHoliday(db.getDay(date).let { if (db.hasWorkDay(date)) it else it.copy(dayType=defaultDayType(date)) }, db))
    }
    // Re-read persisted data whenever the selected date changes or the home screen
    // becomes visible again. Uncommitted editor state is intentionally discarded.
    // Reload the persisted record whenever Home is shown again, the selected date
    // changes, or a save/delete updates the data revision. This also handles returning
    // from another screen after the Home editor left composition.
    LaunchedEffect(screen, date, refresh, workRevision) {
        if (screen == "home" && !dayDirty) {
            day = applyCalendarHoliday(db.getDay(date).let {
                if (db.hasWorkDay(date)) it else it.copy(dayType = defaultDayType(date))
            }, db)
        } else if (screen == "home" && dayDirty) {
            // Do not discard unsaved edits while the user is still editing this date.
        }
    }
    var holidaySyncing by remember { mutableStateOf(false) }
    var holidaySyncMessage by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()
    val syncOfficialHolidays: (Int, Boolean) -> Unit = { yearToSync, force ->
        if (!holidaySyncing && (force || db.shouldSyncOfficialHolidays(yearToSync))) {
            holidaySyncing = true
            holidaySyncMessage = "در حال دریافت تعطیلات سال $yearToSync…"
            coroutineScope.launch {
                try {
                    val synced = withContext(Dispatchers.IO) {
                        val calendarData = fetchCalendarData(yearToSync)
                        db.replaceCalendarData(yearToSync, calendarData.holidays, calendarData.events)
                        db.setSettingText("calendar_last_online_$yearToSync", System.currentTimeMillis().toString())
                        calendarData.events.size
                    }
                    holidaySyncMessage = "تقویم سال $yearToSync به‌روزرسانی شد؛ $synced روز دارای مناسبت و ${db.officialHolidays(yearToSync).size} روز تعطیل رسمی ذخیره شد. پس از ذخیره، آفلاین هم در دسترس است."
                    refresh++
                } catch (e: Exception) {
                    val reason = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName
                    holidaySyncMessage = "به‌روزرسانی انجام نشد ($reason)؛ اطلاعات ذخیره‌شده حفظ شد. اینترنت را بررسی و دوباره تلاش کن."
                } finally {
                    holidaySyncing = false
                }
            }
        }
    }
    LaunchedEffect(jalaliYear) {
        syncOfficialHolidays(jalaliYear, false)
    }

    var lastBackPressed by remember { mutableLongStateOf(0L) }
    BackHandler {
        if (screen != "home") screen = "home"
        else {
            val now = android.os.SystemClock.elapsedRealtime()
            if (now - lastBackPressed < 2200L) (context as? MainActivity)?.finish()
            else {
                lastBackPressed = now
                android.widget.Toast.makeText(context, "برای خروج دوباره بازگشت را بزنید", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF173F71),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFDCEAFB),
            onPrimaryContainer = Color(0xFF173F71),
            secondary = Color(0xFF008F91),
            tertiary = Color(0xFFB48C42),
            background = Color(0xFFF1F6FD),
            surface = Color.White
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = MaterialTheme.colorScheme.background,
                topBar = {
                    // The title is centered against the entire screen, not the area left beside an action button.
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFF1F6FD))
                            // Respect Android status-bar and camera-cutout safe areas.
                            // Insets adapt automatically to each phone instead of using a fixed offset.
                            .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Top))
                            .height(60.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        IconButton(onClick = { screen = "prayer" }, modifier = Modifier.align(Alignment.CenterStart).padding(start = 4.dp).size(44.dp)) {
                            Icon(painter = painterResource(R.drawable.nav_prayer), contentDescription = "اوقات شرعی و اذان", tint = Color(0xFF173F71), modifier = Modifier.size(25.dp))
                        }
                        PersianText(
                            when (screen) {
                                "home" -> "گزارش روز"
                                "calendar" -> "تقویم"
                                "report-monthly" -> "گزارش ماه"
                                "report-annual" -> "گزارش سال"
                                "settings" -> "تنظیمات"
                                "help" -> "راهنما"
                                "reminders" -> "یادآور اقساط و جلسات"
                                "prayer" -> "اوقات شرعی و اذان‌گو"
                                else -> "مورخ"
                            },
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 60.dp),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF123C70),
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                bottomBar = {
                    NavigationBar(containerColor = Color.White, tonalElevation = 8.dp, modifier = Modifier.heightIn(min = 67.dp)) {
                        listOf(
                            Triple("home", "روز", R.drawable.nav_home),
                            Triple("report-monthly", "ماه", R.drawable.nav_report_month),
                            Triple("report-annual", "سال", R.drawable.nav_report_year),
                            Triple("calendar", "تقویم", R.drawable.nav_calendar),
                            Triple("reminders", "یادآورها", R.drawable.nav_reminder),
                            Triple("settings", "تنظیمات", R.drawable.nav_settings)
                        ).forEach { (target,label,iconRes) ->
                            NavigationBarItem(
                                selected = screen == target,
                                onClick = { screen = target },
                                icon = {
                                    Icon(
                                        painter = painterResource(iconRes),
                                        contentDescription = label,
                                        modifier = Modifier.size(if (target == "calendar") 22.dp else 24.dp),
                                        tint = if (screen == target) Color(0xFF173F71) else Color(0xFF62809F)
                                    )
                                },
                                label = { PersianText(label, fontSize = 8.sp, maxLines = 1, textAlign = TextAlign.Center) },
                                alwaysShowLabel = true
                            )
                        }
                    }
                }
            ) { padding ->
                when (screen) {
                    "settings" -> SettingsScreen(
                        db = db, modifier = Modifier.padding(padding),
                        onCsvBackup = { (context as? MainActivity)?.createCsvBackup() },
                        onRestore = { (context as? MainActivity)?.chooseExcelRestore() },
                        onReminderCsvBackup = { (context as? MainActivity)?.createReminderCsvBackup() },
                        onReminderExcelBackup = { (context as? MainActivity)?.createReminderExcelBackup() },
                        onReminderRestore = { (context as? MainActivity)?.chooseReminderRestore() },
                        onSyncHolidays = { selectedYear -> syncOfficialHolidays(selectedYear, true) },
                        syncYear = jalaliYear,
                        holidaySyncing = holidaySyncing,
                        holidaySyncMessage = holidaySyncMessage,
                        onFixedHoursChanged = { enabled ->
                            if (!db.hasWorkDay(date)) {
                                day = day.copy(fixedHoursMode = enabled)
                            }
                            workRevision++
                        },
                        onHelp = { screen = "help" }
                    )
                    "help" -> HelpScreen(Modifier.padding(padding))
                    "reminders" -> RemindersScreen(
                        modifier = Modifier.padding(padding),
                        onPickRingtone = { fromFile -> (context as? MainActivity)?.selectAlertSound(false,fromFile) },
                        onExportPdf = { (context as? MainActivity)?.createRemindersPdf() }
                    )
                    "prayer" -> PrayerTimesScreen(
                        modifier = Modifier.padding(padding),
                        onPickRingtone = { fromFile -> (context as? MainActivity)?.selectAlertSound(true,fromFile) }
                    )
                    "calendar" -> JalaliCalendarScreen(
                        year = jalaliYear, month = jalaliMonth, selectedDate = date,
                        onMonthChange = { y,m -> jalaliYear = y; jalaliMonth = m },
                        onSelectDate = { selected ->
                            date = selected
                            day = applyCalendarHoliday(db.getDay(selected).let { if (db.hasWorkDay(selected)) it else it.copy(dayType=defaultDayType(selected)) }, db)
                            val parts = selected.split("-")
                            if (parts.size == 3) { jalaliYear = parts[0].toInt(); jalaliMonth = parts[1].toInt() }
                            dayDirty = false
                            workRevision++
                        },
                        modifier = Modifier.padding(padding),
                        holidays = remember(refresh, jalaliYear, jalaliMonth) {
                            (officialJalaliHolidays(jalaliYear) + db.officialHolidays(jalaliYear)).toMap()
                        },
                        events = remember(refresh, jalaliYear, jalaliMonth) { db.calendarEvents(jalaliYear).toMap() },
                        hijriDayOffset = 0
                    )
                    "report-monthly" -> ReportScreen(
                        db = db, year = jalaliYear, monthNumber = jalaliMonth, refresh = refresh + workRevision,
                        modifier = Modifier.padding(padding), annual = false,
                        onPeriodChange = { y, m -> jalaliYear = y; jalaliMonth = m },
                        export = { a, notes -> (context as? MainActivity)?.createReportExcel(jalaliYear, jalaliMonth, a, notes) },
                        exportPdf = { a, notes -> (context as? MainActivity)?.createReportPdf(jalaliYear, jalaliMonth, a, notes) },
                        exportSummaryExcel = { notes -> (context as? MainActivity)?.createReportExcel(jalaliYear, jalaliMonth, true, notes, true) },
                        exportSummaryPdf = { notes -> (context as? MainActivity)?.createReportPdf(jalaliYear, jalaliMonth, true, notes, true) },
                        onOpenDay = { selected ->
                            date = selected
                            day = db.getDay(selected).let { if (db.hasWorkDay(selected)) it else it.copy(dayType = defaultDayType(selected)) }
                            val parts = selected.split("-")
                            if (parts.size == 3) { jalaliYear = parts[0].toIntOrNull() ?: jalaliYear; jalaliMonth = parts[1].toIntOrNull() ?: jalaliMonth }
                            dayDirty = false
                            workRevision++
                            screen = "home"
                        },
                        onDataDeleted = { refresh++; workRevision++; dayDirty = false }
                    )
                    "report-annual" -> ReportScreen(
                        db = db, year = jalaliYear, monthNumber = jalaliMonth, refresh = refresh + workRevision,
                        modifier = Modifier.padding(padding), annual = true,
                        onPeriodChange = { y, m -> jalaliYear = y; jalaliMonth = m },
                        export = { a, notes -> (context as? MainActivity)?.createReportExcel(jalaliYear, jalaliMonth, a, notes) },
                        exportPdf = { a, notes -> (context as? MainActivity)?.createReportPdf(jalaliYear, jalaliMonth, a, notes) },
                        exportSummaryExcel = { notes -> (context as? MainActivity)?.createReportExcel(jalaliYear, jalaliMonth, true, notes, true) },
                        exportSummaryPdf = { notes -> (context as? MainActivity)?.createReportPdf(jalaliYear, jalaliMonth, true, notes, true) },
                        onOpenDay = { selected ->
                            date = selected
                            day = db.getDay(selected).let { if (db.hasWorkDay(selected)) it else it.copy(dayType = defaultDayType(selected)) }
                            val parts = selected.split("-")
                            if (parts.size == 3) { jalaliYear = parts[0].toIntOrNull() ?: jalaliYear; jalaliMonth = parts[1].toIntOrNull() ?: jalaliMonth }
                            dayDirty = false
                            workRevision++
                            screen = "home"
                        },
                        onDataDeleted = { refresh++; workRevision++; dayDirty = false }
                    )
                    else -> key(date, refresh) { HomeDashboard(
                        modifier = Modifier.padding(padding), date = date, rawDay = day, isDayDirty = dayDirty,
                        jalaliYear = jalaliYear, jalaliMonth = jalaliMonth, db = db, refresh = refresh,
                        workRevision = workRevision,
                        onDateChange = { newDate ->
                            if (newDate != date && parsedJalaliDate(newDate) != null) {
                                // Writes are performed on each edit. Reload the destination explicitly,
                                // so returning to a visited date never shows a stale editor snapshot.
                                val destination = db.getDay(newDate).let {
                                    if (db.hasWorkDay(newDate)) it else it.copy(dayType = defaultDayType(newDate))
                                }
                                day = destination
                                dayDirty = false
                                date = newDate
                                workRevision++
                                val p = newDate.split("-")
                                if (p.size == 3) {
                                    jalaliYear = p[0].toIntOrNull() ?: jalaliYear
                                    jalaliMonth = p[1].toIntOrNull() ?: jalaliMonth
                                }
                            }
                        },
                        onDayChange = { updated ->
                            // Editing changes UI state only. Persistence is explicit via
                            // the "ذخیره اطلاعات روز" button.
                            day = updated.copy(date = date)
                            dayDirty = true
                        },
                        onSaved = { saved -> day = saved; dayDirty = false; date = saved.date; refresh++; workRevision++ },
                        onDayDeleted = {
                            val reset = db.getDay(date).copy(dayType = defaultDayType(date))
                            day = reset
                            dayDirty = false
                            workRevision++
                            refresh++
                        },
                        onOpenCalendar = {
                            val p = date.split("-").mapNotNull { it.toIntOrNull() }
                            if (p.size == 3) { jalaliYear = p[0]; jalaliMonth = p[1] }
                            screen = "calendar"
                        },
                        onActivityChanged = { workRevision++; refresh++ }
                    ) }
                }
            }
        }
    }
}

@Composable
private fun WorkSummaryCard(
    title: String,
    worked: Int,
    required: Int,
    recordedRequired: Int,
    overtime: Int,
    hourlyLeave: Int,
    shiftCount: Int,
    shiftMinutes: Int,
    missionCount: Int,
    entitledCount: Int,
    sickCount: Int,
    tourahiCount: Int,
    incompleteCount: Int = 0,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FBFF)),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier.fillMaxWidth().border(1.5.dp, Color(0xFFBEDBFA), RoundedCornerShape(12.dp))
    ) {
        Column(Modifier.fillMaxWidth().padding(7.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Surface(
                color = Color(0xFFEAF3FF),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFB6D2EC)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(Modifier.fillMaxWidth().padding(horizontal = 5.dp, vertical = 6.dp), contentAlignment = Alignment.Center) {
                    PersianText(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF163E70), textAlign = TextAlign.Center)
                }
            }
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFCFDFF)),
                shape = RoundedCornerShape(9.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFD9E6F5), RoundedCornerShape(9.dp))
            ) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 5.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        ReportMetricTile("کل کارکرد", hm(worked), "◷", Color(0xFF153F78), Modifier.weight(1f))
                        ReportMetricTile("موظفی مقرر", hm(required), "◎", Color(0xFF153F78), Modifier.weight(1f))
                        ReportMetricTile("موظفی ثبتی", hm(recordedRequired), "◉", Color(0xFF0B6865), Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        ReportMetricTile("اضافه‌کار", hm(overtime), "◴", OvertimeGreenText, Modifier.weight(1f))
                        ReportMetricTile("تعداد فعالیت", shiftCount.toString(), "▦", Color(0xFF153F78), Modifier.weight(1f))
                        ReportMetricTile("جمع مدت فعالیت", hm(shiftMinutes), "◷", ShiftYellowText, Modifier.weight(1f))
                    }
                    Divider(color = Color(0xFFD2E5FA))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        ReportMetricTile("مرخصی ساعتی", hm(hourlyLeave), "◷", Color(0xFF153F78), Modifier.weight(1f))
                        ReportMetricTile("مأموریت", missionCount.toString(), "✈", Color(0xFF153F78), Modifier.weight(1f))
                        ReportMetricTile("استحقاقی", entitledCount.toString(), "☼", Color(0xFF153F78), Modifier.weight(1f))
                        ReportMetricTile("استعلاجی", sickCount.toString(), "✚", Color(0xFF153F78), Modifier.weight(1f))
                        ReportMetricTile("توراهی", tourahiCount.toString(), "↗", Color(0xFF153F78), Modifier.weight(1f))
                    }
                    if (incompleteCount > 0) {
                        Surface(color = Color(0xFFFFF4DF), shape = RoundedCornerShape(7.dp), modifier = Modifier.fillMaxWidth()) {
                            PersianText("اطلاعات ناقص: ${incompleteCount.toString().toPersianDigits()} روز", modifier = Modifier.padding(6.dp), fontSize = 11.sp, color = Color(0xFF8A5700), textAlign = TextAlign.Center)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeDashboard(
    modifier: Modifier,
    date: String,
    rawDay: WorkDay,
    isDayDirty: Boolean,
    jalaliYear: Int,
    jalaliMonth: Int,
    db: WorkDb,
    refresh: Int,
    workRevision: Int,
    onDateChange: (String) -> Unit,
    onDayChange: (WorkDay) -> Unit,
    onSaved: (WorkDay) -> Unit,
    onDayDeleted: () -> Unit,
    onOpenCalendar: () -> Unit,
    onActivityChanged: () -> Unit = {}
) {
    val context = LocalContext.current
    val day = if (isDayDirty) rawDay else applyCalendarHoliday(rawDay, db)
    val calendarTitle = remember(date, refresh) { db.displayHolidayTitle(date) ?: officialJalaliHolidays(date.take(4).toIntOrNull() ?: jalaliYear).toMap()[date] }
    val monthPrefix = "%04d-%02d".format(jalaliYear, jalaliMonth)
    val monthDays = remember(jalaliYear, jalaliMonth) { (1..31).filter { isValidJalali(jalaliYear, jalaliMonth, it) } }
    val recordedDays = remember(refresh, workRevision, monthPrefix) { db.allDays(monthPrefix) }
    val monthSummaryDays = remember(refresh, workRevision, monthPrefix) { reportPeriodDays(db, jalaliYear, jalaliMonth, false) }
    val monthShiftDaysForSummary = remember(monthPrefix, refresh, workRevision) { reportSessions(db, jalaliYear, jalaliMonth) }
    val monthWork = periodWorkedMinutes(db, monthSummaryDays, monthShiftDaysForSummary)
    val monthRequired = monthSummaryDays.sumOf { requiredMinutes(it, db) }
    val monthOvertime = monthSummaryDays.sumOf { overtimeMinutes(it, db) }
    val missionCount = monthSummaryDays.count { hasDayStatus(it,"مأموریت") }
    val monthlyHourlyLeave = monthSummaryDays.sumOf { hourlyLeaveMinutes(it, db) }
    // The home month summary uses the same leave totals as the monthly/yearly reports.
    // Travel days must not also count as entitlement days.
    val (rawEntitledLeaveCount, sickLeaveCount, _) = periodLeaveStats(monthSummaryDays, db)
    val savedHomeTourahiDeduction = db.getSettingText("tourahi_deduction_$monthPrefix", "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
    val entitledLeaveCount = (rawEntitledLeaveCount - savedHomeTourahiDeduction).coerceAtLeast(0)
    val homeTravelCount = savedHomeTourahiDeduction
    val dateParts = date.split("-").mapNotNull { it.toIntOrNull() }
    val dateDay = dateParts.getOrElse(2) { 1 }
    val weekday = jalaliWeekday(date)?.let { JalaliWeekdayNames.getOrNull(it) }.orEmpty()
    val homeCalendarDate = remember(date) { monthGregorianAndHijri(date, 0) }
    var homeGregorianNumeric by remember(date) { mutableStateOf(false) }
    var homeLunarNumeric by remember(date) { mutableStateOf(false) }
    val homeGregorianText = if (homeGregorianNumeric) numericGregorianForCalendar(date) else homeCalendarDate.first
    val homeLunarText = if (homeLunarNumeric) numericHijriForCalendar(homeCalendarDate.second) else homeCalendarDate.second
    val homeOfficialHoliday = remember(date, refresh) {
        db.officialHolidayTitle(date) ?: officialJalaliHolidays(date.take(4).toIntOrNull() ?: jalaliYear).toMap()[date]
    }
    // Re-read on date change and when returning from the reminders page.
    // The HomeDashboard composable leaves composition while that page is open.
    val dayReminders = remember(date) { ReminderStore(context).forJalaliDay(date) }
    var holidayReason by remember(date, refresh) { mutableStateOf(db.holidayTitle(date).orEmpty()) }
    // Visibility belongs to the UI, not the saved work record. Existing entries are
    // expanded automatically when the user opens a day that already has those times.
    var showSecondWorkPair by remember(date) {
        mutableStateOf(day.in2.isNotBlank() || day.out2.isNotBlank() || day.in3.isNotBlank() || day.out3.isNotBlank() || day.in4.isNotBlank() || day.out4.isNotBlank())
    }
    var showThirdWorkPair by remember(date) {
        mutableStateOf(day.in3.isNotBlank() || day.out3.isNotBlank() || day.in4.isNotBlank() || day.out4.isNotBlank())
    }
    var showFourthWorkPair by remember(date) {
        mutableStateOf(day.in4.isNotBlank() || day.out4.isNotBlank())
    }
    var confirmDayDeletion by remember(date) { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 5.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        contentPadding = PaddingValues(bottom = 8.dp)
    ) {
        item {
            PersianText("مدیریت کارکرد", modifier = Modifier.fillMaxWidth().padding(start = 3.dp, top = 2.dp), fontSize = 11.sp, color = Color(0xFF64809B), fontWeight = FontWeight.SemiBold)
            val homeShiftDays = monthShiftDaysForSummary
            val homeShiftMinutes = periodSessionMinutes(homeShiftDays)
            WorkSummaryCard(
                title = "خلاصه کارکرد ماه ${JalaliMonthNames[jalaliMonth - 1]} ${persianDigits(jalaliYear.toString())}",
                worked = monthWork,
                required = monthRequired,
                recordedRequired = monthSummaryDays.sumOf { recordedRequiredMinutes(it, db) },
                overtime = monthOvertime,
                hourlyLeave = monthlyHourlyLeave,
                shiftCount = homeShiftDays.size,
                shiftMinutes = homeShiftMinutes,
                missionCount = missionCount,
                entitledCount = entitledLeaveCount,
                sickCount = sickLeaveCount,
                tourahiCount = homeTravelCount,
                incompleteCount = monthSummaryDays.count { isIncompleteDay(it, db) }
            )
        }
        item {
            val isOfficial = !homeOfficialHoliday.isNullOrBlank()
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().heightIn(min = 93.dp)
                    .border(1.dp, if (isOfficial) Color(0xFFE57373) else Color(0xFFB6D0E8), RoundedCornerShape(12.dp))
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    // In RTL the first column appears on the right. The four date lines
                    // stay together; lunar and Gregorian labels toggle their notation on tap.
                    Column(Modifier.weight(1.2f).clickable(onClick = onOpenCalendar), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(1.dp)) {
                        PersianText(weekday, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF073B45), maxLines = 1)
                        PersianText(jalaliDisplayDate(date), fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color(0xFF426A6D), maxLines = 1)
                        PersianText(
                            "قمری: $homeLunarText",
                            modifier = Modifier.fillMaxWidth().clickable { homeLunarNumeric = !homeLunarNumeric },
                            fontSize = 15.sp, color = Color(0xFF426A6D), maxLines = 1
                        )
                        PersianText(
                            "میلادی: $homeGregorianText",
                            modifier = Modifier.fillMaxWidth().clickable { homeGregorianNumeric = !homeGregorianNumeric },
                            fontSize = 15.sp, color = Color(0xFF426A6D), maxLines = 1
                        )
                    }
                    if (!calendarTitle.isNullOrBlank()) {
                        Divider(Modifier.height(72.dp).width(1.dp), color = if (isOfficial) Color(0xFFE9B5B5) else Color(0xFFE8D69A))
                        Column(Modifier.weight(0.9f).padding(start = 4.dp), verticalArrangement = Arrangement.spacedBy(3.dp), horizontalAlignment = Alignment.Start) {
                            PersianText(
                                if (isOfficial) "تعطیل رسمی" else "مناسبت تقویم",
                                fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                color = if (isOfficial) Color(0xFFB3261E) else Color(0xFF8A6500), maxLines = 1
                            )
                            PersianText(
                                calendarTitle,
                                fontSize = 11.sp,
                                color = if (isOfficial) Color(0xFF8B2525) else Color(0xFF725400),
                                maxLines = 4,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }
            }
        }
        // Show actual saved reminders for this date immediately below the day/date card.
        // Several reminders on the same date are all visible; past one-off entries
        // are not silently hidden, and monthly reminders follow their Jalali due day.
        if (dayReminders.isNotEmpty()) {
            item(key = "day_reminders_$date") {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF4F0FF)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFD7CBEE), RoundedCornerShape(12.dp))
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        PersianText("یادآورهای این روز", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF45316F))
                        dayReminders.forEachIndexed { index, reminder ->
                            if (index > 0) Divider(color = Color(0xFFE1D8F0))
                            val reminderTime = java.time.Instant.ofEpochMilli(reminder.whenMillis)
                                .atZone(java.time.ZoneId.systemDefault()).toLocalTime()
                                .format(DateTimeFormatter.ofPattern("HH:mm", Locale.ROOT))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(9.dp)
                            ) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    PersianText(
                                        "${reminder.kind}: ${reminder.title}",
                                        fontSize = 13.sp,
                                        color = Color(0xFF303B59),
                                        lineHeight = 18.sp
                                    )
                                    if (reminder.monthly) {
                                        PersianText("تکرار ماهانه", fontSize = 10.sp, color = Color(0xFF74618E))
                                    }
                                }
                                PersianText(
                                    "ساعت ${reminderTime}",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF45316F),
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
        item {
            val dayTypes = listOf(
                "کاری" to "◷", "تعطیل رسمی" to "♜", "مرخصی" to "☼",
                "مأموریت" to "✈", "استعلاجی" to "✚", "تعطیل مناسبتی" to "▦"
            )
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFD5E3F2), RoundedCornerShape(12.dp))
            ) {
                Column(Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    PersianText("نوع روز", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF173F71))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                dayTypes.forEach { (type, symbol) ->
                    val selected = hasDayStatus(day,type)
                    Card(
                        modifier = Modifier.weight(1f).height(59.dp).border(1.dp, if (selected) Color(0xFF6BA1F9) else Color(0xFFB6D0CE), RoundedCornerShape(10.dp)),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFFE3EEFF) else Color.White),
                        onClick = { onDayChange(toggleDayStatus(day,type)) }
                    ) {
                        Column(Modifier.fillMaxSize().padding(horizontal = 2.dp, vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            PersianText(symbol, fontSize = 18.sp, color = if (selected) Color(0xFF1556A6) else Color(0xFF426A6D), maxLines = 1)
                            PersianText(if (type == "مرخصی") "استحقاقی" else type, fontSize = 9.sp, color = if (selected) Color(0xFF1556A6) else Color(0xFF426A6D), textAlign = TextAlign.Center, maxLines = 2, lineHeight = 11.sp)
                        }
                    }
                    }
                }
            }
        }
        }
        if (hasDayStatus(day,"تعطیل مناسبتی")) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFB6D0CE), RoundedCornerShape(10.dp))) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        PersianText("علت تعطیلی (اختیاری)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF073B45))
                        OutlinedTextField(
                            value = holidayReason.toPersianDigits(),
                            onValueChange = {
                                holidayReason = it
                                // Persist the title while typing; changing dates will not lose it.
                                if (hasDayStatus(day,"تعطیل مناسبتی")) {
                                    if (it.isBlank()) db.removeHoliday(date)
                                    else db.saveHoliday(date, it.trim())
                                }
                            },
                            placeholder = { PersianText("علت تعطیلی را وارد کنید", fontSize = 12.sp, color = Color(0xFF7E9ABD)) },
                            leadingIcon = { PersianText("✎", fontSize = 18.sp) },
                            modifier = Modifier.fillMaxWidth(), singleLine = true,
                            textStyle = TextStyle(fontSize = 12.sp, textAlign = TextAlign.Start),
                        )
                    }
                }
            }
        }
        if (isHolidayWorkDay(day)) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = OvertimeGreen.copy(alpha = 0.55f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF99D5A8), RoundedCornerShape(12.dp))
                ) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 7.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        PersianText(if (dayStatuses(day).any { it in workLeaveStatuses }) "ثبت اضافه‌کاری در روز مرخصی" else "ساعت کار در روز تعطیل", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = OvertimeGreenText)
                        PersianText("زمان ثبت‌شده در این بخش، تماماً اضافه‌کاری محاسبه می‌شود.", fontSize = 10.sp, color = OvertimeGreenText)
                        CompactTimePairRow("تعطیل", "ورود", day.holidayIn, "خروج", day.holidayOut,
                            { onDayChange(day.copy(holidayIn = it)) },
                            { onDayChange(day.copy(holidayOut = it)) })
                        PersianText("اضافه‌کاری تعطیل: ${hm(holidayWorkDurationMinutes(day))}", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = OvertimeGreenText)
                    }
                }
            }
        } else {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        PersianText(if (day.fixedHoursMode) "ساعت کار روزانه • ساعت کار ثابت" else "ساعت کار روزانه • ساعت کار شناور", modifier = Modifier.fillMaxWidth(), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color(0xFF073B45), textAlign = TextAlign.Start)
                        PersianText(
                            if (day.fixedHoursMode) "ورود و خروج اول برای ساعت موظفی است؛ خروج می‌تواند پس از پایان موظفی باشد، مگر اینکه بازه‌های اضافه‌کاری دوم تا چهارم ثبت شوند." else "در این حالت فقط یک ورود و خروج ثبت می‌شود و حداکثر چهار بازه مرخصی ساعتی از کارکرد کسر می‌شود.",
                            fontSize = 10.sp, color = Color(0xFF52708F), lineHeight = 14.sp
                        )
                        Divider(color = Color(0xFFC8DCD9))
                        CompactTimePairRow("۱", "ورود", day.in1, "خروج", day.out1, { onDayChange(day.copy(in1=it)) }, { onDayChange(day.copy(out1=it)) }, fieldFontSize = 13)
                        if (day.fixedHoursMode) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        showSecondWorkPair = !showSecondWorkPair
                                        if (!showSecondWorkPair) { showThirdWorkPair = false; showFourthWorkPair = false }
                                    },
                                    modifier = Modifier.heightIn(min = 30.dp), contentPadding = PaddingValues(horizontal = 9.dp, vertical = 1.dp)
                                ) { PersianText(if (showSecondWorkPair) "ورود/خروج ۲ −" else "افزودن ورود/خروج ۲", fontSize = 10.sp) }
                                if (showSecondWorkPair) {
                                    OutlinedButton(
                                        onClick = {
                                            showThirdWorkPair = !showThirdWorkPair
                                            if (!showThirdWorkPair) showFourthWorkPair = false
                                        },
                                        modifier = Modifier.heightIn(min = 30.dp), contentPadding = PaddingValues(horizontal = 9.dp, vertical = 1.dp)
                                    ) { PersianText(if (showThirdWorkPair) "۳ −" else "افزودن ۳", fontSize = 10.sp) }
                                }
                                if (showSecondWorkPair && showThirdWorkPair) {
                                    OutlinedButton(
                                        onClick = { showFourthWorkPair = !showFourthWorkPair },
                                        modifier = Modifier.heightIn(min = 30.dp), contentPadding = PaddingValues(horizontal = 9.dp, vertical = 1.dp)
                                    ) { PersianText(if (showFourthWorkPair) "۴ −" else "افزودن ۴", fontSize = 10.sp) }
                                }
                            }
                            if (showSecondWorkPair) {
                                Divider(color = Color(0xFFC8DCD9))
                                CompactTimePairRow("۲", "ورود اضافه‌کار", day.in2, "خروج", day.out2, { onDayChange(day.copy(in2=it)) }, { onDayChange(day.copy(out2=it)) }, fieldFontSize = 12)
                            }
                            if (showSecondWorkPair && showThirdWorkPair) {
                                Divider(color = Color(0xFFC8DCD9))
                                CompactTimePairRow("۳", "ورود اضافه‌کار", day.in3, "خروج", day.out3, { onDayChange(day.copy(in3=it)) }, { onDayChange(day.copy(out3=it)) }, fieldFontSize = 12)
                            }
                            if (showSecondWorkPair && showThirdWorkPair && showFourthWorkPair) {
                                Divider(color = Color(0xFFC8DCD9))
                                CompactTimePairRow("۴", "ورود اضافه‌کار", day.in4, "خروج", day.out4, { onDayChange(day.copy(in4=it)) }, { onDayChange(day.copy(out4=it)) }, fieldFontSize = 12)
                            }
                            PersianText("بازه‌های دوم تا چهارم فقط از پایان موظفی تا ۲۳:۵۹ مجاز هستند.", fontSize = 10.sp, color = OvertimeGreenText)
                        }
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF2E5D7)), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFD5B99F), RoundedCornerShape(12.dp))) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        PersianText("مرخصی ساعتی", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color(0xFF073B45))
                        Switch(
                            checked = day.hourlyLeaveEnabled,
                            onCheckedChange = { onDayChange(day.copy(hourlyLeaveEnabled = it)) }
                        )
                    }
                    if (day.hourlyLeaveEnabled) {
                        Divider(color = Color(0xFFC8DCD9))
                        CompactTimePairRow("۱", "از ساعت", day.leave1Start, "الی ساعت", day.leave1End, { onDayChange(day.copy(leave1Start=it)) }, { onDayChange(day.copy(leave1End=it)) })
                        Divider(color = Color(0xFFC8DCD9))
                        CompactTimePairRow("۲", "از ساعت", day.leave2Start, "الی ساعت", day.leave2End, { onDayChange(day.copy(leave2Start=it)) }, { onDayChange(day.copy(leave2End=it)) })
                        Divider(color = Color(0xFFC8DCD9))
                        CompactTimePairRow("۳", "از ساعت", day.leave3Start, "الی ساعت", day.leave3End, { onDayChange(day.copy(leave3Start=it)) }, { onDayChange(day.copy(leave3End=it)) })
                        if (!day.fixedHoursMode) {
                            Divider(color = Color(0xFFC8DCD9))
                            CompactTimePairRow("۴", "از ساعت", day.leave4Start, "الی ساعت", day.leave4End, { onDayChange(day.copy(leave4Start=it)) }, { onDayChange(day.copy(leave4End=it)) })
                        }
                        PersianText("مرخصی قابل محاسبه: ${hm(hourlyLeaveMinutes(day, db))}", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF0B6865))
                        PersianText(
                            if (day.fixedHoursMode) "حداکثر سه بازه و فقط در ساعات موظفی مجاز است؛ مرخصی در ساعات اضافه‌کاری پذیرفته نمی‌شود." else "حداکثر چهار بازه مجاز است؛ مجموع مرخصی قابل کسر از کارکرد از موظفی روز بیشتر نمی‌شود.",
                            fontSize = 10.sp, color = Color(0xFF52708F), lineHeight = 14.sp
                        )
                    }
                }
            }
        }
        item { WorkSessionsEditor(db = db, date = date, refresh = refresh + workRevision, onChanged = onActivityChanged) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PersianText("▤", fontSize = 20.sp, color = Color(0xFF426A6D))
                        Spacer(Modifier.width(6.dp))
                        PersianText("یادداشت روز", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color(0xFF073B45))
                    }
                    OutlinedTextField(value = day.note.toPersianDigits(), onValueChange = { onDayChange(day.copy(note=it)) }, placeholder = { PersianText("یادداشت اختیاری…", fontSize = 11.sp) }, modifier = Modifier.fillMaxWidth(), minLines = 1, maxLines = Int.MAX_VALUE, textStyle = TextStyle(fontSize = 12.sp))

                }
            }
        }
        if (isIncompleteDay(day, db)) item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)), modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFFFCC80), RoundedCornerShape(9.dp))) {
                PersianText("اطلاعات ناقص است؛ تا تکمیل ساعت خروج یا بازه‌های نیمه‌تمام، این روز در جمع کارکرد قطعی محاسبه نمی‌شود.", modifier = Modifier.fillMaxWidth().padding(9.dp), fontSize = 11.sp, color = Color(0xFF9A5700), textAlign = TextAlign.Center)
            }
        }
        item {
            Button(
                onClick = {
                    val p = date.toLatinDigits().replace('/', '-').split("-").mapNotNull { it.toIntOrNull() }
                    if (p.size == 3 && isValidJalali(p[0], p[1], p[2])) {
                        val normalized = "%04d-%02d-%02d".format(p[0], p[1], p[2])
                        val savedDay = day.copy(date=normalized, shiftEnabled=false, shiftStart="", shiftEnd="", shiftStartDate="", shiftEndDate="")
                        val validationMessage = validateWorkDay(savedDay, db)
                        if (validationMessage != null) {
                            android.widget.Toast.makeText(context, validationMessage, android.widget.Toast.LENGTH_LONG).show()
                        } else {
                            db.saveDayAndHoliday(
                                savedDay,
                                holidayReason.takeIf { hasDayStatus(savedDay, "تعطیل مناسبتی") }
                            )
                            onSaved(savedDay)
                            android.widget.Toast.makeText(context, "اطلاعات روز ذخیره شد", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().heightIn(min = 38.dp),
                contentPadding = PaddingValues(vertical = 5.dp)
            ) { PersianText("ذخیره اطلاعات روز", fontSize = 13.sp) }
        }
        item {
            OutlinedButton(
                onClick = { confirmDayDeletion = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFB3261E))
            ) { PersianText("حذف اطلاعات روز", fontSize = 13.sp) }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    SummaryMiniTile("کل کارکرد", hm(dayReportedWorkMinutes(day, db)), Color(0xFFEAF3FF), Color(0xFF075565), Modifier.weight(1f))
                    SummaryMiniTile("موظفی مقرر", hm(requiredMinutes(day, db)), Color(0xFFEAF3FF), Color(0xFF315C8D), Modifier.weight(1f))
                    SummaryMiniTile("موظفی ثبتی", hm(recordedRequiredMinutes(day, db)), Color(0xFFE6F5F3), Color(0xFF0B6865), Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    SummaryMiniTile("اضافه‌کار", hm(overtimeMinutes(day, db)), OvertimeGreen, OvertimeGreenText, Modifier.weight(1f))
                    SummaryMiniTile("تعداد فعالیت", sessionsStartingOnDate(db, date).size.toString().toPersianDigits(), ShiftYellow, ShiftYellowText, Modifier.weight(1f))
                    SummaryMiniTile("مدت فعالیت", hm(sessionMinutesStartingOnDate(db, date)), ShiftYellow, ShiftYellowText, Modifier.weight(1f))
                }
            }
        }
    }

    if (confirmDayDeletion) AlertDialog(
        onDismissRequest = { confirmDayDeletion = false },
        title = { PersianText("حذف تمام اطلاعات این روز", fontWeight = FontWeight.Bold) },
        text = { PersianText("تمام اطلاعات ثبت‌شدهٔ ${jalaliDisplayDate(date)}، شامل یادداشت، ساعت‌ها، فعالیت‌های شروع‌شده در این روز، مرخصی، مأموریت و علت تعطیلی پاک می‌شود. آیا مطمئنی؟ آیا پشتیبان گرفته‌ای؟") },
        confirmButton = {
            TextButton(onClick = {
                val deletedDates = db.deleteDay(date)
                confirmDayDeletion = false
                // Reset in-memory editor fields even if the saved row was already absent;
                // unsaved UI values must not remain visible after an explicit delete action.
                onDayDeleted()
                val message = if (deletedDates > 0) "تمام اطلاعات این روز حذف و به حالت پیش‌فرض بازگردانده شد"
                    else "اطلاعات ذخیره‌شده‌ای نبود؛ فرم روز به حالت پیش‌فرض بازگردانده شد"
                android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_LONG).show()
            }) { PersianText("بله، حذف شود", color = Color(0xFFB3261E)) }
        },
        dismissButton = {
            TextButton(onClick = { confirmDayDeletion = false }) { PersianText("لغو") }
        }
    )


}

@Composable
private fun WorkSessionsEditor(db: WorkDb, date: String, refresh: Int, onChanged: () -> Unit) {
    val context = LocalContext.current
    var startDate by remember(date) { mutableStateOf(date) }
    var endDate by remember(date) { mutableStateOf(date) }
    var startTime by remember(date) { mutableStateOf("17:00") }
    var endTime by remember(date) { mutableStateOf("18:00") }
    var note by remember(date) { mutableStateOf("") }
    var editingId by remember(date) { mutableStateOf(0L) }
    var localRevision by remember(date, refresh) { mutableIntStateOf(0) }
    var deleteTarget by remember { mutableStateOf<WorkSession?>(null) }
    var errorMessage by remember(date) { mutableStateOf("") }
    val dayKey = normalizedJalaliDateKey(date) ?: date
    val sessions = remember(dayKey, refresh, localRevision) { db.workSessionsStartingOn(dayKey) }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEE)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFE5C34A), RoundedCornerShape(12.dp))
    ) {
        Column(Modifier.fillMaxWidth().padding(9.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PersianText("◷", fontSize = 21.sp, color = Color(0xFFE0A000))
                PersianText("فعالیت کاری", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = ShiftYellowText)
                Spacer(Modifier.weight(1f))
                PersianText("${sessions.size.toString().toPersianDigits()} فعالیت", fontSize = 11.sp, color = ShiftYellowText)
            }
            PersianText("هر فعالیت را جداگانه با تاریخ و ساعت شروع و پایان ثبت کن. فعالیت‌ها مستقل از ورود و خروج روزانه هستند و در گزارش روز، ماه و سال محاسبه می‌شوند.", fontSize = 10.sp, color = Color(0xFF7A651D), lineHeight = 15.sp)
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        PersianText("تاریخ شروع", fontSize = 9.sp, color = Color(0xFF426A6D), textAlign = TextAlign.Center)
                        SplitDateField(startDate, { startDate = it }, Modifier.fillMaxWidth())
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        PersianText("تاریخ پایان", fontSize = 9.sp, color = Color(0xFF426A6D), textAlign = TextAlign.Center)
                        SplitDateField(endDate, { endDate = it }, Modifier.fillMaxWidth())
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SplitTimeField("ساعت شروع", startTime, { startTime = it }, Modifier.weight(1f), 15)
                    SplitTimeField("ساعت پایان", endTime, { endTime = it }, Modifier.weight(1f), 15)
                }
            }
            OutlinedTextField(
                value = note.toPersianDigits(), onValueChange = { note = it },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                label = { PersianText("عنوان فعالیت (اختیاری)", fontSize = 11.sp) },
                textStyle = TextStyle(fontSize = 12.sp)
            )
            if (errorMessage.isNotBlank()) PersianText(errorMessage, fontSize = 11.sp, color = Color(0xFFB3261E))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = {
                        val normalizedStart = normalizedJalaliDateKey(startDate)
                        val normalizedEndInput = normalizedJalaliDateKey(endDate)
                        val startMinutes = mins(formatTimeInput(startTime))
                        val endMinutes = mins(formatTimeInput(endTime))
                        if (normalizedStart == null || normalizedEndInput == null) {
                            errorMessage = "تاریخ شروع و پایان را کامل و معتبر وارد کن."
                        } else if (startMinutes == null || endMinutes == null) {
                            errorMessage = "ساعت شروع و پایان باید معتبر باشد؛ مانند ۱۷:۰۰."
                        } else {
                            var normalizedEnd = normalizedEndInput
                            val startParsed = parsedJalaliDate(normalizedStart)!!
                            var endParsed = parsedJalaliDate(normalizedEnd)!!
                            if (endParsed == startParsed && endMinutes <= startMinutes) {
                                endParsed = startParsed.plusDays(1)
                                normalizedEnd = jalaliDateString(endParsed)
                            }
                            val startAbs = startParsed.toEpochDay() * 1440L + startMinutes
                            val endAbs = endParsed.toEpochDay() * 1440L + endMinutes
                            val duration = endAbs - startAbs
                            if (duration <= 0L || duration > 31L * 1440L) {
                                errorMessage = "مدت فعالیت باید بیشتر از صفر و حداکثر ۳۱ روز باشد."
                            } else {
                                val id = db.saveWorkSession(WorkSession(
                                    id = editingId,
                                    startDate = normalizedStart,
                                    startTime = "%02d:%02d".format(Locale.ROOT, startMinutes / 60, startMinutes % 60),
                                    endDate = normalizedEnd,
                                    endTime = "%02d:%02d".format(Locale.ROOT, endMinutes / 60, endMinutes % 60),
                                    note = note.trim()
                                ))
                                if (id > 0L || editingId > 0L) {
                                    errorMessage = ""
                                    editingId = 0L
                                    startDate = dayKey
                                    endDate = dayKey
                                    startTime = "17:00"
                                    endTime = "18:00"
                                    note = ""
                                    localRevision++
                                    onChanged()
                                    android.widget.Toast.makeText(context, "فعالیت ذخیره شد", android.widget.Toast.LENGTH_SHORT).show()
                                } else errorMessage = "ذخیرهٔ فعالیت انجام نشد."
                            }
                        }
                    }, modifier = Modifier.weight(1f)
                ) { PersianText(if (editingId > 0L) "ذخیره ویرایش" else "ثبت فعالیت", fontSize = 12.sp) }
                if (editingId > 0L) OutlinedButton(onClick = {
                    editingId = 0L; startDate = dayKey; endDate = dayKey; startTime = "17:00"; endTime = "18:00"; note = ""; errorMessage = ""
                }) { PersianText("لغو ویرایش", fontSize = 11.sp) }
            }
            if (sessions.isNotEmpty()) Divider(color = Color(0xFFE5D6A0))
            sessions.forEach { session ->
                Column(
                    Modifier.fillMaxWidth().border(1.dp, Color(0xFFE7D9A7), RoundedCornerShape(9.dp)).padding(7.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    PersianText("${jalaliDisplayDate(session.startDate)}  ${session.startTime} تا ${jalaliDisplayDate(session.endDate)}  ${session.endTime}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF684F0B), lineHeight = 16.sp)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        PersianText("مدت: ${hm(sessionDurationMinutes(session))}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ShiftYellowText)
                        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            TextButton(onClick = {
                                editingId = session.id; startDate = session.startDate; endDate = session.endDate
                                startTime = session.startTime; endTime = session.endTime; note = session.note; errorMessage = ""
                            }) { PersianText("ویرایش", fontSize = 10.sp) }
                            TextButton(onClick = { deleteTarget = session }) { PersianText("حذف", fontSize = 10.sp, color = Color(0xFFB3261E)) }
                        }
                    }
                    if (session.note.isNotBlank()) PersianText(session.note, fontSize = 11.sp, color = Color(0xFF6A5A2A))
                }
            }
        }
    }
    if (deleteTarget != null) AlertDialog(
        onDismissRequest = { deleteTarget = null },
        title = { PersianText("حذف فعالیت", fontWeight = FontWeight.Bold) },
        text = { PersianText("این فعالیت از گزارش‌های کارکرد حذف شود؟") },
        confirmButton = {
            TextButton(onClick = {
                deleteTarget?.let { db.deleteWorkSession(it.id) }
                deleteTarget = null
                localRevision++
                if (editingId > 0L) { editingId = 0L; startDate = dayKey; endDate = dayKey; startTime = "17:00"; endTime = "18:00"; note = "" }
                onChanged()
            }) { PersianText("حذف", color = Color(0xFFB3261E)) }
        },
        dismissButton = { TextButton(onClick = { deleteTarget = null }) { PersianText("انصراف") } }
    )
}

@Composable
private fun MonthMetric(label: String, value: String, symbol: String, valueColor: Color, modifier: Modifier, unit: String = "ساعت") {
    Column(modifier.padding(horizontal = 2.dp, vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            PersianText(symbol, fontSize = 13.sp, color = valueColor, maxLines = 1)
            Spacer(Modifier.width(2.dp))
            PersianText(label, fontSize = 10.sp, color = Color(0xFF426A6D), maxLines = 2, textAlign = TextAlign.Center, lineHeight = 11.sp)
        }
        PersianText(value, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = valueColor, maxLines = 1)
        PersianText(unit, fontSize = 8.sp, color = Color(0xFF426A6D), maxLines = 1)
    }
}

@Composable
private fun MetricDivider() {
    Box(Modifier.width(1.dp).height(44.dp).background(Color(0xFFB6D0CE)))
}

@Composable
private fun CompactTimePairRow(index: String, label1: String, value1: String, label2: String, value2: String, onChange1: (String) -> Unit, onChange2: (String) -> Unit, fieldFontSize: Int = 17) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Box(Modifier.size(25.dp).background(Color(0xFFDDEBE8), RoundedCornerShape(50)), contentAlignment = Alignment.Center) { PersianText(index, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF075565)) }
            CompactTimeTextField(label1, value1, onChange1, Modifier.weight(1f), fieldFontSize)
            CompactTimeTextField(label2, value2, onChange2, Modifier.weight(1f), fieldFontSize)
        }
    }
}

@Composable
private fun CompactTimeTextField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier, fieldFontSize: Int = 17) {
    SplitTimeField(label, value, onChange, modifier, fieldFontSize)
}

@Composable
private fun CompactShiftField(label: String, value: String, modifier: Modifier, isDate: Boolean, onChange: (String) -> Unit) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        PersianText(label, fontSize = 8.sp, color = Color(0xFF426A6D), textAlign = TextAlign.Center, maxLines = 2, lineHeight = 9.sp)
        if (isDate) {
            SplitDateField(value, onChange, Modifier.fillMaxWidth())
        } else {
            SplitTimeField("", value, onChange, Modifier.fillMaxWidth(), 13)
        }
    }
}

/**
 * Extract what the user actually typed, excluding the old value that the IME
 * included in the editing event. Cursor moves/selection changes produce no digits.
 */
private fun insertedDigits(oldText: String, newText: String): String {
    val old = oldText.toLatinDigits()
    val new = newText.toLatinDigits()
    val commonPrefix = old.indices.takeWhile { it < new.length && old[it] == new[it] }.count()
    var oldEnd = old.length
    var newEnd = new.length
    while (oldEnd > commonPrefix && newEnd > commonPrefix && old[oldEnd - 1] == new[newEnd - 1]) {
        oldEnd--
        newEnd--
    }
    return new.substring(commonPrefix, newEnd).filter(Char::isDigit)
}

/**
 * Touching a field only arms replacement. The old digits remain visible and
 * unselected until the first new digit is actually entered. This also avoids
 * focus jumps caused by selection-only TextFieldValue updates.
 */
@Composable
private fun ReplaceableNumberField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier,
    maxDigits: Int,
    fontSize: TextUnit,
    imeAction: ImeAction,
    placeholder: String = ""
) {
    var input by remember { mutableStateOf(TextFieldValue(value.toPersianDigits())) }
    var replaceOnNextDigit by remember { mutableStateOf(false) }
    SideEffect {
        if (input.text.toLatinDigits() != value.toLatinDigits()) {
            val shown = value.toPersianDigits()
            input = TextFieldValue(shown, selection = TextRange(shown.length))
        }
    }
    OutlinedTextField(
        value = input,
        onValueChange = { incoming ->
            if (incoming.text == input.text) {
                // Pure selection/caret movement: do not publish, do not auto-advance.
                input = incoming
            } else {
                val added = insertedDigits(input.text, incoming.text)
                val cleaned = if (replaceOnNextDigit && added.isNotEmpty()) {
                    replaceOnNextDigit = false
                    added.take(maxDigits)
                } else {
                    replaceOnNextDigit = false
                    incoming.text.toLatinDigits().filter(Char::isDigit).take(maxDigits)
                }
                val shown = cleaned.toPersianDigits()
                input = TextFieldValue(shown, selection = TextRange(shown.length))
                if (cleaned != value.toLatinDigits()) onValueChange(cleaned)
            }
        },
        modifier = modifier
            // Re-arm replacement on *every* tap, even when this field already has focus.
            // The initial-pass listener does not consume the tap or select the old text.
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    replaceOnNextDigit = true
                    waitForUpOrCancellation()
                }
            }
            .onFocusChanged { focus ->
                if (focus.isFocused) replaceOnNextDigit = true
                else replaceOnNextDigit = false
            },
        singleLine = true,
        textStyle = TextStyle(fontSize = fontSize, textAlign = TextAlign.Center),
        placeholder = if (placeholder.isNotBlank()) { { PersianText(placeholder, fontSize = 9.sp) } } else null,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = imeAction)
    )
}

/** The same first-new-digit replacement rule for HH:MM settings values. */
@Composable
private fun ReplaceableSettingsTimeField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String
) {
    var input by remember { mutableStateOf(TextFieldValue(value.toPersianDigits())) }
    var replaceOnNextDigit by remember { mutableStateOf(false) }
    SideEffect {
        if (input.text.toLatinDigits() != value.toLatinDigits()) {
            val shown = value.toPersianDigits()
            input = TextFieldValue(shown, selection = TextRange(shown.length))
        }
    }
    OutlinedTextField(
        value = input,
        onValueChange = { incoming ->
            if (incoming.text == input.text) {
                input = incoming
            } else {
                val added = insertedDigits(input.text, incoming.text)
                val normalized = if (replaceOnNextDigit && added.isNotEmpty()) {
                    replaceOnNextDigit = false
                    formatTimeInput(added)
                } else {
                    replaceOnNextDigit = false
                    formatTimeInput(incoming.text)
                }
                val shown = normalized.toPersianDigits()
                input = TextFieldValue(shown, selection = TextRange(shown.length))
                if (normalized != value.toLatinDigits()) onValueChange(normalized)
            }
        },
        label = { PersianText(label) },
        modifier = Modifier.fillMaxWidth()
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    replaceOnNextDigit = true
                    waitForUpOrCancellation()
                }
            }
            .onFocusChanged { focus -> replaceOnNextDigit = focus.isFocused },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done)
    )
}

/**
 * Reminder-only field row with absolute LEFT-to-RIGHT screen coordinates.
 * Unlike a normal Row, its physical order is independent of the outer Persian
 * RTL layout direction: place() (not placeRelative()) is intentional.
 */
@Composable
private fun ReminderPhysicalLtrRow(
    weights: List<Float>,
    modifier: Modifier = Modifier,
    gap: Dp = 4.dp,
    content: @Composable () -> Unit
) {
    androidx.compose.ui.layout.Layout(content = content, modifier = modifier) { measurables, constraints ->
        require(measurables.size == weights.size) { "Every reminder field requires a width weight" }
        val gapPx = gap.roundToPx()
        val width = constraints.maxWidth
        val available = (width - gapPx * (measurables.size - 1)).coerceAtLeast(0)
        val sumWeights = weights.sum().coerceAtLeast(0.01f)
        var usedWidth = 0
        val placeables = measurables.mapIndexed { index, measurable ->
            val childWidth = if (index == measurables.lastIndex) {
                available - usedWidth
            } else {
                (available * weights[index] / sumWeights).toInt().coerceAtLeast(0)
            }
            usedWidth += childWidth
            measurable.measure(androidx.compose.ui.unit.Constraints(
                minWidth = childWidth,
                maxWidth = childWidth,
                minHeight = 0,
                maxHeight = constraints.maxHeight
            ))
        }
        val height = placeables.maxOfOrNull { it.height } ?: 0
        layout(width, height) {
            var x = 0
            placeables.forEach { item ->
                item.place(x, height - item.height)
                x += item.width + gapPx
            }
        }
    }
}

/** Persian reminder year/month/day, physically left to right on screen. */
@Composable
fun ReminderDateFieldLeftToRight(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val parts = value.toLatinDigits().replace('-', '/').split('/')
    val year = parts.getOrElse(0) { "" }.take(4)
    val month = parts.getOrElse(1) { "" }.take(2)
    val day = parts.getOrElse(2) { "" }.take(2)
    val monthFocus = remember { FocusRequester() }
    val dayFocus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    fun publish(y: String, m: String, d: String) {
        onChange(when {
            y.isBlank() && m.isBlank() && d.isBlank() -> ""
            else -> y + (if (m.isNotEmpty() || d.isNotEmpty()) "-" + m else "") + (if (d.isNotEmpty()) "-" + d else "")
        })
    }
    ReminderPhysicalLtrRow(listOf(1.15f, 0.85f, 0.85f), modifier.fillMaxWidth()) {
        ReplaceableNumberField(
            value = year,
            onValueChange = { y -> publish(y, month, day); if (y.length == 4) monthFocus.requestFocus() },
            modifier = Modifier.height(50.dp), maxDigits = 4, fontSize = 13.sp,
            placeholder = "سال", imeAction = ImeAction.Next
        )
        ReplaceableNumberField(
            value = month,
            onValueChange = { m -> publish(year, m, day); if (m.length == 2) dayFocus.requestFocus() },
            modifier = Modifier.height(50.dp).focusRequester(monthFocus), maxDigits = 2,
            fontSize = 13.sp, placeholder = "ماه", imeAction = ImeAction.Next
        )
        ReplaceableNumberField(
            value = day,
            onValueChange = { d -> publish(year, month, d); if (d.length == 2) keyboard?.hide() },
            modifier = Modifier.height(50.dp).focusRequester(dayFocus), maxDigits = 2,
            fontSize = 13.sp, placeholder = "روز", imeAction = ImeAction.Done
        )
    }
}

/** Persian reminder hour/minute, physically left to right on screen. */
@Composable
fun ReminderTimeFieldLeftToRight(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val parts = value.toLatinDigits().split(':')
    val hour = parts.getOrElse(0) { "" }.take(2)
    val minute = parts.getOrElse(1) { "" }.take(2)
    val minuteFocus = remember { FocusRequester() }
    ReminderPhysicalLtrRow(listOf(1f, 0.07f, 1f), modifier.fillMaxWidth(), 3.dp) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
            PersianText("ساعت", fontSize = 9.sp, maxLines = 1, color = Color(0xFF426A6D))
            ReplaceableNumberField(
                value = hour,
                onValueChange = { h ->
                    onChange(if (h.isBlank() && minute.isBlank()) "" else "$h:$minute")
                    if (h.length == 2) minuteFocus.requestFocus()
                },
                modifier = Modifier.fillMaxWidth().height(54.dp), maxDigits = 2,
                fontSize = 17.sp, imeAction = ImeAction.Next
            )
        }
        Box(Modifier.height(54.dp), contentAlignment = Alignment.Center) {
            PersianText(":", fontSize = 16.sp, maxLines = 1)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
            PersianText("دقیقه", fontSize = 9.sp, maxLines = 1, color = Color(0xFF426A6D))
            ReplaceableNumberField(
                value = minute,
                onValueChange = { m -> onChange(if (hour.isBlank() && m.isBlank()) "" else "$hour:$m") },
                modifier = Modifier.fillMaxWidth().height(54.dp).focusRequester(minuteFocus), maxDigits = 2,
                fontSize = 17.sp, imeAction = ImeAction.Done
            )
        }
    }
}

@Composable
fun SplitDateField(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val parts = value.toLatinDigits().replace('-', '/').split('/')
    val year = parts.getOrElse(0) { "" }.take(4)
    val month = parts.getOrElse(1) { "" }.take(2)
    val day = parts.getOrElse(2) { "" }.take(2)
    val monthFocus = remember { FocusRequester() }
    val dayFocus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    fun publish(y: String, m: String, d: String) {
        val out = when {
            y.isBlank() && m.isBlank() && d.isBlank() -> ""
            else -> y + (if (m.isNotEmpty() || d.isNotEmpty()) "-" + m else "") + (if (d.isNotEmpty()) "-" + d else "")
        }
        onChange(out)
    }
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
        ReplaceableNumberField(
            value = year,
            onValueChange = { y -> publish(y, month, day); if (y.length == 4) monthFocus.requestFocus() },
            modifier = Modifier.weight(1.15f).height(50.dp),
            maxDigits = 4, fontSize = 13.sp, placeholder = "سال", imeAction = ImeAction.Next
        )
        ReplaceableNumberField(
            value = month,
            onValueChange = { m -> publish(year, m, day); if (m.length == 2) dayFocus.requestFocus() },
            modifier = Modifier.weight(0.85f).height(50.dp).focusRequester(monthFocus),
            maxDigits = 2, fontSize = 13.sp, placeholder = "ماه", imeAction = ImeAction.Next
        )
        ReplaceableNumberField(
            value = day,
            onValueChange = { d -> publish(year, month, d); if (d.length == 2) keyboard?.hide() },
            modifier = Modifier.weight(0.85f).height(50.dp).focusRequester(dayFocus),
            maxDigits = 2, fontSize = 13.sp, placeholder = "روز", imeAction = ImeAction.Done
        )
    }
}

@Composable
private fun SummaryMiniTile(label: String, value: String, background: Color, foreground: Color, modifier: Modifier) {
    Card(modifier = modifier.border(1.dp, Color(0xFFD5E4F3), RoundedCornerShape(10.dp)), colors = CardDefaults.cardColors(containerColor = background), shape = RoundedCornerShape(10.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 3.dp, vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
            PersianText(label, fontSize = 10.sp, color = foreground, textAlign = TextAlign.Center, maxLines = 1)
            PersianText(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = foreground, maxLines = 1)
            PersianText("ساعت", fontSize = 8.sp, color = foreground)
        }
    }
}

@Composable
fun SplitTimeField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, fieldFontSize: Int = 17) {
    // One controlled implementation for daily entry, hourly leave and work shifts.
    // Do not reset internal hour/minute state after every parent save/recomposition.
    val parts = value.toLatinDigits().split(":")
    val hour = parts.getOrElse(0) { "" }.take(2)
    val minute = parts.getOrElse(1) { "" }.take(2)
    val minuteFocus = remember { FocusRequester() }
    val stableClockFontSize = fieldFontSize.coerceIn(15, 17).sp
    Column(modifier, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        if (label.isNotBlank()) PersianText(label, fontSize = 10.sp, maxLines = 1)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                PersianText("ساعت", fontSize = 9.sp, maxLines = 1, color = Color(0xFF426A6D))
                ReplaceableNumberField(
                    value = hour,
                    onValueChange = { typedHour ->
                        onChange(if (typedHour.isBlank() && minute.isBlank()) "" else "$typedHour:$minute")
                        // A real edit reaches 2 digits; a mere tap/selection never calls this.
                        if (typedHour.length == 2) minuteFocus.requestFocus()
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    maxDigits = 2,
                    fontSize = stableClockFontSize,
                    imeAction = ImeAction.Next
                )
            }
            Box(Modifier.height(54.dp), contentAlignment = Alignment.Center) {
                PersianText(":", fontSize = 16.sp, maxLines = 1)
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                PersianText("دقیقه", fontSize = 9.sp, maxLines = 1, color = Color(0xFF426A6D))
                ReplaceableNumberField(
                    value = minute,
                    onValueChange = { typedMinute ->
                        onChange(if (hour.isBlank() && typedMinute.isBlank()) "" else "$hour:$typedMinute")
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp).focusRequester(minuteFocus),
                    maxDigits = 2,
                    fontSize = stableClockFontSize,
                    imeAction = ImeAction.Done
                )
            }
        }
    }
}

@Composable
fun TimePair(label1: String, v1: String, label2: String, v2: String, c1: (String)->Unit, c2: (String)->Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        SplitTimeField(label1, v1, c1, Modifier.weight(1f))
        SplitTimeField(label2, v2, c2, Modifier.weight(1f))
    }
}

@Composable
fun SettingsScreen(
    db: WorkDb,
    modifier: Modifier = Modifier,
    onCsvBackup: () -> Unit,
    onRestore: () -> Unit,
    onReminderCsvBackup: () -> Unit,
    onReminderExcelBackup: () -> Unit,
    onReminderRestore: () -> Unit,
    onSyncHolidays: (Int) -> Unit,
    syncYear: Int,
    holidaySyncing: Boolean,
    holidaySyncMessage: String,
    onFixedHoursChanged: (Boolean) -> Unit,
    onHelp: () -> Unit
) {
    var tick by remember { mutableIntStateOf(0) }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF173F71)), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                PersianText("مورخ", fontSize = 24.sp, fontWeight = FontWeight.Normal, color = Color.White, maxLines = 1)
                PersianText("تنظیمات، پشتیبان‌گیری و شخصی‌سازی برنامه", fontSize = 12.sp, color = Color(0xFFD9EAFB))
            }
        }
        PersianText("امکانات و تقویم", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF173F71))
        PersianText("تعطیلات و همهٔ مناسبت‌های تقویم ایران", style = MaterialTheme.typography.titleMedium)
        PersianText("سال شمسی را انتخاب کن تا تعطیلات رسمی و مناسبت‌های ملی، مذهبی، فرهنگی و جهانی همان سال دریافت و روی گوشی ذخیره شوند. پس از ذخیره، بدون اینترنت هم در دسترس‌اند. تاریخ قمری آینده ممکن است تا اعلام رسمی تخمینی باشد.", style = MaterialTheme.typography.bodySmall)
        var selectedCalendarYear by remember(syncYear) { mutableIntStateOf(syncYear) }
        var yearMenuExpanded by remember { mutableStateOf(false) }
        Box {
            OutlinedButton(onClick = { yearMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                PersianText("سال انتخاب‌شده: ${selectedCalendarYear.toString().toPersianDigits()}  ▾")
            }
            DropdownMenu(expanded = yearMenuExpanded, onDismissRequest = { yearMenuExpanded = false }) {
                (maxOf(1347, syncYear - 5)..minOf(1500, syncYear + 10)).forEach { optionYear ->
                    DropdownMenuItem(text = { PersianText(optionYear.toString().toPersianDigits()) }, onClick = {
                        selectedCalendarYear = optionYear
                        yearMenuExpanded = false
                    })
                }
            }
        }
        Button(onClick = { onSyncHolidays(selectedCalendarYear) }, enabled = !holidaySyncing, modifier = Modifier.fillMaxWidth()) {
            PersianText(if (holidaySyncing) "در حال دریافت تقویم…" else "دریافت مناسبت‌های سال انتخاب‌شده")
        }
        if (holidaySyncMessage.isNotBlank()) PersianText(holidaySyncMessage, style = MaterialTheme.typography.bodySmall, color = if (holidaySyncMessage.contains("نشد")) Color(0xFFB3261E) else Color(0xFF075565))
        val syncedAt = remember(selectedCalendarYear, tick, holidaySyncMessage) { db.getSettingText("calendar_last_online_$selectedCalendarYear", "0").toLongOrNull() ?: 0L }
        PersianText("آخرین به‌روزرسانی آنلاین تقویم: " + if (syncedAt == 0L) "هنوز انجام نشده" else formattedSyncStamp(syncedAt), fontSize = 11.sp, color = Color(0xFF52708F))
        Divider()
        PersianText("تاریخ قمری آبان ۱۴۰۵ با مرجع تقویم تطبیق داده می‌شود؛ برای سایر تاریخ‌ها نمایش محاسباتی است.", fontSize = 11.sp, color = Color(0xFF52708F))
        AlertManagementSettings()
        Divider()
        OutlinedButton(onClick = onHelp, modifier = Modifier.fillMaxWidth()) {
            PersianText("راهنمای جامع استفاده از مورخ")
        }
        Divider()
        PersianText("پشتیبان‌گیری و بازیابی", style = MaterialTheme.typography.titleMedium)
        Button(onClick = onCsvBackup, modifier = Modifier.fillMaxWidth()) { PersianText("ساخت پشتیبان کارکرد CSV (.csv)") }
        OutlinedButton(onClick = onRestore, modifier = Modifier.fillMaxWidth()) { PersianText("بازیابی اطلاعات کارکرد از csv") }
        PersianText("پشتیبان کارکرد روزانه با CSV ساخته می‌شود. فایل‌های Excel پشتیبان قدیمی نیز برای بازیابی قابل انتخاب‌اند.", style = MaterialTheme.typography.bodySmall)
        PersianText("دسترسی به فایل‌ها از طریق انتخابگر امن اندروید انجام می‌شود و نیازی به دسترسی کامل حافظه نیست.", fontSize = 11.sp, color = Color(0xFF52708F))
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PersianText("پشتیبان‌گیری و بازیابی یادآورها", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF1B5E20))
                PersianText("این بخش فقط مربوط به یادآورهای اقساط و جلسات است و از اطلاعات کارکرد روزانه جداست.", fontSize = 12.sp, color = Color(0xFF2E6034))
                OutlinedButton(onClick = onReminderCsvBackup, modifier = Modifier.fillMaxWidth()) { PersianText("ساخت پشتیبان یادآورها با CSV") }
                OutlinedButton(onClick = onReminderExcelBackup, modifier = Modifier.fillMaxWidth()) { PersianText("ساخت پشتیبان یادآورها با Excel") }
                Button(onClick = onReminderRestore, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))) { PersianText("بازیابی پشتیبان یادآورها (CSV یا Excel)") }
            }
        }
        var fixedHoursEnabled by remember { mutableStateOf(db.isFixedHoursEnabled()) }
        var fixedWeekdayStart by remember { mutableStateOf(db.getSettingText("fixed_weekday_start", "07:00")) }
        var fixedWeekdayEnd by remember { mutableStateOf(db.getSettingText("fixed_weekday_end", "14:00")) }
        var fixedThursdayStart by remember { mutableStateOf(db.getSettingText("fixed_thursday_start", "07:00")) }
        var fixedThursdayEnd by remember { mutableStateOf(db.getSettingText("fixed_thursday_end", "12:00")) }
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F6FF)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFBED3EC), RoundedCornerShape(12.dp))
        ) {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        PersianText("ساعت کار ثابت", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF173F71))
                        PersianText(
                            if (fixedHoursEnabled) "روشن؛ شنبه تا چهارشنبه ${fixedWeekdayStart.toPersianDigits()} تا ${fixedWeekdayEnd.toPersianDigits()} و پنجشنبه ${fixedThursdayStart.toPersianDigits()} تا ${fixedThursdayEnd.toPersianDigits()}"
                            else "خاموش؛ مرخصی داخل بازه حضور مجاز است و محاسبه بر اساس موظفی تنظیم‌شده انجام می‌شود. بازه‌های ثابت برای استفاده در حالت روشن حفظ می‌شوند.",
                            fontSize = 11.sp, color = Color(0xFF426A8A), lineHeight = 15.sp
                        )
                    }
                    Switch(
                        checked = fixedHoursEnabled,
                        onCheckedChange = { enabled ->
                            fixedHoursEnabled = enabled
                            db.setSettingText("fixed_hours_enabled", if (enabled) "1" else "0")
                            onFixedHoursChanged(enabled)
                            tick++
                        }
                    )
                }
                Divider(color = Color(0xFFD2E1F1))
                PersianText(
                    if (fixedHoursEnabled)
                        "در حالت روشن، ورود و خروج اول برای ساعت موظفی است؛ مرخصی ساعتی حداکثر در ۳ بازه و فقط داخل ساعت موظفی ثبت می‌شود. بازه‌های دوم تا چهارم برای اضافه‌کاری پس از پایان موظفی هستند. ثبت روز بدون ساعت خروج مجاز است، اما تا تکمیل خروج با عنوان «اطلاعات ناقص است» نمایش داده می‌شود."
                    else
                        "در حالت خاموش، فقط یک بازه ورود و خروج ثبت می‌شود و مرخصی ساعتی تا ۴ بازه دارد. از مجموع مرخصی، حداکثر به اندازه ساعت موظفی روز کسر می‌شود و اضافه‌کاری از کارکرد خالصِ بیشتر از موظفی به دست می‌آید.",
                    fontSize = 11.sp, color = Color(0xFF315C8D), lineHeight = 16.sp
                )
                run {
                    Divider(color = Color(0xFFD2E1F1))
                    PersianText("بازهٔ ثابت شنبه تا چهارشنبه", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF173F71))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        ReplaceableSettingsTimeField(fixedWeekdayStart, { fixedWeekdayStart = it }, "ساعت ورود (مثلاً 0700)")
                        ReplaceableSettingsTimeField(fixedWeekdayEnd, { fixedWeekdayEnd = it }, "ساعت خروج (مثلاً 1400)")
                    }
                    PersianText("بازهٔ ثابت پنجشنبه", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF173F71))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        ReplaceableSettingsTimeField(fixedThursdayStart, { fixedThursdayStart = it }, "ساعت ورود (مثلاً 0700)")
                        ReplaceableSettingsTimeField(fixedThursdayEnd, { fixedThursdayEnd = it }, "ساعت خروج (مثلاً 1200)")
                    }
                    Button(onClick = {
                        val ws = mins(fixedWeekdayStart); val we = mins(fixedWeekdayEnd)
                        val ts = mins(fixedThursdayStart); val te = mins(fixedThursdayEnd)
                        when {
                            ws == null || we == null || ts == null || te == null -> android.widget.Toast.makeText(context, "هر چهار ساعت را به شکل HH:MM وارد کن.", android.widget.Toast.LENGTH_LONG).show()
                            we <= ws || te <= ts -> android.widget.Toast.makeText(context, "ساعت خروج باید بعد از ساعت ورود باشد.", android.widget.Toast.LENGTH_LONG).show()
                            else -> {
                                db.setSettingText("fixed_weekday_start", fixedWeekdayStart)
                                db.setSettingText("fixed_weekday_end", fixedWeekdayEnd)
                                db.setSettingText("fixed_thursday_start", fixedThursdayStart)
                                db.setSettingText("fixed_thursday_end", fixedThursdayEnd)
                                tick++
                                onFixedHoursChanged(fixedHoursEnabled)
                                android.widget.Toast.makeText(context, "بازه‌های ساعت کار ثابت ذخیره شد.", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        }
                    }, modifier = Modifier.fillMaxWidth()) { PersianText("ذخیره بازه‌های ساعت کار ثابت") }
                }
            }
        }
        var dailyHours by remember { mutableStateOf(db.getSettingText("workday_hours","07:00")) }
        var thursdayHours by remember { mutableStateOf(db.getSettingText("thursday_hours_value","05:00")) }
        PersianText("ساعت موظفی", style = MaterialTheme.typography.titleMedium)
        if (fixedHoursEnabled) {
            val fixedDaily = ((mins(fixedWeekdayEnd) ?: 840) - (mins(fixedWeekdayStart) ?: 420)).coerceAtLeast(0)
            val fixedThu = ((mins(fixedThursdayEnd) ?: 720) - (mins(fixedThursdayStart) ?: 420)).coerceAtLeast(0)
            OutlinedTextField(value = hm(fixedDaily), onValueChange = {}, readOnly = true, label = { PersianText("شنبه تا چهارشنبه؛ محاسبه‌شده از بازه ثابت") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(value = hm(fixedThu), onValueChange = {}, readOnly = true, label = { PersianText("پنجشنبه؛ محاسبه‌شده از بازه ثابت") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        } else {
            ReplaceableSettingsTimeField(dailyHours, { dailyHours = it }, "شنبه تا چهارشنبه (HH:MM)")
            ReplaceableSettingsTimeField(thursdayHours, { thursdayHours = it }, "پنجشنبه (HH:MM)")
            Button(onClick = {
                if (mins(dailyHours) != null && mins(thursdayHours) != null) {
                    db.setSettingText("workday_hours",dailyHours)
                    db.setSettingText("thursday_hours_value",thursdayHours)
                    tick++
                    onFixedHoursChanged(false)
                } else android.widget.Toast.makeText(context, "ساعت موظفی معتبر نیست.", android.widget.Toast.LENGTH_LONG).show()
            }, modifier = Modifier.fillMaxWidth()) { PersianText("ذخیره ساعت موظفی شناور") }
        }
        Divider()
        Spacer(Modifier.height(12.dp))
        PersianText("نسخهٔ برنامه: ۰.۶۳.۰", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 12.sp, color = Color(0xFF52708F))
        PersianText("تهیه کننده: نواب", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF173F71))
        Spacer(Modifier.height(8.dp))
        PersianText(
            "ثواب بهره‌برداری از این اثر نثار امام شهید و یاران او",
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp),
            textAlign = TextAlign.Center,
            fontSize = 15.sp, fontFamily = FontFamily(Font(R.font.aref_ruqaa_regular)),
            fontWeight = FontWeight.Normal, color = Color(0xFF173F71), lineHeight = 25.sp
        )
    }
}



@Composable
fun SummaryTile(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.fillMaxWidth().padding(vertical = 10.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            PersianText(value, style = MaterialTheme.typography.titleMedium)
            PersianText(label, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ReportScreen(
    db: WorkDb, year: Int, monthNumber: Int, refresh: Int,
    modifier: Modifier = Modifier, annual: Boolean,
    onPeriodChange: (Int, Int) -> Unit,
    export: (Boolean, Boolean) -> Unit, exportPdf: (Boolean, Boolean) -> Unit,
    exportSummaryExcel: (Boolean) -> Unit, exportSummaryPdf: (Boolean) -> Unit,
    onOpenDay: (String) -> Unit = {},
    onDataDeleted: () -> Unit = {}
) {
    var monthMenuExpanded by remember { mutableStateOf(false) }
    var yearMenuExpanded by remember { mutableStateOf(false) }
    var includeReportNotes by remember { mutableStateOf(true) }
    var selectionMode by remember(year, monthNumber, annual) { mutableStateOf(false) }
    var selectedCardIds by remember(year, monthNumber, annual) { mutableStateOf(emptySet<String>()) }
    var showDeleteConfirmation by remember { mutableStateOf(false) }
    val deleteEnabled = selectionMode && selectedCardIds.isNotEmpty()
    fun toggleReportCard(key: String) {
        selectedCardIds = if (key in selectedCardIds) selectedCardIds - key else selectedCardIds + key
    }
    fun longPressReportCard(key: String) {
        if (!selectionMode) {
            selectionMode = true
            selectedCardIds = setOf(key)
        } else {
            toggleReportCard(key)
        }
    }
    BackHandler(enabled = selectionMode && !showDeleteConfirmation) {
        selectionMode = false
        selectedCardIds = emptySet()
    }
    val reportListState = androidx.compose.foundation.lazy.rememberLazyListState()
    val todayJalali = remember { jalaliDateString(LocalDate.now()) }
    val monthKey = "%04d-%02d".format(year, monthNumber)
    val deductionSettingKey = "tourahi_deduction_$monthKey"
    var savedTourahiDeduction by remember(monthKey, refresh) {
        mutableStateOf(db.getSettingText(deductionSettingKey, "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0)
    }
    var tourahiDeductionInput by remember(monthKey, refresh) { mutableStateOf(TextFieldValue("")) }
    val reportDays = remember(year, monthNumber, refresh) { reportPeriodDays(db, year, monthNumber, false) }
    val yearDays = remember(year, refresh) { reportPeriodDays(db, year, monthNumber, true) }
    val yearShiftList = remember(year, refresh) { reportSessions(db, year) }
    val yearShiftMinutes = remember(year, refresh) { periodSessionMinutes(yearShiftList) }
    val monthShiftDays = remember(monthKey, refresh) {
        reportSessions(db, year, monthNumber)
    }
    val monthShiftsByStartDate = remember(monthShiftDays) {
        monthShiftDays.groupBy { normalizedJalaliDateKey(it.startDate).orEmpty() }
    }
    val selectedDays = if (annual) yearDays else reportDays
    val selectedShiftList = if (annual) yearShiftList else monthShiftDays
    val totalWork = periodWorkedMinutes(db, selectedDays, selectedShiftList)
    val totalRequired = selectedDays.sumOf { requiredMinutes(it, db) }
    val totalOvertime = selectedDays.sumOf { overtimeMinutes(it, db) }
    val totalShift = if (annual) yearShiftMinutes else periodSessionMinutes(monthShiftDays)
    // Count shifts by their start date, exactly like their duration, so overnight
    // activities are attributed to one and only one reporting month/year.
    val shiftCount = if (annual) reportSessions(db, year).size else monthShiftDays.size
    val missionCount = selectedDays.count { hasDayStatus(it,"مأموریت") }
    val (rawEntitledCount, sickCount, _) = periodLeaveStats(selectedDays,db)
    val savedDeductionTotal = if (annual) (1..12).sumOf { m ->
        db.getSettingText("tourahi_deduction_%04d-%02d".format(year, m), "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
    } else savedTourahiDeduction
    val effectiveDeductionTotal = if (annual) (1..12).sumOf { m ->
        val requested = db.getSettingText("tourahi_deduction_%04d-%02d".format(year, m), "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
        val prefix = "%04d-%02d".format(year, m)
        val monthEntitledRaw = yearDays.filter { it.date.startsWith(prefix) }.count { isEntitledCountable(it, db) }
        minOf(requested, monthEntitledRaw)
    } else minOf(savedTourahiDeduction, rawEntitledCount)
    val entitledCount = (rawEntitledCount - effectiveDeductionTotal).coerceAtLeast(0)
    val tourahiCount = savedDeductionTotal

    LaunchedEffect(year, monthNumber, annual, refresh, todayJalali) {
        if (!annual && todayJalali.startsWith(monthKey)) {
            val dayNum = todayJalali.substringAfterLast("-").toIntOrNull() ?: 1
            // The first daily card follows the selector, summary, settings, and card heading.
            reportListState.scrollToItem(5 + dayNum.coerceAtLeast(1) - 1)
        }
    }
    LazyColumn(
        state = reportListState,
        modifier = modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 5.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(bottom = 14.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!annual) {
                    Box(Modifier.weight(1f)) {
                        OutlinedButton(onClick = { monthMenuExpanded = true }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 7.dp)) {
                            PersianText("ماه: ${JalaliMonthNames.getOrElse(monthNumber - 1) { "ماه" }}  ⌄", fontSize = 13.sp, maxLines = 1)
                        }
                        DropdownMenu(expanded = monthMenuExpanded, onDismissRequest = { monthMenuExpanded = false }) {
                            JalaliMonthNames.forEachIndexed { index, name ->
                                DropdownMenuItem(text = { PersianText(name) }, onClick = { monthMenuExpanded = false; onPeriodChange(year, index + 1) })
                            }
                        }
                    }
                } else {
                    Surface(Modifier.weight(1f), color = Color(0xFFEAF3FF), shape = RoundedCornerShape(9.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBEDBFA))) {
                        Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) { PersianText("خلاصهٔ سالانه", fontSize = 13.sp, color = Color(0xFF073B45)) }
                    }
                }
                Box(Modifier.weight(1f)) {
                    OutlinedButton(onClick = { yearMenuExpanded = true }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 7.dp)) {
                        PersianText("سال: ${persianDigits(year.toString())}  ⌄", fontSize = 13.sp, maxLines = 1)
                    }
                    DropdownMenu(expanded = yearMenuExpanded, onDismissRequest = { yearMenuExpanded = false }) {
                        ((year - 5)..(year + 1)).toList().reversed().forEach { y ->
                            DropdownMenuItem(text = { PersianText(persianDigits(y.toString())) }, onClick = { yearMenuExpanded = false; onPeriodChange(y, monthNumber) })
                        }
                    }
                }
            }
        }
        item {
            WorkSummaryCard(
                title = if (annual) "خلاصه کارکرد سال ${persianDigits(year.toString())}" else "خلاصه کارکرد ماه ${JalaliMonthNames[monthNumber - 1]} ${persianDigits(year.toString())}",
                worked = totalWork,
                required = totalRequired,
                recordedRequired = selectedDays.sumOf { recordedRequiredMinutes(it, db) },
                overtime = totalOvertime,
                hourlyLeave = selectedDays.sumOf { hourlyLeaveMinutes(it, db) },
                shiftCount = shiftCount,
                shiftMinutes = totalShift,
                missionCount = missionCount,
                entitledCount = entitledCount,
                sickCount = sickCount,
                tourahiCount = tourahiCount,
                incompleteCount = selectedDays.count { isIncompleteDay(it, db) }
            )
        }
        if (!annual) item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(10.dp))
            ) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 7.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    PersianText("توراهی", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF153F78))
                    PersianText(
                        "در این صفحه ثبت و حذف توراهی به‌صورت دستی امکان‌پذیر است. برای حذف مقدار ثبت‌شده، عدد ۰ را وارد و «ذخیره» را بزنید.",
                        fontSize = 10.sp, color = Color(0xFF7B3F91), lineHeight = 14.sp
                    )
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        PersianText(
                            "میزان کسر توراهی از استحقاقی‌های ماه جاری",
                            modifier = Modifier.weight(1f), fontSize = 11.sp, color = Color(0xFF315C8D), lineHeight = 15.sp
                        )
                        OutlinedTextField(
                            value = tourahiDeductionInput.copy(text = tourahiDeductionInput.text.toPersianDigits()),
                            onValueChange = { edited ->
                                val digits = edited.text.toLatinDigits().filter { ch -> ch.isDigit() }.take(3)
                                tourahiDeductionInput = TextFieldValue(
                                    text = digits,
                                    selection = TextRange(edited.selection.start.coerceAtMost(digits.length), edited.selection.end.coerceAtMost(digits.length))
                                )
                            },
                            modifier = Modifier.width(64.dp).onFocusChanged { state ->
                                if (state.isFocused) {
                                    tourahiDeductionInput = tourahiDeductionInput.copy(selection = TextRange(0, tourahiDeductionInput.text.length))
                                }
                            }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            textStyle = TextStyle(fontSize = 14.sp, textAlign = TextAlign.Center),
                            placeholder = { PersianText("روز", fontSize = 10.sp) }
                        )
                        Button(onClick = {
                            val amount = tourahiDeductionInput.text.toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
                            db.setSettingText(deductionSettingKey, amount.toString())
                            savedTourahiDeduction = amount
                            tourahiDeductionInput = TextFieldValue("")
                        }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 7.dp)) {
                            PersianText("ذخیره", fontSize = 11.sp)
                        }
                    }
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = includeReportNotes, onCheckedChange = { includeReportNotes = it })
                    PersianText("درج یادداشت‌ها در خروجی گزارش", fontSize = 12.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { export(annual, includeReportNotes) }, modifier = Modifier.weight(1f)) {
                        PersianText("خروجی Excel", fontSize = 12.sp)
                    }
                    OutlinedButton(onClick = { exportPdf(annual, includeReportNotes) }, modifier = Modifier.weight(1f)) {
                        PersianText("خروجی PDF", fontSize = 12.sp)
                    }
                }
                if (annual) {
                    Spacer(Modifier.height(5.dp))
                    PersianText("گزارش جامع سالانه • یک صفحه A4", fontSize = 13.sp,
                        fontWeight = FontWeight.Bold, color = Color(0xFF153F78))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(onClick = { exportSummaryExcel(includeReportNotes) }, modifier = Modifier.weight(1f)) {
                            PersianText("خلاصه جامع Excel", fontSize = 12.sp)
                        }
                        OutlinedButton(onClick = { exportSummaryPdf(includeReportNotes) }, modifier = Modifier.weight(1f)) {
                            PersianText("خلاصه جامع PDF A4", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        if (!annual) {
            item(key = "month_daily_summary") {
                Surface(
                    modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(9.dp)),
                    color = Color(0xFFEAF3FF), shape = RoundedCornerShape(9.dp)
                ) {
                    PersianText("کارت روز", modifier = Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 7.dp),
                        textAlign = TextAlign.Right, style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold, color = Color(0xFF153F78))
                }
            }
            items(reportDays, key = { "report-day-${it.date}" }) { reportDay ->
                val saved = if (db.hasWorkDay(reportDay.date)) db.getDay(reportDay.date) else reportDay
                val cardKey = "day:${reportDay.date}"
                val isSelected = cardKey in selectedCardIds
                val shiftsForDay = monthShiftsByStartDate[normalizedJalaliDateKey(reportDay.date).orEmpty()].orEmpty()
                ReportDayCard(
                    applyCalendarHoliday(saved, db), db,
                    db.holidayTitle(reportDay.date) ?: db.displayHolidayTitle(reportDay.date) ?: officialJalaliHolidays(year).toMap()[reportDay.date],
                    shiftDuration = periodSessionMinutes(shiftsForDay),
                    hasShift = shiftsForDay.isNotEmpty(),
                    activityCount = shiftsForDay.size,
                    selected = isSelected,
                    selectionMode = selectionMode,
                    onClick = {
                        if (selectionMode) toggleReportCard(cardKey) else onOpenDay(reportDay.date)
                    },
                    onLongClick = { longPressReportCard(cardKey) }
                )
            }
        } else {
            item {
                Surface(modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(9.dp)),
                    color = Color(0xFFEAF3FF), shape = RoundedCornerShape(9.dp)) {
                    PersianText("کارت ماه", modifier = Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 7.dp),
                        style = MaterialTheme.typography.titleMedium, color = Color(0xFF073B45), fontWeight = FontWeight.Bold)
                }
            }
            items((1..12).toList()) { m ->
                val monthDays = yearDays.filter { it.date.startsWith("%04d-%02d".format(year, m)) }
                val monthShiftList = reportSessions(db, year, m)
                val monthShift = periodSessionMinutes(monthShiftList)
                val monthTotalWork = periodWorkedMinutes(db, monthDays, monthShiftList)
                val cardKey = "month:$m"
                val isSelected = cardKey in selectedCardIds
                Card(
                    colors = CardDefaults.cardColors(containerColor = if (isSelected) Color(0xFFE8F5E9) else Color(0xFFF3F8F6)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                        .border(if (isSelected) 2.dp else 1.dp, if (isSelected) Color(0xFF24834A) else Color(0xFFBEDBFA), RoundedCornerShape(12.dp))
                        .combinedClickable(
                            onClick = { if (selectionMode) toggleReportCard(cardKey) },
                            onLongClick = { longPressReportCard(cardKey) }
                        )
                ) {
                    Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            PersianText(JalaliMonthNames[m - 1], style = MaterialTheme.typography.titleSmall, color = Color(0xFF073B45), fontWeight = FontWeight.Bold)
                            if (selectionMode) PersianText(if (isSelected) "☑" else "□", fontSize = 20.sp, color = if (isSelected) Color(0xFF24834A) else Color(0xFF78909C))
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            PersianText("کل کارکرد ${hm(monthTotalWork)}", fontSize = 11.sp)
                            PersianText("موظفی مقرر ${hm(monthDays.sumOf { requiredMinutes(it, db) })}", fontSize = 10.sp, color = Color(0xFF315C8D))
                            PersianText("موظفی ثبتی ${hm(monthDays.sumOf { recordedRequiredMinutes(it, db) })}", fontSize = 10.sp, color = Color(0xFF0B6865))
                            PersianText("اضافه‌کار ${hm(monthDays.sumOf { overtimeMinutes(it, db) })}", fontSize = 10.sp, color = OvertimeGreenText)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            PersianText("تعداد فعالیت ${reportSessions(db, year, m).size.toString().toPersianDigits()}", fontSize = 11.sp, color = ShiftYellowText)
                            PersianText("جمع مدت فعالیت ${hm(monthShift)}", fontSize = 11.sp, color = ShiftYellowText)
                        }
                        val (rawMonthEntitled, monthSick, _) = periodLeaveStats(monthDays,db)
                        val monthDeduction = db.getSettingText("tourahi_deduction_%04d-%02d".format(year, m), "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
                        val monthEntitled = (rawMonthEntitled - monthDeduction).coerceAtLeast(0)
                        val monthTravel = monthDeduction
                        PersianText("استحقاقی: ${monthEntitled.toString().toPersianDigits()} | استعلاجی: ${monthSick.toString().toPersianDigits()} | مأموریت: ${monthDays.count { hasDayStatus(it,"مأموریت") }.toString().toPersianDigits()} | توراهی: ${monthTravel.toString().toPersianDigits()}", fontSize = 11.sp)
                        val officialHolidayCount = monthDays.count { d ->
                            db.officialHolidayTitle(d.date) != null || officialJalaliHolidays(year).toMap().containsKey(d.date)
                        }
                        PersianText("تعطیلات رسمی: ${officialHolidayCount.toString().toPersianDigits()} روز", fontSize = 11.sp, color = Color(0xFFB3261E))
                        val incompleteInMonth = monthDays.count { isIncompleteDay(it, db) }
                        if (incompleteInMonth > 0) PersianText("اطلاعات ناقص: ${incompleteInMonth.toString().toPersianDigits()} روز", fontSize = 11.sp, color = Color(0xFF9A6200))
                    }
                }
            }
        }
        item(key = "delete-selected-report-cards") {
            Column(Modifier.fillMaxWidth().padding(top = 4.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                if (selectionMode) {
                    PersianText(
                        "برای افزودن یا برداشتن کارت، آن را لمس کن. برای خروج از حالت انتخاب، یک‌بار دکمهٔ بازگشت را بزن.",
                        modifier = Modifier.fillMaxWidth(), fontSize = 11.sp, color = Color(0xFF52708F), textAlign = TextAlign.Center
                    )
                } else {
                    PersianText(
                        "برای فعال‌کردن حذف، انگشت را روی کارت روز یا ماه نگه دار.",
                        modifier = Modifier.fillMaxWidth(), fontSize = 11.sp, color = Color(0xFF52708F), textAlign = TextAlign.Center
                    )
                }
                Button(
                    onClick = { if (deleteEnabled) showDeleteConfirmation = true },
                    enabled = deleteEnabled,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFB3261E),
                        contentColor = Color.White,
                        disabledContainerColor = Color(0xFFE8EDF2),
                        disabledContentColor = Color(0xFF8A969F)
                    )
                ) {
                    PersianText(
                        if (deleteEnabled) "حذف ${selectedCardIds.size.toString().toPersianDigits()} کارت انتخاب‌شده"
                        else "حذف کارت‌های انتخاب‌شده",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
    if (showDeleteConfirmation) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmation = false },
            title = { PersianText("تأیید حذف اطلاعات", fontWeight = FontWeight.Bold, color = Color(0xFFB3261E)) },
            text = {
                PersianText(
                    if (annual) {
                        "اطلاعات تمام روزهای ${selectedCardIds.size.toString().toPersianDigits()} ماه انتخاب‌شده به‌همراه فعالیت‌هایی که در آن ماه شروع شده‌اند و مقدار توراهی همان ماه‌ها حذف می‌شود. این کار دائمی است؛ پیش از تأیید، از اطلاعات پشتیبان بگیر. اطلاعات تقویم و یادآورها حذف نمی‌شوند."
                    } else {
                        "تمام اطلاعات ثبت‌شده در ${selectedCardIds.size.toString().toPersianDigits()} روز انتخاب‌شده، شامل ساعت‌ها، فعالیت‌های شروع‌شده در همان روز، یادداشت، مرخصی، مأموریت و نوع روز حذف می‌شود. این کار دائمی است؛ پیش از تأیید، از اطلاعات پشتیبان بگیر. اطلاعات تقویم و یادآورها باقی می‌مانند."
                    }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val selected = selectedCardIds.toSet()
                    if (annual) {
                        val months = selected.mapNotNull { it.removePrefix("month:").toIntOrNull() }.toSet()
                        db.deleteReportMonths(year, months)
                    } else {
                        val dates = selected.mapNotNull { key ->
                            key.takeIf { it.startsWith("day:") }?.removePrefix("day:")
                        }.toSet()
                        db.deleteReportDays(dates)
                    }
                    showDeleteConfirmation = false
                    selectionMode = false
                    selectedCardIds = emptySet()
                    onDataDeleted()
                }) { PersianText("حذف قطعی", color = Color(0xFFB3261E), fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { showDeleteConfirmation = false }) { PersianText("انصراف") } }
        )
    }
}

@Composable
private fun ReportMetricTile(title: String, value: String, symbol: String, valueColor: Color, modifier: Modifier = Modifier) {
    Column(modifier = modifier.heightIn(min = 86.dp).background(Color(0xFFF5FAFF), RoundedCornerShape(9.dp))
        .border(1.dp, Color(0xFFD5E4F3), RoundedCornerShape(9.dp)).padding(horizontal = 3.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        PersianText(title, fontSize = 10.sp, color = Color(0xFF315C8D), textAlign = TextAlign.Center, maxLines = 2, lineHeight = 12.sp)
        Spacer(Modifier.height(2.dp))
        PersianText(symbol, fontSize = 17.sp, color = valueColor, maxLines = 1)
        PersianText(value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = valueColor, maxLines = 1)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ReportDayCard(
    day: WorkDay,
    db: WorkDb,
    holidayTitle: String?,
    shiftDuration: Int = 0,
    hasShift: Boolean = false,
    activityCount: Int = if (hasShift) 1 else 0,
    selected: Boolean = false,
    selectionMode: Boolean = false,
    onClick: () -> Unit = {},
    onLongClick: () -> Unit = {}
) {
    val weekDay = jalaliWeekday(day.date)?.let { JalaliWeekdayNames.getOrNull(it) }.orEmpty()
    val holidayEntryExists = isHolidayWorkDay(day)

    // Only include entry/exit values that the user actually entered.
    // Keep the original order: entry 1, exit 1, entry 2, exit 2, entry 3, exit 3.
    val timeEntries: List<Pair<String, String>> = if (holidayEntryExists) {
        buildList {
            if (day.holidayIn.isNotBlank()) add("ورود" to day.holidayIn)
            if (day.holidayOut.isNotBlank()) add("خروج" to day.holidayOut)
        }
    } else {
        buildList {
            if (day.in1.isNotBlank()) add("ورود" to day.in1)
            if (day.out1.isNotBlank()) add("خروج" to day.out1)
            if (day.in2.isNotBlank()) add("ورود" to day.in2)
            if (day.out2.isNotBlank()) add("خروج" to day.out2)
            if (day.in3.isNotBlank()) add("ورود" to day.in3)
            if (day.out3.isNotBlank()) add("خروج" to day.out3)
            if (day.in4.isNotBlank()) add("ورود" to day.in4)
            if (day.out4.isNotBlank()) add("خروج" to day.out4)
        }
    }

    // Shift minutes are supplied by the report's start-date index, not by the
    // database row on which the shift happened to be stored.

    // Holiday cards are distinguished with a soft red fill and red outline.
    // Friday is detected by the Jalali weekday index used in this project (5 = Friday).
    val isHolidayCard = jalaliWeekday(day.date) == 5 ||
        dayStatuses(day).any { it in workHolidayStatuses } ||
        db.officialHolidayTitle(day.date) != null || db.holidayTitle(day.date) != null ||
        officialJalaliHolidays(day.date.take(4).toIntOrNull() ?: 0).toMap().containsKey(day.date)
    val holidayCardBackground = if (isHolidayCard) Color(0xFFFFF5F5) else Color(0xFFF3F8F6)
    val holidayCardBorder = if (isHolidayCard) Color(0xFFE57373) else Color(0xFFBEDBFA)
    val holidayHeaderColor = if (isHolidayCard) Color(0xFFB3261E) else Color(0xFF073B45)

    // Show only the selected day category, rather than all available categories.
    val statusItems = buildList {
        add(if (day.fixedHoursMode) "ساعت کار ثابت (ث)" else "ساعت کار شناور (ش)")
        dayStatuses(day).forEach { type ->
            add(if (type == "مرخصی") "مرخصی استحقاقی" else type)
        }
        if (hasShift) add("فعالیت کاری")
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFFE8F5E9) else holidayCardBackground),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
            .border(if (selected) 2.dp else 1.5.dp, if (selected) Color(0xFF24834A) else holidayCardBorder, RoundedCornerShape(14.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(7.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                PersianText(
                    "${weekDay} ${jalaliDisplayDate(day.date)}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (selected) Color(0xFF24834A) else holidayHeaderColor
                )
                if (selectionMode) {
                    PersianText(if (selected) "☑" else "□", fontSize = 20.sp, color = if (selected) Color(0xFF24834A) else Color(0xFF78909C))
                } else {
                    PersianText("▦", fontSize = 20.sp, color = if (isHolidayCard) Color(0xFFB3261E) else Color(0xFF426A6D))
                }
            }

            Divider(color = if (isHolidayCard) Color(0xFFF0B4B4) else Color(0xFFD9E8F8))

            if (timeEntries.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    timeEntries.forEach { (label, time) ->
                        Column(
                            Modifier.weight(1f)
                                .defaultMinSize(minHeight = 55.dp)
                                .border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(8.dp))
                                .padding(horizontal = 2.dp, vertical = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            PersianText(label, fontSize = 9.sp, color = Color(0xFF075565), maxLines = 1)
                            PersianText(
                                time.toPersianDigits(),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF073B45),
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            if (statusItems.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    statusItems.forEach { status ->
                        val isShift = status == "فعالیت کاری"
                        val bg = when {
                            isShift -> ShiftYellow
                            status == "تعطیل مناسبتی" -> Color(0xFFE0F5E9)
                            else -> Color(0xFFE4F0FF)
                        }
                        val foreground = when {
                            isShift -> ShiftYellowText
                            status == "تعطیل مناسبتی" -> Color(0xFF176B36)
                            else -> Color(0xFF1556A6)
                        }
                        Surface(
                            modifier = Modifier.weight(1f).heightIn(min = 52.dp),
                            shape = RoundedCornerShape(8.dp),
                            color = bg,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isShift) Color(0xFFE5C34A) else Color(0xFF8DBFFF)
                            )
                        ) {
                            Box(
                                Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 5.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                PersianText(
                                    status,
                                    fontSize = 10.sp,
                                    color = foreground,
                                    textAlign = TextAlign.Center,
                                    maxLines = 2,
                                    lineHeight = 12.sp
                                )
                            }
                        }
                    }
                }
            }

            if (hasDayStatus(day,"تعطیل مناسبتی") || !holidayTitle.isNullOrBlank()) {
                Row(
                    Modifier.fillMaxWidth()
                        .border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(8.dp))
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PersianText("✎", fontSize = 17.sp, color = Color(0xFF075565))
                    PersianText("مناسبت / عنوان تعطیلی:", fontSize = 11.sp, color = Color(0xFF075565))
                    PersianText(
                        holidayTitle ?: "—",
                        modifier = Modifier.weight(1f),
                        fontSize = 11.sp,
                        color = Color(0xFF073B45),
                        maxLines = 3,
                        lineHeight = 14.sp
                    )
                }
            }

            if (isIncompleteDay(day, db)) {
                Surface(color = Color(0xFFFFF4DF), shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                    PersianText("اطلاعات ناقص است؛ این روز تا تکمیل بازه‌های ناقص در جمع قطعی کارکرد محاسبه نمی‌شود.", modifier = Modifier.padding(8.dp), fontSize = 11.sp, color = Color(0xFF8A5700), textAlign = TextAlign.Center)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                ReportValueTile("کل کارکرد", hm(dayReportedWorkMinutes(day, db)), Color(0xFFEAF3FF), Color(0xFF153F78), Modifier.weight(1f))
                ReportValueTile("موظفی مقرر", hm(requiredMinutes(day, db)), Color(0xFFEAF3FF), Color(0xFF315C8D), Modifier.weight(1f))
                ReportValueTile("موظفی ثبتی", hm(recordedRequiredMinutes(day, db)), Color(0xFFE3F6F3), Color(0xFF0B6865), Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                ReportValueTile("اضافه‌کار", hm(overtimeMinutes(day, db)), Color(0xFFE4F7EE), OvertimeGreenText, Modifier.weight(1f))
                ReportValueTile("تعداد فعالیت", activityCount.toString(), Color(0xFFFFF7E1), ShiftYellowText, Modifier.weight(1f))
                ReportValueTile("جمع مدت فعالیت", hm(shiftDuration), Color(0xFFFFF7E1), ShiftYellowText, Modifier.weight(1f))
            }

            // The note wraps to as many lines as necessary; the card grows with the text.
            Row(
                Modifier.fillMaxWidth()
                    .border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(8.dp))
                    .padding(8.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PersianText("▤", fontSize = 17.sp, color = Color(0xFF075565))
                PersianText("یادداشت روز:", fontSize = 11.sp, color = Color(0xFF073B45))
                PersianText(
                    day.note.ifBlank { "—" }.toPersianDigits(),
                    modifier = Modifier.weight(1f),
                    fontSize = 12.sp,
                    color = Color(0xFF5D7898),
                    lineHeight = 16.sp,
                    maxLines = Int.MAX_VALUE,
                    softWrap = true
                )
            }

        }
    }
}

@Composable
private fun ReportValueTile(title: String, value: String, background: Color, foreground: Color, modifier: Modifier = Modifier) {
    Column(modifier = modifier.background(background, RoundedCornerShape(9.dp))
        .border(1.dp, Color(0xFFD5E4F3), RoundedCornerShape(9.dp)).padding(horizontal = 5.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        PersianText(title, fontSize = 11.sp, color = foreground, textAlign = TextAlign.Center, maxLines = 1)
        PersianText(value, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = foreground, maxLines = 1)
    }
}

/** Report creation time uses the phone's local timezone and Jalali calendar. */
private fun reportCreatedAt(): String {
    val current = java.time.LocalDateTime.now()
    val (y, m, d) = gregorianToJalali(current.toLocalDate())
    return "%04d/%02d/%02d  %02d:%02d".format(Locale.ROOT, y, m, d, current.hour, current.minute).toPersianDigits()
}

private data class AnnualReportStats(
    val workedMinutes: Int = 0,
    val requiredMinutes: Int = 0,
    val recordedRequiredMinutes: Int = 0,
    val overtimeMinutes: Int = 0,
    val shiftMinutes: Int = 0,
    val shifts: Int = 0,
    val entitled: Int = 0,
    val sick: Int = 0,
    val missions: Int = 0,
    val travel: Int = 0,
    val hourlyLeave: Int = 0,
    val workedDays: Int = 0,
    val holidayDays: Int = 0,
    val incompleteDays: Int = 0
) {
    operator fun plus(other: AnnualReportStats) = AnnualReportStats(
        workedMinutes + other.workedMinutes,
        requiredMinutes + other.requiredMinutes,
        recordedRequiredMinutes + other.recordedRequiredMinutes,
        overtimeMinutes + other.overtimeMinutes,
        shiftMinutes + other.shiftMinutes,
        shifts + other.shifts,
        entitled + other.entitled,
        sick + other.sick,
        missions + other.missions,
        travel + other.travel,
        hourlyLeave + other.hourlyLeave,
        workedDays + other.workedDays,
        holidayDays + other.holidayDays,
        incompleteDays + other.incompleteDays
    )
    fun values(): List<String> = listOf(
        hm(workedMinutes), hm(requiredMinutes), hm(recordedRequiredMinutes), hm(overtimeMinutes), hm(shiftMinutes), shifts.toString(),
        entitled.toString(), sick.toString(), missions.toString(), travel.toString(),
        hm(hourlyLeave), workedDays.toString(), holidayDays.toString(), incompleteDays.toString()
    )
}

private val annualReportHeadings = listOf(
    "ماه", "کل کارکرد", "موظفی مقرر", "موظفی ثبتی", "اضافه‌کار", "جمع مدت فعالیت", "تعداد فعالیت", "استحقاقی", "استعلاجی",
    "مأموریت", "توراهی", "مرخصی ساعتی", "روز کارکرد", "روز تعطیل", "روز ناقص"
)

private fun annualMonthStats(db: WorkDb, year: Int, month: Int): AnnualReportStats {
    val days = reportPeriodDays(db, year, month, false)
    val prefix = "%04d-%02d".format(Locale.ROOT,year,month)
    // Keep annual Excel/PDF summaries on the exact same independent-activity path as
    // on-screen monthly/yearly reports, including date normalization.
    val shifts = reportSessions(db, year, month)
    val (rawEntitled, sick, _) = periodLeaveStats(days, db)
    val deduction = db.getSettingText("tourahi_deduction_$prefix", "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
    val entitled = (rawEntitled - deduction).coerceAtLeast(0)
    val travel = deduction
    return AnnualReportStats(
        workedMinutes = periodWorkedMinutes(db, days, shifts),
        requiredMinutes = days.sumOf { requiredMinutes(it, db) },
        recordedRequiredMinutes = days.sumOf { recordedRequiredMinutes(it, db) },
        overtimeMinutes = days.sumOf { overtimeMinutes(it,db) },
        shiftMinutes = periodSessionMinutes(shifts),
        shifts = shifts.size, entitled = entitled, sick = sick,
        missions = days.count { hasDayStatus(it,"مأموریت") }, travel = travel,
        hourlyLeave = days.sumOf { hourlyLeaveMinutes(it, db) },
        workedDays = days.count { dayReportedWorkMinutes(it, db) > 0 },
        holidayDays = days.count {
            jalaliWeekday(it.date) == 5 || dayStatuses(it).any { status -> status in workHolidayStatuses } ||
                db.officialHolidayTitle(it.date) != null ||
                officialJalaliHolidays(year).any { holiday -> holiday.first == it.date }
        },
        incompleteDays = days.count { isIncompleteDay(it, db) }
    )
}

private fun annualSummarySheetXml(db: WorkDb, year: Int, createdAt: String): String {
    val months = (1..12).map { annualMonthStats(db,year,it) }
    val total = months.fold(AnnualReportStats()) { acc, item -> acc + item }
    val first = MutableList(15) { "" }
    first[0] = "مورخ | گزارش جامع سالانه ${year.toString().toPersianDigits()}"
    first[13] = "تهیه: $createdAt"
    val rows = mutableListOf<List<String>>(
        first,
        listOf("خلاصه کل سال و آمار تفکیکی ۱۲ ماه • هر زمان با ساعت:دقیقه، هر تعداد با روز یا نوبت"),
        listOf("واحد: ساعت:دقیقه برای کارکرد، اضافه‌کار، فعالیت و مرخصی ساعتی؛ سایر مقادیر تعداد هستند"),
        annualReportHeadings,
        listOf("جمع کل سال") + total.values()
    )
    months.forEachIndexed { index, s -> rows.add(listOf(JalaliMonthNames[index]) + s.values()) }
    rows.add(listOf("استحقاقی پس از کسر توراهی نمایش داده شده است؛ توراهی مستقل گزارش می‌شود و دوباره‌شماری ندارد."))
    val widths = listOf(18,15,15,15,15,15,15,14,14,14,12,17,13,13,12)
    val cols = widths.mapIndexed { i,width -> "<col min=\"${i+1}\" max=\"${i+1}\" width=\"$width\" customWidth=\"1\"/>" }.joinToString("")
    val body = rows.mapIndexed { ri,row ->
        val cells = row.mapIndexed { ci,value ->
            val style = when { ri == 0 -> if(ci==13) 5 else 2; ri == 3 -> 1; ri == 4 -> 5; ri in 5..16 && ci==0 -> 5; ri in 5..16 -> 4; else -> 6 }
            "<c r=\"${colName(ci+1)}${ri+1}\" s=\"$style\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${xmlEscape(value.toPersianDigits())}</t></is></c>"
        }.joinToString("")
        val height = when(ri) { 0->34; 1,2->27; 3->44; 4->34; 17->30; else->29 }
        "<row r=\"${ri+1}\" ht=\"$height\" customHeight=\"1\">$cells</row>"
    }.joinToString("")
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><sheetViews><sheetView workbookViewId="0" rightToLeft="1"><pane ySplit="4" topLeftCell="A5" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>$cols</cols><sheetData>$body</sheetData><mergeCells count="5"><mergeCell ref="A1:M1"/><mergeCell ref="N1:O1"/><mergeCell ref="A2:O2"/><mergeCell ref="A3:O3"/><mergeCell ref="A18:O18"/></mergeCells><printOptions horizontalCentered="1"/><pageMargins left="0.18" right="0.18" top="0.28" bottom="0.28" header="0.1" footer="0.1"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="1"/></worksheet>"""
}

fun buildReportXlsx(db: WorkDb, year: Int, month: Int, annual: Boolean, includeNotes: Boolean = true, summaryOnly: Boolean = false): ByteArray {
    // The hidden recovery sheets contain the selected reporting period only, plus
    // independent activity metadata whose start date falls inside the period.
    // This preserves activity recovery without exporting unrelated daily details.
    val months = if (annual) (1..12).toList() else listOf(month)
    val allowedPrefixes = months.map { "%04d-%02d".format(year,it) }
    val allStoredDays = db.allDaysForBackup()
    val inPeriod: (String) -> Boolean = { date ->
        val normalized = normalizedJalaliDateKey(date)
        normalized != null && allowedPrefixes.any { normalized.startsWith(it) }
    }
    val recordedDays = allStoredDays.filter { day -> inPeriod(day.date) }
    val raw = mutableListOf(listOf("date","dayType","in1","out1","in2","out2","in3","out3","duration","overtimeOverride","note","shiftEnabled","shiftStart","shiftEnd","shiftStartDate","shiftEndDate","holidayIn","holidayOut","leave1Start","leave1End","leave2Start","leave2End","hourlyLeaveEnabled","extraDayTypes","in4","out4","leave3Start","leave3End","leave4Start","leave4End","fixedHoursMode"))
    recordedDays.forEach { d -> raw.add(listOf(d.date,d.dayType,d.in1,d.out1,d.in2,d.out2,d.in3,d.out3,hm(duration(d, db)),d.overtimeOverride,if (includeNotes) d.note else "",d.shiftEnabled.toString(),d.shiftStart,d.shiftEnd,d.shiftStartDate,d.shiftEndDate,d.holidayIn,d.holidayOut,d.leave1Start,d.leave1End,d.leave2Start,d.leave2End,d.hourlyLeaveEnabled.toString(),d.extraDayTypes,d.in4,d.out4,d.leave3Start,d.leave3End,d.leave4Start,d.leave4End,d.fixedHoursMode.toString())) }
    val metadata = mutableListOf(listOf("key","value"),listOf("export_format","period_report_v1"),listOf("period",if(annual) "%04d".format(year) else "%04d-%02d".format(year,month)))
    db.allWorkSessions().filter { inPeriod(it.startDate) }.forEachIndexed { index, session ->
        val payload = org.json.JSONObject().apply {
            put("startDate", session.startDate); put("startTime", session.startTime)
            put("endDate", session.endDate); put("endTime", session.endTime); put("note", session.note)
        }.toString()
        metadata.add(listOf("period_activity_$index", payload))
    }
    db.allHolidays().filter { inPeriod(it.first) }.forEachIndexed { index, (date, title) ->
        val payload = org.json.JSONObject().apply { put("date", date); put("title", title) }.toString()
        metadata.add(listOf("period_holiday_$index", payload))
    }
    db.allSettings().filter { (key, _) -> key.startsWith("fixed_") || key in setOf("workday_hours", "thursday_hours_value") }
        .forEach { (key, value) -> metadata.add(listOf("setting_$key", value)) }

    val createdAt = reportCreatedAt()
    val sheets = mutableListOf<Pair<String,String>>()
    sheets.add("داده‌های بازیابی" to sheetXml(raw))
    sheets.add("اطلاعات فایل" to sheetXml(metadata))
    if (annual && summaryOnly) {
        sheets.add("خلاصه جامع سالانه" to annualSummarySheetXml(db, year, createdAt))
    } else {
        months.forEach { m -> sheets.add(JalaliMonthNames[m-1] to monthReportSheetXml(db,year,m,includeNotes,createdAt)) }
    }
    val content = linkedMapOf<String,String>()
    content["[Content_Types].xml"] = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.indices.joinToString("") { "<Override PartName=\"/xl/worksheets/sheet${it+1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" }}</Types>"""
    content["_rels/.rels"] = """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>"""
    val sheetDefs = sheets.mapIndexed { i,pair -> "<sheet name=\"${xmlEscape(pair.first)}\" sheetId=\"${i+1}\" r:id=\"rId${i+1}\"${if(i<2) " state=\"hidden\"" else ""}/>" }.joinToString("")
    content["xl/workbook.xml"] = """<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="2" firstSheet="2"/></bookViews><sheets>$sheetDefs</sheets></workbook>"""
    val relationships = sheets.indices.joinToString("") { i -> "<Relationship Id=\"rId${i+1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet${i+1}.xml\"/>" }
    content["xl/_rels/workbook.xml.rels"] = """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">$relationships<Relationship Id="rId${sheets.size+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>"""
    content["xl/styles.xml"] = reportStylesXml()
    sheets.forEachIndexed { i,pair -> content["xl/worksheets/sheet${i+1}.xml"] = pair.second }
    val output = java.io.ByteArrayOutputStream()
    java.util.zip.ZipOutputStream(output).use { zip -> content.forEach { (name,value) ->
        zip.putNextEntry(java.util.zip.ZipEntry(name));zip.write(value.toByteArray(Charsets.UTF_8));zip.closeEntry()
    } }
    return output.toByteArray()
}

/** Display columns for each of the three work intervals (one value per cell).
 * Holiday overtime is shown in the first pair; the other pairs remain separate and empty.
 */
private fun hasSecondEntryExit(days: List<WorkDay>): Boolean = days.any { it.in2.isNotBlank() || it.out2.isNotBlank() }
private fun hasThirdEntryExit(days: List<WorkDay>): Boolean = days.any { it.in3.isNotBlank() || it.out3.isNotBlank() }
private fun hasFourthEntryExit(days: List<WorkDay>): Boolean = days.any { it.in4.isNotBlank() || it.out4.isNotBlank() }

private fun dayEntryExitColumns(day: WorkDay, includeSecond: Boolean, includeThird: Boolean, includeFourth: Boolean): List<String> {
    val firstPair = if (isHolidayWorkDay(day) && (day.holidayIn.isNotBlank() || day.holidayOut.isNotBlank()))
        listOf(day.holidayIn, day.holidayOut) else listOf(day.in1, day.out1)
    val pairs = mutableListOf<String>().apply {
        addAll(firstPair)
        if (includeSecond) addAll(if (isHolidayWorkDay(day) && (day.holidayIn.isNotBlank() || day.holidayOut.isNotBlank())) listOf("", "") else listOf(day.in2, day.out2))
        if (includeThird) addAll(if (isHolidayWorkDay(day) && (day.holidayIn.isNotBlank() || day.holidayOut.isNotBlank())) listOf("", "") else listOf(day.in3, day.out3))
        if (includeFourth) addAll(if (isHolidayWorkDay(day) && (day.holidayIn.isNotBlank() || day.holidayOut.isNotBlank())) listOf("", "") else listOf(day.in4, day.out4))
    }
    return pairs.map { it.ifBlank { "—" } }
}

private fun reportHeadings(includeSecond: Boolean, includeThird: Boolean, includeFourth: Boolean): List<String> = buildList {
    addAll(listOf("روز هفته", "تاریخ", "وضعیت", "ورود ۱", "خروج ۱"))
    if (includeSecond) addAll(listOf("ورود ۲", "خروج ۲"))
    if (includeThird) addAll(listOf("ورود ۳", "خروج ۳"))
    if (includeFourth) addAll(listOf("ورود ۴", "خروج ۴"))
    addAll(listOf("کل کارکرد", "موظفی مقرر", "موظفی ثبتی", "اضافه‌کار", "تعداد فعالیت", "جمع مدت فعالیت", "مرخصی ساعتی", "یادداشت"))
}

/** Combines a day's note with its occasion-holiday reason in report exports. */
private fun reportNoteWithHolidayReason(day: WorkDay, db: WorkDb): String {
    val note = day.note.trim()
    val reason = if (hasDayStatus(day, "تعطیل مناسبتی")) db.holidayTitle(day.date)?.trim().orEmpty() else ""
    if (reason.isBlank()) return note
    val suffix = "+ علت تعطیلی: $reason"
    return listOf(note, suffix).filter { it.isNotBlank() }.joinToString(" ")
}

private fun monthReportSheetXml(db: WorkDb, year: Int, month: Int, includeNotes: Boolean, createdAt: String): String {
    val days = reportPeriodDays(db, year, month, false)
    val includeSecond = hasSecondEntryExit(days)
    val includeThird = hasThirdEntryExit(days)
    val includeFourth = hasFourthEntryExit(days)
    val headings = reportHeadings(includeSecond, includeThird, includeFourth)
    val shifts = reportSessions(db, year, month)
    val (rawEntitledDays,sickDays,_) = periodLeaveStats(days,db)
    val deduction = db.getSettingText("tourahi_deduction_%04d-%02d".format(year, month), "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
    val entitledDays = (rawEntitledDays - deduction).coerceAtLeast(0)
    val travelDays = deduction
    val title = "مورخ | گزارش ${JalaliMonthNames[month-1]} ${year.toString().toPersianDigits()}"
    val summary = "کل کارکرد: ${hm(periodWorkedMinutes(db, days, shifts))} | موظفی مقرر: ${hm(days.sumOf { requiredMinutes(it, db) })} | موظفی ثبتی: ${hm(days.sumOf { recordedRequiredMinutes(it, db) })} | اضافه‌کاری: ${hm(days.sumOf { overtimeMinutes(it,db) })} | مرخصی ساعتی: ${hm(days.sumOf { hourlyLeaveMinutes(it, db) })}"
    val summary2 = "فعالیت: ${hm(periodSessionMinutes(shifts))} | تعداد فعالیت: ${shifts.size} | روز ناقص: ${days.count { isIncompleteDay(it,db) }} | استحقاقی: $entitledDays | استعلاجی: $sickDays | توراهی: $travelDays | مأموریت: ${days.count { hasDayStatus(it,"مأموریت") }}"
    val stampRow = MutableList(headings.size) { "" }
    stampRow[0] = title
    stampRow[headings.size - 3] = "تهیه: $createdAt"
    val rows = mutableListOf<List<String>>(
        stampRow,
        listOf("گزارش ماهانه • چاپ یک صفحه A4 افقی"),
        listOf(summary),
        listOf(summary2),
        headings.map { if (!includeNotes && it == "یادداشت") "بدون یادداشت" else it }
    )
    days.forEach { day ->
        val weekday = jalaliWeekday(day.date)?.let { JalaliWeekdayNames.getOrNull(it) }.orEmpty()
        val dayActivities = sessionsStartingOnDate(db, day.date)
        val values = listOf(
            hm(dayReportedWorkMinutes(day, db)), hm(requiredMinutes(day,db)), hm(recordedRequiredMinutes(day,db)), hm(overtimeMinutes(day,db)),
            dayActivities.size.toString(), hm(periodSessionMinutes(dayActivities)).takeIf { it != "00:00" } ?: "—",
            hm(hourlyLeaveMinutes(day, db)), if (includeNotes) reportNoteWithHolidayReason(day, db) else ""
        )
        rows.add(listOf(weekday,day.date.replace('-', '/'),reportDayStatusText(day,db)) +
            dayEntryExitColumns(day, includeSecond, includeThird, includeFourth) + values)
    }
    val widths = buildList {
        addAll(listOf(13,16,22,12,12))
        if (includeSecond) addAll(listOf(12,12))
        if (includeThird) addAll(listOf(12,12))
        if (includeFourth) addAll(listOf(12,12))
        addAll(listOf(13,13,13,13,11,13,15,42))
    }
    val cols = widths.mapIndexed { i,width -> """<col min="${i+1}" max="${i+1}" width="$width" customWidth="1"/>""" }.joinToString("")
    val lastCol = colName(headings.size)
    val leftStampEnd = colName((headings.size - 3).coerceAtLeast(1))
    val rightStampStart = colName((headings.size - 2).coerceAtLeast(1))
    val body = rows.mapIndexed { ri,row ->
        val cells = row.mapIndexed { j,v ->
            val style = when {
                ri == 0 -> if (j == headings.size - 3) 5 else 2
                ri == 4 -> 1
                ri in 1..3 -> 6
                j == headings.lastIndex -> 6
                else -> 3
            }
            """<c r="${colName(j+1)}${ri+1}" s="$style" t="inlineStr"><is><t xml:space="preserve">${xmlEscape(v.toPersianDigits())}</t></is></c>"""
        }.joinToString("")
        val height = when(ri) { 0->34; 1,2,3->25; 4->34; else->if(includeNotes) 33 else 23 }
        """<row r="${ri+1}" ht="$height" customHeight="1">$cells</row>"""
    }.joinToString("")
    val mergeItems = mutableListOf(
        "<mergeCell ref=\"A1:${leftStampEnd}1\"/>",
        "<mergeCell ref=\"${rightStampStart}1:${lastCol}1\"/>",
        "<mergeCell ref=\"A2:${lastCol}2\"/>",
        "<mergeCell ref=\"A3:${lastCol}3\"/>",
        "<mergeCell ref=\"A4:${lastCol}4\"/>"
    )
    val merges = mergeItems.joinToString("")
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><sheetViews><sheetView workbookViewId="0" rightToLeft="1"><pane ySplit="5" topLeftCell="A6" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>$cols</cols><sheetData>$body</sheetData><mergeCells count="5">$merges</mergeCells><printOptions horizontalCentered="1"/><pageMargins left="0.17" right="0.17" top="0.28" bottom="0.28" header="0.1" footer="0.1"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="1"/></worksheet>"""
}

fun buildReportPdf(db: WorkDb, year: Int, month: Int, annual: Boolean, includeNotes: Boolean = true, summaryOnly: Boolean = false): ByteArray {
    if (annual && summaryOnly) return buildAnnualSummaryPdf(db,year)
    val createdAt = reportCreatedAt()
    val pdf=android.graphics.pdf.PdfDocument()
    val months=if(annual) (1..12).toList() else listOf(month)
    val pageWidth=842;val pageHeight=595;val left=24f;val right=818f
    val navy=android.graphics.Color.rgb(21,54,93)
    val teal=android.graphics.Color.rgb(0,125,129)
    val gold=android.graphics.Color.rgb(195,150,58)
    val muted=android.graphics.Color.rgb(90,115,141)
    val soft=android.graphics.Color.rgb(239,246,253)
    val white=android.graphics.Color.WHITE
    val p=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    fun rect(canvas:android.graphics.Canvas,l:Float,t:Float,r:Float,b:Float,color:Int,radius:Float=0f) {
        p.color=color;p.style=android.graphics.Paint.Style.FILL
        if(radius>0f) canvas.drawRoundRect(l,t,r,b,radius,radius,p) else canvas.drawRect(l,t,r,b,p)
    }
    fun rtl(canvas:android.graphics.Canvas,value:String,xRight:Float,yTop:Float,width:Int,size:Float,color:Int,bold:Boolean=false,lines:Int=1,center:Boolean=false) {
        val str=value.toPersianDigits()
        val paint=android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textSize=size;this.color=color;typeface=android.graphics.Typeface.create("sans-serif",if(bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        }
        val layout=android.text.StaticLayout.Builder.obtain(str,0,str.length,paint,width.coerceAtLeast(1))
            .setTextDirection(android.text.TextDirectionHeuristics.RTL)
            .setAlignment(if (center) android.text.Layout.Alignment.ALIGN_CENTER else android.text.Layout.Alignment.ALIGN_OPPOSITE)
            .setIncludePad(false).setMaxLines(lines)
            .setEllipsize(android.text.TextUtils.TruncateAt.END).build()
        canvas.save();canvas.translate(xRight-width,yTop);layout.draw(canvas);canvas.restore()
    }
    months.forEachIndexed { index,m ->
        val page=pdf.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth,pageHeight,index+1).create())
        val canvas=page.canvas
        rect(canvas,0f,0f,pageWidth.toFloat(),pageHeight.toFloat(),white)
        rect(canvas,0f,0f,pageWidth.toFloat(),7f,gold)
        rect(canvas,left,18f,right,69f,navy,10f)
        rtl(canvas,"مورخ",right-14,27f,145,16f,white,true)
        rtl(canvas,"گزارش ماهانه ${JalaliMonthNames[m-1]} ${year}",right-178,27f,350,15f,white,true)
        rtl(canvas,"تهیه: $createdAt",left+195,38f,185,9.5f,white,true)
        rtl(canvas,"برگه ${index+1} از ${months.size}",left+148,23f,140,9f,android.graphics.Color.rgb(222,237,249))

        val days=reportPeriodDays(db,year,m,false)
        val includeSecond = hasSecondEntryExit(days)
        val includeThird = hasThirdEntryExit(days)
        val includeFourth = hasFourthEntryExit(days)
        val reportCols = reportHeadings(includeSecond, includeThird, includeFourth)
        val shiftList=reportSessions(db, year, m)
        val (rawEntitledCount,sickCount,_) = periodLeaveStats(days,db)
        val monthDeduction = db.getSettingText("tourahi_deduction_%04d-%02d".format(year, m), "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
        val entitledCount = (rawEntitledCount - monthDeduction).coerceAtLeast(0)
        val travelCount = monthDeduction
        val metrics=listOf(
            "کل کارکرد" to hm(periodWorkedMinutes(db, days, shiftList)),
            "موظفی مقرر" to hm(days.sumOf { requiredMinutes(it,db) }),
            "موظفی ثبتی" to hm(days.sumOf { recordedRequiredMinutes(it,db) }),
            "اضافه‌کاری" to hm(days.sumOf { overtimeMinutes(it,db) }),
            "مرخصی ساعتی" to hm(days.sumOf { hourlyLeaveMinutes(it, db) }),
            "اطلاعات ناقص" to days.count { isIncompleteDay(it,db) }.toString(),
            "جمع مدت فعالیت" to hm(periodSessionMinutes(shiftList)),
            "تعداد فعالیت" to shiftList.size.toString(),
            "استحقاقی" to entitledCount.toString(),
            "استعلاجی" to sickCount.toString(),
            "توراهی" to travelCount.toString(),
            "مأموریت" to days.count { hasDayStatus(it,"مأموریت") }.toString()
        )
        val gap=6f; val metricColumns=6; val tileWidth=(right-left-gap*(metricColumns-1))/metricColumns
        metrics.forEachIndexed { i,metric ->
            val row=i/metricColumns; val col=i%metricColumns
            val l=left+(tileWidth+gap)*col; val top=78f+row*42f
            rect(canvas,l,top,l+tileWidth,top+37f,soft,6f)
            rtl(canvas,metric.first,l+tileWidth-6,top+4f,(tileWidth-12).toInt(),9f,muted)
            rtl(canvas,metric.second,l+tileWidth-6,top+20f,(tileWidth-12).toInt(),12.5f,if(i==2)teal else navy,true)
        }
        // A4 landscape: explicit entry/exit columns for each of the four intervals.
        // Widths sum to 794pt; every column has its own visible border.
        val rawWidths = buildList {
            addAll(listOf(42f,56f,68f,35f,35f))
            if (includeSecond) addAll(listOf(35f,35f))
            if (includeThird) addAll(listOf(32f,32f))
            if (includeFourth) addAll(listOf(32f,32f))
            addAll(listOf(32f,32f,32f,35f,25f,31f,33f,85f))
        }
        val widthScale=(right-left)/rawWidths.sum()
        val widths=rawWidths.map { it*widthScale }
        val headers=reportCols.map { if (!includeNotes && it == "یادداشت") "بدون یادداشت" else it }
        val tableTop=166f;val headerHeight=23f;val rowHeight=11.5f
        rect(canvas,left,tableTop,right,tableTop+headerHeight,navy,5f)
        var x=right
        headers.forEachIndexed { i,heading ->
            rtl(canvas,heading,x-3.5f,tableTop+6f,(widths[i]-7).toInt(),
                if(i >= headers.size - 2) 8f else 7.1f,white,true,1,true)
            x-=widths[i]
            if(i < headers.lastIndex) rect(canvas,x-0.45f,tableTop,x+0.45f,tableTop+headerHeight,android.graphics.Color.rgb(183,207,231))
        }
        days.forEachIndexed { i,d ->
            val top=tableTop+headerHeight+i*rowHeight
            val highlight=jalaliWeekday(d.date)==5 || dayStatuses(d).any { it in workHolidayStatuses }
            val color=when {highlight -> android.graphics.Color.rgb(255,239,239);i%2==0 -> android.graphics.Color.rgb(248,251,255);else -> white}
            rect(canvas,left,top,right,top+rowHeight,color)
            x=right
            val weekName=jalaliWeekday(d.date)?.let { JalaliWeekdayNames.getOrNull(it) }.orEmpty()
            val cellValues=listOf(weekName,d.date.replace('-', '/'),reportDayStatusText(d,db))+
                dayEntryExitColumns(d, includeSecond, includeThird, includeFourth)+
                listOf(hm(dayReportedWorkMinutes(d, db)),hm(requiredMinutes(d,db)),hm(recordedRequiredMinutes(d,db)),hm(overtimeMinutes(d,db)),
                    sessionsStartingOnDate(db, d.date).size.toString(),
                    hm(sessionMinutesStartingOnDate(db, d.date)).takeIf { it != "00:00" } ?: "—",
                    hm(hourlyLeaveMinutes(d, db)),if (includeNotes) reportNoteWithHolidayReason(d, db) else "")
            cellValues.forEachIndexed { j,value ->
                val noteCell = j == cellValues.lastIndex
                rtl(canvas,value,x-3.5f,top+0.6f,(widths[j]-7).toInt(),
                    if(noteCell) 5.7f else if(j==2) 6.2f else 7.2f,
                    if(highlight && (j==0 || j==1)) android.graphics.Color.rgb(170,41,45) else navy,
                    j==0 || j==1,if(noteCell && includeNotes) 2 else 1,true)
                x-=widths[j]
                if(j < cellValues.lastIndex) rect(canvas,x-0.35f,top,x+0.35f,top+rowHeight,android.graphics.Color.rgb(210,225,240))
            }
            rect(canvas,left,top+rowHeight-0.4f,right,top+rowHeight,android.graphics.Color.rgb(210,225,240))
        }
        val footerY=tableTop+headerHeight+days.size*rowHeight+12f
        rtl(canvas,"حالت روز با «ث» (ثابت) یا «ش» (شناور) مشخص است؛ اطلاعات ناقص تا تکمیل در جمع قطعی محاسبه نمی‌شود.",right,footerY,(right-left).toInt(),9f,muted)
        rect(canvas,left,footerY+20,right,footerY+22,gold)
        pdf.finishPage(page)
    }
    val out=java.io.ByteArrayOutputStream();pdf.writeTo(out);pdf.close();return out.toByteArray()
}

/** One A4 landscape page: year totals above an independently bordered 12-month matrix. */
private fun buildAnnualSummaryPdf(db: WorkDb, year: Int): ByteArray {
    val document = android.graphics.pdf.PdfDocument()
    val width = 842; val height = 595 // A4 landscape at 72 dpi.
    val page = document.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(width,height,1).create())
    val c = page.canvas
    val navy = android.graphics.Color.rgb(21,54,93)
    val blue = android.graphics.Color.rgb(36,90,141)
    val teal = android.graphics.Color.rgb(0,118,114)
    val gold = android.graphics.Color.rgb(208,165,75)
    val grey = android.graphics.Color.rgb(100,121,145)
    val pale = android.graphics.Color.rgb(239,247,253)
    val line = android.graphics.Color.rgb(192,213,235)
    val white = android.graphics.Color.WHITE
    val brush = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    fun fill(l: Float,t:Float,r:Float,b:Float,color:Int) {
        brush.color=color; brush.style=android.graphics.Paint.Style.FILL
        c.drawRect(l,t,r,b,brush)
    }
    fun cell(l:Float,t:Float,r:Float,b:Float,color:Int,border:Int=line) {
        fill(l,t,r,b,color)
        brush.color=border; brush.style=android.graphics.Paint.Style.STROKE; brush.strokeWidth=0.8f
        c.drawRect(l,t,r,b,brush); brush.style=android.graphics.Paint.Style.FILL
    }
    fun label(value:String,xRight:Float,top:Float,maxWidth:Int,fontSize:Float=9f,
              ink:Int=navy,bold:Boolean=false,maxLines:Int=1,center:Boolean=false) {
        val rendered=value.toPersianDigits()
        val tp=android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textSize=fontSize; color=ink
            typeface=android.graphics.Typeface.create("sans-serif",if(bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        }
        val layout=android.text.StaticLayout.Builder.obtain(rendered,0,rendered.length,tp,maxWidth.coerceAtLeast(1))
            .setTextDirection(android.text.TextDirectionHeuristics.RTL)
            .setAlignment(if (center) android.text.Layout.Alignment.ALIGN_CENTER else android.text.Layout.Alignment.ALIGN_OPPOSITE)
            .setIncludePad(false).setMaxLines(maxLines)
            .setEllipsize(android.text.TextUtils.TruncateAt.END).build()
        c.save();c.translate(xRight-maxWidth,top);layout.draw(c);c.restore()
    }
    val left=24f; val right=818f
    fill(0f,0f,842f,7f,gold)
    cell(left,18f,right,75f,navy,navy)
    label("مورخ",right-15,26f,135,18f,white,true)
    label("خلاصهٔ جامع عملکرد سال ${year.toString().toPersianDigits()}",right-162,27f,380,15f,white,true)
    label("تهیه: ${reportCreatedAt()}",left+206,43f,198,10f,white,true)
    val perMonth=(1..12).map { annualMonthStats(db,year,it) }
    val total=perMonth.fold(AnnualReportStats()) { acc,item -> acc+item }
    val headline=listOf(
        "کل کارکرد" to hm(total.workedMinutes),
        "موظفی مقرر" to hm(total.requiredMinutes),
        "موظفی ثبتی" to hm(total.recordedRequiredMinutes),
        "اضافه‌کاری" to hm(total.overtimeMinutes),
        "جمع مدت فعالیت" to hm(total.shiftMinutes),
        "تعداد فعالیت" to total.shifts.toString(),
        "مرخصی ساعتی" to hm(total.hourlyLeave),
        "استحقاقی" to total.entitled.toString(),
        "استعلاجی" to total.sick.toString(),
        "مأموریت" to total.missions.toString(),
        "توراهی" to total.travel.toString(),
        "روز ناقص" to total.incompleteDays.toString()
    )
    val cardGap=6f; val cardW=(right-left-4*cardGap)/5f
    headline.forEachIndexed { i,metric ->
        val row=i/5;val col=i%5
        val x=left+col*(cardW+cardGap)
        val y=82f+row*43f
        cell(x,y,x+cardW,y+38f,if(row==0) pale else android.graphics.Color.rgb(246,250,254))
        label(metric.first,x+cardW-7f,y+4f,(cardW-14f).toInt(),9.5f,grey)
        label(metric.second,x+cardW-7f,y+20f,(cardW-14f).toInt(),12.5f,if(i==3) teal else blue,true)
    }
    label("خلاصهٔ ماه‌به‌ماه • ساعت‌ها به صورت ساعت:دقیقه، سایر ستون‌ها تعداد",right,213f,680,10f,navy,true)
    val rawColumns=listOf(64f,56f,55f,55f,53f,50f,48f,48f,48f,44f,52f,55f,52f,52f,42f)
    val columnScale=(right-left)/rawColumns.sum()
    val columns=rawColumns.map { it*columnScale }
    val headerTop=232f; val headerH=31f; val rowH=19f
    var edge=right
    annualReportHeadings.forEachIndexed { index,title ->
        val w=columns[index]
        cell(edge-w,headerTop,edge,headerTop+headerH,navy,android.graphics.Color.rgb(105,148,186))
        label(title,edge-3f,headerTop+8f,(w-6).toInt(),7.8f,white,true,2,true)
        edge-=w
    }
    val allRows=listOf("کل سال" to total)+ (1..12).map { JalaliMonthNames[it-1] to perMonth[it-1] }
    allRows.forEachIndexed { i,(monthName,stats) ->
        val y=headerTop+headerH+rowH*i
        edge=right
        val values=listOf(monthName)+stats.values()
        values.forEachIndexed { j,value ->
            val w=columns[j]
            val bg=when { i==0 -> android.graphics.Color.rgb(222,240,247)
                i%2==0 -> android.graphics.Color.rgb(246,250,254)
                else -> white }
            cell(edge-w,y,edge,y+rowH,bg)
            label(value,edge-3.4f,y+5f,(w-6).toInt(),if(j==0) 9.1f else 8.8f,
                if(i==0) navy else if(j==2) teal else blue, i==0 || j==0,1,true)
            edge-=w
        }
    }
    val footer=headerTop+headerH+rowH*allRows.size+12f
    label("مبنای موظفی: روزهای کاری طبق حالت ثبت‌شده • فعالیت‌ها بر اساس ماه شروع • اطلاعات ناقص در جمع قطعی کارکرد وارد نمی‌شوند",right,footer,(right-left).toInt(),9.0f,grey)
    fill(left,footer+20f,right,footer+22f,gold)
    document.finishPage(page)
    val bytes=java.io.ByteArrayOutputStream()
    document.writeTo(bytes);document.close()
    return bytes.toByteArray()
}

private fun xmlEscape(v: String): String = v.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;")
private fun colName(n: Int): String {
    var x=n; var out=""
    while(x>0){ val r=(x-1)%26; out=(('A'.code+r).toChar())+out; x=(x-1)/26 }
    return out
}
private fun reportStylesXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="4">
<font><sz val="10"/><name val="Arial"/><family val="2"/></font>
<font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Arial"/></font>
<font><b/><sz val="14"/><color rgb="FF15365D"/><name val="Arial"/></font>
<font><b/><sz val="10"/><color rgb="FF15365D"/><name val="Arial"/></font>
</fonts>
<fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF28588A"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFE5F4FB"/><bgColor indexed="64"/></patternFill></fill></fills>
<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>
<border><left style="thin"><color rgb="FFB7CCE0"/></left><right style="thin"><color rgb="FFB7CCE0"/></right><top style="thin"><color rgb="FFB7CCE0"/></top><bottom style="thin"><color rgb="FFB7CCE0"/></bottom><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="7">
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" applyBorder="1"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="1" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="2" fillId="0" borderId="1" applyFont="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="3" fillId="3" borderId="1" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>"""
private fun sheetXml(rows: List<List<String>>): String {
    val maxCols = rows.maxOfOrNull { it.size } ?: 1
    val cols = (1..maxCols).joinToString("") { i ->
        val width = when { i == 1 -> 17; i == 2 -> 18; i == 3 -> 30; else -> 15 }
        "<col min=\"$i\" max=\"$i\" width=\"$width\" customWidth=\"1\"/>"
    }
    val body = rows.mapIndexed { ri,row ->
        val cells = row.mapIndexed { ci,value ->
            val ref = colName(ci+1)+(ri+1)
            val style = if (ri == 0) 1 else if (ci == 0 && ri < 4) 2 else 3
            "<c r=\"$ref\" s=\"$style\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${xmlEscape(value.toPersianDigits())}</t></is></c>"
        }.joinToString("")
        "<row r=\"${ri+1}\" ht=\"${if (ri==0) 30 else 24}\" customHeight=\"1\">$cells</row>"
    }.joinToString("")
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0" rightToLeft="1"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>$cols</cols><sheetData>$body</sheetData><pageMargins left="0.25" right="0.25" top="0.45" bottom="0.45" header="0.2" footer="0.2"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/><printOptions horizontalCentered="1"/><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr></worksheet>"""
}

private val reminderBackupHeaders = listOf("id", "kind", "title", "whenMillis", "monthly", "soundUri", "enabled")

private fun buildReminderBackupCsv(reminders: List<PersonalReminder>): String = buildString {
    append("#REMINDERS\r\n")
    append(reminderBackupHeaders.joinToString(",") { csvEscape(it) }).append("\r\n")
    reminders.forEach { r ->
        append(listOf(r.id.toString(), r.kind, r.title, r.whenMillis.toString(), r.monthly.toString(), r.soundUri, r.enabled.toString()).joinToString(",") { csvEscape(it) }).append("\r\n")
    }
}

private fun reminderRowsToRecords(rows: List<List<String>>): List<PersonalReminder> {
    require(rows.isNotEmpty() && rows.first().map { it.trim() }.containsAll(reminderBackupHeaders)) {
        "ساختار فایل پشتیبان یادآورها معتبر نیست"
    }
    val header = rows.first().map { it.trim() }
    val ix = reminderBackupHeaders.associateWith { header.indexOf(it) }
    return rows.drop(1).filter { row -> row.any { cell -> cell.isNotBlank() } }.map { row ->
        fun cell(name: String): String = row.getOrElse(ix[name] ?: -1) { "" }.trim()
        val id = cell("id").toLongOrNull() ?: 0L
        val millis = cell("whenMillis").toLongOrNull() ?: throw IllegalArgumentException("زمان یکی از یادآورها معتبر نیست")
        val kind = cell("kind").ifBlank { "قسط" }
        val title = cell("title")
        require(title.isNotBlank()) { "عنوان یکی از یادآورها خالی است" }
        PersonalReminder(id, kind, title, millis, cell("monthly").equals("true", true) || cell("monthly") == "1", cell("soundUri"), !cell("enabled").equals("false", true) && cell("enabled") != "0")
    }
}

private fun readReminderBackupCsv(text: String): List<PersonalReminder> {
    val rows = parseCsvRows(text)
    val marker = rows.indexOfFirst { it.firstOrNull()?.trim() == "#REMINDERS" }
    require(marker >= 0 && marker + 1 < rows.size) { "این فایل، پشتیبان یادآورهای مورخ نیست" }
    val table = rows.drop(marker + 1).filter { it.isNotEmpty() }
    return reminderRowsToRecords(table)
}

private fun simpleXlsxSheetXml(rows: List<List<String>>): String {
    val body = rows.mapIndexed { ri, row ->
        val cells = row.mapIndexed { ci, value ->
            "<c r=\"${colName(ci + 1)}${ri + 1}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${xmlEscape(value)}</t></is></c>"
        }.joinToString("")
        "<row r=\"${ri + 1}\">$cells</row>"
    }.joinToString("")
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0" rightToLeft="1"/></sheetViews><sheetData>$body</sheetData></worksheet>"""
}

private fun buildReminderBackupXlsx(reminders: List<PersonalReminder>): ByteArray {
    val rows = mutableListOf(reminderBackupHeaders)
    reminders.forEach { r -> rows.add(listOf(r.id.toString(), r.kind, r.title, r.whenMillis.toString(), r.monthly.toString(), r.soundUri, r.enabled.toString())) }
    val entries = linkedMapOf(
        "[Content_Types].xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""",
        "_rels/.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""",
        "xl/workbook.xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Reminders" sheetId="1" r:id="rId1"/></sheets></workbook>""",
        "xl/_rels/workbook.xml.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""",
        "xl/worksheets/sheet1.xml" to simpleXlsxSheetXml(rows)
    )
    val output = java.io.ByteArrayOutputStream()
    java.util.zip.ZipOutputStream(output).use { zip -> entries.forEach { (name, content) ->
        zip.putNextEntry(java.util.zip.ZipEntry(name)); zip.write(content.toByteArray(Charsets.UTF_8)); zip.closeEntry()
    } }
    return output.toByteArray()
}

private fun readReminderBackupXlsx(bytes: ByteArray): List<PersonalReminder> {
    val entries = mutableMapOf<String, ByteArray>()
    java.util.zip.ZipInputStream(bytes.inputStream()).use { zip ->
        while (true) { val entry = zip.nextEntry ?: break
            if (entry.name == "xl/worksheets/sheet1.xml" || entry.name == "xl/sharedStrings.xml") entries[entry.name] = zip.readBytes()
            zip.closeEntry()
        }
    }
    val shared = mutableListOf<String>()
    entries["xl/sharedStrings.xml"]?.let { bytesShared ->
        val parser = android.util.Xml.newPullParser(); parser.setInput(bytesShared.inputStream(), "UTF-8")
        var inItem = false; var inText = false; var item = StringBuilder(); var event = parser.eventType
        while (event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
            when (event) {
                org.xmlpull.v1.XmlPullParser.START_TAG -> when (parser.name) { "si" -> { inItem = true; item = StringBuilder() }; "t" -> if (inItem) inText = true }
                org.xmlpull.v1.XmlPullParser.TEXT -> if (inItem && inText) item.append(parser.text)
                org.xmlpull.v1.XmlPullParser.END_TAG -> when (parser.name) { "t" -> inText = false; "si" -> { shared.add(item.toString()); inItem = false } }
            }; event = parser.next()
        }
    }
    val sheet = entries["xl/worksheets/sheet1.xml"] ?: throw IllegalArgumentException("برگهٔ Excel پیدا نشد")
    val parser = android.util.Xml.newPullParser(); parser.setInput(sheet.inputStream(), "UTF-8")
    val rows = mutableListOf<List<String>>(); var row: MutableList<String>? = null
    var cell = StringBuilder(); var inCell = false; var cellType = ""; var cellRef = ""; var event = parser.eventType
    while (event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
        when (event) {
            org.xmlpull.v1.XmlPullParser.START_TAG -> when (parser.name) {
                "row" -> row = mutableListOf()
                "c" -> { inCell = true; cell = StringBuilder(); cellType = parser.getAttributeValue(null, "t") ?: ""; cellRef = parser.getAttributeValue(null, "r") ?: "" }
            }
            org.xmlpull.v1.XmlPullParser.TEXT -> if (inCell) cell.append(parser.text)
            org.xmlpull.v1.XmlPullParser.END_TAG -> when (parser.name) {
                "c" -> {
                    val raw = cell.toString(); val value = if (cellType == "s") shared.getOrNull(raw.toIntOrNull() ?: -1).orEmpty() else raw
                    val col = Regex("[A-Z]+").find(cellRef)?.value?.fold(0) { acc, ch -> acc * 26 + ch.code - 'A'.code + 1 }?.minus(1) ?: (row?.size ?: 0)
                    row?.let { while (it.size <= col) it.add(""); it[col] = value }; inCell = false
                }
                "row" -> { row?.let { rows.add(it) }; row = null }
            }
        }; event = parser.next()
    }
    return reminderRowsToRecords(rows)
}

private fun buildRemindersPdf(reminders: List<PersonalReminder>): ByteArray {
    val document = android.graphics.pdf.PdfDocument()
    val pageWidth = 595; val pageHeight = 842
    val margin = 30f; val right = pageWidth - margin; val contentWidth = (pageWidth - margin * 2).toInt()
    val navy = android.graphics.Color.rgb(21, 54, 93)
    val blue = android.graphics.Color.rgb(36, 90, 141)
    val teal = android.graphics.Color.rgb(0, 125, 129)
    val gold = android.graphics.Color.rgb(195, 150, 58)
    val ink = android.graphics.Color.rgb(40, 58, 79)
    val muted = android.graphics.Color.rgb(94, 115, 137)
    val pale = android.graphics.Color.rgb(239, 246, 253)
    val line = android.graphics.Color.rgb(214, 226, 239)
    val white = android.graphics.Color.WHITE
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    fun fill(c: android.graphics.Canvas, l: Float, t: Float, r: Float, b: Float, color: Int, radius: Float = 0f) {
        p.color = color; p.style = android.graphics.Paint.Style.FILL
        if (radius > 0f) c.drawRoundRect(l, t, r, b, radius, radius, p) else c.drawRect(l, t, r, b, p)
    }
    fun text(c: android.graphics.Canvas, value: String, xRight: Float, top: Float, width: Int, size: Float, color: Int = ink, bold: Boolean = false, maxLines: Int = 1, center: Boolean = false): Int {
        val rendered = value.toPersianDigits()
        val tp = android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size; this.color = color
            typeface = android.graphics.Typeface.create("sans-serif", if (bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        }
        val layout = android.text.StaticLayout.Builder.obtain(rendered, 0, rendered.length, tp, width.coerceAtLeast(1))
            .setTextDirection(android.text.TextDirectionHeuristics.RTL)
            .setAlignment(if (center) android.text.Layout.Alignment.ALIGN_CENTER else android.text.Layout.Alignment.ALIGN_OPPOSITE)
            .setIncludePad(false).setMaxLines(maxLines).setEllipsize(android.text.TextUtils.TruncateAt.END).build()
        c.save(); c.translate(xRight - width, top); layout.draw(c); c.restore()
        return layout.height
    }
    val sorted = reminders.sortedBy { it.whenMillis }
    val activeCount = sorted.count { it.enabled }
    val recurringCount = sorted.count { it.monthly }
    var pageNumber = 0
    var page: android.graphics.pdf.PdfDocument.Page? = null
    var canvas: android.graphics.Canvas? = null
    var y = 0f
    fun startPage() {
        pageNumber++
        page = document.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
        canvas = page!!.canvas
        val c = canvas!!
        fill(c, 0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), white)
        fill(c, 0f, 0f, pageWidth.toFloat(), 8f, gold)
        fill(c, margin, 22f, right, 102f, navy, 12f)
        text(c, "مورخ", right - 14f, 33f, 95, 18f, white, true)
        text(c, "یادآورهای اقساط و جلسات", right - 14f, 60f, 320, 17f, white, true)
        text(c, "فهرست یادآوری‌های ثبت‌شده", right - 14f, 83f, 320, 9f, android.graphics.Color.rgb(218, 232, 246))
        fill(c, margin, 113f, right, 158f, pale, 8f)
        val tileGap = 8f; val tileW = (contentWidth - tileGap * 2) / 3f
        val stats = listOf(Triple("مجموع یادآورها", sorted.size.toString(), navy), Triple("فعال", activeCount.toString(), teal), Triple("تکرار ماهانه", recurringCount.toString(), blue))
        stats.forEachIndexed { i, stat ->
            val l = margin + i * (tileW + tileGap)
            fill(c, l, 113f, l + tileW, 158f, white, 6f)
            text(c, stat.first, l + tileW - 7f, 120f, (tileW - 14f).toInt(), 8.5f, muted, false, 1, true)
            text(c, stat.second, l + tileW - 7f, 137f, (tileW - 14f).toInt(), 14f, stat.third, true, 1, true)
        }
        y = 174f
    }
    fun finishPage() {
        val c = canvas
        if (c != null) {
            p.color = line; p.strokeWidth = 0.7f; p.style = android.graphics.Paint.Style.STROKE
            c.drawLine(margin, pageHeight - 30f, right, pageHeight - 30f, p); p.style = android.graphics.Paint.Style.FILL
            text(c, "مورخ  •  خروجی یادآورها", right, pageHeight - 23f, 260, 8f, muted)
            text(c, "صفحه $pageNumber", margin + 90f, pageHeight - 23f, 90, 8f, muted)
        }
        page?.let { document.finishPage(it) }; page = null; canvas = null
    }
    startPage()
    if (sorted.isEmpty()) {
        fill(canvas!!, margin, y, right, y + 92f, pale, 10f)
        text(canvas!!, "هنوز یادآوری ثبت نشده است.", right - 14f, y + 29f, contentWidth - 28, 14f, navy, true, 2, true)
    } else sorted.forEachIndexed { index, reminder ->
        val dt = java.time.Instant.ofEpochMilli(reminder.whenMillis).atZone(java.time.ZoneId.systemDefault())
        val (jy, jm, jd) = gregorianToJalali(dt.toLocalDate())
        val date = "%04d/%02d/%02d".format(jy, jm, jd)
        val time = dt.toLocalTime().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"))
        val title = reminder.title.ifBlank { "بدون عنوان" }
        val titlePaint = android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 12.5f; color = ink; typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
        }
        val titleLayout = android.text.StaticLayout.Builder.obtain(title, 0, title.length, titlePaint, contentWidth - 100)
            .setTextDirection(android.text.TextDirectionHeuristics.RTL).setAlignment(android.text.Layout.Alignment.ALIGN_OPPOSITE)
            .setIncludePad(false).setMaxLines(2).setEllipsize(android.text.TextUtils.TruncateAt.END).build()
        val cardHeight = maxOf(76f, 48f + titleLayout.height)
        if (y + cardHeight > pageHeight - 46f) { finishPage(); startPage() }
        val c = canvas!!
        fill(c, margin, y, right, y + cardHeight, if (index % 2 == 0) pale else white, 8f)
        fill(c, right - 4f, y + 8f, right, y + cardHeight - 8f, if (reminder.enabled) teal else muted, 2f)
        val badgeColor = if (reminder.kind.contains("قسط")) blue else teal
        fill(c, margin + 10f, y + 11f, margin + 88f, y + 32f, badgeColor, 6f)
        text(c, reminder.kind, margin + 82f, y + 17f, 64, 8.5f, white, true, 1, true)
        text(c, title, right - 14f, y + 12f, contentWidth - 115, 12.5f, ink, true, 2)
        val flags = listOf(if (reminder.monthly) "تکرار ماهانه" else "یک‌بار", if (reminder.enabled) "فعال" else "غیرفعال").joinToString("  •  ")
        text(c, flags, right - 14f, y + 19f + titleLayout.height, contentWidth - 28, 8.5f, if (reminder.enabled) teal else muted)
        val detailsY = y + cardHeight - 22f
        text(c, "تاریخ: $date", right - 14f, detailsY, 170, 9f, muted)
        text(c, "ساعت: $time", margin + 190f, detailsY, 105, 9f, muted)
        y += cardHeight + 8f
    }
    finishPage()
    val output = java.io.ByteArrayOutputStream()
    document.writeTo(output); document.close()
    return output.toByteArray()
}
private fun readBackupXlsx(bytes: ByteArray): Pair<List<WorkDay>,List<Pair<String,String>>> {
    val entries = mutableMapOf<String,ByteArray>()
    java.util.zip.ZipInputStream(bytes.inputStream()).use { zip ->
        while(true) {
            val e = zip.nextEntry ?: break
            if (e.name == "xl/worksheets/sheet1.xml" || e.name == "xl/worksheets/sheet2.xml" || e.name == "xl/sharedStrings.xml") entries[e.name] = zip.readBytes()
            zip.closeEntry()
        }
    }
    fun parseXml(xmlBytes: ByteArray?): List<List<String>> {
        if(xmlBytes == null) return emptyList()
        val parser = android.util.Xml.newPullParser()
        parser.setInput(xmlBytes.inputStream(), "UTF-8")
        val rows = mutableListOf<List<String>>()
        var row: MutableList<String>? = null
        var cell = StringBuilder()
        var inCell = false
        var event = parser.eventType
        while(event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
            when(event) {
                org.xmlpull.v1.XmlPullParser.START_TAG -> when(parser.name) {
                    "row" -> row = mutableListOf()
                    "c" -> { inCell = true; cell = StringBuilder() }
                    "t", "v" -> Unit
                }
                org.xmlpull.v1.XmlPullParser.TEXT -> if(inCell) cell.append(parser.text)
                org.xmlpull.v1.XmlPullParser.END_TAG -> when(parser.name) {
                    "c" -> { row?.add(cell.toString()); inCell = false }
                    "row" -> { row?.let { rows.add(it) }; row = null }
                }
            }
            event = parser.next()
        }
        return rows
    }
    val sharedStrings = mutableListOf<String>()
    entries["xl/sharedStrings.xml"]?.let { sharedBytes ->
        val sp = android.util.Xml.newPullParser(); sp.setInput(sharedBytes.inputStream(), "UTF-8")
        var insideItem = false; var insideText = false; var item = StringBuilder(); var ev = sp.eventType
        while (ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
            when (ev) {
                org.xmlpull.v1.XmlPullParser.START_TAG -> when (sp.name) {
                    "si" -> { insideItem = true; item = StringBuilder() }
                    "t" -> if (insideItem) insideText = true
                }
                org.xmlpull.v1.XmlPullParser.TEXT -> if (insideItem && insideText) item.append(sp.text)
                org.xmlpull.v1.XmlPullParser.END_TAG -> when (sp.name) {
                    "t" -> insideText = false
                    "si" -> { sharedStrings.add(item.toString()); insideItem = false }
                }
            }
            ev = sp.next()
        }
    }
    fun parseSheet(xmlBytes: ByteArray?): List<List<String>> {
        if (xmlBytes == null) return emptyList()
        val parser = android.util.Xml.newPullParser(); parser.setInput(xmlBytes.inputStream(), "UTF-8")
        val rows = mutableListOf<List<String>>(); var row: MutableList<String>? = null
        var cellValue = StringBuilder(); var inCell = false; var cellType = ""; var cellRef = ""
        var event = parser.eventType
        while(event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
            when(event) {
                org.xmlpull.v1.XmlPullParser.START_TAG -> when(parser.name) {
                    "row" -> row = mutableListOf()
                    "c" -> { inCell = true; cellValue = StringBuilder(); cellType = parser.getAttributeValue(null,"t") ?: ""; cellRef = parser.getAttributeValue(null,"r") ?: "" }
                }
                org.xmlpull.v1.XmlPullParser.TEXT -> if(inCell) cellValue.append(parser.text)
                org.xmlpull.v1.XmlPullParser.END_TAG -> when(parser.name) {
                    "c" -> {
                        val value = cellValue.toString()
                        val resolved = if (cellType == "s") sharedStrings.getOrNull(value.toIntOrNull() ?: -1).orEmpty() else value
                        val col = Regex("[A-Z]+").find(cellRef)?.value?.let { name -> name.fold(0) { acc,ch -> acc*26 + ch.code-'A'.code+1 }-1 } ?: (row?.size ?: 0)
                        row?.let { r -> while(r.size <= col) r.add(""); r[col] = resolved }
                        inCell = false
                    }
                    "row" -> { row?.let { rows.add(it) }; row = null }
                }
            }
            event = parser.next()
        }
        return rows
    }
    val workRows = parseSheet(entries["xl/worksheets/sheet1.xml"])
    val settingsRows = parseSheet(entries["xl/worksheets/sheet2.xml"])
    require(workRows.isNotEmpty() && workRows.first().firstOrNull()?.trim() == "date") { "ساختار فایل Excel معتبر نیست؛ از فایل پشتیبان کامل استفاده کن" }
    return workRowsToBackup(workRows, settingsRows)
}

private fun workRowsToBackup(workRows: List<List<String>>, settingsRows: List<List<String>>): Pair<List<WorkDay>,List<Pair<String,String>>> {
    val days = workRows.drop(1).map { row -> row.map { it.toLatinDigits().trim() } }
        .filter { it.size >= 11 && it[0].replace('/', '-').matches(Regex("\\d{4}-\\d{1,2}-\\d{1,2}")) }.map { r ->
        val dateParts = r[0].replace('/', '-').split('-')
        val normalizedDate = if (dateParts.size == 3) "%04d-%02d-%02d".format(dateParts[0].toInt(),dateParts[1].toInt(),dateParts[2].toInt()) else r[0]
        WorkDay(normalizedDate,r.getOrElse(2){""},r.getOrElse(3){""},r.getOrElse(4){""},r.getOrElse(5){""},r.getOrElse(6){""},r.getOrElse(7){""},r.getOrElse(10){""},r.getOrElse(1){"کاری"}.ifBlank{"کاری"},r.getOrElse(9){""},r.getOrNull(11)?.toBoolean() ?: false,r.getOrElse(12){""},r.getOrElse(13){""},r.getOrElse(14){""},r.getOrElse(15){""},r.getOrElse(16){""},r.getOrElse(17){""},r.getOrElse(18){""},r.getOrElse(19){""},r.getOrElse(20){""},r.getOrElse(21){""},r.getOrNull(22)?.toBoolean() ?: listOf(18,19,20,21).any { !r.getOrNull(it).isNullOrBlank() },r.getOrElse(23){""},r.getOrElse(24){""},r.getOrElse(25){""},r.getOrElse(26){""},r.getOrElse(27){""},r.getOrElse(28){""},r.getOrElse(29){""},r.getOrNull(30)?.let { it == "true" || it == "1" } ?: true)
    }
    val settings = settingsRows.drop(1).filter { it.size >= 2 && it[0].isNotBlank() }.map { it[0] to it[1] }
    require(days.isNotEmpty() || settings.isNotEmpty()) { "هیچ ردیف معتبری در فایل وجود ندارد" }
    return days to settings
}

private fun csvEscape(value: String): String = if (value.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) "\"${value.replace("\"", "\"\"")}\"" else value
private fun buildBackupCsv(db: WorkDb): String {
    val out = StringBuilder()
    val headers = listOf("date","dayType","in1","out1","in2","out2","in3","out3","duration","overtimeOverride","note","shiftEnabled","shiftStart","shiftEnd","shiftStartDate","shiftEndDate","holidayIn","holidayOut","leave1Start","leave1End","leave2Start","leave2End","hourlyLeaveEnabled","extraDayTypes","in4","out4","leave3Start","leave3End","leave4Start","leave4End","fixedHoursMode")
    out.append("#WORKDAYS\r\n").append(headers.joinToString(",") { csvEscape(it) }).append("\r\n")
    db.allDaysForBackup().forEach { d ->
        val values = listOf(d.date,d.dayType,d.in1,d.out1,d.in2,d.out2,d.in3,d.out3,hm(duration(d, db)),d.overtimeOverride,d.note,d.shiftEnabled.toString(),d.shiftStart,d.shiftEnd,d.shiftStartDate,d.shiftEndDate,d.holidayIn,d.holidayOut,d.leave1Start,d.leave1End,d.leave2Start,d.leave2End,d.hourlyLeaveEnabled.toString(),d.extraDayTypes,d.in4,d.out4,d.leave3Start,d.leave3End,d.leave4Start,d.leave4End,d.fixedHoursMode.toString())
        out.append(values.joinToString(",") { csvEscape(it) }).append("\r\n")
    }
    out.append("#SETTINGS\r\nkey,value\r\n")
    db.allSettings().forEach { (k,v) -> out.append(csvEscape(k)).append(',').append(csvEscape(v)).append("\r\n") }
    return out.toString()
}
private fun parseCsvRows(text: String): List<List<String>> {
    val rows = mutableListOf<List<String>>(); var row = mutableListOf<String>(); val field = StringBuilder(); var quoted = false; var i = 0
    while (i < text.length) {
        val ch = text[i]
        if (quoted) {
            if (ch == '"' && i+1 < text.length && text[i+1] == '"') { field.append('"'); i++ }
            else if (ch == '"') quoted = false else field.append(ch)
        } else when(ch) {
            '"' -> quoted = true
            ',' -> { row.add(field.toString()); field.setLength(0) }
            '\n' -> { row.add(field.toString().removeSuffix("\r")); field.setLength(0); rows.add(row); row = mutableListOf() }
            else -> field.append(ch)
        }
        i++
    }
    if (field.isNotEmpty() || row.isNotEmpty()) { row.add(field.toString().removeSuffix("\r")); rows.add(row) }
    return rows
}
private fun readBackupCsv(text: String): Pair<List<WorkDay>,List<Pair<String,String>>> {
    val rows = parseCsvRows(text); val wi = rows.indexOfFirst { it.firstOrNull()?.trim() == "#WORKDAYS" }; val si = rows.indexOfFirst { it.firstOrNull()?.trim() == "#SETTINGS" }
    require(wi >= 0) { "فایل CSV پشتیبان مورخ نیست یا سرستون‌ها پیدا نشدند" }
    val workEnd = if (si > wi) si else rows.size
    val workRows = rows.subList(wi+1, workEnd).filter { it.isNotEmpty() }
    val settingsRows = if (si >= 0) rows.drop(si+1).filter { it.isNotEmpty() } else emptyList()
    return workRowsToBackup(workRows, settingsRows)
}

@Composable
private fun HelpScreen(modifier: Modifier = Modifier) {
    val sections = listOf(
        "۱. آشنایی با برنامه و نوار پایین" to
            "مورخ سه بخش اصلی مدیریت کارکرد دارد: «روز» برای انتخاب تاریخ و ثبت فعالیت روزانه، «ماه» برای مشاهده و بررسی روزهای یک ماه، و «سال» برای دیدن کارت‌های دوازده ماه و جمع سالانه. این سه بخش فقط اطلاعات کارکرد را مدیریت می‌کنند. «تقویم» منبع نمایش تاریخ‌ها، تعطیلات رسمی و مناسبت‌هاست و تغییرات کارکرد نباید اطلاعات اصلی تقویم را تغییر دهد. گزینه‌های «یادآورها»، «اوقات شرعی و اذان‌گو»، «تنظیمات» و «راهنما» امکانات جداگانه‌اند.",
        "۲. صفحهٔ «روز» — انتخاب تاریخ و کارت تاریخ" to
            "در بالای صفحه تاریخ انتخاب‌شده در چهار خط دیده می‌شود: نام روز هفته، تاریخ شمسی، تاریخ قمری و تاریخ میلادی. با لمس تاریخ قمری یا میلادی، شکل نوشتاری و عددی آن تغییر می‌کند. در سمت دیگر همان کارت، مناسبت‌های تقویم نمایش داده می‌شوند؛ برای روزهای دارای تعطیلی رسمی رنگ هشدار متفاوت است. این مناسبت‌ها از داده‌های تقویم می‌آیند و علت تعطیلی‌ای که خودت برای کارکرد ثبت می‌کنی، تقویم را تغییر نمی‌دهد. برای انتخاب روز دیگر از تقویم استفاده کن.",
        "۳. صفحهٔ «روز» — نوع روز و ذخیرهٔ کارکرد" to
            "ابتدا روز موردنظر را انتخاب کن و نوع روز را مشخص کن؛ مانند کاری، تعطیل رسمی، تعطیل مناسبتی، مرخصی استحقاقی، استعلاجی یا مأموریت. برخی وضعیت‌ها می‌توانند طبق قواعد برنامه با هم ثبت شوند. اگر برای تعطیل مناسبتی عنوان یا علت وارد می‌کنی، این اطلاعات فقط در مدیریت کارکرد و گزارش‌های مربوط استفاده می‌شوند و مناسبت اصلی تقویم را تغییر نمی‌دهند. پس از ورود یا ویرایش اطلاعات، «ذخیره اطلاعات روز» را بزن. حذف اطلاعات روز پس از درخواست تأیید انجام می‌شود.",
        "۴. تنظیم «ساعت کار ثابت» و «ساعت موظفی»" to
            "در «تنظیمات»، کلید «ساعت کار ثابت» بالای فیلد «ساعت موظفی» قرار دارد. در حالت ثابت می‌توانی زمان ورود و خروج شنبه تا چهارشنبه و زمان جداگانهٔ پنجشنبه را مشخص کنی. برای درج سریع، چهار رقم وارد کن؛ مانند 0700 که به صورت 07:00 قالب‌بندی می‌شود. ساعت موظفی حالت ثابت از اختلاف ساعت پایان و شروع محاسبه می‌شود. وقتی حالت شناور خاموش/غیرفعال است، ساعات موظفی قابل تنظیم باقی می‌مانند؛ پیش‌فرض شنبه تا چهارشنبه ۷ ساعت و پنجشنبه ۵ ساعت است. ذخیرهٔ ساعت‌های جدید را با دکمهٔ مربوط تأیید کن.",
        "۵. حالت ساعت کار ثابت روشن" to
            "در حالت ثابت، ورود و خروج اول برای بازهٔ موظفی است. اگر هنوز نمی‌دانی چه ساعتی از محل کار خارج می‌شوی، می‌توانی ورود را بدون خروج ذخیره کنی؛ تا زمان تکمیل خروج، روز با عبارت «اطلاعات ناقص است» مشخص می‌شود و در جمع قطعی کارکرد محاسبه نمی‌شود. اگر بازهٔ اضافه‌کاری دوم تا چهارم ثبت نشده باشد، خروج اول می‌تواند پس از پایان موظفی باشد؛ مثلاً 07:00 تا 18:00. اگر بازه‌های دوم تا چهارم را ثبت کنی، آن‌ها برای کار پس از پایان ساعات ثابت هستند و ورود و خروج اول باید با قاعدهٔ پایان موظفی سازگار باشد. مرخصی ساعتی حداکثر در سه بازه و فقط داخل بازهٔ موظفی قابل ثبت است؛ ثبت مرخصی در بازهٔ اضافه‌کاری مجاز نیست.",
        "۶. حالت ساعت کار شناور خاموش" to
            "در حالت شناور فقط یک بازهٔ ورود و خروج برای حضور روز ثبت می‌شود و تا چهار بازهٔ مرخصی ساعتی در هر ساعت از روز قابل وارد کردن است، به شرط آنکه مرخصی داخل بازهٔ حضور ثبت‌شده قرار گیرد. برای هر روز، مجموع مرخصی قابل کسر از حضور حداکثر برابر موظفی همان روز است؛ بیشتر از این سقف، کارکرد را کاهش نمی‌دهد. مثال: اگر حضور 07:00 تا 16:00 باشد، حضور ۹ ساعت است. با یک ساعت مرخصی، کل کارکرد ۸ ساعت می‌شود؛ از موظفی ۷ ساعته، اضافه‌کاری یک ساعت باقی می‌ماند. اگر ۱۶ ساعت و ۳۰ دقیقه حضور و ۸ ساعت مرخصی ثبت شود و موظفی ۷ ساعت باشد، فقط ۷ ساعت مرخصی کسر می‌شود؛ کارکرد ۹ ساعت و ۳۰ دقیقه و اضافه‌کاری ۲ ساعت و ۳۰ دقیقه خواهد بود.",
        "۷. معنی شاخص‌های کارکرد" to
            "«کل کارکرد» مجموع دقیقه‌های حضور معتبر پس از کسر مرخصی قابل محاسبه است؛ اضافه‌کاری بخشی از همین کارکرد است و دوباره به آن افزوده نمی‌شود. «موظفی مقرر» مقدار زمانی است که طبق تقویم کاری و حالت ثبت‌شده باید انجام شود؛ در حالت ثابت، مرخصی داخل بازهٔ موظفی، مقدار موظفی همان روز را کاهش می‌دهد. «موظفی ثبتی» مقدار حضور مؤثر در محدودهٔ موظفی است و اضافه‌کاری خارج از بازه نباید کمبود حضور داخل موظفی را پنهان کند. «اضافه‌کاری» طبق بازه‌های ثابت یا مازاد کارکرد خالص بر موظفی محاسبه می‌شود. زمان‌ها با قالب ساعت:دقیقه نمایش داده می‌شوند.",
        "۸. اطلاعات ناقص و بازه‌های زمانی" to
            "در حالت ثابت، ثبت ورود اول بدون خروج مجاز است. روز دارای بازهٔ ناقص با عنوان «اطلاعات ناقص است» در کارت روز و گزارش‌ها مشخص می‌شود و تا تکمیل بازه در جمع قطعی کارکرد و اضافه‌کاری وارد نمی‌شود. در حالت شناور، برای ثبت حضور باید ورود و خروج کامل باشند. مرخصی ساعتی و بازه‌های دوم تا چهارم نیز باید با ساعت شروع و پایان کامل ذخیره شوند. پیش از ذخیره، ترتیب ساعت شروع و پایان را بررسی کن. در یک روز، بازه‌های حضور نباید با یکدیگر هم‌پوشانی داشته باشند. مرخصی ساعتی باید با حضور ثبت‌شده تناسب داشته باشد. اگر فعالیت مستقل از نیمه‌شب عبور می‌کند، تاریخ پایان روز بعد را انتخاب کن تا مدت درست محاسبه شود.",
        "۹. فعالیت‌های کاری مستقل" to
            "در کارت «فعالیت کاری» هر فعالیت را جداگانه با تاریخ و ساعت شروع، تاریخ و ساعت پایان و عنوان اختیاری ثبت کن. چند فعالیت برای یک روز قابل ثبت است و می‌توانی هرکدام را ویرایش یا حذف کنی. فعالیت‌ها از اطلاعات اصلی ورود و خروج مستقل‌اند و بر اساس تاریخ شروع در ماه و سال مربوط نمایش داده می‌شوند. گزارش‌ها تعداد فعالیت‌ها و جمع مدت آن‌ها را جداگانه نشان می‌دهند. اگر فعالیت با حضور روزانه هم‌پوشانی داشته باشد، مدت هم‌پوشان فقط یک بار به «کل کارکرد» اضافه می‌شود؛ شاخص تعداد و مدت فعالیت همچنان جداگانه دیده می‌شود.",
        "۱۰. صفحهٔ «ماه» — گزارش ماهانه" to
            "در صفحهٔ «ماه»، سال و ماه را انتخاب کن. «خلاصه کارکرد ماه» و کارت‌های روزانه اطلاعات کارکرد را به شکل یکسان و با قاب‌های مشخص نشان می‌دهند. هر کارت روز شامل نوع روز، ساعت‌های ثبت‌شده، کل کارکرد، موظفی مقرر، موظفی ثبتی، اضافه‌کاری، تعداد و جمع مدت فعالیت، وضعیت اطلاعات و یادداشت است. نشان «ث» یعنی ساعت کار ثابت و نشان «ش» یعنی ساعت کار شناور. عبارت «اطلاعات ناقص است» یعنی حداقل یک بازه کامل نشده و آن روز هنوز به جمع قطعی کارکرد افزوده نمی‌شود. توراهی در این صفحه به صورت دستی ثبت یا حذف می‌شود؛ برای حذف مقدار توراهی، صفر را ذخیره کن.",
        "۱۱. حذف انتخابی کارت‌های گزارش" to
            "برای حذف اطلاعات در صفحهٔ «ماه»، انگشت را روی کارت روز نگه دار تا حالت انتخاب فعال شود؛ سپس با لمس کارت‌های دیگر آن‌ها را انتخاب یا از انتخاب خارج کن. دکمهٔ حذف پس از انتخاب فعال می‌شود و حذف نهایی نیازمند تأیید است. یک بار فشردن دکمهٔ بازگشت از حالت انتخاب خارج می‌شود و چیزی را حذف نمی‌کند. در صفحهٔ «سال» همین روش برای کارت ماه به کار می‌رود. حذف کارت ماه تمام اطلاعات روزهای آن ماه، فعالیت‌هایی که در همان ماه شروع شده‌اند و مقدار توراهی ثبت‌شده برای همان ماه را حذف می‌کند. داده‌های تقویم و یادآورها با این کار حذف نمی‌شوند.",
        "۱۲. صفحهٔ «سال» — گزارش سالانه" to
            "صفحهٔ «سال» کارت جداگانهٔ هر ماه را در کنار شاخص‌های ماهانه نشان می‌دهد و جمع سال از همین محاسبات یکسان به دست می‌آید. «موظفی مقرر» و «موظفی ثبتی» برای مقایسهٔ میزان حضور مورد انتظار و میزان حضور مؤثر ثبت‌شده کنار هم قرار دارند. تعداد و مدت فعالیت‌ها بر اساس تاریخ شروع فعالیت محاسبه می‌شوند. گزارش تفصیلی Excel/PDF، اطلاعات روزانه و خلاصهٔ جامع سالانه، شاخص‌های سال و جمع هر یک از دوازده ماه را ارائه می‌کنند. اگر در یک ماه اطلاعات ناقص وجود داشته باشد، در شمار روزهای ناقص گزارش می‌شود.",
        "۱۳. خروجی Excel، PDF و بازیابی" to
            "Excel برای بررسی داده‌ها و نگهداری نسخهٔ قابل بازیابی مناسب است؛ PDF برای مشاهده و چاپ گزارش به کار می‌رود و فایل پشتیبان نیست. پشتیبان کامل کارکرد در تنظیمات به صورت CSV ساخته می‌شود و شامل رکوردهای روز، تنظیمات و فعالیت‌های مستقل است. هنگام بازیابی پشتیبان کامل، اطلاعات فعلی جایگزین می‌شود؛ پیش از آن از وضعیت موجود پشتیبان بگیر. فایل Excel گزارش دوره‌ای فقط برای ادغام داده‌های همان دوره طراحی شده و سایر ماه‌ها را جایگزین نمی‌کند. در خروجی و پشتیبان، حالت روز با مقدار پایدار ثابت/شناور حفظ می‌شود. فایل‌ها را پس از ساخت در محل امن نگه دار و مطمئن شو که فایل انتخاب‌شده واقعاً متعلق به مورخ است.",
        "۱۴. تقویم، تاریخ‌های قمری و میلادی" to
            "در صفحهٔ «تقویم»، ماه قبل و بعد را با کشیدن صفحه به راست یا چپ ببین و برای نمایش اطلاعات روز، روی عدد آن روز بزن. نام کامل روزهای هفته نمایش داده می‌شود. در سرصفحه نام روز، تاریخ قمری، عدد روز در دایره، نام ماه و سال شمسی و تاریخ میلادی دیده می‌شوند؛ لمس تاریخ قمری یا میلادی نمایش نوشتاری/عددی را عوض می‌کند. زیر شبکهٔ تقویم شش زمان اصلی اوقات شرعی نمایش داده می‌شود: اذان صبح، طلوع آفتاب، اذان ظهر، غروب آفتاب، اذان مغرب و نیمه‌شب شرعی. زیر آن مناسبت‌های تاریخ انتخاب‌شده نمایش داده می‌شوند. تاریخ قمری محاسباتی است و ممکن است با اعلام رسمی رؤیت هلال تفاوت داشته باشد.",
        "۱۵. یادآورها و اذان‌گو" to
            "بخش یادآورها برای اقساط و جلسات است و مستقل از کارکرد روزانه ذخیره می‌شود. نوع یادآور، عنوان، تاریخ، ساعت و در صورت نیاز تکرار ماهانه را مشخص کن؛ یادآورها را می‌توانی فعال، غیرفعال، ویرایش یا حذف کنی. پشتیبان یادآورها با پشتیبان کارکرد فرق دارد و از دکمه‌های مخصوص خود استفاده می‌کند. در صفحهٔ اوقات شرعی و اذان‌گو شهر را انتخاب و زمان‌های موجود را تازه‌سازی کن. اعلان‌های اذان را جداگانه می‌توان فعال کرد و فایل‌های صوتی را از بانک اذان انتخاب یا دریافت کرد. تعداد زمان‌های تقویم همان شش مورد موجود برنامه است.",
        "۱۶. راهنمای عیب‌یابی و نکات پایانی" to
            "اگر جمع گزارش با انتظار تو تفاوت دارد، ابتدا حالت «ثابت» یا «شناور» را در کارت روز بررسی کن، سپس ساعت‌های ورود و خروج، بازه‌های مرخصی و پیام اطلاعات ناقص را مرور کن. در حالت ثابت، بازه‌های اضافه‌کاری باید بعد از پایان ساعت ثابت باشند؛ در حالت شناور، مرخصی باید داخل حضور ثبت‌شده باشد و حداکثر به اندازهٔ موظفی از کارکرد کسر می‌شود. اگر فعالیت کاری در گزارش دیده نمی‌شود، تاریخ شروع و پایان و ذخیره‌شدن فعالیت را بررسی کن و صفحهٔ گزارش را دوباره باز کن. هنگام نصب نسخهٔ جدید، اگر اطلاعات مهم داری ابتدا پشتیبان بساز. برای ارسال گزارش خطا، شمارهٔ نسخه، صفحهٔ موردنظر و یک مثال تاریخ/ساعت بدون اطلاعات محرمانه را ثبت کن."
    )
    LazyColumn(modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF3FF)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFB6D2EC), RoundedCornerShape(12.dp))
            ) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    PersianText("راهنمای جامع مورخ", color = Color(0xFF173F71), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    PersianText("این راهنما بر اساس نسخهٔ ۰٫۶۳٫۰ تنظیم شده است. برای رسیدن به نتیجهٔ درست، بخش مربوط به نوع کار و روش ثبت اطلاعات را به‌ترتیب بخوان.", fontSize = 12.sp, color = Color(0xFF315C8D), lineHeight = 19.sp)
                }
            }
        }
        items(sections) { section ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFD5E4F3), RoundedCornerShape(12.dp))
            ) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    PersianText(section.first, color = Color(0xFF173F71), fontWeight = FontWeight.Bold, fontSize = 15.sp, lineHeight = 20.sp)
                    PersianText(section.second, fontSize = 12.sp, color = Color(0xFF354F68), lineHeight = 20.sp)
                }
            }
        }
    }
}
