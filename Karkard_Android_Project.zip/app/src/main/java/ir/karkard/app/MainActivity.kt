package ir.karkard.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


private val ShiftYellow = Color(0xFFFFF0B3)
private val ShiftYellowText = Color(0xFF795500)
private val OvertimeGreen = Color(0xFFD9F2D9)
private val OvertimeGreenText = Color(0xFF176B36)

private fun String.toLatinDigits(): String = map { ch ->
    when (ch) {
        '۰' -> '0'; '۱' -> '1'; '۲' -> '2'; '۳' -> '3'; '۴' -> '4'
        '۵' -> '5'; '۶' -> '6'; '۷' -> '7'; '۸' -> '8'; '۹' -> '9'
        '٠' -> '0'; '١' -> '1'; '٢' -> '2'; '٣' -> '3'; '٤' -> '4'
        '٥' -> '5'; '٦' -> '6'; '٧' -> '7'; '٨' -> '8'; '٩' -> '9'
        else -> ch
    }
}.joinToString("")

private val JalaliMonthNames = listOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
private val JalaliWeekdayNames = listOf("یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه")
private fun jalaliDisplayDate(value: String): String = value.replace('-', '/').toPersianDigits()

private fun String.toPersianDigits(): String = map { ch ->
    when (ch) {
        '0' -> '۰'; '1' -> '۱'; '2' -> '۲'; '3' -> '۳'; '4' -> '۴'
        '5' -> '۵'; '6' -> '۶'; '7' -> '۷'; '8' -> '۸'; '9' -> '۹'
        else -> ch
    }
}.joinToString("")

@Composable
private fun PersianText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = FontFamily.SansSerif,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    textDecoration: TextDecoration? = null,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    style: TextStyle = LocalTextStyle.current
) {
    androidx.compose.material3.Text(
        text = text.toPersianDigits(),
        modifier = modifier,
        color = color,
        fontSize = fontSize,
        fontStyle = fontStyle,
        fontWeight = fontWeight,
        fontFamily = fontFamily,
        letterSpacing = letterSpacing,
        textDecoration = textDecoration,
        textAlign = textAlign,
        lineHeight = lineHeight,
        overflow = overflow,
        softWrap = softWrap,
        maxLines = maxLines,
        minLines = minLines,
        style = style
    )
}

data class WorkDay(
    val date: String,
    val in1: String = "", val out1: String = "",
    val in2: String = "", val out2: String = "",
    val in3: String = "", val out3: String = "",
    val note: String = "",
    val dayType: String = "کاری",
    val overtimeOverride: String = "",
    val shiftEnabled: Boolean = false,
    val shiftStart: String = "",
    val shiftEnd: String = "",
    val shiftStartDate: String = "",
    val shiftEndDate: String = "",
    val holidayIn: String = "",
    val holidayOut: String = "",
    val leave1Start: String = "", val leave1End: String = "",
    val leave2Start: String = "", val leave2End: String = "",
    val hourlyLeaveEnabled: Boolean = false,
    val extraDayTypes: String = "" // pipe-separated second status; primary dayType remains compatible
)

private val workHolidayStatuses = setOf("تعطیل رسمی", "تعطیل مناسبتی")
private val workLeaveStatuses = setOf("مرخصی", "استعلاجی")
private val workSecondStatuses = workLeaveStatuses + "مأموریت"

/** Day statuses use one primary type plus an optional second type for old-record compatibility. */
private fun dayStatuses(day: WorkDay): Set<String> = buildSet {
    if (day.dayType.isNotBlank()) add(if (day.dayType == "تعطیل") "تعطیل رسمی" else day.dayType)
    day.extraDayTypes.split('|').filter { it.isNotBlank() }.forEach { add(it) }
}
private fun hasDayStatus(day: WorkDay, status: String) = status in dayStatuses(day)

private fun toggleDayStatus(day: WorkDay, selected: String): WorkDay {
    val current = dayStatuses(day)
    val next = if (selected in current) current - selected else {
        when {
            selected in workHolidayStatuses -> (current - workHolidayStatuses - "کاری") + selected
            selected in workSecondStatuses -> {
                // One secondary status only; allow it with one holiday or with work+mission.
                val base = current.intersect(workHolidayStatuses).firstOrNull()
                    ?: if (selected == "مأموریت" && "کاری" in current) "کاری" else null
                (if (base == null) emptySet() else setOf(base)) + selected
            }
            selected == "کاری" -> if ("مأموریت" in current) setOf("کاری", "مأموریت") else setOf("کاری")
            else -> setOf(selected)
        }
    }
    val primary = next.firstOrNull { it in workHolidayStatuses }
        ?: next.firstOrNull { it == "کاری" }
        ?: next.firstOrNull().orEmpty()
    return day.copy(dayType = primary, extraDayTypes = (next - primary).joinToString("|"))
}

class WorkDb(context: Context) : SQLiteOpenHelper(context, "karkard.db", null, 17) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE workdays(
            date TEXT PRIMARY KEY, in1 TEXT, out1 TEXT, in2 TEXT, out2 TEXT,
            in3 TEXT, out3 TEXT, note TEXT, day_type TEXT DEFAULT 'کاری',
            overtime_override TEXT DEFAULT '', shift_enabled INTEGER DEFAULT 0, shift_start TEXT DEFAULT '', shift_end TEXT DEFAULT '', shift_start_date TEXT DEFAULT '', shift_end_date TEXT DEFAULT '', holiday_in TEXT DEFAULT '', holiday_out TEXT DEFAULT '', leave1_start TEXT DEFAULT '', leave1_end TEXT DEFAULT '', leave2_start TEXT DEFAULT '', leave2_end TEXT DEFAULT '', leave_enabled INTEGER DEFAULT 0, extra_day_types TEXT DEFAULT '')""")
        db.execSQL("CREATE TABLE holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL)")
        db.execSQL("CREATE TABLE official_holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL, year INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE holiday_sync(year INTEGER PRIMARY KEY, synced_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE calendar_events(date TEXT PRIMARY KEY, title TEXT NOT NULL, year INTEGER NOT NULL)")
        db.execSQL("""CREATE TABLE settings(
            key TEXT PRIMARY KEY, value TEXT NOT NULL)""")
        val defaults = mapOf(
            "workday_hours" to "07:00", "thursday_hours_value" to "05:00"
        )
        defaults.forEach { (k,v) ->
            val cv = ContentValues().apply { put("key", k); put("value", v) }
            db.insert("settings", null, cv)
        }
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN day_type TEXT DEFAULT 'کاری'")
            db.execSQL("ALTER TABLE workdays ADD COLUMN overtime_override TEXT DEFAULT ''")
            val defaults = mapOf("workday_hours" to "07:00", "thursday_hours_value" to "05:00")
            defaults.forEach { (k,v) ->
                val cv = ContentValues().apply { put("key",k); put("value",v) }
                db.insertWithOnConflict("settings", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
            }
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_enabled INTEGER DEFAULT 0")
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_start TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_end TEXT DEFAULT ''")
        }
        if (oldVersion < 4) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_start_date TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_end_date TEXT DEFAULT ''")
            db.execSQL("DELETE FROM settings WHERE key='shift_hours'")
        }
        if (oldVersion < 5) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN holiday_in TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN holiday_out TEXT DEFAULT ''")
        }
        if (oldVersion < 11) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave1_start TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave1_end TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave2_start TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave2_end TEXT DEFAULT ''")
        }
        if (oldVersion < 12) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave_enabled INTEGER DEFAULT 0")
            // Existing leave entries must remain active after an upgrade.
            db.execSQL("""UPDATE workdays SET leave_enabled=1 WHERE
                COALESCE(leave1_start,'')<>'' OR COALESCE(leave1_end,'')<>'' OR
                COALESCE(leave2_start,'')<>'' OR COALESCE(leave2_end,'')<>''""")
        }
        if (oldVersion < 13) {
            // Migrate factory defaults from prior versions, without overriding other custom choices.
            db.execSQL("UPDATE settings SET value='07:00' WHERE key='workday_hours' AND value='08:00'")
            db.execSQL("UPDATE settings SET value='05:00' WHERE key='thursday_hours_value' AND value='04:00'")
            db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('workday_hours','07:00')")
            db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('thursday_hours_value','05:00')")
        }
        if (oldVersion < 14) {
            // Older versions stored Fridays as the legacy 'تعطیل' status.
            db.execSQL("UPDATE workdays SET day_type='تعطیل رسمی' WHERE day_type='تعطیل'")
        }
        if (oldVersion < 15) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN extra_day_types TEXT DEFAULT ''")
        }
        if (oldVersion < 17) db.execSQL("DROP TABLE IF EXISTS long_leave_days")
        db.execSQL("CREATE TABLE IF NOT EXISTS holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS official_holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL, year INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS holiday_sync(year INTEGER PRIMARY KEY, synced_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS calendar_events(date TEXT PRIMARY KEY, title TEXT NOT NULL, year INTEGER NOT NULL)")
        db.execSQL("DELETE FROM settings WHERE key='shift_hours'")
        if (oldVersion < 10) {
            // Force a fresh calendar download after holiday parser improvements.
            // Existing work records and saved calendar data are retained.
            db.delete("holiday_sync", null, null)
        }
    }

    fun hasWorkDay(date: String): Boolean = readableDatabase.rawQuery(
        "SELECT 1 FROM workdays WHERE date=? LIMIT 1", arrayOf(date)
    ).use { it.moveToFirst() }

    fun getDay(date: String): WorkDay {
        readableDatabase.rawQuery("SELECT * FROM workdays WHERE date=?", arrayOf(date)).use { c ->
            if (c.moveToFirst()) return WorkDay(
                c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "",
                c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "",
                c.getString(6) ?: "", c.getString(7) ?: "",
                if (c.columnCount > 8) c.getString(8) ?: "کاری" else "کاری",
                if (c.columnCount > 9) c.getString(9) ?: "" else "",
                if (c.columnCount > 10) c.getInt(10) == 1 else false,
                if (c.columnCount > 11) c.getString(11) ?: "" else "",
                if (c.columnCount > 12) c.getString(12) ?: "" else "",
                if (c.columnCount > 13) c.getString(13) ?: "" else "",
                if (c.columnCount > 14) c.getString(14) ?: "" else "",
                if (c.columnCount > 15) c.getString(15) ?: "" else "",
                if (c.columnCount > 16) c.getString(16) ?: "" else "",
                if (c.columnCount > 17) c.getString(17) ?: "" else "", if (c.columnCount > 18) c.getString(18) ?: "" else "",
                if (c.columnCount > 19) c.getString(19) ?: "" else "", if (c.columnCount > 20) c.getString(20) ?: "" else "",
                if (c.columnCount > 21) c.getInt(21) == 1 else listOf(17,18,19,20).any { i -> i < c.columnCount && !c.getString(i).isNullOrBlank() },
                if (c.columnCount > 22) c.getString(22) ?: "" else ""
            )
        }
        return WorkDay(date)
    }
    fun calendarSyncTime(year: Int): Long = readableDatabase.rawQuery(
        "SELECT synced_at FROM holiday_sync WHERE year=?", arrayOf(year.toString())
    ).use { if (it.moveToFirst()) it.getLong(0) else 0L }

    /** Deletes only user-entered daily work/leave/shift records in an inclusive Jalali range.
     * Calendar holidays, events, preferences and reminder databases are NOT affected. */
    fun countWorkRecords(start: String, end: String): Int {
        readableDatabase.rawQuery(
            """SELECT COUNT(*) FROM (
                 SELECT REPLACE(TRIM(date), '/', '-') AS normalized_date
                   FROM workdays
                  WHERE REPLACE(TRIM(date), '/', '-') BETWEEN ? AND ?
                 UNION
                 SELECT REPLACE(TRIM(date), '/', '-') AS normalized_date
                   FROM holidays
                  WHERE REPLACE(TRIM(date), '/', '-') BETWEEN ? AND ?
               )""", arrayOf(start, end, start, end)
        ).use { cursor -> return if (cursor.moveToFirst()) cursor.getInt(0) else 0 }
    }

    /** Number of distinct saved dates marked as توراهی in the selected range. */
    fun countTourahiDays(start: String, end: String): Int = readableDatabase.rawQuery(
        """SELECT COUNT(DISTINCT REPLACE(TRIM(date), '/', '-')) FROM workdays
           WHERE REPLACE(TRIM(date), '/', '-') BETWEEN ? AND ?
             AND (day_type = 'توراهی' OR instr('|' || COALESCE(extra_day_types, '') || '|', '|توراهی|') > 0)""",
        arrayOf(start, end)
    ).use { cursor -> if (cursor.moveToFirst()) cursor.getInt(0) else 0 }

    /** Counts all distinct توراهی dates in every Jalali month touched by the selected range. */
    fun countTourahiDaysInMonths(start: String, end: String): Int = readableDatabase.rawQuery(
        """SELECT COUNT(DISTINCT REPLACE(TRIM(date), '/', '-')) FROM workdays
           WHERE substr(REPLACE(TRIM(date), '/', '-'), 1, 7) BETWEEN ? AND ?
             AND (day_type = 'توراهی' OR instr('|' || COALESCE(extra_day_types, '') || '|', '|توراهی|') > 0)""",
        arrayOf(start.take(7), end.take(7))
    ).use { cursor -> if (cursor.moveToFirst()) cursor.getInt(0) else 0 }

    /** Deletes every saved field for one day, restoring the editor to its date defaults. */
    fun deleteDay(date: String): Int {
        val normalized = date.trim().replace('/', '-')
        require(parsedJalaliDate(normalized) != null) { "Invalid date" }
        return deleteWorkRecords(normalized, normalized, preserveTourahiInRange = false, deleteTourahiInMonths = false)
    }

    /** Deletes all saved per-day work and manual-holiday data in an inclusive range.
     * Calendar baselines and global settings are not deleted; deleting each workday row
     * removes manual day-type overrides so the date's own calendar baseline is shown again.
     */
    fun deleteWorkRecords(
        start: String,
        end: String,
        preserveTourahiInRange: Boolean = false,
        deleteTourahiInMonths: Boolean = false
    ): Int {
        // Legacy parameters are retained for source compatibility; range deletion now resets
        // every selected date completely and never recreates a manual day-type override.
        require(start <= end) { "Start date must not be after end date" }
        require(parsedJalaliDate(start) != null) { "Invalid start date" }
        require(parsedJalaliDate(end) != null) { "Invalid end date" }

        val database = writableDatabase
        database.beginTransaction()
        try {
            // Delete complete per-day records. No saved day_type is recreated: after deletion,
            // the UI/report derives the date's own baseline from the calendar (Friday/official
            // holiday => تعطیل رسمی; otherwise کاری). This avoids carrying manual overrides.
            val affected = countWorkRecords(start, end)
            database.delete(
                "workdays",
                "REPLACE(TRIM(date), '/', '-') >= ? AND REPLACE(TRIM(date), '/', '-') <= ?",
                arrayOf(start, end)
            )
            database.delete(
                "holidays",
                "REPLACE(TRIM(date), '/', '-') >= ? AND REPLACE(TRIM(date), '/', '-') <= ?",
                arrayOf(start, end)
            )
            val remaining = countWorkRecords(start, end)
            check(remaining == 0) { "Deletion verification failed: $remaining records remain" }
            database.setTransactionSuccessful()
            return affected
        } finally {
            database.endTransaction()
        }
    }

    fun saveDayAndHoliday(d: WorkDay, holidayReason: String?) {
        val database = writableDatabase
        database.beginTransaction()
        try {
            saveDay(d)
            if (holidayReason.isNullOrBlank()) removeHoliday(d.date)
            else saveHoliday(d.date, holidayReason.trim())
            database.setTransactionSuccessful()
        } finally {
            database.endTransaction()
        }
    }

    fun saveDay(d: WorkDay) {
        val v = ContentValues().apply {
            put("date", d.date); put("in1",d.in1); put("out1",d.out1)
            put("in2",d.in2); put("out2",d.out2); put("in3",d.in3); put("out3",d.out3)
            put("note",d.note); put("day_type",d.dayType); put("overtime_override",d.overtimeOverride); put("shift_enabled", if(d.shiftEnabled) 1 else 0); put("shift_start",d.shiftStart); put("shift_end",d.shiftEnd); put("shift_start_date",d.shiftStartDate); put("shift_end_date",d.shiftEndDate)
            put("holiday_in", d.holidayIn); put("holiday_out", d.holidayOut); put("leave1_start", d.leave1Start); put("leave1_end", d.leave1End); put("leave2_start", d.leave2Start); put("leave2_end", d.leave2End); put("leave_enabled", if (d.hourlyLeaveEnabled) 1 else 0); put("extra_day_types", d.extraDayTypes)
        }
        writableDatabase.insertWithOnConflict("workdays", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun allDays(month: String): List<WorkDay> {
        val result = mutableListOf<WorkDay>()
        readableDatabase.rawQuery("SELECT * FROM workdays WHERE date LIKE ? ORDER BY date", arrayOf("$month%")).use { c ->
            while(c.moveToNext()) result.add(WorkDay(
                c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "",
                c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "",
                c.getString(6) ?: "", c.getString(7) ?: "",
                c.getString(8) ?: "کاری", c.getString(9) ?: "", c.getInt(10) == 1, c.getString(11) ?: "", c.getString(12) ?: "", c.getString(13) ?: "", c.getString(14) ?: "",
                if (c.columnCount > 15) c.getString(15) ?: "" else "", if (c.columnCount > 16) c.getString(16) ?: "" else "",
                if (c.columnCount > 17) c.getString(17) ?: "" else "", if (c.columnCount > 18) c.getString(18) ?: "" else "",
                if (c.columnCount > 19) c.getString(19) ?: "" else "", if (c.columnCount > 20) c.getString(20) ?: "" else "",
                if (c.columnCount > 21) c.getInt(21) == 1 else listOf(17,18,19,20).any { i -> i < c.columnCount && !c.getString(i).isNullOrBlank() },
                if (c.columnCount > 22) c.getString(22) ?: "" else ""
            ))
        }
        return result
    }
    fun allDaysYear(year: Int): List<WorkDay> = allDaysForBackup().filter { it.date.startsWith("%04d-".format(year)) }
    fun officialHolidays(year: Int): List<Pair<String, String>> {
        val result = mutableListOf<Pair<String, String>>()
        readableDatabase.rawQuery(
            "SELECT date,title FROM official_holidays WHERE year=? ORDER BY date",
            arrayOf(year.toString())
        ).use { c -> while (c.moveToNext()) result.add(c.getString(0) to c.getString(1)) }
        return result
    }

    fun officialHolidayTitle(date: String): String? {
        readableDatabase.rawQuery("SELECT title FROM official_holidays WHERE date=?", arrayOf(date)).use { c ->
            return if (c.moveToFirst()) c.getString(0) else null
        }
    }

    fun calendarEventTitle(date: String): String? {
        readableDatabase.rawQuery("SELECT title FROM calendar_events WHERE date=?", arrayOf(date)).use { c ->
            return if (c.moveToFirst()) c.getString(0) else null
        }
    }

    fun displayHolidayTitle(date: String): String? {
        val titles = listOfNotNull(officialHolidayTitle(date), holidayTitle(date), calendarEventTitle(date))
            .flatMap { value -> value.split("،").map { title -> title.trim() } }
            .filter { it.isNotBlank() }.distinct()
        return titles.takeIf { it.isNotEmpty() }?.joinToString("، ")
    }

    /** One-time verified offline seed for 1405. User workdays and manual holidays stay untouched. */
    fun ensureBundled1405Calendar() {
        if (getSettingText("calendar_1405_seed", "") == "1405.1") return
        val storedHolidays = officialHolidays(1405)
        val storedEvents = calendarEvents(1405)
        // A complete remotely synchronized calendar already has more observances than the seed.
        if (storedHolidays.size < 20 || storedEvents.size < 100) {
            val verified = Calendar1405.holidays
            val titles = (storedEvents + Calendar1405.events + verified).groupBy({ it.first }, { it.second })
                .map { (date, list) -> date to list.distinct().joinToString("، ") }
            replaceCalendarData(1405, verified, titles)
        }
        setSettingText("calendar_1405_seed", "1405.1")
    }

    fun shouldSyncOfficialHolidays(year: Int, now: Long = System.currentTimeMillis()): Boolean {
        // Force a refresh of 1405 data if the previous app version saved a partial calendar
        // without the official Mab'ath holiday. This avoids the old 7-day cache hiding the fix.
        if (year == 1405 && officialHolidayTitle("1405-10-16").isNullOrBlank()) return true
        readableDatabase.rawQuery("SELECT synced_at FROM holiday_sync WHERE year=?", arrayOf(year.toString())).use { c ->
            if (!c.moveToFirst()) return true
            // Refresh at most once per week unless the user explicitly requests an update.
            return now - c.getLong(0) >= 7L * 24L * 60L * 60L * 1000L
        }
    }

    fun replaceOfficialHolidays(year: Int, holidays: List<Pair<String, String>>) {
        require(holidays.isNotEmpty()) { "فهرست تعطیلات خالی است؛ اطلاعات قبلی حفظ شد." }
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("official_holidays", "year=?", arrayOf(year.toString()))
            holidays.forEach { (date, title) ->
                val values = ContentValues().apply {
                    put("date", date); put("title", title); put("year", year)
                }
                db.insertWithOnConflict("official_holidays", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            val meta = ContentValues().apply { put("year", year); put("synced_at", System.currentTimeMillis()) }
            db.insertWithOnConflict("holiday_sync", null, meta, SQLiteDatabase.CONFLICT_REPLACE)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun calendarEvents(year: Int): List<Pair<String, String>> {
        val result = mutableListOf<Pair<String, String>>()
        readableDatabase.rawQuery("SELECT date,title FROM calendar_events WHERE year=? ORDER BY date", arrayOf(year.toString())).use { c ->
            while (c.moveToNext()) result.add(c.getString(0) to c.getString(1))
        }
        return result
    }

    fun replaceCalendarData(year: Int, holidays: List<Pair<String, String>>, events: List<Pair<String, String>>) {
        require(holidays.isNotEmpty()) { "فهرست تعطیلات خالی است؛ اطلاعات قبلی حفظ شد." }
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("official_holidays", "year=?", arrayOf(year.toString()))
            holidays.forEach { (date, title) ->
                val values = ContentValues().apply { put("date", date); put("title", title); put("year", year) }
                db.insertWithOnConflict("official_holidays", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.delete("calendar_events", "year=?", arrayOf(year.toString()))
            events.forEach { (date, title) ->
                val values = ContentValues().apply { put("date", date); put("title", title); put("year", year) }
                db.insertWithOnConflict("calendar_events", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            val meta = ContentValues().apply { put("year", year); put("synced_at", System.currentTimeMillis()) }
            db.insertWithOnConflict("holiday_sync", null, meta, SQLiteDatabase.CONFLICT_REPLACE)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun saveHoliday(date: String, title: String) {
        val v = ContentValues().apply { put("date", date); put("title", title) }
        writableDatabase.insertWithOnConflict("holidays", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun removeHoliday(date: String) { writableDatabase.delete("holidays", "date=?", arrayOf(date)) }
    fun allHolidays(): List<Pair<String,String>> {
        val out = mutableListOf<Pair<String,String>>()
        readableDatabase.rawQuery("SELECT date,title FROM holidays ORDER BY date", null).use { c -> while(c.moveToNext()) out.add(c.getString(0) to c.getString(1)) }
        return out
    }
    fun holidayTitle(date: String): String? {
        readableDatabase.rawQuery("SELECT title FROM holidays WHERE date=?", arrayOf(date)).use { c -> return if(c.moveToFirst()) c.getString(0) else null }
    }
    fun getSetting(key: String): Boolean {
        readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?", arrayOf(key)).use { c ->
            return c.moveToFirst() && c.getString(0) == "true"
        }
    }
    fun getSettingText(key: String, fallback: String = ""): String {
        readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?", arrayOf(key)).use { c ->
            return if (c.moveToFirst()) c.getString(0) else fallback
        }
    }
    fun setSettingText(key: String, value: String) {
        val v = ContentValues().apply { put("key",key); put("value",value) }
        writableDatabase.insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun setSetting(key: String, value: Boolean) {
        val v = ContentValues().apply { put("key",key); put("value",value.toString()) }
        writableDatabase.insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun allDaysForBackup(): List<WorkDay> {
        val result = mutableListOf<WorkDay>()
        readableDatabase.rawQuery("SELECT * FROM workdays ORDER BY date", null).use { c ->
            while(c.moveToNext()) result.add(WorkDay(
                c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "",
                c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "",
                c.getString(6) ?: "", c.getString(7) ?: "", c.getString(8) ?: "کاری",
                c.getString(9) ?: "", c.getInt(10) == 1, c.getString(11) ?: "", c.getString(12) ?: "", c.getString(13) ?: "", c.getString(14) ?: "",
                if (c.columnCount > 15) c.getString(15) ?: "" else "", if (c.columnCount > 16) c.getString(16) ?: "" else "",
                if (c.columnCount > 17) c.getString(17) ?: "" else "", if (c.columnCount > 18) c.getString(18) ?: "" else "",
                if (c.columnCount > 19) c.getString(19) ?: "" else "", if (c.columnCount > 20) c.getString(20) ?: "" else "",
                if (c.columnCount > 21) c.getInt(21) == 1 else listOf(17,18,19,20).any { i -> i < c.columnCount && !c.getString(i).isNullOrBlank() },
                if (c.columnCount > 22) c.getString(22) ?: "" else ""
            ))
        }
        return result
    }
    fun allSettings(): List<Pair<String,String>> {
        val result = mutableListOf<Pair<String,String>>()
        readableDatabase.rawQuery("SELECT key,value FROM settings ORDER BY key", null).use { c ->
            while(c.moveToNext()) result.add(c.getString(0) to c.getString(1))
        }
        allHolidays().forEach { (date,title) -> result.add("holiday:$date" to title) }
        return result
    }
    fun restoreBackup(days: List<WorkDay>, settings: List<Pair<String,String>>) {
        writableDatabase.beginTransaction()
        try {
            writableDatabase.delete("workdays", null, null)
            writableDatabase.delete("holidays", null, null)
            days.forEach { d ->
                val v = ContentValues().apply {
                    put("date",d.date); put("in1",d.in1); put("out1",d.out1)
                    put("in2",d.in2); put("out2",d.out2); put("in3",d.in3); put("out3",d.out3)
                    put("note",d.note); put("day_type",d.dayType); put("overtime_override",d.overtimeOverride); put("shift_enabled", if(d.shiftEnabled) 1 else 0); put("shift_start",d.shiftStart); put("shift_end",d.shiftEnd); put("shift_start_date",d.shiftStartDate); put("shift_end_date",d.shiftEndDate)
                    put("holiday_in", d.holidayIn); put("holiday_out", d.holidayOut); put("leave1_start", d.leave1Start); put("leave1_end", d.leave1End); put("leave2_start", d.leave2Start); put("leave2_end", d.leave2End); put("leave_enabled", if (d.hourlyLeaveEnabled) 1 else 0); put("extra_day_types", d.extraDayTypes)
                }
                writableDatabase.insertWithOnConflict("workdays",null,v,SQLiteDatabase.CONFLICT_REPLACE)
            }
            settings.forEach { (k,v) ->
                if (k.startsWith("holiday:")) {
                    val cv = ContentValues().apply { put("date",k.removePrefix("holiday:")); put("title",v) }
                    writableDatabase.insertWithOnConflict("holidays",null,cv,SQLiteDatabase.CONFLICT_REPLACE)
                } else if (!k.startsWith("continuousleave:")) {
                    val cv = ContentValues().apply { put("key",k); put("value",v) }
                    writableDatabase.insertWithOnConflict("settings",null,cv,SQLiteDatabase.CONFLICT_REPLACE)
                }
            }
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }
}

private data class DownloadedCalendarData(
    val holidays: List<Pair<String, String>>,
    val events: List<Pair<String, String>>
)

private fun fetchJson(url: String): org.json.JSONObject {
    val connection = java.net.URL(url).openConnection() as java.net.HttpURLConnection
    connection.requestMethod = "GET"
    connection.connectTimeout = 12_000
    connection.readTimeout = 18_000
    connection.setRequestProperty("Accept", "application/json")
    connection.setRequestProperty("User-Agent", "Morakh/0.30")
    try {
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        if (code !in 200..299) throw IllegalStateException("پاسخ سرویس تقویم: HTTP $code")
        return org.json.JSONObject(body)
    } finally { connection.disconnect() }
}

private fun fetchFarsiUiCalendarData(year: Int): DownloadedCalendarData? {
    // This source has an explicit, stable schema: items[].date, items[].title.fa,
    // and items[].isHoliday. It is the primary source to avoid schema drift in the
    // older Persian-Calendar API response.
    val base = "https://raw.githubusercontent.com/MiladJoodi/FarsiUI/main/calendar/years/$year"
    val holidayRoot = fetchJson("$base/holidays.json")
    if (holidayRoot.has("year") && holidayRoot.optInt("year", -1) != year) return null
    val holidayItems = holidayRoot.optJSONArray("items") ?: return null
    if (holidayItems.length() == 0) return null

    val holidays = linkedMapOf<String, MutableList<String>>()
    val allEvents = linkedMapOf<String, MutableList<String>>()
    fun add(target: MutableMap<String, MutableList<String>>, date: String, title: String) {
        val clean = title.trim()
        if (clean.isNotBlank()) {
            val list = target.getOrPut(date) { mutableListOf() }
            if (clean !in list) list.add(clean)
        }
    }
    fun parseItems(items: org.json.JSONArray, holidayOnly: Boolean) {
        for (i in 0 until items.length()) {
            val item = items.optJSONObject(i) ?: continue
            val date = item.optString("date")
            val parts = date.split("-").mapNotNull { it.toIntOrNull() }
            if (parts.size != 3 || parts[0] != year || parts[1] !in 1..12 || parts[2] !in 1..jalaliMonthLength(year, parts[1])) continue
            val titleObject = item.optJSONObject("title")
            val title = titleObject?.optString("fa").orEmpty().ifBlank { item.optString("title_fa") }
            if (title.isBlank()) continue
            if (!holidayOnly || item.optBoolean("isHoliday", item.optBoolean("is_holiday", false))) {
                if (item.optBoolean("isHoliday", item.optBoolean("is_holiday", false))) add(holidays, date, title)
            }
            add(allEvents, date, title)
        }
    }
    parseItems(holidayItems, holidayOnly = true)
    // Events file contains non-holiday observances, including non-holiday religious dates.
    val eventRoot = fetchJson("$base/events.json")
    if (eventRoot.has("year") && eventRoot.optInt("year", -1) != year) return null
    val eventItems = eventRoot.optJSONArray("items") ?: return null
    if (eventItems.length() == 0) return null
    parseItems(eventItems, holidayOnly = false)

    val holidayList = holidays.map { it.key to it.value.joinToString("، ") }
    val eventList = allEvents.map { it.key to it.value.joinToString("، ") }
    if (holidayList.isEmpty() || eventList.isEmpty()) return null
    return DownloadedCalendarData(holidayList, eventList)
}

private fun fetchCalendarData(year: Int): DownloadedCalendarData {
    require(year in 1347..1500) { "سال باید بین ۱۳۴۷ و ۱۵۰۰ باشد." }
    try {
        fetchFarsiUiCalendarData(year)?.let { return it }
    } catch (_: Exception) {
        // Use the documented Persian-Calendar API below as a fallback if this year
        // has not been published by FarsiUI or the static source is temporarily down.
    }
    val holidayRoot = try {
        fetchJson("https://www.persian-calendar.com/api/holidays?year=$year")
    } catch (e: Exception) {
        // No guessed lunar public holidays: preserve the previously saved calendar.
        throw e
    }
    if (holidayRoot.has("year") && holidayRoot.optInt("year", -1) != year) throw IllegalStateException("سال دریافت‌شده با سال درخواستی یکسان نیست.")
    val holidayDays = holidayRoot.optJSONArray("data") ?: throw IllegalStateException("فهرست تعطیلات معتبر نیست.")
    val holidays = linkedMapOf<String, MutableList<String>>()
    val allEvents = linkedMapOf<String, MutableList<String>>()

    fun addTitle(target: MutableMap<String, MutableList<String>>, date: String, title: String) {
        val cleaned = title.trim()
        if (cleaned.isNotBlank()) {
            val list = target.getOrPut(date) { mutableListOf() }
            if (cleaned !in list) list.add(cleaned)
        }
    }

    // The holidays endpoint is authoritative for days off and also supplies each holiday's title.
    for (i in 0 until holidayDays.length()) {
        val item = holidayDays.optJSONObject(i) ?: continue
        val month = item.optInt("month_sh", 0)
        val day = item.optInt("day_sh", 0)
        if (item.optInt("year_sh", year) != year || month !in 1..12 || day !in 1..jalaliMonthLength(year, month)) continue
        val date = "%04d-%02d-%02d".format(Locale.ROOT, year, month, day)
        val events = item.optJSONArray("events") ?: continue
        for (j in 0 until events.length()) {
            val event = events.optJSONObject(j) ?: continue
            val title = event.optString("title_fa").trim()
            if (event.optBoolean("is_holiday", false)) addTitle(holidays, date, title)
            // Put official holidays in the event list too, so their title is visible in every calendar view.
            addTitle(allEvents, date, title)
        }
    }

    // Fetch all other occasions month by month. A failed month must not discard the verified holiday list.
    for (month in 1..12) {
        try {
            val root = fetchJson("https://www.persian-calendar.com/api/events?year=$year&month_sh=$month")
            if (root.optInt("year", year) != year) continue
            val days = root.optJSONArray("data") ?: continue
            for (i in 0 until days.length()) {
                val item = days.optJSONObject(i) ?: continue
                val m = item.optInt("month_sh", month)
                val d = item.optInt("day_sh", 0)
                if (item.optInt("year_sh", year) != year || m !in 1..12 || d !in 1..jalaliMonthLength(year, m)) continue
                val date = "%04d-%02d-%02d".format(Locale.ROOT, year, m, d)
                // Current API returns one event per item; also accept nested event arrays for compatibility.
                val title = item.optString("title_fa").trim()
                if (title.isNotBlank()) addTitle(allEvents, date, title)
                val nested = item.optJSONArray("events")
                if (nested != null) for (j in 0 until nested.length()) {
                    val event = nested.optJSONObject(j) ?: continue
                    addTitle(allEvents, date, event.optString("title_fa"))
                    if (event.optBoolean("is_holiday", false)) addTitle(holidays, date, event.optString("title_fa"))
                }
            }
        } catch (_: Exception) {
            // Continue; official holiday data is still usable offline even if this month's occasions endpoint fails.
        }
    }

    // Do not mix calculated Hijri dates into an official holiday list. Iran's
    // announced lunar holiday dates can differ by a day from civil calculations.
    val holidayList = holidays.map { it.key to it.value.distinct().joinToString("، ") }
    val eventList = allEvents.map { it.key to it.value.distinct().joinToString("، ") }
    if (holidayList.isEmpty()) throw IllegalStateException("سرویس تعطیلات معتبری برنگرداند؛ اطلاعات قبلی حفظ شد.")
    if (eventList.isEmpty()) throw IllegalStateException("فهرست مناسبت‌ها خالی است؛ اطلاعات قبلی حفظ شد.")
    return DownloadedCalendarData(holidayList, eventList)
}

class MainActivity : ComponentActivity() {
    private lateinit var appDb: WorkDb
    private var systemDate by mutableStateOf(LocalDate.now())
    private var reportYear = 1405
    private var reportMonth = 1
    private var reportAnnual = false
    private var reportPdf = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        // Keep Android system status icons (time, signal, battery) visible.
        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN)
        // Match the system bars and the splash letterboxing to the warm ivory background
        // of the splash artwork, instead of showing dark teal strips.
        val splashIvory = android.graphics.Color.rgb(241, 246, 253)
        window.statusBarColor = splashIvory
        window.navigationBarColor = splashIvory
        window.decorView.systemUiVisibility =
            (window.decorView.systemUiVisibility and android.view.View.SYSTEM_UI_FLAG_FULLSCREEN.inv()) or
                android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val db = WorkDb(this)
        db.ensureBundled1405Calendar()
        appDb = db
        // Refresh enabled reminders and the optional date notification on every launch.
        CompanionAlerts.refresh(this)
        systemDate = LocalDate.now()
        setContent {
            var showIntro by remember { mutableStateOf(true) }
            LaunchedEffect(Unit) {
                kotlinx.coroutines.delay(1000)
                showIntro = false
            }
            if (showIntro) {
                // The splash artwork predates the brand rename and contains its
                // former title as pixels near the bottom. Cover just that section
                // and render the current product name as real Compose text.
                BoxWithConstraints(
                    modifier = Modifier.fillMaxSize().background(Color(0xFFFAFAF4)),
                    contentAlignment = Alignment.Center
                ) {
                    val artRatio = 940f / 1672f
                    val splashFrame = if (maxWidth / maxHeight <= artRatio) {
                        Modifier.fillMaxWidth().aspectRatio(artRatio)
                    } else {
                        Modifier.fillMaxHeight().aspectRatio(artRatio)
                    }
                    Box(modifier = splashFrame, contentAlignment = Alignment.Center) {
                        Image(
                            painter = painterResource(id = R.drawable.splash_vaghtnegar),
                            contentDescription = "مورخ",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.FillBounds
                        )
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .fillMaxHeight(0.22f)
                                .background(Color(0xFFFEFDF9)),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            PersianText(
                                "مورخ",
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Normal,
                                color = Color(0xFF087EAD)
                            )
                            Spacer(Modifier.height(7.dp))
                            PersianText(
                                "تقویم و مدیریت کارکرد",
                                fontSize = 17.sp,
                                color = Color(0xFF087EAD)
                            )
                        }
                    }
                }
            } else {
                KarkardApp(db, systemDate)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh the phone's local date whenever the app returns to the foreground.
        systemDate = LocalDate.now()
        CompanionAlerts.refresh(this)
        // Do not download prayer times automatically. Network refresh is intentionally
        // user-initiated via the dedicated "دریافت تازهٔ شهرها و اوقات شرعی" button.
    }

    fun selectAlertSound(prayer: Boolean, fileAudio: Boolean = false) {
        if (fileAudio) {
            val fileIntent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "audio/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(fileIntent,if(prayer) 5302 else 5301)
            return
        }
        val intent = Intent(android.media.RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TYPE, android.media.RingtoneManager.TYPE_ALL)
            putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
            putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TITLE, if(prayer) "صدای اذان" else "صدای یادآور")
            val selected = CompanionAlerts.ringtone(this@MainActivity,prayer)
            if(selected.isNotBlank()) putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,android.net.Uri.parse(selected))
        }
        startActivityForResult(intent,if(prayer) 5202 else 5201)
    }

    private var reportIncludeNotes: Boolean = true
    private var reportSummaryOnly: Boolean = false
    fun createReportExcel(year: Int, month: Int, annual: Boolean, includeNotes: Boolean = true, summaryOnly: Boolean = false) {
        reportIncludeNotes = includeNotes
        reportSummaryOnly = summaryOnly && annual
        reportYear = year; reportMonth = month; reportAnnual = annual; reportPdf = false
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            putExtra(Intent.EXTRA_TITLE, if (reportSummaryOnly) "مورخ_خلاصه_جامع_سال_$year.xlsx" else if (annual) "مورخ_گزارش_سالانه_$year.xlsx" else "مورخ_گزارش_ماهانه_${year}_$month.xlsx")
        }
        startActivityForResult(intent, 4103)
    }
    fun createReportPdf(year: Int, month: Int, annual: Boolean, includeNotes: Boolean = true, summaryOnly: Boolean = false) {
        reportIncludeNotes = includeNotes
        reportSummaryOnly = summaryOnly && annual
        reportYear = year; reportMonth = month; reportAnnual = annual; reportPdf = true
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"
            putExtra(Intent.EXTRA_TITLE, if (reportSummaryOnly) "مورخ_خلاصه_جامع_سال_$year.pdf" else if (annual) "مورخ_گزارش_سالانه_$year.pdf" else "مورخ_گزارش_ماهانه_${year}_$month.pdf")
        }
        startActivityForResult(intent, 4104)
    }
    fun chooseExcelRestore() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "text/csv", "text/comma-separated-values", "application/csv", "application/octet-stream"
            ))
        }
        startActivityForResult(intent, 4102)
    }
    fun createCsvBackup() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "پشتیبان_مورخ.csv")
        }
        startActivityForResult(intent, 4105)
    }
    fun createReminderCsvBackup() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "پشتیبان_یادآورهای_مورخ.csv")
        }
        startActivityForResult(intent, 4201)
    }
    fun createReminderExcelBackup() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            putExtra(Intent.EXTRA_TITLE, "پشتیبان_یادآورهای_مورخ.xlsx")
        }
        startActivityForResult(intent, 4202)
    }
    fun chooseReminderRestore() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "text/csv", "application/csv", "application/octet-stream"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, 4203)
    }
    fun createRemindersPdf() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"
            putExtra(Intent.EXTRA_TITLE, "یادآورهای_اقساط_و_جلسات_مورخ.pdf")
        }
        startActivityForResult(intent, 4204)
    }
    @Deprecated("Deprecated Android callback kept for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        if (requestCode == 5301 || requestCode == 5302) {
            data?.data?.let { audioUri ->
                try { contentResolver.takePersistableUriPermission(audioUri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                if (requestCode == 5302) {
                    AdhanSelection.setPending(this, audioUri.toString())
                    android.widget.Toast.makeText(this,"فایل اذان آمادهٔ پیش‌شنیدن و انتخاب است؛ صفحهٔ اذان را باز کن",android.widget.Toast.LENGTH_LONG).show()
                } else {
                    CompanionAlerts.saveRingtone(this,false,audioUri.toString())
                    android.widget.Toast.makeText(this,"آهنگ یادآور ذخیره شد",android.widget.Toast.LENGTH_SHORT).show()
                }
            }
            return
        }
        if (requestCode == 5201 || requestCode == 5202) {
            val ringtone = if (android.os.Build.VERSION.SDK_INT >= 33)
                data?.getParcelableExtra(android.media.RingtoneManager.EXTRA_RINGTONE_PICKED_URI,android.net.Uri::class.java)
            else data?.getParcelableExtra<android.net.Uri>(android.media.RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            ringtone?.let {
                CompanionAlerts.saveRingtone(this,requestCode == 5202,it.toString())
                android.widget.Toast.makeText(this,"صدای انتخاب‌شده ذخیره شد",android.widget.Toast.LENGTH_SHORT).show()
            }
            return
        }
        if (data?.data == null) return
        val uri = data.data!!
        try {
            if (requestCode == 4201) {
                val reminders = ReminderStore(this).all()
                contentResolver.openOutputStream(uri)?.use { it.write(buildReminderBackupCsv(reminders).toByteArray(Charsets.UTF_8)) } ?: error("فایل ذخیره نشد")
                android.widget.Toast.makeText(this, "پشتیبان CSV یادآورها ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
                return
            } else if (requestCode == 4202) {
                val reminders = ReminderStore(this).all()
                contentResolver.openOutputStream(uri)?.use { it.write(buildReminderBackupXlsx(reminders)) } ?: error("فایل ذخیره نشد")
                android.widget.Toast.makeText(this, "پشتیبان Excel یادآورها ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
                return
            } else if (requestCode == 4203) {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("فایل خوانده نشد")
                val reminders = if (bytes.size >= 2 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4b.toByte()) readReminderBackupXlsx(bytes)
                    else readReminderBackupCsv(String(bytes, Charsets.UTF_8).removePrefix("\uFEFF"))
                android.app.AlertDialog.Builder(this)
                    .setTitle("بازیابی پشتیبان یادآورها")
                    .setMessage("${reminders.size} یادآور در فایل پیدا شد. با ادامه، فهرست فعلی یادآورها با اطلاعات این فایل جایگزین می‌شود. ادامه می‌دهید؟")
                    .setNegativeButton("انصراف", null)
                    .setPositiveButton("بازیابی") { _, _ ->
                        try {
                            ReminderStore(this).replaceAll(reminders)
                            CompanionAlerts.refresh(this)
                            android.widget.Toast.makeText(this, "یادآورها با موفقیت بازیابی شدند", android.widget.Toast.LENGTH_LONG).show()
                        } catch (e: Exception) {
                            android.widget.Toast.makeText(this, "بازیابی یادآورها ناموفق بود: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                        }
                    }.show()
                return
            } else if (requestCode == 4204) {
                val reminders = ReminderStore(this).all()
                contentResolver.openOutputStream(uri)?.use { it.write(buildRemindersPdf(reminders)) } ?: error("فایل ذخیره نشد")
                android.widget.Toast.makeText(this, "خروجی PDF یادآورها ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
                return
            }
            if (requestCode == 4105) {
                val output = contentResolver.openOutputStream(uri) ?: error("فایل ذخیره نشد")
                output.use { it.write(buildBackupCsv(appDb).toByteArray(Charsets.UTF_8)) }
                android.widget.Toast.makeText(this, "فایل CSV پشتیبان ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
            } else if (requestCode == 4103) {
                contentResolver.openOutputStream(uri)?.use { it.write(buildReportXlsx(appDb, reportYear, reportMonth, reportAnnual, reportIncludeNotes, reportSummaryOnly)) }
                android.widget.Toast.makeText(this, "گزارش Excel ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
            } else if (requestCode == 4104) {
                contentResolver.openOutputStream(uri)?.use { it.write(buildReportPdf(appDb, reportYear, reportMonth, reportAnnual, reportIncludeNotes, reportSummaryOnly)) }
                android.widget.Toast.makeText(this, "گزارش PDF ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
            } else if (requestCode == 4102) {
                val input = contentResolver.openInputStream(uri) ?: error("فایل خوانده نشد")
                val bytes = input.use { it.readBytes() }
                val restored = if (bytes.size >= 2 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4b.toByte()) readBackupXlsx(bytes)
                    else readBackupCsv(String(bytes, Charsets.UTF_8).removePrefix("\uFEFF"))
                require(restored.first.isNotEmpty() || restored.second.isNotEmpty()) { "هیچ اطلاعات قابل بازیابی در فایل پیدا نشد" }
                val isReport = restored.second.any { it.first == "export_format" && it.second == "period_report_v1" }
                android.app.AlertDialog.Builder(this)
                    .setTitle(if(isReport) "ورود اطلاعات گزارش" else "بازیابی پشتیبان")
                    .setMessage(if(isReport) "فقط روزهای ثبت‌شدهٔ همین گزارش با داده‌های موجود ادغام می‌شوند؛ سایر ماه‌ها پاک نمی‌شوند. ادامه؟" else "با ادامه، اطلاعات فعلی جایگزین می‌شود. ادامه می‌دهید؟")
                    .setNegativeButton("انصراف", null)
                    .setPositiveButton("بازیابی") { _, _ ->
                        if(isReport) {
                            restored.first.forEach { appDb.saveDay(it) }
                        } else appDb.restoreBackup(restored.first, restored.second)
                        android.widget.Toast.makeText(this, "بازیابی انجام شد", android.widget.Toast.LENGTH_LONG).show()
                        // Recreate the activity so Home and monthly/yearly report caches reload
                        // the restored SQLite records, including shift fields from CSV.
                        recreate()
                    }.show()
            }
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, "خطا در فایل پشتیبان Excel/CSV: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
        }
    }
}

private fun formatTimeInput(raw: String): String {
    val digits = raw.toLatinDigits().filter { it.isDigit() }.take(4)
    return when (digits.length) {
        0, 1 -> digits
        2 -> digits
        else -> digits.substring(0, 2) + ":" + digits.substring(2)
    }
}

private fun mins(time: String): Int? {
    // Older records and imported CSVs can contain Persian/Arabic numerals.
    // Normalize before parsing so valid saved shift times are not dropped from reports.
    val p = time.toLatinDigits().trim().replace('٫', ':').replace('：', ':').split(":")
    if (p.size != 2) return null
    val h = p[0].toIntOrNull() ?: return null
    val m = p[1].toIntOrNull() ?: return null
    if (h !in 0..23 || m !in 0..59) return null
    return h*60+m
}
private fun timeRangeMinutes(startText: String, endText: String): Int {
    val start = mins(startText) ?: return 0
    val end = mins(endText) ?: return 0
    return if (end >= start) end - start else end + 24 * 60 - start
}
private fun hourlyLeaveMinutes(day: WorkDay): Int =
    if (!day.hourlyLeaveEnabled) 0 else
        timeRangeMinutes(day.leave1Start, day.leave1End) + timeRangeMinutes(day.leave2Start, day.leave2End)

private fun duration(day: WorkDay): Int {
    // An explicitly deselected day has no regular-work contribution.
    if (dayStatuses(day).isEmpty()) return 0
    // Holiday and leave work is tracked separately and counted as overtime only.
    if (isHolidayWorkDay(day)) return 0
    val gross = listOf(day.in1 to day.out1, day.in2 to day.out2, day.in3 to day.out3).sumOf { (a,b) ->
        val start = mins(a); val end = mins(b)
        if (start != null && end != null) { if (end >= start) end - start else (end + 24 * 60) - start } else 0
    }
    return (gross - hourlyLeaveMinutes(day)).coerceAtLeast(0)
}

private fun normalizeDateInput(raw: String): String {
    val digits = raw.toLatinDigits().filter { it.isDigit() }.take(8)
    return when {
        digits.length <= 4 -> digits
        digits.length <= 6 -> digits.take(4) + "-" + digits.drop(4)
        else -> digits.take(4) + "-" + digits.substring(4, 6) + "-" + digits.drop(6)
    }
}

private fun parsedJalaliDate(value: String): LocalDate? {
    val normalized = value.toLatinDigits().trim().replace('/', '-').replace('٫', '-')
    val parts = normalized.split("-").mapNotNull { it.trim().toIntOrNull() }
    if (parts.size != 3 || !isValidJalali(parts[0], parts[1], parts[2])) return null
    return jalaliToGregorian(parts[0], parts[1], parts[2])
}

private fun jalaliDateString(date: LocalDate): String {
    val (y, m, d) = gregorianToJalali(date)
    return "%04d-%02d-%02d".format(Locale.ROOT, y, m, d)
}

private fun defaultShiftEndDate(startDate: String, startTime: String, endTime: String): String {
    val start = parsedJalaliDate(startDate) ?: return startDate
    val startMinutes = mins(startTime)
    val endMinutes = mins(endTime)
    val endDate = if (startMinutes != null && endMinutes != null && endMinutes <= startMinutes) start.plusDays(1) else start
    return jalaliDateString(endDate)
}

private fun shiftDurationMinutes(day: WorkDay, fallbackDate: String = day.date): Int {
    if (!day.shiftEnabled) return 0

    val startDateText = day.shiftStartDate.ifBlank { fallbackDate }.toLatinDigits().trim().replace('/', '-')
    val endDateText = day.shiftEndDate.ifBlank {
        defaultShiftEndDate(startDateText, day.shiftStart, day.shiftEnd)
    }.toLatinDigits().trim().replace('/', '-')
    val startDate = parsedJalaliDate(startDateText) ?: return 0
    var endDate = parsedJalaliDate(endDateText) ?: return 0
    val startMinutes = mins(day.shiftStart) ?: return 0
    val endMinutes = mins(day.shiftEnd) ?: return 0

    // If both dates are the same but the entered end time is earlier (or equal),
    // treat the shift as crossing midnight. Explicit end dates on a later day
    // are respected as entered.
    if (endDate == startDate && endMinutes <= startMinutes) {
        endDate = startDate.plusDays(1)
    }
    if (endDate.isBefore(startDate)) return 0

    val total = (endDate.toEpochDay() - startDate.toEpochDay()) * 1440L +
        endMinutes.toLong() - startMinutes.toLong()
    return total.coerceIn(0L, 31L * 1440L).toInt()
}
private fun hm(n: Int) = "%02d:%02d".format(Locale.ROOT, n/60, n%60)

private fun jalaliWeekday(date: String): Int? {
    val p = date.split("-").mapNotNull { it.toIntOrNull() }
    if (p.size != 3 || !isValidJalali(p[0],p[1],p[2])) return null
    return jalaliToGregorian(p[0],p[1],p[2]).dayOfWeek.value % 7
    // Java Sunday=0, Saturday=6
}
private fun officialJalaliHolidays(year: Int): List<Pair<String,String>> {
    val fixed = mutableListOf<Triple<Int,Int,String>>()
    for (d in 1..4) fixed.add(Triple(1, d, "تعطیل رسمی نوروز"))
    fixed.add(Triple(1, 12, "روز جمهوری اسلامی"))
    fixed.add(Triple(1, 13, "روز طبیعت"))
    fixed.add(Triple(3, 14, "رحلت امام خمینی"))
    fixed.add(Triple(3, 15, "قیام ۱۵ خرداد"))
    fixed.add(Triple(11, 22, "پیروزی انقلاب اسلامی"))
    fixed.add(Triple(12, 29, "روز ملی شدن صنعت نفت"))
    return fixed.map { (m,d,title) -> "%04d-%02d-%02d".format(year,m,d) to title }
}

private fun defaultDayType(date: String): String =
    if (jalaliWeekday(date) == 5) "تعطیل رسمی" else "کاری"

private fun applyCalendarHoliday(day: WorkDay, db: WorkDb): WorkDay {
    val fixedHoliday = officialJalaliHolidays(day.date.take(4).toIntOrNull() ?: 0).toMap()[day.date]
    val officialTitle = db.officialHolidayTitle(day.date) ?: fixedHoliday
    return when {
        !officialTitle.isNullOrBlank() && day.dayType in setOf("کاری", "تعطیل") && day.extraDayTypes.isBlank() -> day.copy(dayType = "تعطیل رسمی")
        !db.holidayTitle(day.date).isNullOrBlank() && day.dayType == "کاری" && day.extraDayTypes.isBlank() -> day.copy(dayType = "تعطیل مناسبتی")
        else -> day
    }
}

/** Shifts belong to the report period in which they start, not merely the date row
 * on which the user happened to save the shift. Keep this rule consistent in all reports. */
private fun reportShifts(db: WorkDb, year: Int, month: Int? = null): List<WorkDay> {
    val prefix = if (month == null) "%04d-".format(year) else "%04d-%02d".format(year, month)
    // Read the persisted shift fields directly from every stored day. Assign a shift
    // to the period of its start date (not its row date or overnight end date), and
    // defensively deduplicate identical shift records before any report totals/counts.
    return db.allDaysForBackup()
        .asSequence()
        .filter { day ->
            if (!day.shiftEnabled) return@filter false
            // CSV imports and older app builds may persist Persian digits in date fields.
            // Normalize before period filtering so valid saved shifts are not silently omitted.
            val startDate = (day.shiftStartDate.ifBlank { day.date })
                .toLatinDigits().trim().replace('/', '-')
                .split('-').mapNotNull { it.toIntOrNull() }
                .takeIf { it.size == 3 && isValidJalali(it[0], it[1], it[2]) }
                ?.let { "%04d-%02d-%02d".format(Locale.ROOT, it[0], it[1], it[2]) }
                ?: return@filter false
            startDate.startsWith(prefix) &&
                mins(day.shiftStart) != null && mins(day.shiftEnd) != null
        }
        .distinctBy { day ->
            val start = day.shiftStartDate.ifBlank { day.date }.toLatinDigits().trim().replace('/', '-')
            val end = day.shiftEndDate.ifBlank { defaultShiftEndDate(start, day.shiftStart, day.shiftEnd) }.toLatinDigits().trim().replace('/', '-')
            listOf(start, day.shiftStart.toLatinDigits().trim(), end, day.shiftEnd.toLatinDigits().trim())
        }
        .toList()
}

private fun reportPeriodDays(db: WorkDb, year: Int, month: Int, annual: Boolean): List<WorkDay> {
    val stored = db.allDaysYear(year).associateBy { it.date }
    val months = if (annual) (1..12).toList() else listOf(month)
    return months.flatMap { m ->
        (1..jalaliMonthLength(year, m)).map { d ->
            val key = "%04d-%02d-%02d".format(year, m, d)
            val base = stored[key] ?: WorkDay(date = key, dayType = defaultDayType(key))
            applyCalendarHoliday(base, db)
        }
    }
}

private fun isHolidayWorkDay(day: WorkDay): Boolean =
    dayStatuses(day).any { it in workHolidayStatuses || it in workLeaveStatuses } ||
        day.dayType == "تعطیل" || jalaliWeekday(day.date) == 5

/** All leave balances exclude Friday and official or individually marked holiday days. */
private fun isExcludedLeaveHoliday(day: WorkDay, db: WorkDb): Boolean =
    jalaliWeekday(day.date) == 5 || dayStatuses(day).any { it in workHolidayStatuses } ||
    db.officialHolidayTitle(day.date) != null ||
    officialJalaliHolidays(day.date.take(4).toIntOrNull() ?: 0).any { it.first == day.date } ||
    db.holidayTitle(day.date) != null

private fun reportDayStatusText(day: WorkDay, db: WorkDb): String {
    val selected=dayStatuses(day).filter { it != "توراهی" }.joinToString(" + ") { if(it=="مرخصی") "استحقاقی" else it }
    return selected
}

private fun isEntitledCountable(day: WorkDay, db: WorkDb): Boolean =
    hasDayStatus(day,"مرخصی") && !isExcludedLeaveHoliday(day,db)
private fun isSickCountable(day: WorkDay, db: WorkDb): Boolean =
    hasDayStatus(day,"استعلاجی") && !isExcludedLeaveHoliday(day,db)
private fun periodLeaveStats(days: List<WorkDay>, db: WorkDb): Triple<Int,Int,Int> {
    val entitledCount = days.count { isEntitledCountable(it, db) }
    val sickCount = days.count { isSickCountable(it, db) }
    // Tourahi is a monthly deduction setting, never a daily status.
    return Triple(entitledCount, sickCount, 0)
}


private fun holidayWorkDurationMinutes(day: WorkDay): Int {
    val start = mins(day.holidayIn)
    val end = mins(day.holidayOut)
    if (start == null || end == null) return 0
    return if (end >= start) end - start else (end + 24 * 60) - start
}

private fun overtimeMinutes(day: WorkDay, db: WorkDb): Int {
    val override = mins(day.overtimeOverride)
    if (override != null) return override
    if (isHolidayWorkDay(day)) return holidayWorkDurationMinutes(day)
    if (!hasDayStatus(day,"کاری")) return 0
    val weekday = jalaliWeekday(day.date)
    val targetText = if (weekday == 4) db.getSettingText("thursday_hours_value") else db.getSettingText("workday_hours")
    val target = mins(targetText) ?: (if (weekday == 4) 300 else 420)
    return (duration(day) - target).coerceAtLeast(0)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KarkardApp(db: WorkDb, systemDate: LocalDate) {
    val context = LocalContext.current
    var screen by remember { mutableStateOf("home") }
    val nowJalali = remember(systemDate) { gregorianToJalali(systemDate) }
    var jalaliYear by remember { mutableIntStateOf(nowJalali.first) }
    var jalaliMonth by remember { mutableIntStateOf(nowJalali.second) }
    var date by remember { mutableStateOf("%04d-%02d-%02d".format(nowJalali.first, nowJalali.second, nowJalali.third)) }
    var lastObservedSystemDate by remember { mutableStateOf(systemDate) }
    LaunchedEffect(systemDate) {
        val previousDeviceDate = jalaliDateString(lastObservedSystemDate)
        val currentDeviceDate = jalaliDateString(systemDate)
        // Update automatically if the user is still on the previous phone-today date.
        // A deliberately selected earlier/later day is left alone.
        if (date == previousDeviceDate) {
            date = currentDeviceDate
            val parts = currentDeviceDate.split("-")
            if (parts.size == 3) {
                jalaliYear = parts[0].toIntOrNull() ?: jalaliYear
                jalaliMonth = parts[1].toIntOrNull() ?: jalaliMonth
            }
        }
        lastObservedSystemDate = systemDate
    }
    var refresh by remember { mutableIntStateOf(0) }
    var workRevision by remember { mutableIntStateOf(0) }
    var dayDirty by remember { mutableStateOf(false) }
    // One editor state for the lifetime of the screen. A keyed remember(date)
    // would recreate the mutable state during date navigation and could replace
    // the just-reloaded record with a stale frame's values.
    var day by remember {
        mutableStateOf(db.getDay(date).let { if (db.hasWorkDay(date)) it else it.copy(dayType=defaultDayType(date)) })
    }
    // Re-read persisted data whenever the selected date changes or the home screen
    // becomes visible again. Uncommitted editor state is intentionally discarded.
    // Reload the persisted record whenever Home is shown again, the selected date
    // changes, or a save/delete updates the data revision. This also handles returning
    // from another screen after the Home editor left composition.
    LaunchedEffect(screen, date, refresh, workRevision) {
        if (screen == "home" && !dayDirty) {
            day = db.getDay(date).let {
                if (db.hasWorkDay(date)) it else it.copy(dayType = defaultDayType(date))
            }
        } else if (screen == "home" && dayDirty) {
            // Do not discard unsaved edits while the user is still editing this date.
        }
    }
    var holidaySyncing by remember { mutableStateOf(false) }
    var holidaySyncMessage by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()
    val syncOfficialHolidays: (Int, Boolean) -> Unit = { yearToSync, force ->
        if (!holidaySyncing && (force || db.shouldSyncOfficialHolidays(yearToSync))) {
            holidaySyncing = true
            holidaySyncMessage = "در حال دریافت تعطیلات سال $yearToSync…"
            coroutineScope.launch {
                try {
                    val synced = withContext(Dispatchers.IO) {
                        val calendarData = fetchCalendarData(yearToSync)
                        db.replaceCalendarData(yearToSync, calendarData.holidays, calendarData.events)
                        db.setSettingText("calendar_last_online_$yearToSync", System.currentTimeMillis().toString())
                        calendarData.events.size
                    }
                    holidaySyncMessage = "تقویم سال $yearToSync به‌روزرسانی شد؛ $synced روز دارای مناسبت و ${db.officialHolidays(yearToSync).size} روز تعطیل رسمی ذخیره شد. پس از ذخیره، آفلاین هم در دسترس است."
                    refresh++
                } catch (e: Exception) {
                    val reason = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName
                    holidaySyncMessage = "به‌روزرسانی انجام نشد ($reason)؛ اطلاعات ذخیره‌شده حفظ شد. اینترنت را بررسی و دوباره تلاش کن."
                } finally {
                    holidaySyncing = false
                }
            }
        }
    }
    LaunchedEffect(jalaliYear) {
        syncOfficialHolidays(jalaliYear, false)
    }

    var lastBackPressed by remember { mutableLongStateOf(0L) }
    BackHandler {
        if (screen != "home") screen = "home"
        else {
            val now = android.os.SystemClock.elapsedRealtime()
            if (now - lastBackPressed < 2200L) (context as? MainActivity)?.finish()
            else {
                lastBackPressed = now
                android.widget.Toast.makeText(context, "برای خروج دوباره بازگشت را بزنید", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF173F71),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFDCEAFB),
            onPrimaryContainer = Color(0xFF173F71),
            secondary = Color(0xFF008F91),
            tertiary = Color(0xFFB48C42),
            background = Color(0xFFF1F6FD),
            surface = Color.White
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = MaterialTheme.colorScheme.background,
                topBar = {
                    // The title is centered against the entire screen, not the area left beside an action button.
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFF1F6FD))
                            // Respect Android status-bar and camera-cutout safe areas.
                            // Insets adapt automatically to each phone instead of using a fixed offset.
                            .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Top))
                            .height(60.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        IconButton(onClick = { screen = "prayer" }, modifier = Modifier.align(Alignment.CenterStart).padding(start = 4.dp).size(44.dp)) {
                            Icon(painter = painterResource(R.drawable.nav_prayer), contentDescription = "اوقات شرعی و اذان", tint = Color(0xFF173F71), modifier = Modifier.size(25.dp))
                        }
                        PersianText(
                            when (screen) {
                                "home" -> "خانه"
                                "calendar" -> "تقویم"
                                "report-monthly" -> "گزارش‌گیری ماهانه"
                                "report-annual" -> "گزارش‌گیری سالانه"
                                "settings" -> "تنظیمات"
                                "help" -> "راهنما"
                                "reminders" -> "یادآور اقساط و جلسات"
                                "prayer" -> "اوقات شرعی و اذان‌گو"
                                else -> "مورخ"
                            },
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 60.dp),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF123C70),
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                bottomBar = {
                    NavigationBar(containerColor = Color.White, tonalElevation = 8.dp, modifier = Modifier.heightIn(min = 67.dp)) {
                        listOf(
                            Triple("home", "خانه", R.drawable.nav_home),
                            Triple("report-monthly", "گزارش ماه", R.drawable.nav_report_month),
                            Triple("report-annual", "گزارش سال", R.drawable.nav_report_year),
                            Triple("calendar", "تقویم", R.drawable.nav_calendar),
                            Triple("reminders", "یادآورها", R.drawable.nav_reminder),
                            Triple("settings", "تنظیمات", R.drawable.nav_settings)
                        ).forEach { (target,label,iconRes) ->
                            NavigationBarItem(
                                selected = screen == target,
                                onClick = {
                                    if (target == "calendar") {
                                        val now = gregorianToJalali(LocalDate.now())
                                        jalaliYear = now.first; jalaliMonth = now.second
                                    }
                                    screen = target
                                },
                                icon = {
                                    Icon(
                                        painter = painterResource(iconRes),
                                        contentDescription = label,
                                        modifier = Modifier.size(if (target == "calendar") 22.dp else 24.dp),
                                        tint = if (screen == target) Color(0xFF173F71) else Color(0xFF62809F)
                                    )
                                },
                                label = { PersianText(label, fontSize = 8.sp, maxLines = 1, textAlign = TextAlign.Center) },
                                alwaysShowLabel = true
                            )
                        }
                    }
                }
            ) { padding ->
                when (screen) {
                    "settings" -> SettingsScreen(
                        db = db, modifier = Modifier.padding(padding),
                        onCsvBackup = { (context as? MainActivity)?.createCsvBackup() },
                        onRestore = { (context as? MainActivity)?.chooseExcelRestore() },
                        onReminderCsvBackup = { (context as? MainActivity)?.createReminderCsvBackup() },
                        onReminderExcelBackup = { (context as? MainActivity)?.createReminderExcelBackup() },
                        onReminderRestore = { (context as? MainActivity)?.chooseReminderRestore() },
                        onSyncHolidays = { selectedYear -> syncOfficialHolidays(selectedYear, true) },
                        syncYear = jalaliYear,
                        holidaySyncing = holidaySyncing,
                        holidaySyncMessage = holidaySyncMessage,
                        onRecordsDeleted = { deletedFrom, deletedUntil ->
                            refresh++
                            workRevision++
                            dayDirty = false
                            // Reload from SQLite after deletion. If the user chose to preserve
                            // توراهی, that minimal status row must remain visible in the editor.
                            // Rebuild the selected day immediately from the calendar baseline
                            // after range deletion; all deleted dates are now absent from workdays.
                            day = db.getDay(date).let {
                                if (db.hasWorkDay(date)) it else applyCalendarHoliday(WorkDay(date = date, dayType = defaultDayType(date)), db)
                            }
                        },
                        onHelp = { screen = "help" }
                    )
                    "help" -> HelpScreen(Modifier.padding(padding))
                    "reminders" -> RemindersScreen(
                        modifier = Modifier.padding(padding),
                        onPickRingtone = { fromFile -> (context as? MainActivity)?.selectAlertSound(false,fromFile) },
                        onExportPdf = { (context as? MainActivity)?.createRemindersPdf() }
                    )
                    "prayer" -> PrayerTimesScreen(
                        modifier = Modifier.padding(padding),
                        onPickRingtone = { fromFile -> (context as? MainActivity)?.selectAlertSound(true,fromFile) }
                    )
                    "calendar" -> JalaliCalendarScreen(
                        year = jalaliYear, month = jalaliMonth, selectedDate = jalaliDateString(LocalDate.now()),
                        onMonthChange = { y,m -> jalaliYear = y; jalaliMonth = m },
                        onSelectDate = { selected ->
                            date = selected
                            day = db.getDay(selected).let { if (db.hasWorkDay(selected)) it else it.copy(dayType=defaultDayType(selected)) }
                            val parts = selected.split("-")
                            if (parts.size == 3) { jalaliYear = parts[0].toInt(); jalaliMonth = parts[1].toInt() }
                            screen = "home"
                        },
                        modifier = Modifier.padding(padding),
                        holidays = remember(refresh, jalaliYear, jalaliMonth) {
                            (officialJalaliHolidays(jalaliYear) + db.officialHolidays(jalaliYear) + db.allHolidays()).toMap()
                        },
                        events = remember(refresh, jalaliYear, jalaliMonth) { db.calendarEvents(jalaliYear).toMap() },
                        hijriDayOffset = 0
                    )
                    "report-monthly" -> ReportScreen(
                        db = db, year = jalaliYear, monthNumber = jalaliMonth, refresh = refresh + workRevision,
                        modifier = Modifier.padding(padding), annual = false,
                        onPeriodChange = { y, m -> jalaliYear = y; jalaliMonth = m },
                        export = { a, notes -> (context as? MainActivity)?.createReportExcel(jalaliYear, jalaliMonth, a, notes) },
                        exportPdf = { a, notes -> (context as? MainActivity)?.createReportPdf(jalaliYear, jalaliMonth, a, notes) },
                        exportSummaryExcel = { notes -> (context as? MainActivity)?.createReportExcel(jalaliYear, jalaliMonth, true, notes, true) },
                        exportSummaryPdf = { notes -> (context as? MainActivity)?.createReportPdf(jalaliYear, jalaliMonth, true, notes, true) },
                        onOpenDay = { selected ->
                            date = selected
                            day = db.getDay(selected).let { if (db.hasWorkDay(selected)) it else it.copy(dayType = defaultDayType(selected)) }
                            val parts = selected.split("-")
                            if (parts.size == 3) { jalaliYear = parts[0].toIntOrNull() ?: jalaliYear; jalaliMonth = parts[1].toIntOrNull() ?: jalaliMonth }
                            dayDirty = false
                            workRevision++
                            screen = "home"
                        }
                    )
                    "report-annual" -> ReportScreen(
                        db = db, year = jalaliYear, monthNumber = jalaliMonth, refresh = refresh + workRevision,
                        modifier = Modifier.padding(padding), annual = true,
                        onPeriodChange = { y, m -> jalaliYear = y; jalaliMonth = m },
                        export = { a, notes -> (context as? MainActivity)?.createReportExcel(jalaliYear, jalaliMonth, a, notes) },
                        exportPdf = { a, notes -> (context as? MainActivity)?.createReportPdf(jalaliYear, jalaliMonth, a, notes) },
                        exportSummaryExcel = { notes -> (context as? MainActivity)?.createReportExcel(jalaliYear, jalaliMonth, true, notes, true) },
                        exportSummaryPdf = { notes -> (context as? MainActivity)?.createReportPdf(jalaliYear, jalaliMonth, true, notes, true) },
                        onOpenDay = { selected ->
                            date = selected
                            day = db.getDay(selected).let { if (db.hasWorkDay(selected)) it else it.copy(dayType = defaultDayType(selected)) }
                            val parts = selected.split("-")
                            if (parts.size == 3) { jalaliYear = parts[0].toIntOrNull() ?: jalaliYear; jalaliMonth = parts[1].toIntOrNull() ?: jalaliMonth }
                            dayDirty = false
                            workRevision++
                            screen = "home"
                        }
                    )
                    else -> key(date, refresh) { HomeDashboard(
                        modifier = Modifier.padding(padding), date = date, rawDay = day, isDayDirty = dayDirty,
                        jalaliYear = jalaliYear, jalaliMonth = jalaliMonth, db = db, refresh = refresh,
                        workRevision = workRevision,
                        onDateChange = { newDate ->
                            if (newDate != date && parsedJalaliDate(newDate) != null) {
                                // Writes are performed on each edit. Reload the destination explicitly,
                                // so returning to a visited date never shows a stale editor snapshot.
                                val destination = db.getDay(newDate).let {
                                    if (db.hasWorkDay(newDate)) it else it.copy(dayType = defaultDayType(newDate))
                                }
                                day = destination
                                dayDirty = false
                                date = newDate
                                workRevision++
                                val p = newDate.split("-")
                                if (p.size == 3) {
                                    jalaliYear = p[0].toIntOrNull() ?: jalaliYear
                                    jalaliMonth = p[1].toIntOrNull() ?: jalaliMonth
                                }
                            }
                        },
                        onDayChange = { updated ->
                            // Editing changes UI state only. Persistence is explicit via
                            // the "ذخیره اطلاعات روز" button.
                            day = updated.copy(date = date)
                            dayDirty = true
                        },
                        onSaved = { saved -> day = saved; dayDirty = false; date = saved.date; refresh++; workRevision++ },
                        onDayDeleted = {
                            val reset = WorkDay(date = date, dayType = defaultDayType(date))
                            day = reset
                            dayDirty = false
                            workRevision++
                            refresh++
                        },
                        onOpenCalendar = {
                            val now = gregorianToJalali(LocalDate.now())
                            jalaliYear = now.first; jalaliMonth = now.second
                            screen = "calendar"
                        }
                    ) }
                }
            }
        }
    }
}

@Composable
private fun HomeDashboard(
    modifier: Modifier,
    date: String,
    rawDay: WorkDay,
    isDayDirty: Boolean,
    jalaliYear: Int,
    jalaliMonth: Int,
    db: WorkDb,
    refresh: Int,
    workRevision: Int,
    onDateChange: (String) -> Unit,
    onDayChange: (WorkDay) -> Unit,
    onSaved: (WorkDay) -> Unit,
    onDayDeleted: () -> Unit,
    onOpenCalendar: () -> Unit
) {
    val context = LocalContext.current
    val day = if (isDayDirty) rawDay else applyCalendarHoliday(rawDay, db)
    val calendarTitle = remember(date, refresh) { db.displayHolidayTitle(date) ?: officialJalaliHolidays(date.take(4).toIntOrNull() ?: jalaliYear).toMap()[date] }
    val monthPrefix = "%04d-%02d".format(jalaliYear, jalaliMonth)
    val monthDays = remember(jalaliYear, jalaliMonth) { (1..31).filter { isValidJalali(jalaliYear, jalaliMonth, it) } }
    val recordedDays = remember(refresh, workRevision, monthPrefix) { db.allDays(monthPrefix) }
    val monthWork = recordedDays.sumOf { duration(it) }
    val monthOvertime = recordedDays.sumOf { overtimeMinutes(it, db) }
    val missionCount = recordedDays.count { hasDayStatus(it,"مأموریت") }
    val monthlyHourlyLeave = recordedDays.sumOf { hourlyLeaveMinutes(it) }
    // The home month summary uses the same leave totals as the monthly/yearly reports.
    // Travel days must not also count as entitlement days.
    val (rawEntitledLeaveCount, sickLeaveCount, _) = periodLeaveStats(recordedDays, db)
    val savedHomeTourahiDeduction = db.getSettingText("tourahi_deduction_$monthPrefix", "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
    val entitledLeaveCount = (rawEntitledLeaveCount - savedHomeTourahiDeduction).coerceAtLeast(0)
    val homeTravelCount = savedHomeTourahiDeduction
    val dateParts = date.split("-").mapNotNull { it.toIntOrNull() }
    val dateDay = dateParts.getOrElse(2) { 1 }
    val weekday = jalaliWeekday(date)?.let { JalaliWeekdayNames.getOrNull(it) }.orEmpty()
    // Re-read on date change and when returning from the reminders page.
    // The HomeDashboard composable leaves composition while that page is open.
    val dayReminders = remember(date) { ReminderStore(context).forJalaliDay(date) }
    var holidayReason by remember(date, refresh) { mutableStateOf(db.holidayTitle(date).orEmpty()) }
    // Visibility belongs to the UI, not the saved work record. Existing entries are
    // expanded automatically when the user opens a day that already has those times.
    var showSecondWorkPair by remember(date) {
        mutableStateOf(day.in2.isNotBlank() || day.out2.isNotBlank() || day.in3.isNotBlank() || day.out3.isNotBlank())
    }
    var showThirdWorkPair by remember(date) {
        mutableStateOf(day.in3.isNotBlank() || day.out3.isNotBlank())
    }
    var confirmDayDeletion by remember(date) { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 5.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        contentPadding = PaddingValues(bottom = 8.dp)
    ) {
        item {
            val homeShiftDays = remember(monthPrefix, refresh, workRevision) { reportShifts(db, jalaliYear, jalaliMonth) }
            val homeShiftMinutes = homeShiftDays.sumOf { shiftDurationMinutes(it, it.shiftStartDate.ifBlank { it.date }) }
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FBFF)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().border(1.5.dp, Color(0xFFBEDBFA), RoundedCornerShape(12.dp))
            ) {
              Column(Modifier.fillMaxWidth().padding(7.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                PersianText(
                    "خلاصه کارکرد ماه ${JalaliMonthNames[jalaliMonth - 1]} ${persianDigits(jalaliYear.toString())}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF073B45),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp)
                )
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFCFDFF)),
                    shape = RoundedCornerShape(9.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFD9E6F5), RoundedCornerShape(9.dp))
                ) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            ReportMetricTile("جمع کارکرد", hm(monthWork), "◷", Color(0xFF153F78), Modifier.weight(1f))
                            ReportMetricTile("اضافه‌کار", hm(monthOvertime), "◴", OvertimeGreenText, Modifier.weight(1f))
                            ReportMetricTile("مرخصی ساعتی", hm(monthlyHourlyLeave), "◷", Color(0xFF153F78), Modifier.weight(1f))
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            ReportMetricTile("استحقاقی", persianDigits(entitledLeaveCount.toString()), "☼", Color(0xFF153F78), Modifier.weight(1f))
                            ReportMetricTile("استعلاجی", persianDigits(sickLeaveCount.toString()), "✚", Color(0xFF153F78), Modifier.weight(1f))
                            ReportMetricTile("مأموریت", persianDigits(missionCount.toString()), "✈", Color(0xFF153F78), Modifier.weight(1f))
                            ReportMetricTile("توراهی", persianDigits(homeTravelCount.toString()), "↗", Color(0xFF153F78), Modifier.weight(1f))
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            ReportMetricTile("تعداد شیفت", persianDigits(homeShiftDays.size.toString()), "▦", Color(0xFF153F78), Modifier.weight(1f))
                            ReportMetricTile("جمع مدت شیفت", hm(homeShiftMinutes), "◷", ShiftYellowText, Modifier.weight(1f))
                        }
                    }
                }
              }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            IconButton(onClick = {
                                val prev = parsedJalaliDate(date)?.minusDays(1)?.let { jalaliDateString(it) }
                                if (prev != null) onDateChange(prev)
                            }, modifier = Modifier.size(44.dp)) {
                                PersianText("‹", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color(0xFF075565))
                            }
                            PersianText("روز قبل", fontSize = 9.sp, color = Color(0xFF426A6D), maxLines = 1)
                        }
                        PersianText("روز $dateDay از ${monthDays.size}", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF173F71))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            IconButton(onClick = {
                                val next = parsedJalaliDate(date)?.plusDays(1)?.let { jalaliDateString(it) }
                                if (next != null) onDateChange(next)
                            }, modifier = Modifier.size(44.dp)) {
                                PersianText("›", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color(0xFF075565))
                            }
                            PersianText("روز بعد", fontSize = 9.sp, color = Color(0xFF426A6D), maxLines = 1)
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        // The calendar symbol next to the weekday is removed.
                        // Tapping the weekday/date itself still opens the calendar.
                        Column(
                            modifier = Modifier.clickable(onClick = onOpenCalendar)
                                .padding(horizontal = 6.dp, vertical = 5.dp),
                            horizontalAlignment = Alignment.End,
                            verticalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            PersianText(weekday, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF073B45))
                            PersianText(jalaliDisplayDate(date), fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color(0xFF426A6D))
                        }
                    }
                }
            }
        }
        // Show actual saved reminders for this date immediately below the day/date card.
        // Several reminders on the same date are all visible; past one-off entries
        // are not silently hidden, and monthly reminders follow their Jalali due day.
        if (dayReminders.isNotEmpty()) {
            item(key = "day_reminders_$date") {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF4F0FF)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFD7CBEE), RoundedCornerShape(12.dp))
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        PersianText("یادآورهای این روز", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF45316F))
                        dayReminders.forEachIndexed { index, reminder ->
                            if (index > 0) Divider(color = Color(0xFFE1D8F0))
                            val reminderTime = java.time.Instant.ofEpochMilli(reminder.whenMillis)
                                .atZone(java.time.ZoneId.systemDefault()).toLocalTime()
                                .format(DateTimeFormatter.ofPattern("HH:mm", Locale.ROOT))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(9.dp)
                            ) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    PersianText(
                                        "${reminder.kind}: ${reminder.title}",
                                        fontSize = 13.sp,
                                        color = Color(0xFF303B59),
                                        lineHeight = 18.sp
                                    )
                                    if (reminder.monthly) {
                                        PersianText("تکرار ماهانه", fontSize = 10.sp, color = Color(0xFF74618E))
                                    }
                                }
                                PersianText(
                                    "ساعت ${reminderTime}",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF45316F),
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
        if (!calendarTitle.isNullOrBlank()) {
            item {
                val isOfficialCalendarHoliday = db.officialHolidayTitle(date) != null || officialJalaliHolidays(jalaliYear).toMap().containsKey(date)
                Card(
                    colors = CardDefaults.cardColors(containerColor = if (isOfficialCalendarHoliday) Color(0xFFFFF0F0) else Color(0xFFFFF8E5)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, if (isOfficialCalendarHoliday) Color(0xFFE57373) else Color(0xFFE5C34A), RoundedCornerShape(10.dp))
                ) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        PersianText(if (isOfficialCalendarHoliday) "تعطیل رسمی" else "مناسبت تقویم", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (isOfficialCalendarHoliday) Color(0xFFB3261E) else Color(0xFF795500))
                        PersianText(calendarTitle, fontSize = 12.sp, color = if (isOfficialCalendarHoliday) Color(0xFF7F1D1D) else Color(0xFF5F4500))
                    }
                }
            }
        }
        item {
            val dayTypes = listOf(
                "کاری" to "◷", "تعطیل رسمی" to "♜", "مرخصی" to "☼",
                "مأموریت" to "✈", "استعلاجی" to "✚", "تعطیل مناسبتی" to "▦"
            )
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFD5E3F2), RoundedCornerShape(12.dp))
            ) {
                Column(Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    PersianText("نوع روز", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF173F71))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                dayTypes.forEach { (type, symbol) ->
                    val selected = hasDayStatus(day,type)
                    Card(
                        modifier = Modifier.weight(1f).height(59.dp).border(1.dp, if (selected) Color(0xFF6BA1F9) else Color(0xFFB6D0CE), RoundedCornerShape(10.dp)),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFFE3EEFF) else Color.White),
                        onClick = { onDayChange(toggleDayStatus(day,type)) }
                    ) {
                        Column(Modifier.fillMaxSize().padding(horizontal = 2.dp, vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            PersianText(symbol, fontSize = 18.sp, color = if (selected) Color(0xFF1556A6) else Color(0xFF426A6D), maxLines = 1)
                            PersianText(if (type == "مرخصی") "استحقاقی" else type, fontSize = 9.sp, color = if (selected) Color(0xFF1556A6) else Color(0xFF426A6D), textAlign = TextAlign.Center, maxLines = 2, lineHeight = 11.sp)
                        }
                    }
                    }
                }
            }
        }
        }
        if (hasDayStatus(day,"تعطیل مناسبتی")) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFB6D0CE), RoundedCornerShape(10.dp))) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        PersianText("علت تعطیلی (اختیاری)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF073B45))
                        OutlinedTextField(
                            value = holidayReason.toPersianDigits(),
                            onValueChange = {
                                holidayReason = it
                                // Persist the title while typing; changing dates will not lose it.
                                if (hasDayStatus(day,"تعطیل مناسبتی")) {
                                    if (it.isBlank()) db.removeHoliday(date)
                                    else db.saveHoliday(date, it.trim())
                                }
                            },
                            placeholder = { PersianText("علت تعطیلی را وارد کنید", fontSize = 12.sp, color = Color(0xFF7E9ABD)) },
                            leadingIcon = { PersianText("✎", fontSize = 18.sp) },
                            modifier = Modifier.fillMaxWidth(), singleLine = true,
                            textStyle = TextStyle(fontSize = 12.sp, textAlign = TextAlign.Start),
                        )
                    }
                }
            }
        }
        if (isHolidayWorkDay(day)) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = OvertimeGreen.copy(alpha = 0.55f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF99D5A8), RoundedCornerShape(12.dp))
                ) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 7.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        PersianText(if (dayStatuses(day).any { it in workLeaveStatuses }) "ثبت اضافه‌کاری در روز مرخصی" else "ساعت کار در روز تعطیل", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = OvertimeGreenText)
                        PersianText("زمان ثبت‌شده در این بخش، تماماً اضافه‌کاری محاسبه می‌شود.", fontSize = 10.sp, color = OvertimeGreenText)
                        CompactTimePairRow("تعطیل", "ورود", day.holidayIn, "خروج", day.holidayOut,
                            { onDayChange(day.copy(holidayIn = it)) },
                            { onDayChange(day.copy(holidayOut = it)) })
                        PersianText("اضافه‌کاری تعطیل: ${hm(holidayWorkDurationMinutes(day))}", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = OvertimeGreenText)
                    }
                }
            }
        } else {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        PersianText("ساعت کار روزانه", modifier = Modifier.fillMaxWidth(), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color(0xFF073B45), textAlign = TextAlign.Start)
                        Divider(color = Color(0xFFC8DCD9))
                        CompactTimePairRow("۱", "ورود", day.in1, "خروج", day.out1, { onDayChange(day.copy(in1=it)) }, { onDayChange(day.copy(out1=it)) }, fieldFontSize = 13)
                        // The next two pairs are optional. Collapsing only hides the
                        // fields; it never clears recorded arrival/departure times.
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            OutlinedButton(
                                onClick = {
                                    showSecondWorkPair = !showSecondWorkPair
                                    if (!showSecondWorkPair) showThirdWorkPair = false
                                },
                                modifier = Modifier.heightIn(min = 32.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                            ) { PersianText(if (showSecondWorkPair) "۲ −" else "۲ +", fontSize = 13.sp) }
                            if (showSecondWorkPair) {
                                OutlinedButton(
                                    onClick = { showThirdWorkPair = !showThirdWorkPair },
                                    modifier = Modifier.heightIn(min = 32.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                                ) { PersianText(if (showThirdWorkPair) "۳ −" else "۳ +", fontSize = 13.sp) }
                            }
                        }
                        if (showSecondWorkPair) {
                            Divider(color = Color(0xFFC8DCD9))
                            CompactTimePairRow("۲", "ورود", day.in2, "خروج", day.out2, { onDayChange(day.copy(in2=it)) }, { onDayChange(day.copy(out2=it)) }, fieldFontSize = 13)
                        }
                        if (showSecondWorkPair && showThirdWorkPair) {
                            Divider(color = Color(0xFFC8DCD9))
                            CompactTimePairRow("۳", "ورود", day.in3, "خروج", day.out3, { onDayChange(day.copy(in3=it)) }, { onDayChange(day.copy(out3=it)) }, fieldFontSize = 13)
                        }
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF2E5D7)), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFD5B99F), RoundedCornerShape(12.dp))) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        PersianText("مرخصی ساعتی", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color(0xFF073B45))
                        Switch(
                            checked = day.hourlyLeaveEnabled,
                            onCheckedChange = { onDayChange(day.copy(hourlyLeaveEnabled = it)) }
                        )
                    }
                    if (day.hourlyLeaveEnabled) {
                        Divider(color = Color(0xFFC8DCD9))
                        CompactTimePairRow("۱", "از ساعت", day.leave1Start, "الی ساعت", day.leave1End, { onDayChange(day.copy(leave1Start=it)) }, { onDayChange(day.copy(leave1End=it)) })
                        Divider(color = Color(0xFFC8DCD9))
                        CompactTimePairRow("۲", "از ساعت", day.leave2Start, "الی ساعت", day.leave2End, { onDayChange(day.copy(leave2Start=it)) }, { onDayChange(day.copy(leave2End=it)) })
                        PersianText("مجموع مرخصی ساعتی: ${hm(hourlyLeaveMinutes(day))}", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF0B6865))
                    }
                }
            }
        }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEE)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFFFD24D), RoundedCornerShape(12.dp))
            ) {
                Column(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().background(Color(0xFFFFF6DD)).padding(horizontal = 9.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
                        PersianText("☼", fontSize = 21.sp, color = Color(0xFFE9A600))
                        Spacer(Modifier.width(6.dp))
                        PersianText("شیفت کاری", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = ShiftYellowText)
                        Spacer(Modifier.weight(1f))
                        Switch(checked = day.shiftEnabled, onCheckedChange = { enabled ->
                            val start = day.shiftStartDate.ifBlank { date }
                            onDayChange(day.copy(
                                shiftEnabled = enabled,
                                shiftStart = if (enabled && day.shiftStart.isBlank()) "17:00" else day.shiftStart,
                                shiftEnd = if (enabled && day.shiftEnd.isBlank()) "07:00" else day.shiftEnd,
                                shiftStartDate = if (enabled && day.shiftStartDate.isBlank()) date else day.shiftStartDate,
                                shiftEndDate = if (enabled && day.shiftEndDate.isBlank()) defaultShiftEndDate(start, "17:00", "07:00") else day.shiftEndDate
                            ))
                        })
                    }
                    if (day.shiftEnabled) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 5.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        // Row 1: shift dates
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Top) {
                            CompactShiftField("تاریخ شروع", jalaliDisplayDate(day.shiftStartDate.ifBlank { date }), Modifier.weight(1f), true) {
                                // SplitDateField already owns year/month/day separators.
                                // Preserve partially edited segments; never merge them back
                                // into a new 8-digit stream while the user is typing.
                                val newStartDate = it
                                val oldStartDate = day.shiftStartDate.ifBlank { date }
                                val oldAutomaticEndDate = defaultShiftEndDate(oldStartDate, day.shiftStart, day.shiftEnd)
                                val endDateWasAutomatic = day.shiftEndDate.isBlank() || day.shiftEndDate == oldStartDate || day.shiftEndDate == oldAutomaticEndDate
                                val computedEnd = if (endDateWasAutomatic && parsedJalaliDate(newStartDate) != null)
                                    defaultShiftEndDate(newStartDate, day.shiftStart, day.shiftEnd) else day.shiftEndDate
                                onDayChange(day.copy(shiftStartDate = newStartDate, shiftEndDate = computedEnd))
                            }
                            CompactShiftField("تاریخ پایان", jalaliDisplayDate(day.shiftEndDate.ifBlank { defaultShiftEndDate(day.shiftStartDate.ifBlank { date }, day.shiftStart.ifBlank { "17:00" }, day.shiftEnd.ifBlank { "07:00" }) }), Modifier.weight(1f), true) { onDayChange(day.copy(shiftEndDate=it)) }
                        }
                        // Row 2: shift times
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Top) {
                            CompactShiftField("ساعت شروع", day.shiftStart.ifBlank { "17:00" }, Modifier.weight(1f), false) {
                                val startDate = day.shiftStartDate.ifBlank { date }
                                val oldAutomaticEndDate = defaultShiftEndDate(startDate, day.shiftStart, day.shiftEnd)
                                val endDateWasAutomatic = day.shiftEndDate.isBlank() || day.shiftEndDate == startDate || day.shiftEndDate == oldAutomaticEndDate
                                onDayChange(day.copy(shiftStart = it, shiftStartDate = startDate, shiftEndDate = if (endDateWasAutomatic) defaultShiftEndDate(startDate, it, day.shiftEnd) else day.shiftEndDate))
                            }
                            CompactShiftField("ساعت پایان", day.shiftEnd.ifBlank { "07:00" }, Modifier.weight(1f), false) {
                                val startDate = day.shiftStartDate.ifBlank { date }
                                val oldAutomaticEndDate = defaultShiftEndDate(startDate, day.shiftStart, day.shiftEnd)
                                val endDateWasAutomatic = day.shiftEndDate.isBlank() || day.shiftEndDate == startDate || day.shiftEndDate == oldAutomaticEndDate
                                onDayChange(day.copy(shiftEnd = it, shiftStartDate = startDate, shiftEndDate = if (endDateWasAutomatic) defaultShiftEndDate(startDate, day.shiftStart, it) else day.shiftEndDate))
                            }
                        }
                        }
                    }
                    PersianText("مدت شیفت: ${hm(shiftDurationMinutes(day, date))}", modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp), fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = ShiftYellowText)
                    Spacer(Modifier.height(5.dp))
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PersianText("▤", fontSize = 20.sp, color = Color(0xFF426A6D))
                        Spacer(Modifier.width(6.dp))
                        PersianText("یادداشت روز", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color(0xFF073B45))
                    }
                    OutlinedTextField(value = day.note.toPersianDigits(), onValueChange = { onDayChange(day.copy(note=it)) }, placeholder = { PersianText("یادداشت اختیاری…", fontSize = 11.sp) }, modifier = Modifier.fillMaxWidth(), minLines = 1, maxLines = Int.MAX_VALUE, textStyle = TextStyle(fontSize = 12.sp))

                }
            }
        }
        item {
            Button(
                onClick = {
                    val p = date.toLatinDigits().replace('/', '-').split("-").mapNotNull { it.toIntOrNull() }
                    if (p.size == 3 && isValidJalali(p[0], p[1], p[2])) {
                        val normalized = "%04d-%02d-%02d".format(p[0], p[1], p[2])
                        val startDate = day.shiftStartDate.ifBlank { normalized }
                        val endDate = day.shiftEndDate.ifBlank { defaultShiftEndDate(startDate, day.shiftStart, day.shiftEnd) }
                        val savedDay = day.copy(date=normalized, shiftStartDate=startDate, shiftEndDate=endDate)
                        if (savedDay.shiftEnabled && (parsedJalaliDate(startDate) == null || parsedJalaliDate(endDate) == null)) {
                            android.widget.Toast.makeText(context, "تاریخ شروع و پایان شیفت معتبر نیست.", android.widget.Toast.LENGTH_LONG).show()
                        } else if (savedDay.shiftEnabled && (mins(savedDay.shiftStart) == null || mins(savedDay.shiftEnd) == null)) {
                            android.widget.Toast.makeText(context, "ساعت شروع و پایان شیفت را درست وارد کنید.", android.widget.Toast.LENGTH_LONG).show()
                        } else {
                            db.saveDayAndHoliday(
                                savedDay,
                                holidayReason.takeIf { hasDayStatus(savedDay, "تعطیل مناسبتی") }
                            )
                            onSaved(savedDay)
                            android.widget.Toast.makeText(context, "اطلاعات روز ذخیره شد", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().heightIn(min = 38.dp),
                contentPadding = PaddingValues(vertical = 5.dp)
            ) { PersianText("ذخیره اطلاعات روز", fontSize = 13.sp) }
        }
        item {
            OutlinedButton(
                onClick = { confirmDayDeletion = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFB3261E))
            ) { PersianText("حذف اطلاعات روز", fontSize = 13.sp) }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                SummaryMiniTile("مجموع کارکرد", hm(duration(day)), Color(0xFFEAF3FF), Color(0xFF075565), Modifier.weight(1f))
                SummaryMiniTile("اضافه‌کار", hm(overtimeMinutes(day, db)), OvertimeGreen, OvertimeGreenText, Modifier.weight(1f))
                SummaryMiniTile("مدت شیفت", hm(shiftDurationMinutes(day, date)), ShiftYellow, ShiftYellowText, Modifier.weight(1f))
            }
        }
    }

    if (confirmDayDeletion) AlertDialog(
        onDismissRequest = { confirmDayDeletion = false },
        title = { PersianText("حذف تمام اطلاعات این روز", fontWeight = FontWeight.Bold) },
        text = { PersianText("تمام اطلاعات ثبت‌شدهٔ ${jalaliDisplayDate(date)}، شامل یادداشت، ساعت‌ها، شیفت، مرخصی، مأموریت و علت تعطیلی پاک می‌شود. آیا مطمئنی؟ آیا پشتیبان گرفته‌ای؟") },
        confirmButton = {
            TextButton(onClick = {
                val deletedDates = db.deleteDay(date)
                confirmDayDeletion = false
                // Reset in-memory editor fields even if the saved row was already absent;
                // unsaved UI values must not remain visible after an explicit delete action.
                onDayDeleted()
                val message = if (deletedDates > 0) "تمام اطلاعات این روز حذف و به حالت پیش‌فرض بازگردانده شد"
                    else "اطلاعات ذخیره‌شده‌ای نبود؛ فرم روز به حالت پیش‌فرض بازگردانده شد"
                android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_LONG).show()
            }) { PersianText("بله، حذف شود", color = Color(0xFFB3261E)) }
        },
        dismissButton = {
            TextButton(onClick = { confirmDayDeletion = false }) { PersianText("لغو") }
        }
    )


}

@Composable
private fun MonthMetric(label: String, value: String, symbol: String, valueColor: Color, modifier: Modifier, unit: String = "ساعت") {
    Column(modifier.padding(horizontal = 2.dp, vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            PersianText(symbol, fontSize = 13.sp, color = valueColor, maxLines = 1)
            Spacer(Modifier.width(2.dp))
            PersianText(label, fontSize = 10.sp, color = Color(0xFF426A6D), maxLines = 2, textAlign = TextAlign.Center, lineHeight = 11.sp)
        }
        PersianText(value, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = valueColor, maxLines = 1)
        PersianText(unit, fontSize = 8.sp, color = Color(0xFF426A6D), maxLines = 1)
    }
}

@Composable
private fun MetricDivider() {
    Box(Modifier.width(1.dp).height(44.dp).background(Color(0xFFB6D0CE)))
}

@Composable
private fun CompactTimePairRow(index: String, label1: String, value1: String, label2: String, value2: String, onChange1: (String) -> Unit, onChange2: (String) -> Unit, fieldFontSize: Int = 17) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Box(Modifier.size(25.dp).background(Color(0xFFDDEBE8), RoundedCornerShape(50)), contentAlignment = Alignment.Center) { PersianText(index, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF075565)) }
            CompactTimeTextField(label1, value1, onChange1, Modifier.weight(1f), fieldFontSize)
            CompactTimeTextField(label2, value2, onChange2, Modifier.weight(1f), fieldFontSize)
        }
    }
}

@Composable
private fun CompactTimeTextField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier, fieldFontSize: Int = 17) {
    SplitTimeField(label, value, onChange, modifier, fieldFontSize)
}

@Composable
private fun CompactShiftField(label: String, value: String, modifier: Modifier, isDate: Boolean, onChange: (String) -> Unit) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        PersianText(label, fontSize = 8.sp, color = Color(0xFF426A6D), textAlign = TextAlign.Center, maxLines = 2, lineHeight = 9.sp)
        if (isDate) {
            SplitDateField(value, onChange, Modifier.fillMaxWidth())
        } else {
            SplitTimeField("", value, onChange, Modifier.fillMaxWidth(), 13)
        }
    }
}

/**
 * Extract what the user actually typed, excluding the old value that the IME
 * included in the editing event. Cursor moves/selection changes produce no digits.
 */
private fun insertedDigits(oldText: String, newText: String): String {
    val old = oldText.toLatinDigits()
    val new = newText.toLatinDigits()
    val commonPrefix = old.indices.takeWhile { it < new.length && old[it] == new[it] }.count()
    var oldEnd = old.length
    var newEnd = new.length
    while (oldEnd > commonPrefix && newEnd > commonPrefix && old[oldEnd - 1] == new[newEnd - 1]) {
        oldEnd--
        newEnd--
    }
    return new.substring(commonPrefix, newEnd).filter(Char::isDigit)
}

/**
 * Touching a field only arms replacement. The old digits remain visible and
 * unselected until the first new digit is actually entered. This also avoids
 * focus jumps caused by selection-only TextFieldValue updates.
 */
@Composable
private fun ReplaceableNumberField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier,
    maxDigits: Int,
    fontSize: TextUnit,
    imeAction: ImeAction,
    placeholder: String = ""
) {
    var input by remember { mutableStateOf(TextFieldValue(value.toPersianDigits())) }
    var replaceOnNextDigit by remember { mutableStateOf(false) }
    SideEffect {
        if (input.text.toLatinDigits() != value.toLatinDigits()) {
            val shown = value.toPersianDigits()
            input = TextFieldValue(shown, selection = TextRange(shown.length))
        }
    }
    OutlinedTextField(
        value = input,
        onValueChange = { incoming ->
            if (incoming.text == input.text) {
                // Pure selection/caret movement: do not publish, do not auto-advance.
                input = incoming
            } else {
                val added = insertedDigits(input.text, incoming.text)
                val cleaned = if (replaceOnNextDigit && added.isNotEmpty()) {
                    replaceOnNextDigit = false
                    added.take(maxDigits)
                } else {
                    replaceOnNextDigit = false
                    incoming.text.toLatinDigits().filter(Char::isDigit).take(maxDigits)
                }
                val shown = cleaned.toPersianDigits()
                input = TextFieldValue(shown, selection = TextRange(shown.length))
                if (cleaned != value.toLatinDigits()) onValueChange(cleaned)
            }
        },
        modifier = modifier
            // Re-arm replacement on *every* tap, even when this field already has focus.
            // The initial-pass listener does not consume the tap or select the old text.
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    replaceOnNextDigit = true
                    waitForUpOrCancellation()
                }
            }
            .onFocusChanged { focus ->
                if (focus.isFocused) replaceOnNextDigit = true
                else replaceOnNextDigit = false
            },
        singleLine = true,
        textStyle = TextStyle(fontSize = fontSize, textAlign = TextAlign.Center),
        placeholder = if (placeholder.isNotBlank()) { { PersianText(placeholder, fontSize = 9.sp) } } else null,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = imeAction)
    )
}

/** The same first-new-digit replacement rule for HH:MM settings values. */
@Composable
private fun ReplaceableSettingsTimeField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String
) {
    var input by remember { mutableStateOf(TextFieldValue(value.toPersianDigits())) }
    var replaceOnNextDigit by remember { mutableStateOf(false) }
    SideEffect {
        if (input.text.toLatinDigits() != value.toLatinDigits()) {
            val shown = value.toPersianDigits()
            input = TextFieldValue(shown, selection = TextRange(shown.length))
        }
    }
    OutlinedTextField(
        value = input,
        onValueChange = { incoming ->
            if (incoming.text == input.text) {
                input = incoming
            } else {
                val added = insertedDigits(input.text, incoming.text)
                val normalized = if (replaceOnNextDigit && added.isNotEmpty()) {
                    replaceOnNextDigit = false
                    formatTimeInput(added)
                } else {
                    replaceOnNextDigit = false
                    formatTimeInput(incoming.text)
                }
                val shown = normalized.toPersianDigits()
                input = TextFieldValue(shown, selection = TextRange(shown.length))
                if (normalized != value.toLatinDigits()) onValueChange(normalized)
            }
        },
        label = { PersianText(label) },
        modifier = Modifier.fillMaxWidth()
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    replaceOnNextDigit = true
                    waitForUpOrCancellation()
                }
            }
            .onFocusChanged { focus -> replaceOnNextDigit = focus.isFocused },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done)
    )
}

/**
 * Reminder-only field row with absolute LEFT-to-RIGHT screen coordinates.
 * Unlike a normal Row, its physical order is independent of the outer Persian
 * RTL layout direction: place() (not placeRelative()) is intentional.
 */
@Composable
private fun ReminderPhysicalLtrRow(
    weights: List<Float>,
    modifier: Modifier = Modifier,
    gap: Dp = 4.dp,
    content: @Composable () -> Unit
) {
    androidx.compose.ui.layout.Layout(content = content, modifier = modifier) { measurables, constraints ->
        require(measurables.size == weights.size) { "Every reminder field requires a width weight" }
        val gapPx = gap.roundToPx()
        val width = constraints.maxWidth
        val available = (width - gapPx * (measurables.size - 1)).coerceAtLeast(0)
        val sumWeights = weights.sum().coerceAtLeast(0.01f)
        var usedWidth = 0
        val placeables = measurables.mapIndexed { index, measurable ->
            val childWidth = if (index == measurables.lastIndex) {
                available - usedWidth
            } else {
                (available * weights[index] / sumWeights).toInt().coerceAtLeast(0)
            }
            usedWidth += childWidth
            measurable.measure(androidx.compose.ui.unit.Constraints(
                minWidth = childWidth,
                maxWidth = childWidth,
                minHeight = 0,
                maxHeight = constraints.maxHeight
            ))
        }
        val height = placeables.maxOfOrNull { it.height } ?: 0
        layout(width, height) {
            var x = 0
            placeables.forEach { item ->
                item.place(x, height - item.height)
                x += item.width + gapPx
            }
        }
    }
}

/** Persian reminder year/month/day, physically left to right on screen. */
@Composable
fun ReminderDateFieldLeftToRight(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val parts = value.toLatinDigits().replace('-', '/').split('/')
    val year = parts.getOrElse(0) { "" }.take(4)
    val month = parts.getOrElse(1) { "" }.take(2)
    val day = parts.getOrElse(2) { "" }.take(2)
    val monthFocus = remember { FocusRequester() }
    val dayFocus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    fun publish(y: String, m: String, d: String) {
        onChange(when {
            y.isBlank() && m.isBlank() && d.isBlank() -> ""
            else -> y + (if (m.isNotEmpty() || d.isNotEmpty()) "-" + m else "") + (if (d.isNotEmpty()) "-" + d else "")
        })
    }
    ReminderPhysicalLtrRow(listOf(1.15f, 0.85f, 0.85f), modifier.fillMaxWidth()) {
        ReplaceableNumberField(
            value = year,
            onValueChange = { y -> publish(y, month, day); if (y.length == 4) monthFocus.requestFocus() },
            modifier = Modifier.height(50.dp), maxDigits = 4, fontSize = 13.sp,
            placeholder = "سال", imeAction = ImeAction.Next
        )
        ReplaceableNumberField(
            value = month,
            onValueChange = { m -> publish(year, m, day); if (m.length == 2) dayFocus.requestFocus() },
            modifier = Modifier.height(50.dp).focusRequester(monthFocus), maxDigits = 2,
            fontSize = 13.sp, placeholder = "ماه", imeAction = ImeAction.Next
        )
        ReplaceableNumberField(
            value = day,
            onValueChange = { d -> publish(year, month, d); if (d.length == 2) keyboard?.hide() },
            modifier = Modifier.height(50.dp).focusRequester(dayFocus), maxDigits = 2,
            fontSize = 13.sp, placeholder = "روز", imeAction = ImeAction.Done
        )
    }
}

/** Persian reminder hour/minute, physically left to right on screen. */
@Composable
fun ReminderTimeFieldLeftToRight(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val parts = value.toLatinDigits().split(':')
    val hour = parts.getOrElse(0) { "" }.take(2)
    val minute = parts.getOrElse(1) { "" }.take(2)
    val minuteFocus = remember { FocusRequester() }
    ReminderPhysicalLtrRow(listOf(1f, 0.07f, 1f), modifier.fillMaxWidth(), 3.dp) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
            PersianText("ساعت", fontSize = 9.sp, maxLines = 1, color = Color(0xFF426A6D))
            ReplaceableNumberField(
                value = hour,
                onValueChange = { h ->
                    onChange(if (h.isBlank() && minute.isBlank()) "" else "$h:$minute")
                    if (h.length == 2) minuteFocus.requestFocus()
                },
                modifier = Modifier.fillMaxWidth().height(54.dp), maxDigits = 2,
                fontSize = 17.sp, imeAction = ImeAction.Next
            )
        }
        Box(Modifier.height(54.dp), contentAlignment = Alignment.Center) {
            PersianText(":", fontSize = 16.sp, maxLines = 1)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
            PersianText("دقیقه", fontSize = 9.sp, maxLines = 1, color = Color(0xFF426A6D))
            ReplaceableNumberField(
                value = minute,
                onValueChange = { m -> onChange(if (hour.isBlank() && m.isBlank()) "" else "$hour:$m") },
                modifier = Modifier.fillMaxWidth().height(54.dp).focusRequester(minuteFocus), maxDigits = 2,
                fontSize = 17.sp, imeAction = ImeAction.Done
            )
        }
    }
}

@Composable
fun SplitDateField(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val parts = value.toLatinDigits().replace('-', '/').split('/')
    val year = parts.getOrElse(0) { "" }.take(4)
    val month = parts.getOrElse(1) { "" }.take(2)
    val day = parts.getOrElse(2) { "" }.take(2)
    val monthFocus = remember { FocusRequester() }
    val dayFocus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    fun publish(y: String, m: String, d: String) {
        val out = when {
            y.isBlank() && m.isBlank() && d.isBlank() -> ""
            else -> y + (if (m.isNotEmpty() || d.isNotEmpty()) "-" + m else "") + (if (d.isNotEmpty()) "-" + d else "")
        }
        onChange(out)
    }
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
        ReplaceableNumberField(
            value = year,
            onValueChange = { y -> publish(y, month, day); if (y.length == 4) monthFocus.requestFocus() },
            modifier = Modifier.weight(1.15f).height(50.dp),
            maxDigits = 4, fontSize = 13.sp, placeholder = "سال", imeAction = ImeAction.Next
        )
        ReplaceableNumberField(
            value = month,
            onValueChange = { m -> publish(year, m, day); if (m.length == 2) dayFocus.requestFocus() },
            modifier = Modifier.weight(0.85f).height(50.dp).focusRequester(monthFocus),
            maxDigits = 2, fontSize = 13.sp, placeholder = "ماه", imeAction = ImeAction.Next
        )
        ReplaceableNumberField(
            value = day,
            onValueChange = { d -> publish(year, month, d); if (d.length == 2) keyboard?.hide() },
            modifier = Modifier.weight(0.85f).height(50.dp).focusRequester(dayFocus),
            maxDigits = 2, fontSize = 13.sp, placeholder = "روز", imeAction = ImeAction.Done
        )
    }
}

@Composable
private fun SummaryMiniTile(label: String, value: String, background: Color, foreground: Color, modifier: Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = background), shape = RoundedCornerShape(10.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 3.dp, vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
            PersianText(label, fontSize = 10.sp, color = foreground, textAlign = TextAlign.Center, maxLines = 1)
            PersianText(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = foreground, maxLines = 1)
            PersianText("ساعت", fontSize = 8.sp, color = foreground)
        }
    }
}

@Composable
fun SplitTimeField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, fieldFontSize: Int = 17) {
    // One controlled implementation for daily entry, hourly leave and work shifts.
    // Do not reset internal hour/minute state after every parent save/recomposition.
    val parts = value.toLatinDigits().split(":")
    val hour = parts.getOrElse(0) { "" }.take(2)
    val minute = parts.getOrElse(1) { "" }.take(2)
    val minuteFocus = remember { FocusRequester() }
    val stableClockFontSize = fieldFontSize.coerceIn(15, 17).sp
    Column(modifier, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        if (label.isNotBlank()) PersianText(label, fontSize = 10.sp, maxLines = 1)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                PersianText("ساعت", fontSize = 9.sp, maxLines = 1, color = Color(0xFF426A6D))
                ReplaceableNumberField(
                    value = hour,
                    onValueChange = { typedHour ->
                        onChange(if (typedHour.isBlank() && minute.isBlank()) "" else "$typedHour:$minute")
                        // A real edit reaches 2 digits; a mere tap/selection never calls this.
                        if (typedHour.length == 2) minuteFocus.requestFocus()
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    maxDigits = 2,
                    fontSize = stableClockFontSize,
                    imeAction = ImeAction.Next
                )
            }
            Box(Modifier.height(54.dp), contentAlignment = Alignment.Center) {
                PersianText(":", fontSize = 16.sp, maxLines = 1)
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                PersianText("دقیقه", fontSize = 9.sp, maxLines = 1, color = Color(0xFF426A6D))
                ReplaceableNumberField(
                    value = minute,
                    onValueChange = { typedMinute ->
                        onChange(if (hour.isBlank() && typedMinute.isBlank()) "" else "$hour:$typedMinute")
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp).focusRequester(minuteFocus),
                    maxDigits = 2,
                    fontSize = stableClockFontSize,
                    imeAction = ImeAction.Done
                )
            }
        }
    }
}

@Composable
fun TimePair(label1: String, v1: String, label2: String, v2: String, c1: (String)->Unit, c2: (String)->Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        SplitTimeField(label1, v1, c1, Modifier.weight(1f))
        SplitTimeField(label2, v2, c2, Modifier.weight(1f))
    }
}

@Composable
fun SettingsScreen(
    db: WorkDb,
    modifier: Modifier = Modifier,
    onCsvBackup: () -> Unit,
    onRestore: () -> Unit,
    onReminderCsvBackup: () -> Unit,
    onReminderExcelBackup: () -> Unit,
    onReminderRestore: () -> Unit,
    onSyncHolidays: (Int) -> Unit,
    syncYear: Int,
    holidaySyncing: Boolean,
    holidaySyncMessage: String,
    onRecordsDeleted: (String, String) -> Unit,
    onHelp: () -> Unit
) {
    var tick by remember { mutableIntStateOf(0) }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF173F71)), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                PersianText("مورخ", fontSize = 24.sp, fontWeight = FontWeight.Normal, color = Color.White, maxLines = 1)
                PersianText("تنظیمات، پشتیبان‌گیری و شخصی‌سازی برنامه", fontSize = 12.sp, color = Color(0xFFD9EAFB))
            }
        }
        PersianText("امکانات و تقویم", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF173F71))
        PersianText("تعطیلات و همهٔ مناسبت‌های تقویم ایران", style = MaterialTheme.typography.titleMedium)
        PersianText("سال شمسی را انتخاب کن تا تعطیلات رسمی و مناسبت‌های ملی، مذهبی، فرهنگی و جهانی همان سال دریافت و روی گوشی ذخیره شوند. پس از ذخیره، بدون اینترنت هم در دسترس‌اند. تاریخ قمری آینده ممکن است تا اعلام رسمی تخمینی باشد.", style = MaterialTheme.typography.bodySmall)
        var selectedCalendarYear by remember(syncYear) { mutableIntStateOf(syncYear) }
        var yearMenuExpanded by remember { mutableStateOf(false) }
        Box {
            OutlinedButton(onClick = { yearMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                PersianText("سال انتخاب‌شده: ${selectedCalendarYear.toString().toPersianDigits()}  ▾")
            }
            DropdownMenu(expanded = yearMenuExpanded, onDismissRequest = { yearMenuExpanded = false }) {
                (maxOf(1347, syncYear - 5)..minOf(1500, syncYear + 10)).forEach { optionYear ->
                    DropdownMenuItem(text = { PersianText(optionYear.toString().toPersianDigits()) }, onClick = {
                        selectedCalendarYear = optionYear
                        yearMenuExpanded = false
                    })
                }
            }
        }
        Button(onClick = { onSyncHolidays(selectedCalendarYear) }, enabled = !holidaySyncing, modifier = Modifier.fillMaxWidth()) {
            PersianText(if (holidaySyncing) "در حال دریافت تقویم…" else "دریافت مناسبت‌های سال انتخاب‌شده")
        }
        if (holidaySyncMessage.isNotBlank()) PersianText(holidaySyncMessage, style = MaterialTheme.typography.bodySmall, color = if (holidaySyncMessage.contains("نشد")) Color(0xFFB3261E) else Color(0xFF075565))
        val syncedAt = remember(selectedCalendarYear, tick, holidaySyncMessage) { db.getSettingText("calendar_last_online_$selectedCalendarYear", "0").toLongOrNull() ?: 0L }
        PersianText("آخرین به‌روزرسانی آنلاین تقویم: " + if (syncedAt == 0L) "هنوز انجام نشده" else formattedSyncStamp(syncedAt), fontSize = 11.sp, color = Color(0xFF52708F))
        Divider()
        PersianText("تاریخ قمری آبان ۱۴۰۵ با مرجع تقویم تطبیق داده می‌شود؛ برای سایر تاریخ‌ها نمایش محاسباتی است.", fontSize = 11.sp, color = Color(0xFF52708F))
        AlertManagementSettings()
        Divider()
        OutlinedButton(onClick = onHelp, modifier = Modifier.fillMaxWidth()) {
            PersianText("راهنمای جامع استفاده از مورخ")
        }
        Divider()
        DeleteWorkRecordsPanel(db = db, onDeleted = { start, end -> tick++; onRecordsDeleted(start, end) })
        Divider()
        PersianText("پشتیبان‌گیری و بازیابی", style = MaterialTheme.typography.titleMedium)
        Button(onClick = onCsvBackup, modifier = Modifier.fillMaxWidth()) { PersianText("ساخت پشتیبان کارکرد CSV (.csv)") }
        OutlinedButton(onClick = onRestore, modifier = Modifier.fillMaxWidth()) { PersianText("بازیابی اطلاعات کارکرد از csv") }
        PersianText("پشتیبان کارکرد روزانه با CSV ساخته می‌شود. فایل‌های Excel پشتیبان قدیمی نیز برای بازیابی قابل انتخاب‌اند.", style = MaterialTheme.typography.bodySmall)
        PersianText("دسترسی به فایل‌ها از طریق انتخابگر امن اندروید انجام می‌شود و نیازی به دسترسی کامل حافظه نیست.", fontSize = 11.sp, color = Color(0xFF52708F))
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PersianText("پشتیبان‌گیری و بازیابی یادآورها", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF1B5E20))
                PersianText("این بخش فقط مربوط به یادآورهای اقساط و جلسات است و از اطلاعات کارکرد روزانه جداست.", fontSize = 12.sp, color = Color(0xFF2E6034))
                OutlinedButton(onClick = onReminderCsvBackup, modifier = Modifier.fillMaxWidth()) { PersianText("ساخت پشتیبان یادآورها با CSV") }
                OutlinedButton(onClick = onReminderExcelBackup, modifier = Modifier.fillMaxWidth()) { PersianText("ساخت پشتیبان یادآورها با Excel") }
                Button(onClick = onReminderRestore, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))) { PersianText("بازیابی پشتیبان یادآورها (CSV یا Excel)") }
            }
        }
        var dailyHours by remember { mutableStateOf(db.getSettingText("workday_hours","07:00")) }
        var thursdayHours by remember { mutableStateOf(db.getSettingText("thursday_hours_value","05:00")) }
        PersianText("ساعت موظفی", style = MaterialTheme.typography.titleMedium)
        ReplaceableSettingsTimeField(dailyHours, { dailyHours = it }, "شنبه تا چهارشنبه (HH:MM)")
        ReplaceableSettingsTimeField(thursdayHours, { thursdayHours = it }, "پنجشنبه (HH:MM)")
        Button(onClick = {
            if (mins(dailyHours) != null && mins(thursdayHours) != null) {
                db.setSettingText("workday_hours",dailyHours)
                db.setSettingText("thursday_hours_value",thursdayHours)
                tick++
            }
        }, modifier = Modifier.fillMaxWidth()) { PersianText("ذخیره ساعت موظفی") }
        Divider()
        Spacer(Modifier.height(12.dp))
        PersianText("نسخهٔ برنامه: ۰.۴۴.۰", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 12.sp, color = Color(0xFF52708F))
        PersianText("تهیه کننده: نواب", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF173F71))
        Spacer(Modifier.height(8.dp))
        PersianText(
            "ثواب بهره‌برداری از این اثر نثار امام شهید و یاران او",
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp),
            textAlign = TextAlign.Center,
            fontSize = 15.sp, fontFamily = FontFamily(Font(R.font.aref_ruqaa_regular)),
            fontWeight = FontWeight.Normal, color = Color(0xFF173F71), lineHeight = 25.sp
        )
    }
}



@Composable
private fun DeleteWorkRecordsPanel(db: WorkDb, onDeleted: (String, String) -> Unit) {
    val today = remember { val (y, m, d) = gregorianToJalali(LocalDate.now()); "%04d-%02d-%02d".format(y, m, d) }
    var from by remember { mutableStateOf(today) }
    var until by remember { mutableStateOf(today) }
    var error by remember { mutableStateOf("") }
    var proposed by remember { mutableIntStateOf(0) }
    var confirm by remember { mutableStateOf(false) }
    var acceptPermanent by remember { mutableStateOf(false) }
    var acceptBackup by remember { mutableStateOf(false) }

    fun normalized(input: String): String? {
        val fields = input.toLatinDigits().replace('/', '-').split('-')
        if (fields.size != 3) return null
        val numbers = fields.map { it.toIntOrNull() ?: return null }
        if (!isValidJalali(numbers[0], numbers[1], numbers[2])) return null
        return "%04d-%02d-%02d".format(numbers[0], numbers[1], numbers[2])
    }
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7F5)), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            PersianText("حذف اطلاعات کارکرد در بازهٔ زمانی", fontWeight = FontWeight.Bold, color = Color(0xFFB3261E))
            PersianText("تمام اطلاعات روزهای بازه، شامل ساعت‌ها، یادداشت، نوع روز، شیفت، مرخصی، مأموریت و علت تعطیلی پاک و به حالت پیش‌فرض برمی‌گردند؛ تقویم رسمی و تنظیمات دست‌نخورده می‌مانند.", fontSize = 12.sp)
            PersianText("توجه: اگر برای این ماه «توراهی» ثبت کرده‌اید، باید آن را به‌صورت دستی از صفحهٔ گزارش ماه حذف کنید.", fontSize = 12.sp, color = Color(0xFF7B3F91), fontWeight = FontWeight.SemiBold)
            PersianText("از تاریخ شمسی", fontSize = 12.sp)
            ReminderDateFieldLeftToRight(from, { from = it }, Modifier.fillMaxWidth())
            PersianText("تا تاریخ شمسی (شامل خود این روز)", fontSize = 12.sp)
            ReminderDateFieldLeftToRight(until, { until = it }, Modifier.fillMaxWidth())
            if (error.isNotBlank()) PersianText(error, color = Color(0xFFB3261E), fontSize = 12.sp)
            OutlinedButton(onClick = {
                val a = normalized(from); val b = normalized(until)
                when {
                    a == null || b == null -> error = "تاریخ شروع یا پایان معتبر نیست."
                    a > b -> error = "تاریخ شروع نباید بعد از پایان باشد."
                    else -> {
                        proposed = db.countWorkRecords(a,b)
                        if (proposed == 0) {
                            error = "در این بازه هیچ اطلاعاتی برای حذف وجود ندارد."
                            confirm = false
                        } else {
                            error = ""
                            acceptPermanent = false; acceptBackup = false; confirm = true
                        }
                    }
                }
            }, modifier = Modifier.fillMaxWidth()) { PersianText("بررسی تعداد رکوردها و درخواست حذف") }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { PersianText("تأیید حذف ${persianDigits(proposed.toString())} روز", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (proposed == 0) PersianText("در پایگاه داده رکوردی برای این بازه پیدا نشد؛ با تأیید، فرم روز انتخاب‌شده در صورت قرار داشتن در این بازه نیز به حالت پیش‌فرض برمی‌گردد.", fontSize = 12.sp)
                PersianText("تمام ساعت‌ها، یادداشت‌ها، نوع روز، شیفت‌ها، مرخصی‌ها، مأموریت و علت تعطیلی در این بازه پاک و به حالت پیش‌فرض برمی‌گردند. آیا مطمئنی؟ آیا پشتیبان گرفته‌ای؟\nپس از حذف، بازیابی بدون نسخهٔ پشتیبان ممکن نیست.")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = acceptPermanent, onCheckedChange = { acceptPermanent = it })
                    PersianText("بله، از حذف دائمی مطمئن هستم.", fontSize = 12.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = acceptBackup, onCheckedChange = { acceptBackup = it })
                    PersianText("پشتیبان دارم یا مسئولیت حذف بدون پشتیبان را می‌پذیرم.", fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            TextButton(enabled = acceptPermanent && acceptBackup, onClick = {
                val a = normalized(from); val b = normalized(until)
                if (a != null && b != null && a <= b) {
                    // Verify that the number of records has not changed since preview.
                    if (db.countWorkRecords(a, b) != proposed) {
                        error = "تعداد رکوردها تغییر کرده است؛ دوباره بازه را بررسی کن."
                    } else {
                        val count = db.deleteWorkRecords(a, b, preserveTourahiInRange = false, deleteTourahiInMonths = false)
                        error = "${persianDigits(count.toString())} روز حذف شد."
                        onDeleted(a, b)
                    }
                }
                confirm = false
            }) { PersianText("حذف قطعی", color = Color(0xFFB3261E)) }
        },
        dismissButton = { TextButton(onClick = { confirm = false }) { PersianText("انصراف") } }
    )
}

@Composable
fun SummaryTile(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.fillMaxWidth().padding(vertical = 10.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            PersianText(value, style = MaterialTheme.typography.titleMedium)
            PersianText(label, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportScreen(
    db: WorkDb, year: Int, monthNumber: Int, refresh: Int,
    modifier: Modifier = Modifier, annual: Boolean,
    onPeriodChange: (Int, Int) -> Unit,
    export: (Boolean, Boolean) -> Unit, exportPdf: (Boolean, Boolean) -> Unit,
    exportSummaryExcel: (Boolean) -> Unit, exportSummaryPdf: (Boolean) -> Unit,
    onOpenDay: (String) -> Unit = {}
) {
    var monthMenuExpanded by remember { mutableStateOf(false) }
    var yearMenuExpanded by remember { mutableStateOf(false) }
    var includeReportNotes by remember { mutableStateOf(true) }
    val reportListState = androidx.compose.foundation.lazy.rememberLazyListState()
    val todayJalali = remember { jalaliDateString(LocalDate.now()) }
    val monthKey = "%04d-%02d".format(year, monthNumber)
    val deductionSettingKey = "tourahi_deduction_$monthKey"
    var savedTourahiDeduction by remember(monthKey, refresh) {
        mutableStateOf(db.getSettingText(deductionSettingKey, "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0)
    }
    var tourahiDeductionInput by remember(monthKey, refresh) { mutableStateOf(TextFieldValue("")) }
    val storedMonthDays = remember(monthKey, refresh) { db.allDays(monthKey).associateBy { it.date } }
    val reportDays = remember(year, monthNumber, refresh) { reportPeriodDays(db, year, monthNumber, false) }
    val yearDays = remember(year, refresh) { reportPeriodDays(db, year, monthNumber, true) }
    val yearPrefix = "%04d-".format(year)
    val yearShiftMinutes = remember(year, refresh) {
        reportShifts(db, year)
            .sumOf { shiftDurationMinutes(it, it.shiftStartDate.ifBlank { it.date }) }
    }
    val monthShiftDays = remember(monthKey, refresh) {
        reportShifts(db, year, monthNumber)
    }
    val selectedDays = if (annual) yearDays else reportDays
    val totalWork = selectedDays.sumOf { duration(it) }
    val totalOvertime = selectedDays.sumOf { overtimeMinutes(it, db) }
    val totalShift = if (annual) yearShiftMinutes else monthShiftDays.sumOf { shiftDurationMinutes(it, it.shiftStartDate.ifBlank { it.date }) }
    // Count shifts by their start date, exactly like their duration, so overnight
    // shifts are attributed to one and only one reporting month/year.
    val shiftCount = if (annual) reportShifts(db, year).size else monthShiftDays.size
    val missionCount = selectedDays.count { hasDayStatus(it,"مأموریت") }
    val (rawEntitledCount, sickCount, _) = periodLeaveStats(selectedDays,db)
    val savedDeductionTotal = if (annual) (1..12).sumOf { m ->
        db.getSettingText("tourahi_deduction_%04d-%02d".format(year, m), "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
    } else savedTourahiDeduction
    val effectiveDeductionTotal = if (annual) (1..12).sumOf { m ->
        val requested = db.getSettingText("tourahi_deduction_%04d-%02d".format(year, m), "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
        val prefix = "%04d-%02d".format(year, m)
        val monthEntitledRaw = yearDays.filter { it.date.startsWith(prefix) }.count { isEntitledCountable(it, db) }
        minOf(requested, monthEntitledRaw)
    } else minOf(savedTourahiDeduction, rawEntitledCount)
    val entitledCount = (rawEntitledCount - effectiveDeductionTotal).coerceAtLeast(0)
    val tourahiCount = savedDeductionTotal

    LaunchedEffect(year, monthNumber, annual, refresh, todayJalali) {
        if (!annual && todayJalali.startsWith(monthKey)) {
            val dayNum = todayJalali.substringAfterLast("-").toIntOrNull() ?: 1
            // The first daily card follows the selector, summary, settings, and card heading.
            reportListState.scrollToItem(5 + dayNum.coerceAtLeast(1) - 1)
        }
    }
    LazyColumn(
        state = reportListState,
        modifier = modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 5.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(bottom = 14.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!annual) {
                    Box(Modifier.weight(1f)) {
                        OutlinedButton(onClick = { monthMenuExpanded = true }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 7.dp)) {
                            PersianText("ماه: ${JalaliMonthNames.getOrElse(monthNumber - 1) { "ماه" }}  ⌄", fontSize = 13.sp, maxLines = 1)
                        }
                        DropdownMenu(expanded = monthMenuExpanded, onDismissRequest = { monthMenuExpanded = false }) {
                            JalaliMonthNames.forEachIndexed { index, name ->
                                DropdownMenuItem(text = { PersianText(name) }, onClick = { monthMenuExpanded = false; onPeriodChange(year, index + 1) })
                            }
                        }
                    }
                } else {
                    Surface(Modifier.weight(1f), color = Color(0xFFEAF3FF), shape = RoundedCornerShape(9.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBEDBFA))) {
                        Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) { PersianText("خلاصهٔ سالانه", fontSize = 13.sp, color = Color(0xFF073B45)) }
                    }
                }
                Box(Modifier.weight(1f)) {
                    OutlinedButton(onClick = { yearMenuExpanded = true }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 7.dp)) {
                        PersianText("سال: ${persianDigits(year.toString())}  ⌄", fontSize = 13.sp, maxLines = 1)
                    }
                    DropdownMenu(expanded = yearMenuExpanded, onDismissRequest = { yearMenuExpanded = false }) {
                        ((year - 5)..(year + 1)).toList().reversed().forEach { y ->
                            DropdownMenuItem(text = { PersianText(persianDigits(y.toString())) }, onClick = { yearMenuExpanded = false; onPeriodChange(y, monthNumber) })
                        }
                    }
                }
            }
        }
        item {
            if (!annual) {
                PersianText("کارکرد ماه", modifier = Modifier.fillMaxWidth().padding(start = 4.dp, top = 2.dp),
                    fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF153F78))
            }
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF3F8F6)), shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(14.dp))) {
                Column(Modifier.fillMaxWidth().padding(7.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        ReportMetricTile("جمع کارکرد", hm(totalWork), "◷", Color(0xFF153F78), Modifier.weight(1f))
                        ReportMetricTile("اضافه‌کار", hm(totalOvertime), "◴", OvertimeGreenText, Modifier.weight(1f))
                        ReportMetricTile("جمع مدت شیفت", hm(totalShift), "◷", ShiftYellowText, Modifier.weight(1f))
                        ReportMetricTile("تعداد شیفت", shiftCount.toString(), "▦", Color(0xFF153F78), Modifier.weight(1f))
                    }
                    Divider(color = Color(0xFFD2E5FA))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        ReportMetricTile("مرخصی ساعتی", hm(selectedDays.sumOf { hourlyLeaveMinutes(it) }), "◷", Color(0xFF153F78), Modifier.weight(1f))
                        ReportMetricTile("مأموریت", missionCount.toString(), "✈", Color(0xFF153F78), Modifier.weight(1f))
                        ReportMetricTile("استحقاقی", entitledCount.toString(), "☼", Color(0xFF153F78), Modifier.weight(1f))
                        ReportMetricTile("استعلاجی", sickCount.toString(), "✚", Color(0xFF153F78), Modifier.weight(1f))
                        ReportMetricTile("توراهی", tourahiCount.toString(), "↗", Color(0xFF153F78), Modifier.weight(1f))
                    }
                    Divider(color = Color(0xFFD2E5FA))
                }
            }
        }
        if (!annual) item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(10.dp))
            ) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 7.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    PersianText("توراهی", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF153F78))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        PersianText(
                            "میزان کسر توراهی از استحقاقی‌های ماه جاری",
                            modifier = Modifier.weight(1f), fontSize = 11.sp, color = Color(0xFF315C8D), lineHeight = 15.sp
                        )
                        OutlinedTextField(
                            value = tourahiDeductionInput.copy(text = tourahiDeductionInput.text.toPersianDigits()),
                            onValueChange = { edited ->
                                val digits = edited.text.toLatinDigits().filter { ch -> ch.isDigit() }.take(3)
                                tourahiDeductionInput = TextFieldValue(
                                    text = digits,
                                    selection = TextRange(edited.selection.start.coerceAtMost(digits.length), edited.selection.end.coerceAtMost(digits.length))
                                )
                            },
                            modifier = Modifier.width(64.dp).onFocusChanged { state ->
                                if (state.isFocused) {
                                    tourahiDeductionInput = tourahiDeductionInput.copy(selection = TextRange(0, tourahiDeductionInput.text.length))
                                }
                            }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            textStyle = TextStyle(fontSize = 14.sp, textAlign = TextAlign.Center),
                            placeholder = { PersianText("روز", fontSize = 10.sp) }
                        )
                        Button(onClick = {
                            val amount = tourahiDeductionInput.text.toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
                            db.setSettingText(deductionSettingKey, amount.toString())
                            savedTourahiDeduction = amount
                            tourahiDeductionInput = TextFieldValue("")
                        }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 7.dp)) {
                            PersianText("ذخیره", fontSize = 11.sp)
                        }
                    }
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = includeReportNotes, onCheckedChange = { includeReportNotes = it })
                    PersianText("درج یادداشت‌ها در خروجی گزارش", fontSize = 12.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { export(annual, includeReportNotes) }, modifier = Modifier.weight(1f)) {
                        PersianText("خروجی Excel", fontSize = 12.sp)
                    }
                    OutlinedButton(onClick = { exportPdf(annual, includeReportNotes) }, modifier = Modifier.weight(1f)) {
                        PersianText("خروجی PDF", fontSize = 12.sp)
                    }
                }
                if (annual) {
                    Spacer(Modifier.height(5.dp))
                    PersianText("گزارش جامع سالانه • یک صفحه A4", fontSize = 13.sp,
                        fontWeight = FontWeight.Bold, color = Color(0xFF153F78))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(onClick = { exportSummaryExcel(includeReportNotes) }, modifier = Modifier.weight(1f)) {
                            PersianText("خلاصه جامع Excel", fontSize = 12.sp)
                        }
                        OutlinedButton(onClick = { exportSummaryPdf(includeReportNotes) }, modifier = Modifier.weight(1f)) {
                            PersianText("خلاصه جامع PDF A4", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        if (!annual) {
            item(key = "month_daily_summary") {
                PersianText("کارت روز", modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp),
                    textAlign = TextAlign.Right, style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold, color = Color(0xFF153F78))
            }
            items(reportDays, key = { "report-day-${it.date}" }) { reportDay ->
                val saved = if (db.hasWorkDay(reportDay.date)) db.getDay(reportDay.date) else reportDay
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(12.dp))) {
                    ReportDayCard(
                        applyCalendarHoliday(saved, db), db,
                        db.displayHolidayTitle(reportDay.date) ?: officialJalaliHolidays(year).toMap()[reportDay.date],
                        onClick = { onOpenDay(reportDay.date) }
                    )
                }
            }
        } else {
            item { PersianText("خلاصهٔ ماه‌به‌ماه سال ${persianDigits(year.toString())}", style = MaterialTheme.typography.titleMedium, color = Color(0xFF073B45)) }
            items((1..12).toList()) { m ->
                val monthDays = yearDays.filter { it.date.startsWith("%04d-%02d".format(year, m)) }
                val monthShift = reportShifts(db, year, m).sumOf { shiftDurationMinutes(it, it.shiftStartDate.ifBlank { it.date }) }
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF3F8F6)), shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(12.dp))) {
                    Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        PersianText(JalaliMonthNames[m - 1], style = MaterialTheme.typography.titleSmall, color = Color(0xFF073B45), fontWeight = FontWeight.Bold)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            PersianText("کارکرد ${hm(monthDays.sumOf { duration(it) })}", fontSize = 12.sp)
                            PersianText("اضافه‌کار ${hm(monthDays.sumOf { overtimeMinutes(it, db) })}", fontSize = 12.sp, color = OvertimeGreenText)
                            PersianText("شیفت ${hm(monthShift)}", fontSize = 12.sp, color = ShiftYellowText)
                        }
                        val (rawMonthEntitled, monthSick, _) = periodLeaveStats(monthDays,db)
                        val monthDeduction = db.getSettingText("tourahi_deduction_%04d-%02d".format(year, m), "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
                        val monthEntitled = (rawMonthEntitled - monthDeduction).coerceAtLeast(0)
                        val monthTravel = monthDeduction
                        PersianText("استحقاقی: ${monthEntitled.toString().toPersianDigits()} | استعلاجی: ${monthSick.toString().toPersianDigits()} | مأموریت: ${monthDays.count { hasDayStatus(it,"مأموریت") }.toString().toPersianDigits()} | توراهی: ${monthTravel.toString().toPersianDigits()}", fontSize = 11.sp)
                        val officialHolidayCount = monthDays.count { d ->
                            db.officialHolidayTitle(d.date) != null || officialJalaliHolidays(year).toMap().containsKey(d.date)
                        }
                        PersianText("تعطیلات رسمی: ${officialHolidayCount.toString().toPersianDigits()} روز", fontSize = 11.sp, color = Color(0xFFB3261E))
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportMetricTile(title: String, value: String, symbol: String, valueColor: Color, modifier: Modifier = Modifier) {
    Column(modifier = modifier.heightIn(min = 86.dp).background(Color(0xFFF5FAFF), RoundedCornerShape(9.dp)).padding(horizontal = 3.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        PersianText(title, fontSize = 10.sp, color = Color(0xFF315C8D), textAlign = TextAlign.Center, maxLines = 2, lineHeight = 12.sp)
        Spacer(Modifier.height(2.dp))
        PersianText(symbol, fontSize = 17.sp, color = valueColor, maxLines = 1)
        PersianText(value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = valueColor, maxLines = 1)
    }
}

@Composable
private fun ReportDayCard(day: WorkDay, db: WorkDb, holidayTitle: String?, onClick: () -> Unit = {}) {
    val weekDay = jalaliWeekday(day.date)?.let { JalaliWeekdayNames.getOrNull(it) }.orEmpty()
    val holidayEntryExists = isHolidayWorkDay(day)

    // Only include entry/exit values that the user actually entered.
    // Keep the original order: entry 1, exit 1, entry 2, exit 2, entry 3, exit 3.
    val timeEntries: List<Pair<String, String>> = if (holidayEntryExists) {
        buildList {
            if (day.holidayIn.isNotBlank()) add("ورود" to day.holidayIn)
            if (day.holidayOut.isNotBlank()) add("خروج" to day.holidayOut)
        }
    } else {
        buildList {
            if (day.in1.isNotBlank()) add("ورود" to day.in1)
            if (day.out1.isNotBlank()) add("خروج" to day.out1)
            if (day.in2.isNotBlank()) add("ورود" to day.in2)
            if (day.out2.isNotBlank()) add("خروج" to day.out2)
            if (day.in3.isNotBlank()) add("ورود" to day.in3)
            if (day.out3.isNotBlank()) add("خروج" to day.out3)
        }
    }

    val shiftDuration = if (day.shiftEnabled) shiftDurationMinutes(day, day.date) else 0

    // Holiday cards are distinguished with a soft red fill and red outline.
    // Friday is detected by the Jalali weekday index used in this project (5 = Friday).
    val isHolidayCard = jalaliWeekday(day.date) == 5 ||
        dayStatuses(day).any { it in workHolidayStatuses } ||
        db.officialHolidayTitle(day.date) != null || db.holidayTitle(day.date) != null ||
        officialJalaliHolidays(day.date.take(4).toIntOrNull() ?: 0).toMap().containsKey(day.date)
    val holidayCardBackground = if (isHolidayCard) Color(0xFFFFF5F5) else Color(0xFFF3F8F6)
    val holidayCardBorder = if (isHolidayCard) Color(0xFFE57373) else Color(0xFFBEDBFA)
    val holidayHeaderColor = if (isHolidayCard) Color(0xFFB3261E) else Color(0xFF073B45)

    // Show only the selected day category, rather than all available categories.
    val statusItems = buildList {
        dayStatuses(day).forEach { type ->
            add(if (type == "مرخصی") "مرخصی استحقاقی" else type)
        }
        if (day.shiftEnabled) add("شیفت")
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = holidayCardBackground),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().border(1.5.dp, holidayCardBorder, RoundedCornerShape(14.dp)).clickable(onClick = onClick)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(7.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                PersianText(
                    "${weekDay} ${jalaliDisplayDate(day.date)}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = holidayHeaderColor
                )
                PersianText("▦", fontSize = 20.sp, color = if (isHolidayCard) Color(0xFFB3261E) else Color(0xFF426A6D))
            }

            Divider(color = if (isHolidayCard) Color(0xFFF0B4B4) else Color(0xFFD9E8F8))

            if (timeEntries.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    timeEntries.forEach { (label, time) ->
                        Column(
                            Modifier.weight(1f)
                                .defaultMinSize(minHeight = 55.dp)
                                .border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(8.dp))
                                .padding(horizontal = 2.dp, vertical = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            PersianText(label, fontSize = 9.sp, color = Color(0xFF075565), maxLines = 1)
                            PersianText(
                                time.toPersianDigits(),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF073B45),
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            if (statusItems.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    statusItems.forEach { status ->
                        val isShift = status == "شیفت"
                        val bg = when {
                            isShift -> ShiftYellow
                            status == "تعطیل مناسبتی" -> Color(0xFFE0F5E9)
                            else -> Color(0xFFE4F0FF)
                        }
                        val foreground = when {
                            isShift -> ShiftYellowText
                            status == "تعطیل مناسبتی" -> Color(0xFF176B36)
                            else -> Color(0xFF1556A6)
                        }
                        Surface(
                            modifier = Modifier.weight(1f).heightIn(min = 52.dp),
                            shape = RoundedCornerShape(8.dp),
                            color = bg,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isShift) Color(0xFFE5C34A) else Color(0xFF8DBFFF)
                            )
                        ) {
                            Box(
                                Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 5.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                PersianText(
                                    status,
                                    fontSize = 10.sp,
                                    color = foreground,
                                    textAlign = TextAlign.Center,
                                    maxLines = 2,
                                    lineHeight = 12.sp
                                )
                            }
                        }
                    }
                }
            }

            if (hasDayStatus(day,"تعطیل مناسبتی") || !holidayTitle.isNullOrBlank()) {
                Row(
                    Modifier.fillMaxWidth()
                        .border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(8.dp))
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PersianText("✎", fontSize = 17.sp, color = Color(0xFF075565))
                    PersianText("مناسبت / عنوان تعطیلی:", fontSize = 11.sp, color = Color(0xFF075565))
                    PersianText(
                        holidayTitle ?: "—",
                        modifier = Modifier.weight(1f),
                        fontSize = 11.sp,
                        color = Color(0xFF073B45),
                        maxLines = 3,
                        lineHeight = 14.sp
                    )
                }
            }

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                ReportValueTile("جمع کار", hm(duration(day)), Color(0xFFEAF3FF), Color(0xFF153F78), Modifier.weight(1f))
                ReportValueTile("مدت شیفت", hm(shiftDuration), Color(0xFFFFF7E1), ShiftYellowText, Modifier.weight(1f))
                ReportValueTile("اضافه‌کار", hm(overtimeMinutes(day, db)), Color(0xFFE4F7EE), OvertimeGreenText, Modifier.weight(1f))
            }

            // The note wraps to as many lines as necessary; the card grows with the text.
            Row(
                Modifier.fillMaxWidth()
                    .border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(8.dp))
                    .padding(8.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PersianText("▤", fontSize = 17.sp, color = Color(0xFF075565))
                PersianText("یادداشت روز:", fontSize = 11.sp, color = Color(0xFF073B45))
                PersianText(
                    day.note.ifBlank { "—" }.toPersianDigits(),
                    modifier = Modifier.weight(1f),
                    fontSize = 12.sp,
                    color = Color(0xFF5D7898),
                    lineHeight = 16.sp,
                    maxLines = Int.MAX_VALUE,
                    softWrap = true
                )
            }

        }
    }
}

@Composable
private fun ReportValueTile(title: String, value: String, background: Color, foreground: Color, modifier: Modifier = Modifier) {
    Column(modifier = modifier.background(background, RoundedCornerShape(9.dp)).padding(horizontal = 5.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        PersianText(title, fontSize = 11.sp, color = foreground, textAlign = TextAlign.Center, maxLines = 1)
        PersianText(value, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = foreground, maxLines = 1)
    }
}

/** Report creation time uses the phone's local timezone and Jalali calendar. */
private fun reportCreatedAt(): String {
    val current = java.time.LocalDateTime.now()
    val (y, m, d) = gregorianToJalali(current.toLocalDate())
    return "%04d/%02d/%02d  %02d:%02d".format(Locale.ROOT, y, m, d, current.hour, current.minute).toPersianDigits()
}

private data class AnnualReportStats(
    val workedMinutes: Int = 0,
    val overtimeMinutes: Int = 0,
    val shiftMinutes: Int = 0,
    val shifts: Int = 0,
    val entitled: Int = 0,
    val sick: Int = 0,
    val missions: Int = 0,
    val travel: Int = 0,
    val hourlyLeave: Int = 0,
    val workedDays: Int = 0,
    val holidayDays: Int = 0
) {
    operator fun plus(other: AnnualReportStats) = AnnualReportStats(
        workedMinutes + other.workedMinutes,
        overtimeMinutes + other.overtimeMinutes,
        shiftMinutes + other.shiftMinutes,
        shifts + other.shifts,
        entitled + other.entitled,
        sick + other.sick,
        missions + other.missions,
        travel + other.travel,
        hourlyLeave + other.hourlyLeave,
        workedDays + other.workedDays,
        holidayDays + other.holidayDays
    )
    fun values(): List<String> = listOf(
        hm(workedMinutes), hm(overtimeMinutes), hm(shiftMinutes), shifts.toString(),
        entitled.toString(), sick.toString(), missions.toString(), travel.toString(),
        hm(hourlyLeave), workedDays.toString(), holidayDays.toString()
    )
}

private val annualReportHeadings = listOf(
    "ماه", "کارکرد", "اضافه‌کار", "مدت شیفت", "تعداد شیفت", "استحقاقی", "استعلاجی",
    "مأموریت", "توراهی", "مرخصی ساعتی", "روز کارکرد", "روز تعطیل"
)

private fun annualMonthStats(db: WorkDb, year: Int, month: Int): AnnualReportStats {
    val days = reportPeriodDays(db, year, month, false)
    val prefix = "%04d-%02d".format(Locale.ROOT,year,month)
    // Shifts belong to the month in which they began, even across month boundaries.
    val shifts = db.allDaysForBackup().filter { it.shiftEnabled && (it.shiftStartDate.ifBlank { it.date }).startsWith(prefix) }
    val (rawEntitled, sick, _) = periodLeaveStats(days, db)
    val deduction = db.getSettingText("tourahi_deduction_$prefix", "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
    val entitled = (rawEntitled - deduction).coerceAtLeast(0)
    val travel = deduction
    return AnnualReportStats(
        workedMinutes = days.sumOf { duration(it) },
        overtimeMinutes = days.sumOf { overtimeMinutes(it,db) },
        shiftMinutes = shifts.sumOf { shiftDurationMinutes(it,it.shiftStartDate.ifBlank { it.date }) },
        shifts = shifts.size, entitled = entitled, sick = sick,
        missions = days.count { hasDayStatus(it,"مأموریت") }, travel = travel,
        hourlyLeave = days.sumOf { hourlyLeaveMinutes(it) },
        workedDays = days.count { duration(it) > 0 },
        holidayDays = days.count {
            jalaliWeekday(it.date) == 5 || dayStatuses(it).any { status -> status in workHolidayStatuses } ||
                db.officialHolidayTitle(it.date) != null ||
                officialJalaliHolidays(year).any { holiday -> holiday.first == it.date }
        }
    )
}

private fun annualSummarySheetXml(db: WorkDb, year: Int, createdAt: String): String {
    val months = (1..12).map { annualMonthStats(db,year,it) }
    val total = months.fold(AnnualReportStats()) { acc, item -> acc + item }
    val first = MutableList(12) { "" }
    first[0] = "مورخ | گزارش جامع سالانه ${year.toString().toPersianDigits()}"
    first[10] = "تهیه: $createdAt"
    val rows = mutableListOf<List<String>>(
        first,
        listOf("خلاصه کل سال و آمار تفکیکی ۱۲ ماه • هر زمان با ساعت:دقیقه، هر تعداد با روز یا نوبت"),
        listOf("واحد: ساعت:دقیقه برای کارکرد، اضافه‌کار، شیفت و مرخصی ساعتی؛ سایر مقادیر تعداد هستند"),
        annualReportHeadings,
        listOf("جمع کل سال") + total.values()
    )
    months.forEachIndexed { index, s -> rows.add(listOf(JalaliMonthNames[index]) + s.values()) }
    rows.add(listOf("استحقاقی پس از کسر توراهی نمایش داده شده است؛ توراهی مستقل گزارش می‌شود و دوباره‌شماری ندارد."))
    val widths = listOf(18,15,15,15,15,14,14,14,12,17,13,13)
    val cols = widths.mapIndexed { i,width -> "<col min=\"${i+1}\" max=\"${i+1}\" width=\"$width\" customWidth=\"1\"/>" }.joinToString("")
    val body = rows.mapIndexed { ri,row ->
        val cells = row.mapIndexed { ci,value ->
            val style = when { ri == 0 -> if(ci==10) 5 else 2; ri == 3 -> 1; ri == 4 -> 5; ri in 5..16 && ci==0 -> 5; ri in 5..16 -> 4; else -> 6 }
            "<c r=\"${colName(ci+1)}${ri+1}\" s=\"$style\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${xmlEscape(value.toPersianDigits())}</t></is></c>"
        }.joinToString("")
        val height = when(ri) { 0->34; 1,2->27; 3->44; 4->34; 17->30; else->29 }
        "<row r=\"${ri+1}\" ht=\"$height\" customHeight=\"1\">$cells</row>"
    }.joinToString("")
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><sheetViews><sheetView workbookViewId="0" rightToLeft="1"><pane ySplit="4" topLeftCell="A5" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>$cols</cols><sheetData>$body</sheetData><mergeCells count="5"><mergeCell ref="A1:J1"/><mergeCell ref="K1:L1"/><mergeCell ref="A2:L2"/><mergeCell ref="A3:L3"/><mergeCell ref="A18:L18"/></mergeCells><printOptions horizontalCentered="1"/><pageMargins left="0.18" right="0.18" top="0.28" bottom="0.28" header="0.1" footer="0.1"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="1"/></worksheet>"""
}

fun buildReportXlsx(db: WorkDb, year: Int, month: Int, annual: Boolean, includeNotes: Boolean = true, summaryOnly: Boolean = false): ByteArray {
    // Two hidden, lossless import sheets contain ONLY the selected reporting period.
    // This avoids leaking unrelated private records when a report is shared.
    val months = if (annual) (1..12).toList() else listOf(month)
    val allowedPrefixes = months.map { "%04d-%02d".format(year,it) }
    val recordedDays = db.allDaysForBackup().filter { day -> allowedPrefixes.any { day.date.startsWith(it) } }
    val raw = mutableListOf(listOf("date","dayType","in1","out1","in2","out2","in3","out3","duration","overtimeOverride","note","shiftEnabled","shiftStart","shiftEnd","shiftStartDate","shiftEndDate","holidayIn","holidayOut","leave1Start","leave1End","leave2Start","leave2End","hourlyLeaveEnabled","extraDayTypes"))
    recordedDays.forEach { d -> raw.add(listOf(d.date,d.dayType,d.in1,d.out1,d.in2,d.out2,d.in3,d.out3,hm(duration(d)),d.overtimeOverride,if (includeNotes) d.note else "",d.shiftEnabled.toString(),d.shiftStart,d.shiftEnd,d.shiftStartDate,d.shiftEndDate,d.holidayIn,d.holidayOut,d.leave1Start,d.leave1End,d.leave2Start,d.leave2End,d.hourlyLeaveEnabled.toString(),d.extraDayTypes)) }
    val metadata = mutableListOf(listOf("key","value"),listOf("export_format","period_report_v1"),listOf("period",if(annual) "%04d".format(year) else "%04d-%02d".format(year,month)))

    val createdAt = reportCreatedAt()
    val sheets = mutableListOf<Pair<String,String>>()
    sheets.add("داده‌های بازیابی" to sheetXml(raw))
    sheets.add("اطلاعات فایل" to sheetXml(metadata))
    if (annual && summaryOnly) {
        sheets.add("خلاصه جامع سالانه" to annualSummarySheetXml(db, year, createdAt))
    } else {
        months.forEach { m -> sheets.add(JalaliMonthNames[m-1] to monthReportSheetXml(db,year,m,includeNotes,createdAt)) }
    }
    val content = linkedMapOf<String,String>()
    content["[Content_Types].xml"] = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.indices.joinToString("") { "<Override PartName=\"/xl/worksheets/sheet${it+1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" }}</Types>"""
    content["_rels/.rels"] = """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>"""
    val sheetDefs = sheets.mapIndexed { i,pair -> "<sheet name=\"${xmlEscape(pair.first)}\" sheetId=\"${i+1}\" r:id=\"rId${i+1}\"${if(i<2) " state=\"hidden\"" else ""}/>" }.joinToString("")
    content["xl/workbook.xml"] = """<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="2" firstSheet="2"/></bookViews><sheets>$sheetDefs</sheets></workbook>"""
    val relationships = sheets.indices.joinToString("") { i -> "<Relationship Id=\"rId${i+1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet${i+1}.xml\"/>" }
    content["xl/_rels/workbook.xml.rels"] = """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">$relationships<Relationship Id="rId${sheets.size+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>"""
    content["xl/styles.xml"] = reportStylesXml()
    sheets.forEachIndexed { i,pair -> content["xl/worksheets/sheet${i+1}.xml"] = pair.second }
    val output = java.io.ByteArrayOutputStream()
    java.util.zip.ZipOutputStream(output).use { zip -> content.forEach { (name,value) ->
        zip.putNextEntry(java.util.zip.ZipEntry(name));zip.write(value.toByteArray(Charsets.UTF_8));zip.closeEntry()
    } }
    return output.toByteArray()
}

/** Display columns for each of the three work intervals (one value per cell).
 * Holiday overtime is shown in the first pair; the other pairs remain separate and empty.
 */
private fun hasSecondEntryExit(days: List<WorkDay>): Boolean = days.any { it.in2.isNotBlank() || it.out2.isNotBlank() }
private fun hasThirdEntryExit(days: List<WorkDay>): Boolean = days.any { it.in3.isNotBlank() || it.out3.isNotBlank() }

private fun dayEntryExitColumns(day: WorkDay, includeSecond: Boolean, includeThird: Boolean): List<String> {
    val firstPair = if (isHolidayWorkDay(day) && (day.holidayIn.isNotBlank() || day.holidayOut.isNotBlank()))
        listOf(day.holidayIn, day.holidayOut) else listOf(day.in1, day.out1)
    val pairs = mutableListOf<String>().apply {
        addAll(firstPair)
        if (includeSecond) addAll(if (isHolidayWorkDay(day) && (day.holidayIn.isNotBlank() || day.holidayOut.isNotBlank())) listOf("", "") else listOf(day.in2, day.out2))
        if (includeThird) addAll(if (isHolidayWorkDay(day) && (day.holidayIn.isNotBlank() || day.holidayOut.isNotBlank())) listOf("", "") else listOf(day.in3, day.out3))
    }
    return pairs.map { it.ifBlank { "—" } }
}

private fun reportHeadings(includeSecond: Boolean, includeThird: Boolean): List<String> = buildList {
    addAll(listOf("روز هفته", "تاریخ", "وضعیت", "ورود ۱", "خروج ۱"))
    if (includeSecond) addAll(listOf("ورود ۲", "خروج ۲"))
    if (includeThird) addAll(listOf("ورود ۳", "خروج ۳"))
    addAll(listOf("کارکرد", "اضافه‌کار", "شیفت", "مرخصی ساعتی", "یادداشت"))
}

/** Combines a day's note with its occasion-holiday reason in report exports. */
private fun reportNoteWithHolidayReason(day: WorkDay, db: WorkDb): String {
    val note = day.note.trim()
    val reason = if (hasDayStatus(day, "تعطیل مناسبتی")) db.holidayTitle(day.date)?.trim().orEmpty() else ""
    if (reason.isBlank()) return note
    val suffix = "+ علت تعطیلی: $reason"
    return listOf(note, suffix).filter { it.isNotBlank() }.joinToString(" ")
}

private fun monthReportSheetXml(db: WorkDb, year: Int, month: Int, includeNotes: Boolean, createdAt: String): String {
    val days = reportPeriodDays(db, year, month, false)
    val includeSecond = hasSecondEntryExit(days)
    val includeThird = hasThirdEntryExit(days)
    val headings = reportHeadings(includeSecond, includeThird)
    val shifts = reportShifts(db, year, month)
    val (rawEntitledDays,sickDays,_) = periodLeaveStats(days,db)
    val deduction = db.getSettingText("tourahi_deduction_%04d-%02d".format(year, month), "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
    val entitledDays = (rawEntitledDays - deduction).coerceAtLeast(0)
    val travelDays = deduction
    val title = "مورخ | گزارش ${JalaliMonthNames[month-1]} ${year.toString().toPersianDigits()}"
    val summary = "کارکرد: ${hm(days.sumOf { duration(it) })} | اضافه‌کاری: ${hm(days.sumOf { overtimeMinutes(it,db) })} | مرخصی ساعتی: ${hm(days.sumOf { hourlyLeaveMinutes(it) })}"
    val summary2 = "شیفت: ${hm(shifts.sumOf { shiftDurationMinutes(it,it.shiftStartDate.ifBlank { it.date }) })} | تعداد شیفت: ${shifts.size} | استحقاقی: $entitledDays | استعلاجی: $sickDays | توراهی: $travelDays | مأموریت: ${days.count { hasDayStatus(it,"مأموریت") }}"
    val stampRow = MutableList(headings.size) { "" }
    stampRow[0] = title
    stampRow[headings.size - 3] = "تهیه: $createdAt"
    val rows = mutableListOf<List<String>>(
        stampRow,
        listOf("گزارش ماهانه • چاپ یک صفحه A4 افقی"),
        listOf(summary),
        listOf(summary2),
        headings.map { if (!includeNotes && it == "یادداشت") "بدون یادداشت" else it }
    )
    days.forEach { day ->
        val weekday = jalaliWeekday(day.date)?.let { JalaliWeekdayNames.getOrNull(it) }.orEmpty()
        val values = listOf(hm(duration(day)), hm(overtimeMinutes(day,db)),
            if (day.shiftEnabled) hm(shiftDurationMinutes(day,day.date)) else "—",
            hm(hourlyLeaveMinutes(day)), if (includeNotes) reportNoteWithHolidayReason(day, db) else "")
        rows.add(listOf(weekday,day.date.replace('-', '/'),reportDayStatusText(day,db)) +
            dayEntryExitColumns(day, includeSecond, includeThird) + values)
    }
    val widths = buildList {
        addAll(listOf(13,16,22,12,12))
        if (includeSecond) addAll(listOf(12,12))
        if (includeThird) addAll(listOf(12,12))
        addAll(listOf(14,15,14,18,42))
    }
    val cols = widths.mapIndexed { i,width -> """<col min="${i+1}" max="${i+1}" width="$width" customWidth="1"/>""" }.joinToString("")
    val lastCol = colName(headings.size)
    val leftStampEnd = colName((headings.size - 3).coerceAtLeast(1))
    val rightStampStart = colName((headings.size - 2).coerceAtLeast(1))
    val body = rows.mapIndexed { ri,row ->
        val cells = row.mapIndexed { j,v ->
            val style = when {
                ri == 0 -> if (j == headings.size - 3) 5 else 2
                ri == 4 -> 1
                ri in 1..3 -> 6
                j == headings.lastIndex -> 6
                else -> 3
            }
            """<c r="${colName(j+1)}${ri+1}" s="$style" t="inlineStr"><is><t xml:space="preserve">${xmlEscape(v.toPersianDigits())}</t></is></c>"""
        }.joinToString("")
        val height = when(ri) { 0->34; 1,2,3->25; 4->34; else->if(includeNotes) 33 else 23 }
        """<row r="${ri+1}" ht="$height" customHeight="1">$cells</row>"""
    }.joinToString("")
    val mergeItems = mutableListOf(
        "<mergeCell ref=\"A1:${leftStampEnd}1\"/>",
        "<mergeCell ref=\"${rightStampStart}1:${lastCol}1\"/>",
        "<mergeCell ref=\"A2:${lastCol}2\"/>",
        "<mergeCell ref=\"A3:${lastCol}3\"/>",
        "<mergeCell ref=\"A4:${lastCol}4\"/>"
    )
    val merges = mergeItems.joinToString("")
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><sheetViews><sheetView workbookViewId="0" rightToLeft="1"><pane ySplit="5" topLeftCell="A6" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>$cols</cols><sheetData>$body</sheetData><mergeCells count="5">$merges</mergeCells><printOptions horizontalCentered="1"/><pageMargins left="0.17" right="0.17" top="0.28" bottom="0.28" header="0.1" footer="0.1"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="1"/></worksheet>"""
}

fun buildReportPdf(db: WorkDb, year: Int, month: Int, annual: Boolean, includeNotes: Boolean = true, summaryOnly: Boolean = false): ByteArray {
    if (annual && summaryOnly) return buildAnnualSummaryPdf(db,year)
    val createdAt = reportCreatedAt()
    val pdf=android.graphics.pdf.PdfDocument()
    val months=if(annual) (1..12).toList() else listOf(month)
    val pageWidth=842;val pageHeight=595;val left=24f;val right=818f
    val navy=android.graphics.Color.rgb(21,54,93)
    val teal=android.graphics.Color.rgb(0,125,129)
    val gold=android.graphics.Color.rgb(195,150,58)
    val muted=android.graphics.Color.rgb(90,115,141)
    val soft=android.graphics.Color.rgb(239,246,253)
    val white=android.graphics.Color.WHITE
    val p=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    fun rect(canvas:android.graphics.Canvas,l:Float,t:Float,r:Float,b:Float,color:Int,radius:Float=0f) {
        p.color=color;p.style=android.graphics.Paint.Style.FILL
        if(radius>0f) canvas.drawRoundRect(l,t,r,b,radius,radius,p) else canvas.drawRect(l,t,r,b,p)
    }
    fun rtl(canvas:android.graphics.Canvas,value:String,xRight:Float,yTop:Float,width:Int,size:Float,color:Int,bold:Boolean=false,lines:Int=1,center:Boolean=false) {
        val str=value.toPersianDigits()
        val paint=android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textSize=size;this.color=color;typeface=android.graphics.Typeface.create("sans-serif",if(bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        }
        val layout=android.text.StaticLayout.Builder.obtain(str,0,str.length,paint,width.coerceAtLeast(1))
            .setTextDirection(android.text.TextDirectionHeuristics.RTL)
            .setAlignment(if (center) android.text.Layout.Alignment.ALIGN_CENTER else android.text.Layout.Alignment.ALIGN_OPPOSITE)
            .setIncludePad(false).setMaxLines(lines)
            .setEllipsize(android.text.TextUtils.TruncateAt.END).build()
        canvas.save();canvas.translate(xRight-width,yTop);layout.draw(canvas);canvas.restore()
    }
    months.forEachIndexed { index,m ->
        val page=pdf.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth,pageHeight,index+1).create())
        val canvas=page.canvas
        rect(canvas,0f,0f,pageWidth.toFloat(),pageHeight.toFloat(),white)
        rect(canvas,0f,0f,pageWidth.toFloat(),7f,gold)
        rect(canvas,left,18f,right,69f,navy,10f)
        rtl(canvas,"مورخ",right-14,27f,145,16f,white,true)
        rtl(canvas,"گزارش ماهانه ${JalaliMonthNames[m-1]} ${year}",right-178,27f,350,15f,white,true)
        rtl(canvas,"تهیه: $createdAt",left+195,38f,185,9.5f,white,true)
        rtl(canvas,"برگه ${index+1} از ${months.size}",left+148,23f,140,9f,android.graphics.Color.rgb(222,237,249))

        val days=reportPeriodDays(db,year,m,false)
        val includeSecond = hasSecondEntryExit(days)
        val includeThird = hasThirdEntryExit(days)
        val reportCols = reportHeadings(includeSecond, includeThird)
        val shiftList=reportShifts(db, year, m)
        val (rawEntitledCount,sickCount,_) = periodLeaveStats(days,db)
        val monthDeduction = db.getSettingText("tourahi_deduction_%04d-%02d".format(year, m), "0").toLatinDigits().toIntOrNull()?.coerceAtLeast(0) ?: 0
        val entitledCount = (rawEntitledCount - monthDeduction).coerceAtLeast(0)
        val travelCount = monthDeduction
        val metrics=listOf(
            "کارکرد" to hm(days.sumOf { duration(it) }),
            "اضافه‌کاری" to hm(days.sumOf { overtimeMinutes(it,db) }),
            "مرخصی ساعتی" to hm(days.sumOf { hourlyLeaveMinutes(it) }),
            "شیفت" to hm(shiftList.sumOf { shiftDurationMinutes(it,it.shiftStartDate.ifBlank { it.date }) }),
            "تعداد شیفت" to shiftList.size.toString(),
            "استحقاقی" to entitledCount.toString(),
            "استعلاجی" to sickCount.toString(),
            "توراهی" to travelCount.toString(),
            "مأموریت" to days.count { hasDayStatus(it,"مأموریت") }.toString()
        )
        val gap=6f;val tileWidth=(right-left-gap*(metrics.size-1))/metrics.size
        metrics.forEachIndexed { i,metric ->
            val l=left+(tileWidth+gap)*i
            rect(canvas,l,78f,l+tileWidth,125f,soft,6f)
            rtl(canvas,metric.first,l+tileWidth-6,84f,(tileWidth-12).toInt(),9f,muted)
            rtl(canvas,metric.second,l+tileWidth-6,103f,(tileWidth-12).toInt(),13f,if(i==1)teal else navy,true)
        }
        // A4 landscape: explicit entry/exit columns for each of the three intervals.
        // Widths sum to 794pt; every column has its own visible border.
        val rawWidths = buildList {
            addAll(listOf(42f,56f,68f,35f,35f))
            if (includeSecond) addAll(listOf(35f,35f))
            if (includeThird) addAll(listOf(35f,35f))
            addAll(listOf(45f,50f,42f,48f,100f))
        }
        val widthScale=(right-left)/rawWidths.sum()
        val widths=rawWidths.map { it*widthScale }
        val headers=reportCols.map { if (!includeNotes && it == "یادداشت") "بدون یادداشت" else it }
        val tableTop=137f;val headerHeight=24f;val rowHeight=12.5f
        rect(canvas,left,tableTop,right,tableTop+headerHeight,navy,5f)
        var x=right
        headers.forEachIndexed { i,heading ->
            rtl(canvas,heading,x-3.5f,tableTop+6f,(widths[i]-7).toInt(),
                if(i >= headers.size - 2) 8f else 7.1f,white,true,1,true)
            x-=widths[i]
            if(i < headers.lastIndex) rect(canvas,x-0.45f,tableTop,x+0.45f,tableTop+headerHeight,android.graphics.Color.rgb(183,207,231))
        }
        days.forEachIndexed { i,d ->
            val top=tableTop+headerHeight+i*rowHeight
            val highlight=jalaliWeekday(d.date)==5 || dayStatuses(d).any { it in workHolidayStatuses }
            val color=when {highlight -> android.graphics.Color.rgb(255,239,239);i%2==0 -> android.graphics.Color.rgb(248,251,255);else -> white}
            rect(canvas,left,top,right,top+rowHeight,color)
            x=right
            val weekName=jalaliWeekday(d.date)?.let { JalaliWeekdayNames.getOrNull(it) }.orEmpty()
            val cellValues=listOf(weekName,d.date.replace('-', '/'),reportDayStatusText(d,db))+
                dayEntryExitColumns(d, includeSecond, includeThird)+
                listOf(hm(duration(d)),hm(overtimeMinutes(d,db)),
                    if(d.shiftEnabled) hm(shiftDurationMinutes(d,d.date)) else "—",
                    hm(hourlyLeaveMinutes(d)),if (includeNotes) reportNoteWithHolidayReason(d, db) else "")
            cellValues.forEachIndexed { j,value ->
                val noteCell = j == cellValues.lastIndex
                rtl(canvas,value,x-3.5f,top+0.6f,(widths[j]-7).toInt(),
                    if(noteCell) 5.7f else if(j==2) 6.2f else 7.2f,
                    if(highlight && (j==0 || j==1)) android.graphics.Color.rgb(170,41,45) else navy,
                    j==0 || j==1,if(noteCell && includeNotes) 2 else 1,true)
                x-=widths[j]
                if(j < cellValues.lastIndex) rect(canvas,x-0.35f,top,x+0.35f,top+rowHeight,android.graphics.Color.rgb(210,225,240))
            }
            rect(canvas,left,top+rowHeight-0.4f,right,top+rowHeight,android.graphics.Color.rgb(210,225,240))
        }
        val footerY=tableTop+headerHeight+days.size*rowHeight+12f
        rtl(canvas,"برای بازیابی اطلاعات، فایل Excel گزارش را نگه دارید؛ ورود و خروج‌های ثبت‌شده در ستون‌های مستقل قرار دارند.",right,footerY,(right-left).toInt(),9f,muted)
        rect(canvas,left,footerY+20,right,footerY+22,gold)
        pdf.finishPage(page)
    }
    val out=java.io.ByteArrayOutputStream();pdf.writeTo(out);pdf.close();return out.toByteArray()
}

/** One A4 landscape page: year totals above an independently bordered 12-month matrix. */
private fun buildAnnualSummaryPdf(db: WorkDb, year: Int): ByteArray {
    val document = android.graphics.pdf.PdfDocument()
    val width = 842; val height = 595 // A4 landscape at 72 dpi.
    val page = document.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(width,height,1).create())
    val c = page.canvas
    val navy = android.graphics.Color.rgb(21,54,93)
    val blue = android.graphics.Color.rgb(36,90,141)
    val teal = android.graphics.Color.rgb(0,118,114)
    val gold = android.graphics.Color.rgb(208,165,75)
    val grey = android.graphics.Color.rgb(100,121,145)
    val pale = android.graphics.Color.rgb(239,247,253)
    val line = android.graphics.Color.rgb(192,213,235)
    val white = android.graphics.Color.WHITE
    val brush = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    fun fill(l: Float,t:Float,r:Float,b:Float,color:Int) {
        brush.color=color; brush.style=android.graphics.Paint.Style.FILL
        c.drawRect(l,t,r,b,brush)
    }
    fun cell(l:Float,t:Float,r:Float,b:Float,color:Int,border:Int=line) {
        fill(l,t,r,b,color)
        brush.color=border; brush.style=android.graphics.Paint.Style.STROKE; brush.strokeWidth=0.8f
        c.drawRect(l,t,r,b,brush); brush.style=android.graphics.Paint.Style.FILL
    }
    fun label(value:String,xRight:Float,top:Float,maxWidth:Int,fontSize:Float=9f,
              ink:Int=navy,bold:Boolean=false,maxLines:Int=1,center:Boolean=false) {
        val rendered=value.toPersianDigits()
        val tp=android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textSize=fontSize; color=ink
            typeface=android.graphics.Typeface.create("sans-serif",if(bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        }
        val layout=android.text.StaticLayout.Builder.obtain(rendered,0,rendered.length,tp,maxWidth.coerceAtLeast(1))
            .setTextDirection(android.text.TextDirectionHeuristics.RTL)
            .setAlignment(if (center) android.text.Layout.Alignment.ALIGN_CENTER else android.text.Layout.Alignment.ALIGN_OPPOSITE)
            .setIncludePad(false).setMaxLines(maxLines)
            .setEllipsize(android.text.TextUtils.TruncateAt.END).build()
        c.save();c.translate(xRight-maxWidth,top);layout.draw(c);c.restore()
    }
    val left=24f; val right=818f
    fill(0f,0f,842f,7f,gold)
    cell(left,18f,right,75f,navy,navy)
    label("مورخ",right-15,26f,135,18f,white,true)
    label("خلاصهٔ جامع عملکرد سال ${year.toString().toPersianDigits()}",right-162,27f,380,15f,white,true)
    label("تهیه: ${reportCreatedAt()}",left+206,43f,198,10f,white,true)
    val perMonth=(1..12).map { annualMonthStats(db,year,it) }
    val total=perMonth.fold(AnnualReportStats()) { acc,item -> acc+item }
    val headline=listOf(
        "مجموع کارکرد" to hm(total.workedMinutes),
        "اضافه‌کاری" to hm(total.overtimeMinutes),
        "مدت شیفت" to hm(total.shiftMinutes),
        "تعداد شیفت" to total.shifts.toString(),
        "مرخصی ساعتی" to hm(total.hourlyLeave),
        "استحقاقی" to total.entitled.toString(),
        "استعلاجی" to total.sick.toString(),
        "مأموریت" to total.missions.toString(),
        "توراهی" to total.travel.toString(),
    )
    val cardGap=6f; val cardW=(right-left-4*cardGap)/5f
    headline.forEachIndexed { i,metric ->
        val row=i/5;val col=i%5
        val x=left+col*(cardW+cardGap)
        val y=84f+row*47f
        cell(x,y,x+cardW,y+41f,if(row==0) pale else android.graphics.Color.rgb(246,250,254))
        label(metric.first,x+cardW-7f,y+5f,(cardW-14f).toInt(),10f,grey)
        label(metric.second,x+cardW-7f,y+22f,(cardW-14f).toInt(),13f,if(i==1) teal else blue,true)
    }
    label("خلاصهٔ ماه‌به‌ماه • ساعت‌ها به صورت ساعت:دقیقه، سایر ستون‌ها تعداد",right,184f,680,10f,navy,true)
    val columns=listOf(87f,66f,66f,62f,58f,55f,55f,53f,49f,70f,70f,48f,55f)
    val headerTop=207f; val headerH=31f; val rowH=20f
    var edge=right
    annualReportHeadings.forEachIndexed { index,title ->
        val w=columns[index]
        cell(edge-w,headerTop,edge,headerTop+headerH,navy,android.graphics.Color.rgb(105,148,186))
        label(title,edge-3f,headerTop+8f,(w-6).toInt(),7.8f,white,true,2,true)
        edge-=w
    }
    val allRows=listOf("کل سال" to total)+ (1..12).map { JalaliMonthNames[it-1] to perMonth[it-1] }
    allRows.forEachIndexed { i,(monthName,stats) ->
        val y=headerTop+headerH+rowH*i
        edge=right
        val values=listOf(monthName)+stats.values()
        values.forEachIndexed { j,value ->
            val w=columns[j]
            val bg=when { i==0 -> android.graphics.Color.rgb(222,240,247)
                i%2==0 -> android.graphics.Color.rgb(246,250,254)
                else -> white }
            cell(edge-w,y,edge,y+rowH,bg)
            label(value,edge-3.4f,y+5f,(w-6).toInt(),if(j==0) 9.1f else 8.8f,
                if(i==0) navy else if(j==2) teal else blue, i==0 || j==0,1,true)
            edge-=w
        }
    }
    val footer=headerTop+headerH+rowH*allRows.size+12f
    label("مبنای استحقاقی: پس از کسر توراهی و حذف تعطیلات • شیفت‌ها بر اساس ماه شروع • جمع مرخصی‌ها بدون دوباره‌شماری",right,footer,(right-left).toInt(),9.3f,grey)
    fill(left,footer+20f,right,footer+22f,gold)
    document.finishPage(page)
    val bytes=java.io.ByteArrayOutputStream()
    document.writeTo(bytes);document.close()
    return bytes.toByteArray()
}

private fun xmlEscape(v: String): String = v.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;")
private fun colName(n: Int): String {
    var x=n; var out=""
    while(x>0){ val r=(x-1)%26; out=(('A'.code+r).toChar())+out; x=(x-1)/26 }
    return out
}
private fun reportStylesXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="4">
<font><sz val="10"/><name val="Arial"/><family val="2"/></font>
<font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Arial"/></font>
<font><b/><sz val="14"/><color rgb="FF15365D"/><name val="Arial"/></font>
<font><b/><sz val="10"/><color rgb="FF15365D"/><name val="Arial"/></font>
</fonts>
<fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FF28588A"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFE5F4FB"/><bgColor indexed="64"/></patternFill></fill></fills>
<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>
<border><left style="thin"><color rgb="FFB7CCE0"/></left><right style="thin"><color rgb="FFB7CCE0"/></right><top style="thin"><color rgb="FFB7CCE0"/></top><bottom style="thin"><color rgb="FFB7CCE0"/></bottom><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="7">
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" applyBorder="1"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="1" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="2" fillId="0" borderId="1" applyFont="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="3" fillId="3" borderId="1" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
<xf numFmtId="0" fontId="0" fillId="0" borderId="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>"""
private fun sheetXml(rows: List<List<String>>): String {
    val maxCols = rows.maxOfOrNull { it.size } ?: 1
    val cols = (1..maxCols).joinToString("") { i ->
        val width = when { i == 1 -> 17; i == 2 -> 18; i == 3 -> 30; else -> 15 }
        "<col min=\"$i\" max=\"$i\" width=\"$width\" customWidth=\"1\"/>"
    }
    val body = rows.mapIndexed { ri,row ->
        val cells = row.mapIndexed { ci,value ->
            val ref = colName(ci+1)+(ri+1)
            val style = if (ri == 0) 1 else if (ci == 0 && ri < 4) 2 else 3
            "<c r=\"$ref\" s=\"$style\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${xmlEscape(value.toPersianDigits())}</t></is></c>"
        }.joinToString("")
        "<row r=\"${ri+1}\" ht=\"${if (ri==0) 30 else 24}\" customHeight=\"1\">$cells</row>"
    }.joinToString("")
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0" rightToLeft="1"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>$cols</cols><sheetData>$body</sheetData><pageMargins left="0.25" right="0.25" top="0.45" bottom="0.45" header="0.2" footer="0.2"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/><printOptions horizontalCentered="1"/><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr></worksheet>"""
}

private val reminderBackupHeaders = listOf("id", "kind", "title", "whenMillis", "monthly", "soundUri", "enabled")

private fun buildReminderBackupCsv(reminders: List<PersonalReminder>): String = buildString {
    append("#REMINDERS\r\n")
    append(reminderBackupHeaders.joinToString(",") { csvEscape(it) }).append("\r\n")
    reminders.forEach { r ->
        append(listOf(r.id.toString(), r.kind, r.title, r.whenMillis.toString(), r.monthly.toString(), r.soundUri, r.enabled.toString()).joinToString(",") { csvEscape(it) }).append("\r\n")
    }
}

private fun reminderRowsToRecords(rows: List<List<String>>): List<PersonalReminder> {
    require(rows.isNotEmpty() && rows.first().map { it.trim() }.containsAll(reminderBackupHeaders)) {
        "ساختار فایل پشتیبان یادآورها معتبر نیست"
    }
    val header = rows.first().map { it.trim() }
    val ix = reminderBackupHeaders.associateWith { header.indexOf(it) }
    return rows.drop(1).filter { row -> row.any { cell -> cell.isNotBlank() } }.map { row ->
        fun cell(name: String): String = row.getOrElse(ix[name] ?: -1) { "" }.trim()
        val id = cell("id").toLongOrNull() ?: 0L
        val millis = cell("whenMillis").toLongOrNull() ?: throw IllegalArgumentException("زمان یکی از یادآورها معتبر نیست")
        val kind = cell("kind").ifBlank { "قسط" }
        val title = cell("title")
        require(title.isNotBlank()) { "عنوان یکی از یادآورها خالی است" }
        PersonalReminder(id, kind, title, millis, cell("monthly").equals("true", true) || cell("monthly") == "1", cell("soundUri"), !cell("enabled").equals("false", true) && cell("enabled") != "0")
    }
}

private fun readReminderBackupCsv(text: String): List<PersonalReminder> {
    val rows = parseCsvRows(text)
    val marker = rows.indexOfFirst { it.firstOrNull()?.trim() == "#REMINDERS" }
    require(marker >= 0 && marker + 1 < rows.size) { "این فایل، پشتیبان یادآورهای مورخ نیست" }
    val table = rows.drop(marker + 1).filter { it.isNotEmpty() }
    return reminderRowsToRecords(table)
}

private fun simpleXlsxSheetXml(rows: List<List<String>>): String {
    val body = rows.mapIndexed { ri, row ->
        val cells = row.mapIndexed { ci, value ->
            "<c r=\"${colName(ci + 1)}${ri + 1}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${xmlEscape(value)}</t></is></c>"
        }.joinToString("")
        "<row r=\"${ri + 1}\">$cells</row>"
    }.joinToString("")
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0" rightToLeft="1"/></sheetViews><sheetData>$body</sheetData></worksheet>"""
}

private fun buildReminderBackupXlsx(reminders: List<PersonalReminder>): ByteArray {
    val rows = mutableListOf(reminderBackupHeaders)
    reminders.forEach { r -> rows.add(listOf(r.id.toString(), r.kind, r.title, r.whenMillis.toString(), r.monthly.toString(), r.soundUri, r.enabled.toString())) }
    val entries = linkedMapOf(
        "[Content_Types].xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""",
        "_rels/.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""",
        "xl/workbook.xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Reminders" sheetId="1" r:id="rId1"/></sheets></workbook>""",
        "xl/_rels/workbook.xml.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""",
        "xl/worksheets/sheet1.xml" to simpleXlsxSheetXml(rows)
    )
    val output = java.io.ByteArrayOutputStream()
    java.util.zip.ZipOutputStream(output).use { zip -> entries.forEach { (name, content) ->
        zip.putNextEntry(java.util.zip.ZipEntry(name)); zip.write(content.toByteArray(Charsets.UTF_8)); zip.closeEntry()
    } }
    return output.toByteArray()
}

private fun readReminderBackupXlsx(bytes: ByteArray): List<PersonalReminder> {
    val entries = mutableMapOf<String, ByteArray>()
    java.util.zip.ZipInputStream(bytes.inputStream()).use { zip ->
        while (true) { val entry = zip.nextEntry ?: break
            if (entry.name == "xl/worksheets/sheet1.xml" || entry.name == "xl/sharedStrings.xml") entries[entry.name] = zip.readBytes()
            zip.closeEntry()
        }
    }
    val shared = mutableListOf<String>()
    entries["xl/sharedStrings.xml"]?.let { bytesShared ->
        val parser = android.util.Xml.newPullParser(); parser.setInput(bytesShared.inputStream(), "UTF-8")
        var inItem = false; var inText = false; var item = StringBuilder(); var event = parser.eventType
        while (event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
            when (event) {
                org.xmlpull.v1.XmlPullParser.START_TAG -> when (parser.name) { "si" -> { inItem = true; item = StringBuilder() }; "t" -> if (inItem) inText = true }
                org.xmlpull.v1.XmlPullParser.TEXT -> if (inItem && inText) item.append(parser.text)
                org.xmlpull.v1.XmlPullParser.END_TAG -> when (parser.name) { "t" -> inText = false; "si" -> { shared.add(item.toString()); inItem = false } }
            }; event = parser.next()
        }
    }
    val sheet = entries["xl/worksheets/sheet1.xml"] ?: throw IllegalArgumentException("برگهٔ Excel پیدا نشد")
    val parser = android.util.Xml.newPullParser(); parser.setInput(sheet.inputStream(), "UTF-8")
    val rows = mutableListOf<List<String>>(); var row: MutableList<String>? = null
    var cell = StringBuilder(); var inCell = false; var cellType = ""; var cellRef = ""; var event = parser.eventType
    while (event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
        when (event) {
            org.xmlpull.v1.XmlPullParser.START_TAG -> when (parser.name) {
                "row" -> row = mutableListOf()
                "c" -> { inCell = true; cell = StringBuilder(); cellType = parser.getAttributeValue(null, "t") ?: ""; cellRef = parser.getAttributeValue(null, "r") ?: "" }
            }
            org.xmlpull.v1.XmlPullParser.TEXT -> if (inCell) cell.append(parser.text)
            org.xmlpull.v1.XmlPullParser.END_TAG -> when (parser.name) {
                "c" -> {
                    val raw = cell.toString(); val value = if (cellType == "s") shared.getOrNull(raw.toIntOrNull() ?: -1).orEmpty() else raw
                    val col = Regex("[A-Z]+").find(cellRef)?.value?.fold(0) { acc, ch -> acc * 26 + ch.code - 'A'.code + 1 }?.minus(1) ?: (row?.size ?: 0)
                    row?.let { while (it.size <= col) it.add(""); it[col] = value }; inCell = false
                }
                "row" -> { row?.let { rows.add(it) }; row = null }
            }
        }; event = parser.next()
    }
    return reminderRowsToRecords(rows)
}

private fun buildRemindersPdf(reminders: List<PersonalReminder>): ByteArray {
    val document = android.graphics.pdf.PdfDocument()
    val pageWidth = 595; val pageHeight = 842
    val margin = 30f; val right = pageWidth - margin; val contentWidth = (pageWidth - margin * 2).toInt()
    val navy = android.graphics.Color.rgb(21, 54, 93)
    val blue = android.graphics.Color.rgb(36, 90, 141)
    val teal = android.graphics.Color.rgb(0, 125, 129)
    val gold = android.graphics.Color.rgb(195, 150, 58)
    val ink = android.graphics.Color.rgb(40, 58, 79)
    val muted = android.graphics.Color.rgb(94, 115, 137)
    val pale = android.graphics.Color.rgb(239, 246, 253)
    val line = android.graphics.Color.rgb(214, 226, 239)
    val white = android.graphics.Color.WHITE
    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    fun fill(c: android.graphics.Canvas, l: Float, t: Float, r: Float, b: Float, color: Int, radius: Float = 0f) {
        p.color = color; p.style = android.graphics.Paint.Style.FILL
        if (radius > 0f) c.drawRoundRect(l, t, r, b, radius, radius, p) else c.drawRect(l, t, r, b, p)
    }
    fun text(c: android.graphics.Canvas, value: String, xRight: Float, top: Float, width: Int, size: Float, color: Int = ink, bold: Boolean = false, maxLines: Int = 1, center: Boolean = false): Int {
        val rendered = value.toPersianDigits()
        val tp = android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size; this.color = color
            typeface = android.graphics.Typeface.create("sans-serif", if (bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        }
        val layout = android.text.StaticLayout.Builder.obtain(rendered, 0, rendered.length, tp, width.coerceAtLeast(1))
            .setTextDirection(android.text.TextDirectionHeuristics.RTL)
            .setAlignment(if (center) android.text.Layout.Alignment.ALIGN_CENTER else android.text.Layout.Alignment.ALIGN_OPPOSITE)
            .setIncludePad(false).setMaxLines(maxLines).setEllipsize(android.text.TextUtils.TruncateAt.END).build()
        c.save(); c.translate(xRight - width, top); layout.draw(c); c.restore()
        return layout.height
    }
    val sorted = reminders.sortedBy { it.whenMillis }
    val activeCount = sorted.count { it.enabled }
    val recurringCount = sorted.count { it.monthly }
    var pageNumber = 0
    var page: android.graphics.pdf.PdfDocument.Page? = null
    var canvas: android.graphics.Canvas? = null
    var y = 0f
    fun startPage() {
        pageNumber++
        page = document.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
        canvas = page!!.canvas
        val c = canvas!!
        fill(c, 0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), white)
        fill(c, 0f, 0f, pageWidth.toFloat(), 8f, gold)
        fill(c, margin, 22f, right, 102f, navy, 12f)
        text(c, "مورخ", right - 14f, 33f, 95, 18f, white, true)
        text(c, "یادآورهای اقساط و جلسات", right - 14f, 60f, 320, 17f, white, true)
        text(c, "فهرست یادآوری‌های ثبت‌شده", right - 14f, 83f, 320, 9f, android.graphics.Color.rgb(218, 232, 246))
        fill(c, margin, 113f, right, 158f, pale, 8f)
        val tileGap = 8f; val tileW = (contentWidth - tileGap * 2) / 3f
        val stats = listOf(Triple("مجموع یادآورها", sorted.size.toString(), navy), Triple("فعال", activeCount.toString(), teal), Triple("تکرار ماهانه", recurringCount.toString(), blue))
        stats.forEachIndexed { i, stat ->
            val l = margin + i * (tileW + tileGap)
            fill(c, l, 113f, l + tileW, 158f, white, 6f)
            text(c, stat.first, l + tileW - 7f, 120f, (tileW - 14f).toInt(), 8.5f, muted, false, 1, true)
            text(c, stat.second, l + tileW - 7f, 137f, (tileW - 14f).toInt(), 14f, stat.third, true, 1, true)
        }
        y = 174f
    }
    fun finishPage() {
        val c = canvas
        if (c != null) {
            p.color = line; p.strokeWidth = 0.7f; p.style = android.graphics.Paint.Style.STROKE
            c.drawLine(margin, pageHeight - 30f, right, pageHeight - 30f, p); p.style = android.graphics.Paint.Style.FILL
            text(c, "مورخ  •  خروجی یادآورها", right, pageHeight - 23f, 260, 8f, muted)
            text(c, "صفحه $pageNumber", margin + 90f, pageHeight - 23f, 90, 8f, muted)
        }
        page?.let { document.finishPage(it) }; page = null; canvas = null
    }
    startPage()
    if (sorted.isEmpty()) {
        fill(canvas!!, margin, y, right, y + 92f, pale, 10f)
        text(canvas!!, "هنوز یادآوری ثبت نشده است.", right - 14f, y + 29f, contentWidth - 28, 14f, navy, true, 2, true)
    } else sorted.forEachIndexed { index, reminder ->
        val dt = java.time.Instant.ofEpochMilli(reminder.whenMillis).atZone(java.time.ZoneId.systemDefault())
        val (jy, jm, jd) = gregorianToJalali(dt.toLocalDate())
        val date = "%04d/%02d/%02d".format(jy, jm, jd)
        val time = dt.toLocalTime().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"))
        val title = reminder.title.ifBlank { "بدون عنوان" }
        val titlePaint = android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 12.5f; color = ink; typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
        }
        val titleLayout = android.text.StaticLayout.Builder.obtain(title, 0, title.length, titlePaint, contentWidth - 100)
            .setTextDirection(android.text.TextDirectionHeuristics.RTL).setAlignment(android.text.Layout.Alignment.ALIGN_OPPOSITE)
            .setIncludePad(false).setMaxLines(2).setEllipsize(android.text.TextUtils.TruncateAt.END).build()
        val cardHeight = maxOf(76f, 48f + titleLayout.height)
        if (y + cardHeight > pageHeight - 46f) { finishPage(); startPage() }
        val c = canvas!!
        fill(c, margin, y, right, y + cardHeight, if (index % 2 == 0) pale else white, 8f)
        fill(c, right - 4f, y + 8f, right, y + cardHeight - 8f, if (reminder.enabled) teal else muted, 2f)
        val badgeColor = if (reminder.kind.contains("قسط")) blue else teal
        fill(c, margin + 10f, y + 11f, margin + 88f, y + 32f, badgeColor, 6f)
        text(c, reminder.kind, margin + 82f, y + 17f, 64, 8.5f, white, true, 1, true)
        text(c, title, right - 14f, y + 12f, contentWidth - 115, 12.5f, ink, true, 2)
        val flags = listOf(if (reminder.monthly) "تکرار ماهانه" else "یک‌بار", if (reminder.enabled) "فعال" else "غیرفعال").joinToString("  •  ")
        text(c, flags, right - 14f, y + 19f + titleLayout.height, contentWidth - 28, 8.5f, if (reminder.enabled) teal else muted)
        val detailsY = y + cardHeight - 22f
        text(c, "تاریخ: $date", right - 14f, detailsY, 170, 9f, muted)
        text(c, "ساعت: $time", margin + 190f, detailsY, 105, 9f, muted)
        y += cardHeight + 8f
    }
    finishPage()
    val output = java.io.ByteArrayOutputStream()
    document.writeTo(output); document.close()
    return output.toByteArray()
}
private fun readBackupXlsx(bytes: ByteArray): Pair<List<WorkDay>,List<Pair<String,String>>> {
    val entries = mutableMapOf<String,ByteArray>()
    java.util.zip.ZipInputStream(bytes.inputStream()).use { zip ->
        while(true) {
            val e = zip.nextEntry ?: break
            if (e.name == "xl/worksheets/sheet1.xml" || e.name == "xl/worksheets/sheet2.xml" || e.name == "xl/sharedStrings.xml") entries[e.name] = zip.readBytes()
            zip.closeEntry()
        }
    }
    fun parseXml(xmlBytes: ByteArray?): List<List<String>> {
        if(xmlBytes == null) return emptyList()
        val parser = android.util.Xml.newPullParser()
        parser.setInput(xmlBytes.inputStream(), "UTF-8")
        val rows = mutableListOf<List<String>>()
        var row: MutableList<String>? = null
        var cell = StringBuilder()
        var inCell = false
        var event = parser.eventType
        while(event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
            when(event) {
                org.xmlpull.v1.XmlPullParser.START_TAG -> when(parser.name) {
                    "row" -> row = mutableListOf()
                    "c" -> { inCell = true; cell = StringBuilder() }
                    "t", "v" -> Unit
                }
                org.xmlpull.v1.XmlPullParser.TEXT -> if(inCell) cell.append(parser.text)
                org.xmlpull.v1.XmlPullParser.END_TAG -> when(parser.name) {
                    "c" -> { row?.add(cell.toString()); inCell = false }
                    "row" -> { row?.let { rows.add(it) }; row = null }
                }
            }
            event = parser.next()
        }
        return rows
    }
    val sharedStrings = mutableListOf<String>()
    entries["xl/sharedStrings.xml"]?.let { sharedBytes ->
        val sp = android.util.Xml.newPullParser(); sp.setInput(sharedBytes.inputStream(), "UTF-8")
        var insideItem = false; var insideText = false; var item = StringBuilder(); var ev = sp.eventType
        while (ev != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
            when (ev) {
                org.xmlpull.v1.XmlPullParser.START_TAG -> when (sp.name) {
                    "si" -> { insideItem = true; item = StringBuilder() }
                    "t" -> if (insideItem) insideText = true
                }
                org.xmlpull.v1.XmlPullParser.TEXT -> if (insideItem && insideText) item.append(sp.text)
                org.xmlpull.v1.XmlPullParser.END_TAG -> when (sp.name) {
                    "t" -> insideText = false
                    "si" -> { sharedStrings.add(item.toString()); insideItem = false }
                }
            }
            ev = sp.next()
        }
    }
    fun parseSheet(xmlBytes: ByteArray?): List<List<String>> {
        if (xmlBytes == null) return emptyList()
        val parser = android.util.Xml.newPullParser(); parser.setInput(xmlBytes.inputStream(), "UTF-8")
        val rows = mutableListOf<List<String>>(); var row: MutableList<String>? = null
        var cellValue = StringBuilder(); var inCell = false; var cellType = ""; var cellRef = ""
        var event = parser.eventType
        while(event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
            when(event) {
                org.xmlpull.v1.XmlPullParser.START_TAG -> when(parser.name) {
                    "row" -> row = mutableListOf()
                    "c" -> { inCell = true; cellValue = StringBuilder(); cellType = parser.getAttributeValue(null,"t") ?: ""; cellRef = parser.getAttributeValue(null,"r") ?: "" }
                }
                org.xmlpull.v1.XmlPullParser.TEXT -> if(inCell) cellValue.append(parser.text)
                org.xmlpull.v1.XmlPullParser.END_TAG -> when(parser.name) {
                    "c" -> {
                        val value = cellValue.toString()
                        val resolved = if (cellType == "s") sharedStrings.getOrNull(value.toIntOrNull() ?: -1).orEmpty() else value
                        val col = Regex("[A-Z]+").find(cellRef)?.value?.let { name -> name.fold(0) { acc,ch -> acc*26 + ch.code-'A'.code+1 }-1 } ?: (row?.size ?: 0)
                        row?.let { r -> while(r.size <= col) r.add(""); r[col] = resolved }
                        inCell = false
                    }
                    "row" -> { row?.let { rows.add(it) }; row = null }
                }
            }
            event = parser.next()
        }
        return rows
    }
    val workRows = parseSheet(entries["xl/worksheets/sheet1.xml"])
    val settingsRows = parseSheet(entries["xl/worksheets/sheet2.xml"])
    require(workRows.isNotEmpty() && workRows.first().firstOrNull()?.trim() == "date") { "ساختار فایل Excel معتبر نیست؛ از فایل پشتیبان کامل استفاده کن" }
    return workRowsToBackup(workRows, settingsRows)
}

private fun workRowsToBackup(workRows: List<List<String>>, settingsRows: List<List<String>>): Pair<List<WorkDay>,List<Pair<String,String>>> {
    val days = workRows.drop(1).map { row -> row.map { it.toLatinDigits().trim() } }
        .filter { it.size >= 11 && it[0].replace('/', '-').matches(Regex("\\d{4}-\\d{1,2}-\\d{1,2}")) }.map { r ->
        val dateParts = r[0].replace('/', '-').split('-')
        val normalizedDate = if (dateParts.size == 3) "%04d-%02d-%02d".format(dateParts[0].toInt(),dateParts[1].toInt(),dateParts[2].toInt()) else r[0]
        WorkDay(normalizedDate,r.getOrElse(2){""},r.getOrElse(3){""},r.getOrElse(4){""},r.getOrElse(5){""},r.getOrElse(6){""},r.getOrElse(7){""},r.getOrElse(10){""},r.getOrElse(1){"کاری"}.ifBlank{"کاری"},r.getOrElse(9){""},r.getOrNull(11)?.toBoolean() ?: false,r.getOrElse(12){""},r.getOrElse(13){""},r.getOrElse(14){""},r.getOrElse(15){""},r.getOrElse(16){""},r.getOrElse(17){""},r.getOrElse(18){""},r.getOrElse(19){""},r.getOrElse(20){""},r.getOrElse(21){""},r.getOrNull(22)?.toBoolean() ?: listOf(18,19,20,21).any { !r.getOrNull(it).isNullOrBlank() },r.getOrElse(23){""})
    }
    val settings = settingsRows.drop(1).filter { it.size >= 2 && it[0].isNotBlank() }.map { it[0] to it[1] }
    require(days.isNotEmpty() || settings.isNotEmpty()) { "هیچ ردیف معتبری در فایل وجود ندارد" }
    return days to settings
}

private fun csvEscape(value: String): String = if (value.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) "\"${value.replace("\"", "\"\"")}\"" else value
private fun buildBackupCsv(db: WorkDb): String {
    val out = StringBuilder()
    val headers = listOf("date","dayType","in1","out1","in2","out2","in3","out3","duration","overtimeOverride","note","shiftEnabled","shiftStart","shiftEnd","shiftStartDate","shiftEndDate","holidayIn","holidayOut","leave1Start","leave1End","leave2Start","leave2End","hourlyLeaveEnabled","extraDayTypes")
    out.append("#WORKDAYS\r\n").append(headers.joinToString(",") { csvEscape(it) }).append("\r\n")
    db.allDaysForBackup().forEach { d ->
        val values = listOf(d.date,d.dayType,d.in1,d.out1,d.in2,d.out2,d.in3,d.out3,hm(duration(d)),d.overtimeOverride,d.note,d.shiftEnabled.toString(),d.shiftStart,d.shiftEnd,d.shiftStartDate,d.shiftEndDate,d.holidayIn,d.holidayOut,d.leave1Start,d.leave1End,d.leave2Start,d.leave2End,d.hourlyLeaveEnabled.toString(),d.extraDayTypes)
        out.append(values.joinToString(",") { csvEscape(it) }).append("\r\n")
    }
    out.append("#SETTINGS\r\nkey,value\r\n")
    db.allSettings().forEach { (k,v) -> out.append(csvEscape(k)).append(',').append(csvEscape(v)).append("\r\n") }
    return out.toString()
}
private fun parseCsvRows(text: String): List<List<String>> {
    val rows = mutableListOf<List<String>>(); var row = mutableListOf<String>(); val field = StringBuilder(); var quoted = false; var i = 0
    while (i < text.length) {
        val ch = text[i]
        if (quoted) {
            if (ch == '"' && i+1 < text.length && text[i+1] == '"') { field.append('"'); i++ }
            else if (ch == '"') quoted = false else field.append(ch)
        } else when(ch) {
            '"' -> quoted = true
            ',' -> { row.add(field.toString()); field.setLength(0) }
            '\n' -> { row.add(field.toString().removeSuffix("\r")); field.setLength(0); rows.add(row); row = mutableListOf() }
            else -> field.append(ch)
        }
        i++
    }
    if (field.isNotEmpty() || row.isNotEmpty()) { row.add(field.toString().removeSuffix("\r")); rows.add(row) }
    return rows
}
private fun readBackupCsv(text: String): Pair<List<WorkDay>,List<Pair<String,String>>> {
    val rows = parseCsvRows(text); val wi = rows.indexOfFirst { it.firstOrNull()?.trim() == "#WORKDAYS" }; val si = rows.indexOfFirst { it.firstOrNull()?.trim() == "#SETTINGS" }
    require(wi >= 0) { "فایل CSV پشتیبان مورخ نیست یا سرستون‌ها پیدا نشدند" }
    val workEnd = if (si > wi) si else rows.size
    val workRows = rows.subList(wi+1, workEnd).filter { it.isNotEmpty() }
    val settingsRows = if (si >= 0) rows.drop(si+1).filter { it.isNotEmpty() } else emptyList()
    return workRowsToBackup(workRows, settingsRows)
}

@Composable
private fun HelpScreen(modifier: Modifier = Modifier) {
    val sections = listOf(
        "۱. صفحهٔ خانه — انتخاب تاریخ و ثبت روز" to
            "در ابتدای خانه، خلاصهٔ کارکرد ماه انتخاب‌شده شامل ساعت کار، اضافه‌کاری، استحقاقی، استعلاجی، مرخصی ساعتی، مأموریت، تعداد شیفت و توراهی را می‌بینی. این اعداد با تغییر تاریخ یا ثبت اطلاعات به‌روز می‌شوند. فلش‌های «روز قبل» و «روز بعد» برای جابه‌جایی روزها هستند. با لمس تاریخ می‌توانی از تقویم هم روز موردنظر را انتخاب کنی. ثبت هر روز از روزهای دیگر مستقل است. دکمهٔ «ذخیره اطلاعات روز» ثبت را تأیید می‌کند و دکمهٔ «حذف اطلاعات روز» پس از درخواست تأیید، همهٔ اطلاعات ثبت‌شدهٔ همان روز را حذف می‌کند.",
        "۲. صفحهٔ خانه — نوع روز و ساعت‌های ورود و خروج" to
            "در کادر «نوع روز» گزینه‌های کاری، تعطیل رسمی، استحقاقی، مأموریت، استعلاجی و تعطیل مناسبتی قرار دارند. برخی وضعیت‌ها هم‌زمان مجازند: تعطیل رسمی یا مناسبتی همراه با یکی از مرخصی‌ها یا مأموریت، و کاری همراه مأموریت. لمس دوبارهٔ گزینهٔ روشن آن را خاموش می‌کند. جمعه پیش‌فرض تعطیل رسمی است. برای روز کاری، ساعت و دقیقهٔ ورود و خروج را در کادرهای جدا وارد کن؛ با دکمهٔ ۲ و سپس ۳ نوبت‌های دیگر را باز کن. هنگام ویرایش ساعت، اولین رقم جدید جایگزین عدد قبلی می‌شود. زمان‌های خالی در محاسبات وارد نمی‌شوند. در روزهای تعطیل یا مرخصی، زمان‌های قسمت اضافه‌کاری جدا از کارکرد عادی محسوب می‌شوند.",
        "۳. صفحهٔ خانه — مرخصی ساعتی، شیفت و یادداشت" to
            "مرخصی ساعتی کلید روشن/خاموش دارد و تنها در حالت روشن، زمان شروع و پایانش دیده می‌شود. برای شیفت، تاریخ و ساعت شروع و پایان را مستقل وارد کن؛ مدت شیفت در کادر زرد نمایش داده می‌شود و با اضافه‌کاری یکی نیست. یادداشت روز را می‌توان با متن طولانی ثبت کرد؛ یادداشت همان روز در گزارش ماهانه و خروجی‌ها نیز نمایش داده می‌شود، مگر اینکه هنگام خروجی‌گرفتن گزینهٔ درج یادداشت را خاموش کرده باشی. ذخیرهٔ اطلاعات هر روز نباید یادداشت روز دیگر را تغییر دهد.",
        "۵. تقویم" to
            "از نوار پایین «تقویم» را باز کن. روزهای تعطیل رسمی و مناسبت‌ها مشخص‌اند. با انتخاب هر روز، مناسبت‌های همان تاریخ را ببین و برای ثبت کارکرد از دکمهٔ ورود به آن روز استفاده کن. تاریخ شمسی، قمری و میلادی نمایش داده می‌شوند؛ لمس تاریخ قمری یا میلادی قالب نمایش را بین نوشتاری و عددی تغییر می‌دهد. تاریخ قمریِ محاسباتی ممکن است با اعلام رسمی رؤیت هلال متفاوت باشد. در تنظیمات می‌توانی اطلاعات رسمی سال را دستی دریافت و ذخیره کنی.",
        "۶. گزارش ماه — جزئیات و خروجی" to
            "با آیکون «گزارش ماه» در نوار پایین وارد شو. ماه و سال را انتخاب کن. خلاصهٔ بالای صفحه، آمار کارکرد و انواع مرخصی، اضافه‌کاری، مأموریت، شیفت و توراهی را نشان می‌دهد. در بخش «کارت روز»، کارت هر روز به ترتیب تاریخ با وضعیت‌ها، ساعت‌های ثبت‌شده، یادداشت و اعداد مربوط نشان داده می‌شود. روزهای تعطیل از نظر رنگ متمایز هستند. برای گرفتن Excel یا PDF، ابتدا مشخص کن یادداشت‌ها در خروجی درج شوند یا خیر. در گزارش تفصیلی، سه ورود و سه خروج در ستون‌های جدا هستند.",
        "۷. گزارش سال — تفصیلی و جامع" to
            "با آیکون «گزارش سال» وارد شو و سال را انتخاب کن. خلاصهٔ ماه‌های سال و جمع کل سال نشان داده می‌شوند. خروجی تفصیلی Excel/PDF جزئیات ثبت روزانه را در گزارش ماهانهٔ هر ماه ارائه می‌دهد. گزینهٔ «خلاصهٔ جامع سالانه» خروجی جداگانه‌ای برای یک صفحهٔ A4 ارائه می‌کند: آمار کل سال در بالا و عملکرد هر یک از ۱۲ ماه در پایین. تعداد شیفت‌ها، ساعت کار، اضافه‌کاری، مرخصی ساعتی، مأموریت، استحقاقی، استعلاجی، توراهی و دیگر شاخص‌ها در آن قرار دارند. این خلاصه جایگزین گزارش تفصیلی نیست.",
        "۸. یادآورها — اقساط و جلسات" to
            "در «یادآورها» نوع قسط یا جلسه، عنوان، تاریخ شمسی و ساعت را وارد کن. برای یک روز حتی اگر ساعت گذشته باشد می‌توان یادآور ثبت کرد؛ هشدار گذشته پخش نمی‌شود. تکرار ماهانه را در صورت نیاز روشن کن. یادآورهای ثبت‌شده قابل مشاهده، ویرایش و حذف هستند. صدای هشدار می‌تواند از زنگ‌های گوشی یا فایل انتخابی باشد. اگر برای روز انتخاب‌شده یادآوری وجود داشته باشد، متن و ساعت آن در صفحهٔ خانه زیر تاریخ همان روز نمایش داده می‌شود.",
        "۹. اوقات شرعی و اذان" to
            "شهر ایران را انتخاب کن تا اذان صبح، طلوع آفتاب، اذان ظهر، غروب آفتاب، اذان مغرب و نیمه‌شب نمایش داده شوند. دریافت تازهٔ شهرها و زمان‌ها فقط از طریق دکمهٔ مخصوص انجام می‌شود. می‌توانی هشدار صبح، ظهر و مغرب را جداگانه کنترل کنی. در بانک اذان، ابتدا فقط نام مؤذن‌ها نمایش داده می‌شود؛ برای هر مورد می‌توان فایلش را جدا دانلود کرد، پخش آزمایشی را شروع یا متوقف کرد، و پس از پسندیدن با دکمهٔ انتخاب آن را صدای اصلی قرار داد. حذف اذان دانلودی فایل برنامه را از حافظه پاک می‌کند، اما نام مؤذن و امکان دانلود مجدد را نگه می‌دارد.",
        "۱۰. تنظیمات — اعلان‌ها و ساعت موظفی" to
            "در «تنظیمات» کلید اصلی اعلان‌ها را برای روشن/خاموش‌کردن همهٔ اعلان‌ها و هشدارهای برنامه به کار ببر. کلیدهای جداگانهٔ تاریخ دائمی، اذان، قسط و جلسه هم در همین بخش هستند. اعلان دائمی می‌تواند تاریخ شمسی و قمری و اذان بعدی را نمایش دهد. ساعت موظفی شنبه تا چهارشنبه به‌صورت پیش‌فرض ۰۷:۰۰ و پنجشنبه ۰۵:۰۰ است؛ هر دو مقدار را می‌توان تغییر داد و ذخیره کرد. دریافت تازهٔ مناسبت‌های تقویم نیز در تنظیمات انجام می‌شود.",
        "۱۱. پشتیبان‌گیری، بازیابی و حذف اطلاعات" to
            "قبل از هر حذف گسترده یا به‌روزرسانی حساس، از «تنظیمات ← ساخت پشتیبان کارکرد CSV» یک فایل پشتیبان بساز و آن را در حافظهٔ امن نگهدار. برای بازیابی کارکرد، گزینهٔ «بازیابی اطلاعات کارکرد از Excel یا CSV» را بزن و فایل صحیح را انتخاب کن. برای یادآورها، از بخش سبزرنگ «پشتیبان‌گیری و بازیابی یادآورها» استفاده کن؛ این بخش به‌طور مستقل از کارکرد، CSV و Excel می‌سازد و بازیابی می‌کند. پشتیبان کامل بعد از تأیید، داده‌های روزانهٔ فعلی را جایگزین می‌کند؛ بنابراین پیش از بازیابی فایل دیگری از وضع موجود تهیه کن. فایل Excel گزارش دوره‌ای با پشتیبان کامل فرق دارد: هنگام بازیابی آن، فقط داده‌های روزهای آن دوره ادغام می‌شوند و سایر ماه‌ها باقی می‌مانند. فایل PDF برای مشاهده و چاپ است و پشتیبان قابل بازیابی نیست. در «حذف اطلاعات کارکرد در بازهٔ زمانی» تاریخ شروع و پایان را انتخاب کن؛ تعداد روزهای دارای داده نمایش داده می‌شود و حذف فقط پس از تأیید دائمی و وضعیت پشتیبان انجام می‌شود. حذف شامل ساعت‌ها، شیفت، یادداشت، نوع مرخصی، مأموریت، توراهی و ست؛ مناسبت‌های تقویم و یادآورها مستقل هستند.",
        "۱۲. نصب نسخهٔ جدید" to
            "نسخه جدید را فقط از سازنده دریافت شود . برای نصب نسخه جدید شماره نسخه باید بالاتر باشد.هنگام بروزرسانی در صورتی که پشتیبان گیری نکرده ای ، برای حفظ اطلاعات وارد شده ، برنامه قبلی را حذف نکن"
    )
    LazyColumn(modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        items(sections) { section ->
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp)) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    PersianText(section.first, color = Color(0xFF173F71), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    PersianText(section.second, fontSize = 12.sp, color = Color(0xFF426A6D), lineHeight = 20.sp)
                }
            }
        }
    }
}
