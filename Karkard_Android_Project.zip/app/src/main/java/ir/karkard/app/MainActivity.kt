package ir.karkard.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


private val ShiftYellow = Color(0xFFFFF0B3)
private val ShiftYellowText = Color(0xFF795500)
private val OvertimeGreen = Color(0xFFD9F2D9)
private val OvertimeGreenText = Color(0xFF176B36)

private fun String.toLatinDigits(): String = map { ch ->
    when (ch) {
        '۰' -> '0'; '۱' -> '1'; '۲' -> '2'; '۳' -> '3'; '۴' -> '4'
        '۵' -> '5'; '۶' -> '6'; '۷' -> '7'; '۸' -> '8'; '۹' -> '9'
        '٠' -> '0'; '١' -> '1'; '٢' -> '2'; '٣' -> '3'; '٤' -> '4'
        '٥' -> '5'; '٦' -> '6'; '٧' -> '7'; '٨' -> '8'; '٩' -> '9'
        else -> ch
    }
}.joinToString("")

private val JalaliMonthNames = listOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
private val JalaliWeekdayNames = listOf("یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه")
private fun jalaliDisplayDate(value: String): String = value.replace('-', '/').toPersianDigits()

private fun String.toPersianDigits(): String = map { ch ->
    when (ch) {
        '0' -> '۰'; '1' -> '۱'; '2' -> '۲'; '3' -> '۳'; '4' -> '۴'
        '5' -> '۵'; '6' -> '۶'; '7' -> '۷'; '8' -> '۸'; '9' -> '۹'
        else -> ch
    }
}.joinToString("")

@Composable
private fun PersianText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = FontFamily.SansSerif,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    textDecoration: TextDecoration? = null,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    style: TextStyle = LocalTextStyle.current
) {
    androidx.compose.material3.Text(
        text = text.toPersianDigits(),
        modifier = modifier,
        color = color,
        fontSize = fontSize,
        fontStyle = fontStyle,
        fontWeight = fontWeight,
        fontFamily = fontFamily,
        letterSpacing = letterSpacing,
        textDecoration = textDecoration,
        textAlign = textAlign,
        lineHeight = lineHeight,
        overflow = overflow,
        softWrap = softWrap,
        maxLines = maxLines,
        minLines = minLines,
        style = style
    )
}

data class WorkDay(
    val date: String,
    val in1: String = "", val out1: String = "",
    val in2: String = "", val out2: String = "",
    val in3: String = "", val out3: String = "",
    val note: String = "",
    val dayType: String = "کاری",
    val overtimeOverride: String = "",
    val shiftEnabled: Boolean = false,
    val shiftStart: String = "",
    val shiftEnd: String = "",
    val shiftStartDate: String = "",
    val shiftEndDate: String = "",
    val holidayIn: String = "",
    val holidayOut: String = ""
)

class WorkDb(context: Context) : SQLiteOpenHelper(context, "karkard.db", null, 9) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE workdays(
            date TEXT PRIMARY KEY, in1 TEXT, out1 TEXT, in2 TEXT, out2 TEXT,
            in3 TEXT, out3 TEXT, note TEXT, day_type TEXT DEFAULT 'کاری',
            overtime_override TEXT DEFAULT '', shift_enabled INTEGER DEFAULT 0, shift_start TEXT DEFAULT '', shift_end TEXT DEFAULT '', shift_start_date TEXT DEFAULT '', shift_end_date TEXT DEFAULT '', holiday_in TEXT DEFAULT '', holiday_out TEXT DEFAULT '')""")
        db.execSQL("CREATE TABLE holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL)")
        db.execSQL("CREATE TABLE official_holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL, year INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE holiday_sync(year INTEGER PRIMARY KEY, synced_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE calendar_events(date TEXT PRIMARY KEY, title TEXT NOT NULL, year INTEGER NOT NULL)")
        db.execSQL("""CREATE TABLE settings(
            key TEXT PRIMARY KEY, value TEXT NOT NULL)""")
        val defaults = mapOf(
            "overtime" to "true", "leave_hourly" to "true", "leave_daily" to "true",
            "mission" to "true", "shifts" to "true", "thursday_hours" to "true",
            "fixed_hours" to "false", "calendar" to "true",
            "workday_hours" to "08:00", "thursday_hours_value" to "04:00"
        )
        defaults.forEach { (k,v) ->
            val cv = ContentValues().apply { put("key", k); put("value", v) }
            db.insert("settings", null, cv)
        }
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN day_type TEXT DEFAULT 'کاری'")
            db.execSQL("ALTER TABLE workdays ADD COLUMN overtime_override TEXT DEFAULT ''")
            val defaults = mapOf("workday_hours" to "08:00", "thursday_hours_value" to "04:00")
            defaults.forEach { (k,v) ->
                val cv = ContentValues().apply { put("key",k); put("value",v) }
                db.insertWithOnConflict("settings", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
            }
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_enabled INTEGER DEFAULT 0")
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_start TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_end TEXT DEFAULT ''")
        }
        if (oldVersion < 4) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_start_date TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_end_date TEXT DEFAULT ''")
            db.execSQL("DELETE FROM settings WHERE key='shift_hours'")
        }
        if (oldVersion < 5) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN holiday_in TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN holiday_out TEXT DEFAULT ''")
        }
        db.execSQL("CREATE TABLE IF NOT EXISTS holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS official_holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL, year INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS holiday_sync(year INTEGER PRIMARY KEY, synced_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS calendar_events(date TEXT PRIMARY KEY, title TEXT NOT NULL, year INTEGER NOT NULL)")
        db.execSQL("DELETE FROM settings WHERE key='shift_hours'")
        if (oldVersion < 9) {
            // Force one fresh download from the verified FarsiUI calendar data source.
            // Existing saved calendar entries remain until the new download succeeds.
            db.delete("holiday_sync", null, null)
        }
    }

    fun getDay(date: String): WorkDay {
        readableDatabase.rawQuery("SELECT * FROM workdays WHERE date=?", arrayOf(date)).use { c ->
            if (c.moveToFirst()) return WorkDay(
                c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "",
                c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "",
                c.getString(6) ?: "", c.getString(7) ?: "",
                if (c.columnCount > 8) c.getString(8) ?: "کاری" else "کاری",
                if (c.columnCount > 9) c.getString(9) ?: "" else "",
                if (c.columnCount > 10) c.getInt(10) == 1 else false,
                if (c.columnCount > 11) c.getString(11) ?: "" else "",
                if (c.columnCount > 12) c.getString(12) ?: "" else "",
                if (c.columnCount > 13) c.getString(13) ?: "" else "",
                if (c.columnCount > 14) c.getString(14) ?: "" else "",
                if (c.columnCount > 15) c.getString(15) ?: "" else "",
                if (c.columnCount > 16) c.getString(16) ?: "" else ""
            )
        }
        return WorkDay(date)
    }
    fun saveDay(d: WorkDay) {
        val v = ContentValues().apply {
            put("date", d.date); put("in1",d.in1); put("out1",d.out1)
            put("in2",d.in2); put("out2",d.out2); put("in3",d.in3); put("out3",d.out3)
            put("note",d.note); put("day_type",d.dayType); put("overtime_override",d.overtimeOverride); put("shift_enabled", if(d.shiftEnabled) 1 else 0); put("shift_start",d.shiftStart); put("shift_end",d.shiftEnd); put("shift_start_date",d.shiftStartDate); put("shift_end_date",d.shiftEndDate)
            put("holiday_in", d.holidayIn); put("holiday_out", d.holidayOut)
        }
        writableDatabase.insertWithOnConflict("workdays", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun allDays(month: String): List<WorkDay> {
        val result = mutableListOf<WorkDay>()
        readableDatabase.rawQuery("SELECT * FROM workdays WHERE date LIKE ? ORDER BY date", arrayOf("$month%")).use { c ->
            while(c.moveToNext()) result.add(WorkDay(
                c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "",
                c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "",
                c.getString(6) ?: "", c.getString(7) ?: "",
                c.getString(8) ?: "کاری", c.getString(9) ?: "", c.getInt(10) == 1, c.getString(11) ?: "", c.getString(12) ?: "", c.getString(13) ?: "", c.getString(14) ?: "",
                if (c.columnCount > 15) c.getString(15) ?: "" else "", if (c.columnCount > 16) c.getString(16) ?: "" else ""
            ))
        }
        return result
    }
    fun allDaysYear(year: Int): List<WorkDay> = allDaysForBackup().filter { it.date.startsWith("%04d-".format(year)) }
    fun officialHolidays(year: Int): List<Pair<String, String>> {
        val result = mutableListOf<Pair<String, String>>()
        readableDatabase.rawQuery(
            "SELECT date,title FROM official_holidays WHERE year=? ORDER BY date",
            arrayOf(year.toString())
        ).use { c -> while (c.moveToNext()) result.add(c.getString(0) to c.getString(1)) }
        return result
    }

    fun officialHolidayTitle(date: String): String? {
        readableDatabase.rawQuery("SELECT title FROM official_holidays WHERE date=?", arrayOf(date)).use { c ->
            return if (c.moveToFirst()) c.getString(0) else null
        }
    }

    fun calendarEventTitle(date: String): String? {
        readableDatabase.rawQuery("SELECT title FROM calendar_events WHERE date=?", arrayOf(date)).use { c ->
            return if (c.moveToFirst()) c.getString(0) else null
        }
    }

    fun displayHolidayTitle(date: String): String? {
        val titles = listOfNotNull(officialHolidayTitle(date), holidayTitle(date), calendarEventTitle(date))
            .flatMap { value -> value.split("،").map { title -> title.trim() } }
            .filter { it.isNotBlank() }.distinct()
        return titles.takeIf { it.isNotEmpty() }?.joinToString("، ")
    }

    fun shouldSyncOfficialHolidays(year: Int, now: Long = System.currentTimeMillis()): Boolean {
        // Force a refresh of 1405 data if the previous app version saved a partial calendar
        // without the official Mab'ath holiday. This avoids the old 7-day cache hiding the fix.
        if (year == 1405 && officialHolidayTitle("1405-10-16").isNullOrBlank()) return true
        readableDatabase.rawQuery("SELECT synced_at FROM holiday_sync WHERE year=?", arrayOf(year.toString())).use { c ->
            if (!c.moveToFirst()) return true
            // Refresh at most once per week unless the user explicitly requests an update.
            return now - c.getLong(0) >= 7L * 24L * 60L * 60L * 1000L
        }
    }

    fun replaceOfficialHolidays(year: Int, holidays: List<Pair<String, String>>) {
        require(holidays.isNotEmpty()) { "فهرست تعطیلات خالی است؛ اطلاعات قبلی حفظ شد." }
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("official_holidays", "year=?", arrayOf(year.toString()))
            holidays.forEach { (date, title) ->
                val values = ContentValues().apply {
                    put("date", date); put("title", title); put("year", year)
                }
                db.insertWithOnConflict("official_holidays", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            val meta = ContentValues().apply { put("year", year); put("synced_at", System.currentTimeMillis()) }
            db.insertWithOnConflict("holiday_sync", null, meta, SQLiteDatabase.CONFLICT_REPLACE)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun calendarEvents(year: Int): List<Pair<String, String>> {
        val result = mutableListOf<Pair<String, String>>()
        readableDatabase.rawQuery("SELECT date,title FROM calendar_events WHERE year=? ORDER BY date", arrayOf(year.toString())).use { c ->
            while (c.moveToNext()) result.add(c.getString(0) to c.getString(1))
        }
        return result
    }

    fun replaceCalendarData(year: Int, holidays: List<Pair<String, String>>, events: List<Pair<String, String>>) {
        require(holidays.isNotEmpty()) { "فهرست تعطیلات خالی است؛ اطلاعات قبلی حفظ شد." }
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("official_holidays", "year=?", arrayOf(year.toString()))
            holidays.forEach { (date, title) ->
                val values = ContentValues().apply { put("date", date); put("title", title); put("year", year) }
                db.insertWithOnConflict("official_holidays", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.delete("calendar_events", "year=?", arrayOf(year.toString()))
            events.forEach { (date, title) ->
                val values = ContentValues().apply { put("date", date); put("title", title); put("year", year) }
                db.insertWithOnConflict("calendar_events", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            val meta = ContentValues().apply { put("year", year); put("synced_at", System.currentTimeMillis()) }
            db.insertWithOnConflict("holiday_sync", null, meta, SQLiteDatabase.CONFLICT_REPLACE)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun saveHoliday(date: String, title: String) {
        val v = ContentValues().apply { put("date", date); put("title", title) }
        writableDatabase.insertWithOnConflict("holidays", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun removeHoliday(date: String) { writableDatabase.delete("holidays", "date=?", arrayOf(date)) }
    fun allHolidays(): List<Pair<String,String>> {
        val out = mutableListOf<Pair<String,String>>()
        readableDatabase.rawQuery("SELECT date,title FROM holidays ORDER BY date", null).use { c -> while(c.moveToNext()) out.add(c.getString(0) to c.getString(1)) }
        return out
    }
    fun holidayTitle(date: String): String? {
        readableDatabase.rawQuery("SELECT title FROM holidays WHERE date=?", arrayOf(date)).use { c -> return if(c.moveToFirst()) c.getString(0) else null }
    }
    fun getSetting(key: String): Boolean {
        readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?", arrayOf(key)).use { c ->
            return c.moveToFirst() && c.getString(0) == "true"
        }
    }
    fun getSettingText(key: String, fallback: String = ""): String {
        readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?", arrayOf(key)).use { c ->
            return if (c.moveToFirst()) c.getString(0) else fallback
        }
    }
    fun setSettingText(key: String, value: String) {
        val v = ContentValues().apply { put("key",key); put("value",value) }
        writableDatabase.insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun setSetting(key: String, value: Boolean) {
        val v = ContentValues().apply { put("key",key); put("value",value.toString()) }
        writableDatabase.insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun allDaysForBackup(): List<WorkDay> {
        val result = mutableListOf<WorkDay>()
        readableDatabase.rawQuery("SELECT * FROM workdays ORDER BY date", null).use { c ->
            while(c.moveToNext()) result.add(WorkDay(
                c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "",
                c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "",
                c.getString(6) ?: "", c.getString(7) ?: "", c.getString(8) ?: "کاری",
                c.getString(9) ?: "", c.getInt(10) == 1, c.getString(11) ?: "", c.getString(12) ?: "", c.getString(13) ?: "", c.getString(14) ?: "",
                if (c.columnCount > 15) c.getString(15) ?: "" else "", if (c.columnCount > 16) c.getString(16) ?: "" else ""
            ))
        }
        return result
    }
    fun allSettings(): List<Pair<String,String>> {
        val result = mutableListOf<Pair<String,String>>()
        readableDatabase.rawQuery("SELECT key,value FROM settings ORDER BY key", null).use { c ->
            while(c.moveToNext()) result.add(c.getString(0) to c.getString(1))
        }
        allHolidays().forEach { (date,title) -> result.add("holiday:$date" to title) }
        return result
    }
    fun restoreBackup(days: List<WorkDay>, settings: List<Pair<String,String>>) {
        writableDatabase.beginTransaction()
        try {
            writableDatabase.delete("workdays", null, null)
            writableDatabase.delete("holidays", null, null)
            days.forEach { d ->
                val v = ContentValues().apply {
                    put("date",d.date); put("in1",d.in1); put("out1",d.out1)
                    put("in2",d.in2); put("out2",d.out2); put("in3",d.in3); put("out3",d.out3)
                    put("note",d.note); put("day_type",d.dayType); put("overtime_override",d.overtimeOverride); put("shift_enabled", if(d.shiftEnabled) 1 else 0); put("shift_start",d.shiftStart); put("shift_end",d.shiftEnd); put("shift_start_date",d.shiftStartDate); put("shift_end_date",d.shiftEndDate)
                    put("holiday_in", d.holidayIn); put("holiday_out", d.holidayOut)
                }
                writableDatabase.insertWithOnConflict("workdays",null,v,SQLiteDatabase.CONFLICT_REPLACE)
            }
            settings.forEach { (k,v) ->
                if (k.startsWith("holiday:")) {
                    val cv = ContentValues().apply { put("date",k.removePrefix("holiday:")); put("title",v) }
                    writableDatabase.insertWithOnConflict("holidays",null,cv,SQLiteDatabase.CONFLICT_REPLACE)
                } else {
                    val cv = ContentValues().apply { put("key",k); put("value",v) }
                    writableDatabase.insertWithOnConflict("settings",null,cv,SQLiteDatabase.CONFLICT_REPLACE)
                }
            }
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }
}

private data class DownloadedCalendarData(
    val holidays: List<Pair<String, String>>,
    val events: List<Pair<String, String>>
)

private fun fetchJson(url: String): org.json.JSONObject {
    val connection = java.net.URL(url).openConnection() as java.net.HttpURLConnection
    connection.requestMethod = "GET"
    connection.connectTimeout = 12_000
    connection.readTimeout = 18_000
    connection.setRequestProperty("Accept", "application/json")
    connection.setRequestProperty("User-Agent", "VaghtNegar-Android/0.7.0")
    try {
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        if (code !in 200..299) throw IllegalStateException("پاسخ سرویس تقویم: HTTP $code")
        return org.json.JSONObject(body)
    } finally { connection.disconnect() }
}

private fun fetchFarsiUiCalendarData(year: Int): DownloadedCalendarData? {
    // This source has an explicit, stable schema: items[].date, items[].title.fa,
    // and items[].isHoliday. It is the primary source to avoid schema drift in the
    // older Persian-Calendar API response.
    val base = "https://raw.githubusercontent.com/MiladJoodi/FarsiUI/main/calendar/years/$year"
    val holidayRoot = fetchJson("$base/holidays.json")
    if (holidayRoot.optInt("year", -1) != year) return null
    val holidayItems = holidayRoot.optJSONArray("items") ?: return null
    if (holidayItems.length() == 0) return null

    val holidays = linkedMapOf<String, MutableList<String>>()
    val allEvents = linkedMapOf<String, MutableList<String>>()
    fun add(target: MutableMap<String, MutableList<String>>, date: String, title: String) {
        val clean = title.trim()
        if (clean.isNotBlank()) {
            val list = target.getOrPut(date) { mutableListOf() }
            if (clean !in list) list.add(clean)
        }
    }
    fun parseItems(items: org.json.JSONArray, holidayOnly: Boolean) {
        for (i in 0 until items.length()) {
            val item = items.optJSONObject(i) ?: continue
            val date = item.optString("date")
            val parts = date.split("-").mapNotNull { it.toIntOrNull() }
            if (parts.size != 3 || parts[0] != year || parts[1] !in 1..12 || parts[2] !in 1..jalaliMonthLength(year, parts[1])) continue
            val titleObject = item.optJSONObject("title")
            val title = titleObject?.optString("fa").orEmpty().ifBlank { item.optString("title_fa") }
            if (title.isBlank()) continue
            if (!holidayOnly || item.optBoolean("isHoliday", item.optBoolean("is_holiday", false))) {
                if (item.optBoolean("isHoliday", item.optBoolean("is_holiday", false))) add(holidays, date, title)
            }
            add(allEvents, date, title)
        }
    }
    parseItems(holidayItems, holidayOnly = true)
    // Events file contains non-holiday observances, including non-holiday religious dates.
    val eventRoot = fetchJson("$base/events.json")
    if (eventRoot.optInt("year", -1) != year) return null
    val eventItems = eventRoot.optJSONArray("items") ?: return null
    if (eventItems.length() == 0) return null
    parseItems(eventItems, holidayOnly = false)

    val holidayList = holidays.map { it.key to it.value.joinToString("، ") }
    val eventList = allEvents.map { it.key to it.value.joinToString("، ") }
    if (holidayList.isEmpty() || eventList.isEmpty()) return null
    return DownloadedCalendarData(holidayList, eventList)
}

private fun fetchCalendarData(year: Int): DownloadedCalendarData {
    require(year in 1347..1500) { "سال باید بین ۱۳۴۷ و ۱۵۰۰ باشد." }
    try {
        fetchFarsiUiCalendarData(year)?.let { return it }
    } catch (_: Exception) {
        // Use the documented Persian-Calendar API below as a fallback if this year
        // has not been published by FarsiUI or the static source is temporarily down.
    }
    val holidayRoot = fetchJson("https://www.persian-calendar.com/api/holidays?year=$year")
    if (holidayRoot.optInt("year", -1) != year) throw IllegalStateException("سال دریافت‌شده با سال درخواستی یکسان نیست.")
    val holidayDays = holidayRoot.optJSONArray("data") ?: throw IllegalStateException("فهرست تعطیلات معتبر نیست.")
    val holidays = linkedMapOf<String, MutableList<String>>()
    val allEvents = linkedMapOf<String, MutableList<String>>()

    fun addTitle(target: MutableMap<String, MutableList<String>>, date: String, title: String) {
        val cleaned = title.trim()
        if (cleaned.isNotBlank()) {
            val list = target.getOrPut(date) { mutableListOf() }
            if (cleaned !in list) list.add(cleaned)
        }
    }

    // The holidays endpoint is authoritative for days off and also supplies each holiday's title.
    for (i in 0 until holidayDays.length()) {
        val item = holidayDays.optJSONObject(i) ?: continue
        val month = item.optInt("month_sh", 0)
        val day = item.optInt("day_sh", 0)
        if (item.optInt("year_sh", year) != year || month !in 1..12 || day !in 1..jalaliMonthLength(year, month)) continue
        val date = "%04d-%02d-%02d".format(Locale.ROOT, year, month, day)
        val events = item.optJSONArray("events") ?: continue
        for (j in 0 until events.length()) {
            val event = events.optJSONObject(j) ?: continue
            val title = event.optString("title_fa").trim()
            if (event.optBoolean("is_holiday", false)) addTitle(holidays, date, title)
            // Put official holidays in the event list too, so their title is visible in every calendar view.
            addTitle(allEvents, date, title)
        }
    }

    // Fetch all other occasions month by month. A failed month must not discard the verified holiday list.
    for (month in 1..12) {
        try {
            val root = fetchJson("https://www.persian-calendar.com/api/events?year=$year&month_sh=$month")
            if (root.optInt("year", year) != year) continue
            val days = root.optJSONArray("data") ?: continue
            for (i in 0 until days.length()) {
                val item = days.optJSONObject(i) ?: continue
                val m = item.optInt("month_sh", month)
                val d = item.optInt("day_sh", 0)
                if (item.optInt("year_sh", year) != year || m !in 1..12 || d !in 1..jalaliMonthLength(year, m)) continue
                val date = "%04d-%02d-%02d".format(Locale.ROOT, year, m, d)
                // Current API returns one event per item; also accept nested event arrays for compatibility.
                val title = item.optString("title_fa").trim()
                if (title.isNotBlank()) addTitle(allEvents, date, title)
                val nested = item.optJSONArray("events")
                if (nested != null) for (j in 0 until nested.length()) {
                    val event = nested.optJSONObject(j) ?: continue
                    addTitle(allEvents, date, event.optString("title_fa"))
                    if (event.optBoolean("is_holiday", false)) addTitle(holidays, date, event.optString("title_fa"))
                }
            }
        } catch (_: Exception) {
            // Continue; official holiday data is still usable offline even if this month's occasions endpoint fails.
        }
    }

    val holidayList = holidays.map { it.key to it.value.joinToString("، ") }
    val eventList = allEvents.map { it.key to it.value.joinToString("، ") }
    if (holidayList.isEmpty()) throw IllegalStateException("سرویس تعطیلات معتبری برنگرداند؛ اطلاعات قبلی حفظ شد.")
    if (eventList.isEmpty()) throw IllegalStateException("فهرست تعطیلات دریافت شد اما مناسبت‌ها خالی بودند؛ اطلاعات قبلی حفظ شد.")
    return DownloadedCalendarData(holidayList, eventList)
}

class MainActivity : ComponentActivity() {
    private lateinit var appDb: WorkDb
    private var systemDate by mutableStateOf(LocalDate.now())
    private var pendingBackup = false
    private var reportYear = 1405
    private var reportMonth = 1
    private var reportAnnual = false
    private var reportPdf = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        val db = WorkDb(this)
        appDb = db
        systemDate = LocalDate.now()
        setContent {
            var showIntro by remember { mutableStateOf(true) }
            LaunchedEffect(Unit) {
                kotlinx.coroutines.delay(3000)
                showIntro = false
            }
            if (showIntro) {
                androidx.compose.foundation.layout.Box(
                    modifier = Modifier.fillMaxSize().background(Color(0xFFFFFEFA)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.splash_vaghtnegar),
                        contentDescription = "وقت نگار حور",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                }
            } else {
                KarkardApp(db, systemDate)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh the phone's local date whenever the app returns to the foreground.
        systemDate = LocalDate.now()
    }

    fun createExcelBackup() {
        pendingBackup = true
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            putExtra(Intent.EXTRA_TITLE, "پشتیبان_دفتر_کارکرد.xlsx")
        }
        startActivityForResult(intent, 4101)
    }
    fun createReportExcel(year: Int, month: Int, annual: Boolean) {
        reportYear = year; reportMonth = month; reportAnnual = annual; reportPdf = false
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            putExtra(Intent.EXTRA_TITLE, if (annual) "گزارش_سالانه_$year.xlsx" else "گزارش_ماهانه_${year}_$month.xlsx")
        }
        startActivityForResult(intent, 4103)
    }
    fun createReportPdf(year: Int, month: Int, annual: Boolean) {
        reportYear = year; reportMonth = month; reportAnnual = annual; reportPdf = true
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"
            putExtra(Intent.EXTRA_TITLE, if (annual) "گزارش_سالانه_$year.pdf" else "گزارش_ماهانه_${year}_$month.pdf")
        }
        startActivityForResult(intent, 4104)
    }
    fun chooseExcelRestore() {
        pendingBackup = false
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        }
        startActivityForResult(intent, 4102)
    }
    @Deprecated("Deprecated Android callback kept for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        try {
            if (requestCode == 4101) {
                contentResolver.openOutputStream(uri)?.use { it.write(buildBackupXlsx(appDb)) }
                android.widget.Toast.makeText(this, "فایل Excel پشتیبان ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
            } else if (requestCode == 4103) {
                contentResolver.openOutputStream(uri)?.use { it.write(buildReportXlsx(appDb, reportYear, reportMonth, reportAnnual)) }
                android.widget.Toast.makeText(this, "گزارش Excel ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
            } else if (requestCode == 4104) {
                contentResolver.openOutputStream(uri)?.use { it.write(buildReportPdf(appDb, reportYear, reportMonth, reportAnnual)) }
                android.widget.Toast.makeText(this, "گزارش PDF ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
            } else if (requestCode == 4102) {
                val input = contentResolver.openInputStream(uri) ?: error("فایل خوانده نشد")
                val restored = input.use { readBackupXlsx(it.readBytes()) }
                android.app.AlertDialog.Builder(this)
                    .setTitle("بازیابی پشتیبان")
                    .setMessage("با ادامه، اطلاعات فعلی جایگزین می‌شود. ادامه می‌دهید؟")
                    .setNegativeButton("انصراف", null)
                    .setPositiveButton("بازیابی") { _, _ ->
                        appDb.restoreBackup(restored.first, restored.second)
                        android.widget.Toast.makeText(this, "بازیابی انجام شد؛ صفحه را دوباره باز کنید", android.widget.Toast.LENGTH_LONG).show()
                    }.show()
            }
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, "خطا در فایل Excel: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
        }
    }
}

private fun formatTimeInput(raw: String): String {
    val digits = raw.toLatinDigits().filter { it.isDigit() }.take(4)
    return when (digits.length) {
        0, 1 -> digits
        2 -> digits
        else -> digits.substring(0, 2) + ":" + digits.substring(2)
    }
}

private fun mins(time: String): Int? {
    val p = time.trim().split(":")
    if (p.size != 2) return null
    val h = p[0].toIntOrNull() ?: return null
    val m = p[1].toIntOrNull() ?: return null
    if (h !in 0..23 || m !in 0..59) return null
    return h*60+m
}
private fun duration(day: WorkDay): Int {
    // Holiday work is tracked separately and counted as overtime only.
    if (isHolidayWorkDay(day)) return 0
    return listOf(day.in1 to day.out1, day.in2 to day.out2, day.in3 to day.out3).sumOf { (a,b) ->
        val start = mins(a); val end = mins(b)
        if (start != null && end != null) {
            if (end >= start) end - start else (end + 24 * 60) - start
        } else 0
    }
}

private fun normalizeDateInput(raw: String): String {
    val digits = raw.toLatinDigits().filter { it.isDigit() }.take(8)
    return when {
        digits.length <= 4 -> digits
        digits.length <= 6 -> digits.take(4) + "-" + digits.drop(4)
        else -> digits.take(4) + "-" + digits.substring(4, 6) + "-" + digits.drop(6)
    }
}

private fun parsedJalaliDate(value: String): LocalDate? {
    val parts = value.replace('/', '-').split("-").mapNotNull { it.toIntOrNull() }
    if (parts.size != 3 || !isValidJalali(parts[0], parts[1], parts[2])) return null
    return jalaliToGregorian(parts[0], parts[1], parts[2])
}

private fun jalaliDateString(date: LocalDate): String {
    val (y, m, d) = gregorianToJalali(date)
    return "%04d-%02d-%02d".format(Locale.ROOT, y, m, d)
}

private fun defaultShiftEndDate(startDate: String, startTime: String, endTime: String): String {
    val start = parsedJalaliDate(startDate) ?: return startDate
    val startMinutes = mins(startTime)
    val endMinutes = mins(endTime)
    val endDate = if (startMinutes != null && endMinutes != null && endMinutes <= startMinutes) start.plusDays(1) else start
    return jalaliDateString(endDate)
}

private fun shiftDurationMinutes(day: WorkDay, fallbackDate: String = day.date): Int {
    if (!day.shiftEnabled) return 0

    val startDateText = day.shiftStartDate.ifBlank { fallbackDate }
    val endDateText = day.shiftEndDate.ifBlank {
        defaultShiftEndDate(startDateText, day.shiftStart, day.shiftEnd)
    }
    val startDate = parsedJalaliDate(startDateText) ?: return 0
    var endDate = parsedJalaliDate(endDateText) ?: return 0
    val startMinutes = mins(day.shiftStart) ?: return 0
    val endMinutes = mins(day.shiftEnd) ?: return 0

    // If both dates are the same but the entered end time is earlier (or equal),
    // treat the shift as crossing midnight. Explicit end dates on a later day
    // are respected as entered.
    if (endDate == startDate && endMinutes <= startMinutes) {
        endDate = startDate.plusDays(1)
    }
    if (endDate.isBefore(startDate)) return 0

    val total = (endDate.toEpochDay() - startDate.toEpochDay()) * 1440L +
        endMinutes.toLong() - startMinutes.toLong()
    return total.coerceIn(0L, 31L * 1440L).toInt()
}
private fun hm(n: Int) = "%02d:%02d".format(Locale.ROOT, n/60, n%60)

private fun jalaliWeekday(date: String): Int? {
    val p = date.split("-").mapNotNull { it.toIntOrNull() }
    if (p.size != 3 || !isValidJalali(p[0],p[1],p[2])) return null
    return jalaliToGregorian(p[0],p[1],p[2]).dayOfWeek.value % 7
    // Java Sunday=0, Saturday=6
}
private fun officialJalaliHolidays(year: Int): List<Pair<String,String>> {
    val fixed = mutableListOf<Triple<Int,Int,String>>()
    for (d in 1..4) fixed.add(Triple(1, d, "تعطیل رسمی نوروز"))
    fixed.add(Triple(1, 12, "روز جمهوری اسلامی"))
    fixed.add(Triple(1, 13, "روز طبیعت"))
    fixed.add(Triple(3, 14, "رحلت امام خمینی"))
    fixed.add(Triple(3, 15, "قیام ۱۵ خرداد"))
    fixed.add(Triple(11, 22, "پیروزی انقلاب اسلامی"))
    fixed.add(Triple(12, 29, "روز ملی شدن صنعت نفت"))
    return fixed.map { (m,d,title) -> "%04d-%02d-%02d".format(year,m,d) to title }
}

private fun defaultDayType(date: String): String =
    if (jalaliWeekday(date) == 5) "تعطیل" else "کاری"

private fun applyCalendarHoliday(day: WorkDay, db: WorkDb): WorkDay {
    val fixedHoliday = officialJalaliHolidays(day.date.take(4).toIntOrNull() ?: 0).toMap()[day.date]
    val officialTitle = db.officialHolidayTitle(day.date) ?: fixedHoliday
    return when {
        !officialTitle.isNullOrBlank() && day.dayType in setOf("کاری", "تعطیل") -> day.copy(dayType = "تعطیل رسمی")
        !db.holidayTitle(day.date).isNullOrBlank() && day.dayType == "کاری" -> day.copy(dayType = "تعطیل مناسبتی")
        else -> day
    }
}

private fun reportPeriodDays(db: WorkDb, year: Int, month: Int, annual: Boolean): List<WorkDay> {
    val stored = db.allDaysYear(year).associateBy { it.date }
    val months = if (annual) (1..12).toList() else listOf(month)
    return months.flatMap { m ->
        (1..jalaliMonthLength(year, m)).map { d ->
            val key = "%04d-%02d-%02d".format(year, m, d)
            val base = stored[key] ?: db.getDay(key).copy(dayType = defaultDayType(key))
            applyCalendarHoliday(base, db)
        }
    }
}

private fun isHolidayWorkDay(day: WorkDay): Boolean =
    day.dayType in setOf("تعطیل", "تعطیل رسمی", "تعطیل مناسبتی")

private fun holidayWorkDurationMinutes(day: WorkDay): Int {
    val start = mins(day.holidayIn)
    val end = mins(day.holidayOut)
    if (start == null || end == null) return 0
    return if (end >= start) end - start else (end + 24 * 60) - start
}

private fun overtimeMinutes(day: WorkDay, db: WorkDb): Int {
    val override = mins(day.overtimeOverride)
    if (override != null) return override
    if (isHolidayWorkDay(day)) return holidayWorkDurationMinutes(day)
    if (day.dayType != "کاری") return 0
    val weekday = jalaliWeekday(day.date)
    val targetText = if (weekday == 4 && db.getSetting("thursday_hours"))
        db.getSettingText("thursday_hours_value") else db.getSettingText("workday_hours")
    val target = mins(targetText) ?: 480
    return (duration(day) - target).coerceAtLeast(0)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KarkardApp(db: WorkDb, systemDate: LocalDate) {
    val context = LocalContext.current
    var screen by remember { mutableStateOf("home") }
    val nowJalali = remember(systemDate) { gregorianToJalali(systemDate) }
    var jalaliYear by remember { mutableIntStateOf(nowJalali.first) }
    var jalaliMonth by remember { mutableIntStateOf(nowJalali.second) }
    var date by remember { mutableStateOf("%04d-%02d-%02d".format(nowJalali.first, nowJalali.second, nowJalali.third)) }
    var lastObservedSystemDate by remember { mutableStateOf(systemDate) }
    LaunchedEffect(systemDate) {
        val previousDeviceDate = jalaliDateString(lastObservedSystemDate)
        val currentDeviceDate = jalaliDateString(systemDate)
        // Update automatically if the user is still on the previous phone-today date.
        // A deliberately selected earlier/later day is left alone.
        if (date == previousDeviceDate) {
            date = currentDeviceDate
            val parts = currentDeviceDate.split("-")
            if (parts.size == 3) {
                jalaliYear = parts[0].toIntOrNull() ?: jalaliYear
                jalaliMonth = parts[1].toIntOrNull() ?: jalaliMonth
            }
        }
        lastObservedSystemDate = systemDate
    }
    var day by remember(date) {
        mutableStateOf(db.getDay(date).let { if (db.allDays(date.take(7)).any { d -> d.date == date }) it else it.copy(dayType=defaultDayType(date)) })
    }
    var refresh by remember { mutableIntStateOf(0) }
    var menuExpanded by remember { mutableStateOf(false) }
    var holidaySyncing by remember { mutableStateOf(false) }
    var holidaySyncMessage by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()
    val syncOfficialHolidays: (Int, Boolean) -> Unit = { yearToSync, force ->
        if (!holidaySyncing && (force || db.shouldSyncOfficialHolidays(yearToSync))) {
            holidaySyncing = true
            holidaySyncMessage = "در حال دریافت تعطیلات سال $yearToSync…"
            coroutineScope.launch {
                try {
                    val synced = withContext(Dispatchers.IO) {
                        val calendarData = fetchCalendarData(yearToSync)
                        db.replaceCalendarData(yearToSync, calendarData.holidays, calendarData.events)
                        calendarData.events.size
                    }
                    holidaySyncMessage = "تقویم سال $yearToSync به‌روزرسانی شد؛ $synced روز دارای مناسبت و ${db.officialHolidays(yearToSync).size} روز تعطیل رسمی ذخیره شد. پس از ذخیره، آفلاین هم در دسترس است."
                    refresh++
                } catch (e: Exception) {
                    val reason = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName
                    holidaySyncMessage = "به‌روزرسانی انجام نشد ($reason)؛ اطلاعات ذخیره‌شده حفظ شد. اینترنت را بررسی و دوباره تلاش کن."
                } finally {
                    holidaySyncing = false
                }
            }
        }
    }
    LaunchedEffect(jalaliYear) {
        syncOfficialHolidays(jalaliYear, false)
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF28588A),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFDCEAFB),
            onPrimaryContainer = Color(0xFF163D6B),
            secondary = Color(0xFF368C83),
            tertiary = ShiftYellowText,
            background = Color(0xFFEEF5FD),
            surface = Color.White
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                topBar = {
                    TopAppBar(
                        title = {
                            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                PersianText(
                                    when (screen) {
                                        "report-monthly" -> "گزارش‌گیری ماهانه"
                                        "report-annual" -> "گزارش‌گیری سالانه"
                                        else -> "وقت‌نگار"
                                    },
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF123C70)
                                )
                            }
                        },
                        navigationIcon = {
                            TextButton(onClick = {
                                if (screen.startsWith("report-")) screen = "home" else screen = "calendar"
                            }) { PersianText(if (screen.startsWith("report-")) "‹" else "⋮", fontSize = 25.sp) }
                        },
                        actions = {
                            Box {
                                TextButton(onClick = { menuExpanded = true }) { PersianText("☰", fontSize = 23.sp) }
                                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                                    DropdownMenuItem(text = { PersianText("خانه") }, onClick = { menuExpanded = false; screen = "home" })
                                    DropdownMenuItem(text = { PersianText("تقویم") }, onClick = { menuExpanded = false; screen = "calendar" })
                                    DropdownMenuItem(text = { PersianText("گزارش‌گیری ماهانه") }, onClick = { menuExpanded = false; screen = "report-monthly" })
                                    DropdownMenuItem(text = { PersianText("گزارش‌گیری سالانه") }, onClick = { menuExpanded = false; screen = "report-annual" })
                                    DropdownMenuItem(text = { PersianText("تنظیمات") }, onClick = { menuExpanded = false; screen = "settings" })
                                }
                            }
                        }
                    )
                }
            ) { padding ->
                when (screen) {
                    "settings" -> SettingsScreen(
                        db = db, modifier = Modifier.padding(padding),
                        onBackup = { (context as? MainActivity)?.createExcelBackup() },
                        onRestore = { (context as? MainActivity)?.chooseExcelRestore() },
                        onSyncHolidays = { selectedYear -> syncOfficialHolidays(selectedYear, true) },
                        syncYear = jalaliYear,
                        holidaySyncing = holidaySyncing,
                        holidaySyncMessage = holidaySyncMessage
                    ) { screen = "home" }
                    "calendar" -> JalaliCalendarScreen(
                        year = jalaliYear, month = jalaliMonth, selectedDate = date,
                        onMonthChange = { y,m -> jalaliYear = y; jalaliMonth = m },
                        onSelectDate = { selected ->
                            date = selected
                            val parts = selected.split("-")
                            if (parts.size == 3) { jalaliYear = parts[0].toInt(); jalaliMonth = parts[1].toInt() }
                            screen = "home"
                        },
                        modifier = Modifier.padding(padding),
                        holidays = remember(refresh, jalaliYear, jalaliMonth) {
                            (officialJalaliHolidays(jalaliYear) + db.officialHolidays(jalaliYear) + db.allHolidays()).toMap()
                        },
                        events = remember(refresh, jalaliYear, jalaliMonth) { db.calendarEvents(jalaliYear).toMap() }
                    )
                    "report-monthly" -> ReportScreen(
                        db = db, year = jalaliYear, monthNumber = jalaliMonth, refresh = refresh,
                        modifier = Modifier.padding(padding), annual = false,
                        onPeriodChange = { y, m -> jalaliYear = y; jalaliMonth = m },
                        export = { a -> (context as? MainActivity)?.createReportExcel(jalaliYear, jalaliMonth, a) },
                        exportPdf = { a -> (context as? MainActivity)?.createReportPdf(jalaliYear, jalaliMonth, a) }
                    )
                    "report-annual" -> ReportScreen(
                        db = db, year = jalaliYear, monthNumber = jalaliMonth, refresh = refresh,
                        modifier = Modifier.padding(padding), annual = true,
                        onPeriodChange = { y, m -> jalaliYear = y; jalaliMonth = m },
                        export = { a -> (context as? MainActivity)?.createReportExcel(jalaliYear, jalaliMonth, a) },
                        exportPdf = { a -> (context as? MainActivity)?.createReportPdf(jalaliYear, jalaliMonth, a) }
                    )
                    else -> HomeDashboard(
                        modifier = Modifier.padding(padding), date = date, rawDay = day,
                        jalaliYear = jalaliYear, jalaliMonth = jalaliMonth, db = db, refresh = refresh,
                        onDateChange = { newDate ->
                            date = newDate
                            val p = newDate.split("-")
                            if (p.size == 3) { jalaliYear = p[0].toIntOrNull() ?: jalaliYear; jalaliMonth = p[1].toIntOrNull() ?: jalaliMonth }
                        },
                        onDayChange = { updated ->
                            // Save every edit immediately, so navigating to another date does not discard it.
                            val saved = updated.copy(date = date)
                            val previousType = day.dayType
                            day = saved
                            db.saveDay(saved)
                            if (previousType == "تعطیل مناسبتی" && saved.dayType != "تعطیل مناسبتی") {
                                db.removeHoliday(date)
                            }
                        },
                        onSaved = { saved -> day = saved; date = saved.date; refresh++ },
                        onOpenCalendar = { screen = "calendar" }
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeDashboard(
    modifier: Modifier,
    date: String,
    rawDay: WorkDay,
    jalaliYear: Int,
    jalaliMonth: Int,
    db: WorkDb,
    refresh: Int,
    onDateChange: (String) -> Unit,
    onDayChange: (WorkDay) -> Unit,
    onSaved: (WorkDay) -> Unit,
    onOpenCalendar: () -> Unit
) {
    val context = LocalContext.current
    val day = remember(rawDay, date, refresh) { applyCalendarHoliday(rawDay, db) }
    val calendarTitle = remember(date, refresh) { db.displayHolidayTitle(date) ?: officialJalaliHolidays(date.take(4).toIntOrNull() ?: jalaliYear).toMap()[date] }
    val monthPrefix = "%04d-%02d".format(jalaliYear, jalaliMonth)
    val monthDays = remember(jalaliYear, jalaliMonth) { (1..31).filter { isValidJalali(jalaliYear, jalaliMonth, it) } }
    val recordedDays = remember(refresh, monthPrefix) { db.allDays(monthPrefix) }
    val monthWork = recordedDays.sumOf { duration(it) }
    val monthOvertime = recordedDays.sumOf { overtimeMinutes(it, db) }
    val monthShiftDays = remember(refresh, monthPrefix) { db.allDaysForBackup().filter { it.shiftEnabled && (it.shiftStartDate.ifBlank { it.date }).startsWith(monthPrefix) } }
    val monthShift = monthShiftDays.sumOf { shiftDurationMinutes(it, it.date) }
    val missionCount = recordedDays.count { it.dayType == "مأموریت" }
    val dateParts = date.split("-").mapNotNull { it.toIntOrNull() }
    val dateDay = dateParts.getOrElse(2) { 1 }
    val weekday = jalaliWeekday(date)?.let { JalaliWeekdayNames.getOrNull(it) }.orEmpty()
    var holidayReason by remember(date, refresh) { mutableStateOf(db.holidayTitle(date).orEmpty()) }

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 5.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        contentPadding = PaddingValues(bottom = 8.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 7.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                        PersianText("▦", fontSize = 21.sp, color = Color(0xFF426B91))
                        Spacer(Modifier.width(7.dp))
                        PersianText("${JalaliMonthNames.getOrElse(jalaliMonth - 1) { "ماه" }} $jalaliYear", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF163D6B))
                    }
                    Divider(color = Color(0xFFD8E6F7))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        MonthMetric("مجموع کارکرد", hm(monthWork), "◷", Color(0xFF345A86), Modifier.weight(1.15f))
                        MetricDivider()
                        MonthMetric("اضافه‌کار", hm(monthOvertime), "◴", OvertimeGreenText, Modifier.weight(1f))
                        MetricDivider()
                        MonthMetric("مدت شیفت", hm(monthShift), "☼", ShiftYellowText, Modifier.weight(1f))
                        MetricDivider()
                        MonthMetric("تعداد شیفت", monthShiftDays.size.toString(), "▤", ShiftYellowText, Modifier.weight(0.95f), "شیفت")
                        MetricDivider()
                        MonthMetric("ماموریت", missionCount.toString(), "▣", Color(0xFF345A86), Modifier.weight(0.85f), "روز")
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        TextButton(onClick = {
                            val prev = parsedJalaliDate(date)?.minusDays(1)?.let { jalaliDateString(it) }
                            if (prev != null) onDateChange(prev)
                        }, contentPadding = PaddingValues(horizontal = 3.dp)) { PersianText("‹", fontSize = 25.sp, color = Color(0xFF28588A)) }
                        PersianText("روز $dateDay از ${monthDays.size}", fontSize = 12.sp, color = Color(0xFF426B91))
                        TextButton(onClick = {
                            val next = parsedJalaliDate(date)?.plusDays(1)?.let { jalaliDateString(it) }
                            if (next != null) onDateChange(next)
                        }, contentPadding = PaddingValues(horizontal = 3.dp)) { PersianText("›", fontSize = 25.sp, color = Color(0xFF28588A)) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Column(horizontalAlignment = Alignment.End) {
                            PersianText(weekday, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF163D6B))
                            PersianText(jalaliDisplayDate(date), style = MaterialTheme.typography.bodyMedium, color = Color(0xFF426B91))
                        }
                        TextButton(onClick = onOpenCalendar, contentPadding = PaddingValues(2.dp)) { PersianText("▦", fontSize = 23.sp, color = Color(0xFF426B91)) }
                    }
                }
            }
        }
        if (!calendarTitle.isNullOrBlank()) {
            item {
                val isOfficialCalendarHoliday = db.officialHolidayTitle(date) != null || officialJalaliHolidays(jalaliYear).toMap().containsKey(date)
                Card(
                    colors = CardDefaults.cardColors(containerColor = if (isOfficialCalendarHoliday) Color(0xFFFFF0F0) else Color(0xFFFFF8E5)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, if (isOfficialCalendarHoliday) Color(0xFFE57373) else Color(0xFFE5C34A), RoundedCornerShape(10.dp))
                ) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        PersianText(if (isOfficialCalendarHoliday) "تعطیل رسمی" else "مناسبت تقویم", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (isOfficialCalendarHoliday) Color(0xFFB3261E) else Color(0xFF795500))
                        PersianText(calendarTitle, fontSize = 12.sp, color = if (isOfficialCalendarHoliday) Color(0xFF7F1D1D) else Color(0xFF5F4500))
                    }
                }
            }
        }
        item {
            val dayTypes = listOf(
                "کاری" to "◷", "تعطیل رسمی" to "♜", "مرخصی" to "☼",
                "مأموریت" to "✈", "استعلاجی" to "✚", "تعطیل مناسبتی" to "▦"
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                dayTypes.forEach { (type, symbol) ->
                    val selected = day.dayType == type
                    Card(
                        modifier = Modifier.weight(1f).height(59.dp).border(1.dp, if (selected) Color(0xFF6BA1F9) else Color(0xFFBED5F7), RoundedCornerShape(10.dp)),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFFE3EEFF) else Color.White),
                        onClick = { onDayChange(day.copy(dayType = type)) }
                    ) {
                        Column(Modifier.fillMaxSize().padding(horizontal = 2.dp, vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            PersianText(symbol, fontSize = 18.sp, color = if (selected) Color(0xFF1556A6) else Color(0xFF426B91), maxLines = 1)
                            PersianText(type, fontSize = 9.sp, color = if (selected) Color(0xFF1556A6) else Color(0xFF345A86), textAlign = TextAlign.Center, maxLines = 2, lineHeight = 11.sp)
                        }
                    }
                }
            }
        }
        if (day.dayType == "تعطیل مناسبتی") {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFBED5F7), RoundedCornerShape(10.dp))) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        PersianText("علت تعطیلی (اختیاری)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF163D6B))
                        OutlinedTextField(
                            value = holidayReason.toPersianDigits(),
                            onValueChange = {
                                holidayReason = it
                                // Persist the title while typing; changing dates will not lose it.
                                if (day.dayType == "تعطیل مناسبتی") {
                                    if (it.isBlank()) db.removeHoliday(date)
                                    else db.saveHoliday(date, it.trim())
                                }
                            },
                            placeholder = { PersianText("علت تعطیلی را وارد کنید", fontSize = 12.sp, color = Color(0xFF7E9ABD)) },
                            leadingIcon = { PersianText("✎", fontSize = 18.sp) },
                            modifier = Modifier.fillMaxWidth(), singleLine = true,
                            textStyle = TextStyle(fontSize = 12.sp, textAlign = TextAlign.Start),
                        )
                    }
                }
            }
        }
        if (isHolidayWorkDay(day)) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = OvertimeGreen.copy(alpha = 0.55f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF99D5A8), RoundedCornerShape(12.dp))
                ) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 7.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        PersianText("ساعت کار در روز تعطیل", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = OvertimeGreenText)
                        PersianText("زمان ثبت‌شده در این بخش، تماماً اضافه‌کاری محاسبه می‌شود.", fontSize = 10.sp, color = OvertimeGreenText)
                        CompactTimePairRow("تعطیل", "ورود", day.holidayIn, "خروج", day.holidayOut,
                            { onDayChange(day.copy(holidayIn = formatTimeInput(it))) },
                            { onDayChange(day.copy(holidayOut = formatTimeInput(it))) })
                        PersianText("اضافه‌کاری تعطیل: ${hm(holidayWorkDurationMinutes(day))}", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = OvertimeGreenText)
                    }
                }
            }
        } else {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        PersianText("ساعات کار روزانه", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color(0xFF163D6B))
                        Divider(color = Color(0xFFD8E6F7))
                        CompactTimePairRow("۱", "ورود", day.in1, "خروج", day.out1, { onDayChange(day.copy(in1=it)) }, { onDayChange(day.copy(out1=it)) })
                        Divider(color = Color(0xFFD8E6F7))
                        CompactTimePairRow("۲", "ورود", day.in2, "خروج", day.out2, { onDayChange(day.copy(in2=it)) }, { onDayChange(day.copy(out2=it)) })
                        Divider(color = Color(0xFFD8E6F7))
                        CompactTimePairRow("۳", "ورود", day.in3, "خروج", day.out3, { onDayChange(day.copy(in3=it)) }, { onDayChange(day.copy(out3=it)) })
                    }
                }
            }
        }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEE)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFFFD24D), RoundedCornerShape(12.dp))
            ) {
                Column(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().background(Color(0xFFFFF6DD)).padding(horizontal = 9.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
                        PersianText("☼", fontSize = 21.sp, color = Color(0xFFE9A600))
                        Spacer(Modifier.width(6.dp))
                        PersianText("شیفت کاری", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = ShiftYellowText)
                        Spacer(Modifier.weight(1f))
                        Switch(checked = day.shiftEnabled, onCheckedChange = { onDayChange(day.copy(shiftEnabled=it)) })
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        CompactShiftField("تاریخ شروع", jalaliDisplayDate(day.shiftStartDate.ifBlank { date }), Modifier.weight(1.25f), true) {
                            val newStartDate = normalizeDateInput(it)
                            val oldStartDate = day.shiftStartDate.ifBlank { date }
                            val oldAutomaticEndDate = defaultShiftEndDate(oldStartDate, day.shiftStart, day.shiftEnd)
                            val endDateWasAutomatic = day.shiftEndDate.isBlank() || day.shiftEndDate == oldStartDate || day.shiftEndDate == oldAutomaticEndDate
                            onDayChange(day.copy(
                                shiftStartDate = newStartDate,
                                shiftEndDate = if (endDateWasAutomatic) defaultShiftEndDate(newStartDate, day.shiftStart, day.shiftEnd) else day.shiftEndDate
                            ))
                        }
                        CompactShiftField("ساعت شروع", day.shiftStart, Modifier.weight(0.8f), false) {
                            val startDate = day.shiftStartDate.ifBlank { date }
                            val oldAutomaticEndDate = defaultShiftEndDate(startDate, day.shiftStart, day.shiftEnd)
                            val endDateWasAutomatic = day.shiftEndDate.isBlank() || day.shiftEndDate == startDate || day.shiftEndDate == oldAutomaticEndDate
                            onDayChange(day.copy(
                                shiftStart = formatTimeInput(it),
                                shiftStartDate = startDate,
                                shiftEndDate = if (endDateWasAutomatic) defaultShiftEndDate(startDate, it, day.shiftEnd) else day.shiftEndDate
                            ))
                        }
                        CompactShiftField("تاریخ پایان", jalaliDisplayDate(day.shiftEndDate.ifBlank { defaultShiftEndDate(day.shiftStartDate.ifBlank { date }, day.shiftStart, day.shiftEnd) }), Modifier.weight(1.25f), true) { onDayChange(day.copy(shiftEndDate=normalizeDateInput(it))) }
                        CompactShiftField("ساعت پایان", day.shiftEnd, Modifier.weight(0.8f), false) {
                            val startDate = day.shiftStartDate.ifBlank { date }
                            val oldAutomaticEndDate = defaultShiftEndDate(startDate, day.shiftStart, day.shiftEnd)
                            val endDateWasAutomatic = day.shiftEndDate.isBlank() || day.shiftEndDate == startDate || day.shiftEndDate == oldAutomaticEndDate
                            onDayChange(day.copy(
                                shiftEnd = formatTimeInput(it),
                                shiftStartDate = startDate,
                                shiftEndDate = if (endDateWasAutomatic) defaultShiftEndDate(startDate, day.shiftStart, it) else day.shiftEndDate
                            ))
                        }
                    }
                    PersianText("مدت شیفت: ${hm(shiftDurationMinutes(day, date))}", modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp), fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = ShiftYellowText)
                    Spacer(Modifier.height(5.dp))
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PersianText("▤", fontSize = 20.sp, color = Color(0xFF426B91))
                        Spacer(Modifier.width(6.dp))
                        PersianText("یادداشت روز", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color(0xFF163D6B))
                    }
                    OutlinedTextField(value = day.note.toPersianDigits(), onValueChange = { onDayChange(day.copy(note=it)) }, placeholder = { PersianText("یادداشت اختیاری…", fontSize = 11.sp) }, modifier = Modifier.fillMaxWidth(), minLines = 1, maxLines = 2, textStyle = TextStyle(fontSize = 12.sp))
                }
            }
        }
        item {
            Button(
                onClick = {
                    val p = date.toLatinDigits().replace('/', '-').split("-").mapNotNull { it.toIntOrNull() }
                    if (p.size == 3 && isValidJalali(p[0], p[1], p[2])) {
                        val normalized = "%04d-%02d-%02d".format(p[0], p[1], p[2])
                        val startDate = day.shiftStartDate.ifBlank { normalized }
                        val endDate = day.shiftEndDate.ifBlank { defaultShiftEndDate(startDate, day.shiftStart, day.shiftEnd) }
                        val savedDay = day.copy(date=normalized, shiftStartDate=startDate, shiftEndDate=endDate)
                        if (savedDay.shiftEnabled && (parsedJalaliDate(startDate) == null || parsedJalaliDate(endDate) == null)) {
                            android.widget.Toast.makeText(context, "تاریخ شروع و پایان شیفت معتبر نیست.", android.widget.Toast.LENGTH_LONG).show()
                        } else if (savedDay.shiftEnabled && (mins(savedDay.shiftStart) == null || mins(savedDay.shiftEnd) == null)) {
                            android.widget.Toast.makeText(context, "ساعت شروع و پایان شیفت را درست وارد کنید.", android.widget.Toast.LENGTH_LONG).show()
                        } else {
                            db.saveDay(savedDay)
                            if (savedDay.dayType == "تعطیل مناسبتی") {
                                if (holidayReason.isNotBlank()) db.saveHoliday(normalized, holidayReason.trim()) else db.removeHoliday(normalized)
                            } else {
                                db.removeHoliday(normalized)
                            }
                            onSaved(savedDay)
                            android.widget.Toast.makeText(context, "اطلاعات روز ذخیره شد", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().heightIn(min = 38.dp),
                contentPadding = PaddingValues(vertical = 5.dp)
            ) { PersianText("ذخیره اطلاعات روز", fontSize = 13.sp) }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                SummaryMiniTile("مجموع کارکرد", hm(duration(day)), Color(0xFFEAF3FF), Color(0xFF28588A), Modifier.weight(1f))
                SummaryMiniTile("اضافه‌کار", hm(overtimeMinutes(day, db)), OvertimeGreen, OvertimeGreenText, Modifier.weight(1f))
                SummaryMiniTile("مدت شیفت", hm(shiftDurationMinutes(day, date)), ShiftYellow, ShiftYellowText, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun MonthMetric(label: String, value: String, symbol: String, valueColor: Color, modifier: Modifier, unit: String = "ساعت") {
    Column(modifier.padding(horizontal = 2.dp, vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            PersianText(symbol, fontSize = 13.sp, color = valueColor, maxLines = 1)
            Spacer(Modifier.width(2.dp))
            PersianText(label, fontSize = 9.sp, color = Color(0xFF345A86), maxLines = 2, textAlign = TextAlign.Center, lineHeight = 10.sp)
        }
        PersianText(value, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = valueColor, maxLines = 1)
        PersianText(unit, fontSize = 8.sp, color = Color(0xFF426B91), maxLines = 1)
    }
}

@Composable
private fun MetricDivider() {
    Box(Modifier.width(1.dp).height(44.dp).background(Color(0xFFBED5F7)))
}

@Composable
private fun CompactTimePairRow(index: String, label1: String, value1: String, label2: String, value2: String, onChange1: (String) -> Unit, onChange2: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(25.dp).background(Color(0xFFEAF1FA), RoundedCornerShape(50)), contentAlignment = Alignment.Center) { PersianText(index, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF28588A)) }
        CompactTimeTextField(label1, value1, onChange1, Modifier.weight(1f))
        CompactTimeTextField(label2, value2, onChange2, Modifier.weight(1f))
    }
}

@Composable
private fun CompactTimeTextField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier) {
    OutlinedTextField(
        value = value.toPersianDigits(),
        onValueChange = { onChange(formatTimeInput(it)) },
        modifier = modifier.heightIn(min = 48.dp),
        label = { PersianText(label, fontSize = 10.sp) },
        placeholder = { PersianText("۰۰:۰۰", fontSize = 11.sp, color = Color(0xFF7E9ABD)) },
        singleLine = true,
        textStyle = TextStyle(fontSize = 17.sp, textAlign = TextAlign.Center),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
    )
}

@Composable
private fun CompactShiftField(label: String, value: String, modifier: Modifier, isDate: Boolean, onChange: (String) -> Unit) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        PersianText(label, fontSize = 8.sp, color = Color(0xFF345A86), textAlign = TextAlign.Center, maxLines = 2, lineHeight = 9.sp)
        OutlinedTextField(
            value = value.toPersianDigits(),
            onValueChange = onChange,
            modifier = Modifier.fillMaxWidth().heightIn(min = 42.dp),
            singleLine = true,
            textStyle = TextStyle(fontSize = if (isDate) 11.sp else 16.sp, textAlign = TextAlign.Center),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            placeholder = { PersianText(if (isDate) "۱۴۰۵/۰۸/۰۳" else "۲۱:۰۰", fontSize = if (isDate) 10.sp else 12.sp) },
        )
    }
}

@Composable
private fun SummaryMiniTile(label: String, value: String, background: Color, foreground: Color, modifier: Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = background), shape = RoundedCornerShape(10.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 3.dp, vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
            PersianText(label, fontSize = 10.sp, color = foreground, textAlign = TextAlign.Center, maxLines = 1)
            PersianText(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = foreground, maxLines = 1)
            PersianText("ساعت", fontSize = 8.sp, color = foreground)
        }
    }
}

@Composable
private fun SplitTimeField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val parts = value.split(":")
    var hour by remember(value) { mutableStateOf(parts.getOrElse(0) { "" }.take(2)) }
    var minute by remember(value) { mutableStateOf(parts.getOrElse(1) { "" }.take(2)) }
    Column(modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        PersianText(label, style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = hour, onValueChange = { raw ->
                hour = raw.filter { it.isDigit() }.take(2)
                val h = hour.toIntOrNull()
                if (hour.length == 2 && h != null && h in 0..23) onChange("%02d:%s".format(h, minute.padStart(2, '0').take(2)))
                else onChange(if (hour.isBlank() && minute.isBlank()) "" else "$hour:$minute")
            }, label = { PersianText("ساعت") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
            PersianText(":", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(value = minute, onValueChange = { raw ->
                minute = raw.filter { it.isDigit() }.take(2)
                val m = minute.toIntOrNull()
                if (minute.length == 2 && m != null && m in 0..59) onChange("${hour.padStart(2, '0').take(2)}:%02d".format(m))
                else onChange(if (hour.isBlank() && minute.isBlank()) "" else "$hour:$minute")
            }, label = { PersianText("دقیقه") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
        }
    }
}

@Composable
fun TimePair(label1: String, v1: String, label2: String, v2: String, c1: (String)->Unit, c2: (String)->Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        SplitTimeField(label1, v1, c1, Modifier.weight(1f))
        SplitTimeField(label2, v2, c2, Modifier.weight(1f))
    }
}

@Composable
fun SettingsScreen(
    db: WorkDb,
    modifier: Modifier = Modifier,
    onBackup: () -> Unit,
    onRestore: () -> Unit,
    onSyncHolidays: (Int) -> Unit,
    syncYear: Int,
    holidaySyncing: Boolean,
    holidaySyncMessage: String,
    back: () -> Unit
) {
    var tick by remember { mutableIntStateOf(0) }
    val settings = listOf(
        "fixed_hours" to "ساعت ورود و خروج ثابت",
        "thursday_hours" to "تنظیم جداگانه ساعت پنجشنبه",
        "overtime" to "ثبت و محاسبه اضافه‌کاری",
        "leave_hourly" to "مرخصی ساعتی",
        "leave_daily" to "مرخصی روزانه و نوع مرخصی",
        "mission" to "مأموریت روزانه",
        "shifts" to "تعریف و ثبت شیفت کاری",
        "calendar" to "تقویم ماهانه و تعطیلات"
    )
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        PersianText("تنظیمات امکانات", style = MaterialTheme.typography.headlineSmall)
        PersianText("هر قابلیت را می‌توانید روشن یا خاموش کنید.")
        PersianText("تعطیلات و همهٔ مناسبت‌های تقویم ایران", style = MaterialTheme.typography.titleMedium)
        PersianText("سال شمسی را انتخاب کن تا تعطیلات رسمی و مناسبت‌های ملی، مذهبی، فرهنگی و جهانی همان سال دریافت و روی گوشی ذخیره شوند. پس از ذخیره، بدون اینترنت هم در دسترس‌اند. تاریخ قمری آینده ممکن است تا اعلام رسمی تخمینی باشد.", style = MaterialTheme.typography.bodySmall)
        var selectedCalendarYear by remember(syncYear) { mutableIntStateOf(syncYear) }
        var yearMenuExpanded by remember { mutableStateOf(false) }
        Box {
            OutlinedButton(onClick = { yearMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                PersianText("سال انتخاب‌شده: ${selectedCalendarYear.toString().toPersianDigits()}  ▾")
            }
            DropdownMenu(expanded = yearMenuExpanded, onDismissRequest = { yearMenuExpanded = false }) {
                (maxOf(1347, syncYear - 5)..minOf(1500, syncYear + 10)).forEach { optionYear ->
                    DropdownMenuItem(text = { PersianText(optionYear.toString().toPersianDigits()) }, onClick = {
                        selectedCalendarYear = optionYear
                        yearMenuExpanded = false
                    })
                }
            }
        }
        Button(onClick = { onSyncHolidays(selectedCalendarYear) }, enabled = !holidaySyncing, modifier = Modifier.fillMaxWidth()) {
            PersianText(if (holidaySyncing) "در حال دریافت تقویم…" else "دریافت مناسبت‌های سال انتخاب‌شده")
        }
        if (holidaySyncMessage.isNotBlank()) PersianText(holidaySyncMessage, style = MaterialTheme.typography.bodySmall, color = if (holidaySyncMessage.contains("نشد")) Color(0xFFB3261E) else Color(0xFF28588A))
        Divider()
        PersianText("پشتیبان‌گیری و بازیابی", style = MaterialTheme.typography.titleMedium)
        Button(onClick = onBackup, modifier = Modifier.fillMaxWidth()) { PersianText("ساخت پشتیبان Excel (.xlsx)") }
        OutlinedButton(onClick = onRestore, modifier = Modifier.fillMaxWidth()) { PersianText("بازیابی از فایل Excel") }
        PersianText("بازیابی، اطلاعات فعلی را پس از تأیید جایگزین می‌کند.", style = MaterialTheme.typography.bodySmall)
        settings.forEach { (key, label) ->
            val enabled = remember(key, tick) { db.getSetting(key) }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                PersianText(label, modifier = Modifier.weight(1f))
                Switch(checked = enabled, onCheckedChange = { db.setSetting(key,it); tick++ })
            }
        }
        var dailyHours by remember { mutableStateOf(db.getSettingText("workday_hours","08:00")) }
        var thursdayHours by remember { mutableStateOf(db.getSettingText("thursday_hours_value","04:00")) }
        PersianText("ساعت موظفی", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(dailyHours, { dailyHours = formatTimeInput(it) }, label = { PersianText("شنبه تا چهارشنبه (HH:MM)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(thursdayHours, { thursdayHours = formatTimeInput(it) }, label = { PersianText("پنجشنبه (HH:MM)") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            if (mins(dailyHours) != null && mins(thursdayHours) != null) {
                db.setSettingText("workday_hours",dailyHours)
                db.setSettingText("thursday_hours_value",thursdayHours)
                tick++
            }
        }, modifier = Modifier.fillMaxWidth()) { PersianText("ذخیره ساعت موظفی") }
        Divider()
        Spacer(Modifier.height(12.dp))
        Button(onClick = back, modifier = Modifier.fillMaxWidth()) { PersianText("بازگشت") }
    }
}



@Composable
fun SummaryTile(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.fillMaxWidth().padding(vertical = 10.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            PersianText(value, style = MaterialTheme.typography.titleMedium)
            PersianText(label, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportScreen(
    db: WorkDb, year: Int, monthNumber: Int, refresh: Int,
    modifier: Modifier = Modifier, annual: Boolean,
    onPeriodChange: (Int, Int) -> Unit,
    export: (Boolean) -> Unit, exportPdf: (Boolean) -> Unit
) {
    var monthMenuExpanded by remember { mutableStateOf(false) }
    var yearMenuExpanded by remember { mutableStateOf(false) }
    val monthKey = "%04d-%02d".format(year, monthNumber)
    val storedMonthDays = remember(monthKey, refresh) { db.allDays(monthKey).associateBy { it.date } }
    val reportDays = remember(year, monthNumber, refresh) { reportPeriodDays(db, year, monthNumber, false) }
    val yearDays = remember(year, refresh) { reportPeriodDays(db, year, monthNumber, true) }
    val yearPrefix = "%04d-".format(year)
    val yearShiftMinutes = remember(year, refresh) {
        db.allDaysForBackup().filter { it.shiftEnabled && (it.shiftStartDate.ifBlank { it.date }).startsWith(yearPrefix) }
            .sumOf { shiftDurationMinutes(it, it.date) }
    }
    val monthShiftDays = remember(monthKey, refresh) {
        db.allDaysForBackup().filter { it.shiftEnabled && (it.shiftStartDate.ifBlank { it.date }).startsWith(monthKey) }
    }
    val selectedDays = if (annual) yearDays else reportDays
    val totalWork = selectedDays.sumOf { duration(it) }
    val totalOvertime = selectedDays.sumOf { overtimeMinutes(it, db) }
    val totalShift = if (annual) yearShiftMinutes else monthShiftDays.sumOf { shiftDurationMinutes(it, it.date) }
    val shiftCount = if (annual) yearDays.count { it.shiftEnabled } else monthShiftDays.size
    val missionCount = selectedDays.count { it.dayType == "مأموریت" }
    val sickCount = selectedDays.count { it.dayType == "استعلاجی" }
    val entitledCount = selectedDays.count { it.dayType == "مرخصی" }

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 5.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(bottom = 14.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!annual) {
                    Box(Modifier.weight(1f)) {
                        OutlinedButton(onClick = { monthMenuExpanded = true }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 7.dp)) {
                            PersianText("ماه: ${JalaliMonthNames.getOrElse(monthNumber - 1) { "ماه" }}  ⌄", fontSize = 13.sp, maxLines = 1)
                        }
                        DropdownMenu(expanded = monthMenuExpanded, onDismissRequest = { monthMenuExpanded = false }) {
                            JalaliMonthNames.forEachIndexed { index, name ->
                                DropdownMenuItem(text = { PersianText(name) }, onClick = { monthMenuExpanded = false; onPeriodChange(year, index + 1) })
                            }
                        }
                    }
                } else {
                    Surface(Modifier.weight(1f), color = Color(0xFFEAF3FF), shape = RoundedCornerShape(9.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBEDBFA))) {
                        Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) { PersianText("خلاصهٔ سالانه", fontSize = 13.sp, color = Color(0xFF163D6B)) }
                    }
                }
                Box(Modifier.weight(1f)) {
                    OutlinedButton(onClick = { yearMenuExpanded = true }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 7.dp)) {
                        PersianText("سال: ${persianDigits(year.toString())}  ⌄", fontSize = 13.sp, maxLines = 1)
                    }
                    DropdownMenu(expanded = yearMenuExpanded, onDismissRequest = { yearMenuExpanded = false }) {
                        ((year - 5)..(year + 1)).toList().reversed().forEach { y ->
                            DropdownMenuItem(text = { PersianText(persianDigits(y.toString())) }, onClick = { yearMenuExpanded = false; onPeriodChange(y, monthNumber) })
                        }
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FCFF)), shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(14.dp))) {
                Column(Modifier.fillMaxWidth().padding(7.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        ReportMetricTile("مجموع کارکرد", hm(totalWork), "◷", Color(0xFF153F78), Modifier.weight(1f))
                        ReportMetricTile("اضافه‌کار", hm(totalOvertime), "◴", OvertimeGreenText, Modifier.weight(1f))
                        ReportMetricTile("جمع مدت شیفت", hm(totalShift), "◷", ShiftYellowText, Modifier.weight(1f))
                        ReportMetricTile("تعداد شیفت", shiftCount.toString(), "▦", Color(0xFF153F78), Modifier.weight(1f))
                    }
                    Divider(color = Color(0xFFD2E5FA))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        ReportMetricTile("مرخصی ساعتی", "—", "◷", Color(0xFF153F78), Modifier.weight(1.05f))
                        ReportMetricTile("مأموریت", missionCount.toString(), "✈", Color(0xFF153F78), Modifier.weight(0.9f))
                        ReportMetricTile("مرخصی استحقاقی", entitledCount.toString(), "☼", Color(0xFF153F78), Modifier.weight(1.1f))
                        ReportMetricTile("مرخصی استعلاجی", sickCount.toString(), "✚", Color(0xFF153F78), Modifier.weight(1.1f))
                    }
                }
            }
        }
        if (!annual) {
            items(reportDays, key = { it.date }) { d -> ReportDayCard(d, db, db.displayHolidayTitle(d.date) ?: officialJalaliHolidays(d.date.take(4).toIntOrNull() ?: year).toMap()[d.date]) }
        } else {
            item { PersianText("خلاصهٔ ماه‌به‌ماه سال ${persianDigits(year.toString())}", style = MaterialTheme.typography.titleMedium, color = Color(0xFF163D6B)) }
            items((1..12).toList()) { m ->
                val monthDays = yearDays.filter { it.date.startsWith("%04d-%02d".format(year, m)) }
                val monthShift = db.allDaysForBackup().filter { it.shiftEnabled && (it.shiftStartDate.ifBlank { it.date }).startsWith("%04d-%02d".format(year, m)) }.sumOf { shiftDurationMinutes(it, it.date) }
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FCFF)), shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(12.dp))) {
                    Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        PersianText(JalaliMonthNames[m - 1], style = MaterialTheme.typography.titleSmall, color = Color(0xFF163D6B), fontWeight = FontWeight.Bold)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            PersianText("کارکرد ${hm(monthDays.sumOf { duration(it) })}", fontSize = 12.sp)
                            PersianText("اضافه‌کار ${hm(monthDays.sumOf { overtimeMinutes(it, db) })}", fontSize = 12.sp, color = OvertimeGreenText)
                            PersianText("شیفت ${hm(monthShift)}", fontSize = 12.sp, color = ShiftYellowText)
                        }
                        val officialHolidayCount = monthDays.count { d ->
                            db.officialHolidayTitle(d.date) != null || officialJalaliHolidays(year).toMap().containsKey(d.date)
                        }
                        PersianText("تعطیلات رسمی: ${officialHolidayCount.toString().toPersianDigits()} روز", fontSize = 11.sp, color = Color(0xFFB3261E))
                    }
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { export(annual) }, modifier = Modifier.fillMaxWidth()) { PersianText("خروجی Excel گزارش ${if (annual) "سالانه" else "ماهانه"}") }
                OutlinedButton(onClick = { exportPdf(annual) }, modifier = Modifier.fillMaxWidth()) { PersianText("خروجی PDF گزارش ${if (annual) "سالانه" else "ماهانه"}") }
            }
        }
    }
}

@Composable
private fun ReportMetricTile(title: String, value: String, symbol: String, valueColor: Color, modifier: Modifier = Modifier) {
    Column(modifier = modifier.heightIn(min = 86.dp).background(Color(0xFFF5FAFF), RoundedCornerShape(9.dp)).padding(horizontal = 3.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        PersianText(title, fontSize = 9.sp, color = Color(0xFF315C8D), textAlign = TextAlign.Center, maxLines = 2, lineHeight = 11.sp)
        Spacer(Modifier.height(2.dp))
        PersianText(symbol, fontSize = 17.sp, color = valueColor, maxLines = 1)
        PersianText(value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = valueColor, maxLines = 1)
    }
}

@Composable
private fun ReportDayCard(day: WorkDay, db: WorkDb, holidayTitle: String?) {
    val weekDay = jalaliWeekday(day.date)?.let { JalaliWeekdayNames.getOrNull(it) }.orEmpty()
    val holidayEntryExists = isHolidayWorkDay(day) && (day.holidayIn.isNotBlank() || day.holidayOut.isNotBlank())

    // Only include entry/exit values that the user actually entered.
    // Keep the original order: entry 1, exit 1, entry 2, exit 2, entry 3, exit 3.
    val timeEntries: List<Pair<String, String>> = if (holidayEntryExists) {
        buildList {
            if (day.holidayIn.isNotBlank()) add("ورود" to day.holidayIn)
            if (day.holidayOut.isNotBlank()) add("خروج" to day.holidayOut)
        }
    } else {
        buildList {
            if (day.in1.isNotBlank()) add("ورود" to day.in1)
            if (day.out1.isNotBlank()) add("خروج" to day.out1)
            if (day.in2.isNotBlank()) add("ورود" to day.in2)
            if (day.out2.isNotBlank()) add("خروج" to day.out2)
            if (day.in3.isNotBlank()) add("ورود" to day.in3)
            if (day.out3.isNotBlank()) add("خروج" to day.out3)
        }
    }

    val shiftDuration = if (day.shiftEnabled) shiftDurationMinutes(day, day.date) else 0

    // Holiday cards are distinguished with a soft red fill and red outline.
    // Friday is detected by the Jalali weekday index used in this project (5 = Friday).
    val isHolidayCard = jalaliWeekday(day.date) == 5 ||
        day.dayType in setOf("تعطیل", "تعطیل رسمی", "تعطیل مناسبتی") ||
        db.officialHolidayTitle(day.date) != null || db.holidayTitle(day.date) != null ||
        officialJalaliHolidays(day.date.take(4).toIntOrNull() ?: 0).toMap().containsKey(day.date)
    val holidayCardBackground = if (isHolidayCard) Color(0xFFFFF5F5) else Color(0xFFF9FCFF)
    val holidayCardBorder = if (isHolidayCard) Color(0xFFE57373) else Color(0xFFBEDBFA)
    val holidayHeaderColor = if (isHolidayCard) Color(0xFFB3261E) else Color(0xFF163D6B)

    // Show only the selected day category, rather than all available categories.
    val selectedStatus = when (day.dayType) {
        "مرخصی" -> "مرخصی استحقاقی"
        else -> day.dayType
    }
    val statusItems = buildList {
        if (selectedStatus.isNotBlank()) add(selectedStatus)
        if (day.shiftEnabled) add("شیفت")
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = holidayCardBackground),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().border(1.5.dp, holidayCardBorder, RoundedCornerShape(14.dp))
    ) {
        Column(
            Modifier.fillMaxWidth().padding(7.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                PersianText(
                    "${weekDay} ${jalaliDisplayDate(day.date)}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = holidayHeaderColor
                )
                PersianText("▦", fontSize = 20.sp, color = if (isHolidayCard) Color(0xFFB3261E) else Color(0xFF426B91))
            }

            Divider(color = if (isHolidayCard) Color(0xFFF0B4B4) else Color(0xFFD9E8F8))

            if (timeEntries.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    timeEntries.forEach { (label, time) ->
                        Column(
                            Modifier.weight(1f)
                                .defaultMinSize(minHeight = 55.dp)
                                .border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(8.dp))
                                .padding(horizontal = 2.dp, vertical = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            PersianText(label, fontSize = 9.sp, color = Color(0xFF28588A), maxLines = 1)
                            PersianText(
                                time.toPersianDigits(),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF123C70),
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            if (statusItems.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    statusItems.forEach { status ->
                        val isShift = status == "شیفت"
                        val bg = when {
                            isShift -> ShiftYellow
                            status == "تعطیل مناسبتی" -> Color(0xFFE0F5E9)
                            else -> Color(0xFFE4F0FF)
                        }
                        val foreground = when {
                            isShift -> ShiftYellowText
                            status == "تعطیل مناسبتی" -> Color(0xFF176B36)
                            else -> Color(0xFF1556A6)
                        }
                        Surface(
                            modifier = Modifier.weight(1f).heightIn(min = 36.dp),
                            shape = RoundedCornerShape(8.dp),
                            color = bg,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isShift) Color(0xFFE5C34A) else Color(0xFF8DBFFF)
                            )
                        ) {
                            Box(
                                Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 5.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                PersianText(
                                    status,
                                    fontSize = 10.sp,
                                    color = foreground,
                                    textAlign = TextAlign.Center,
                                    maxLines = 2,
                                    lineHeight = 12.sp
                                )
                            }
                        }
                    }
                }
            }

            if (day.dayType == "تعطیل مناسبتی" || !holidayTitle.isNullOrBlank()) {
                Row(
                    Modifier.fillMaxWidth()
                        .border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(8.dp))
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PersianText("✎", fontSize = 17.sp, color = Color(0xFF28588A))
                    PersianText("مناسبت / عنوان تعطیلی:", fontSize = 11.sp, color = Color(0xFF28588A))
                    PersianText(
                        holidayTitle ?: "—",
                        modifier = Modifier.weight(1f),
                        fontSize = 11.sp,
                        color = Color(0xFF163D6B),
                        maxLines = 3,
                        lineHeight = 14.sp
                    )
                }
            }

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                ReportValueTile("جمع کار", hm(duration(day)), Color(0xFFEAF3FF), Color(0xFF153F78), Modifier.weight(1f))
                ReportValueTile("مدت شیفت", hm(shiftDuration), Color(0xFFFFF7E1), ShiftYellowText, Modifier.weight(1f))
                ReportValueTile("اضافه‌کار", hm(overtimeMinutes(day, db)), Color(0xFFE4F7EE), OvertimeGreenText, Modifier.weight(1f))
            }

            // The note wraps to as many lines as necessary; the card grows with the text.
            Row(
                Modifier.fillMaxWidth()
                    .border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(8.dp))
                    .padding(8.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PersianText("▤", fontSize = 17.sp, color = Color(0xFF28588A))
                PersianText("یادداشت روز:", fontSize = 11.sp, color = Color(0xFF163D6B))
                PersianText(
                    day.note.ifBlank { "—" }.toPersianDigits(),
                    modifier = Modifier.weight(1f),
                    fontSize = 12.sp,
                    color = Color(0xFF5D7898),
                    lineHeight = 16.sp,
                    maxLines = Int.MAX_VALUE,
                    softWrap = true
                )
            }
        }
    }
}

@Composable
private fun ReportValueTile(title: String, value: String, background: Color, foreground: Color, modifier: Modifier = Modifier) {
    Column(modifier = modifier.background(background, RoundedCornerShape(9.dp)).padding(horizontal = 5.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        PersianText(title, fontSize = 11.sp, color = foreground, textAlign = TextAlign.Center, maxLines = 1)
        PersianText(value, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = foreground, maxLines = 1)
    }
}

fun buildReportXlsx(db: WorkDb, year: Int, month: Int, annual: Boolean): ByteArray {
    val days = reportPeriodDays(db, year, month, annual)
    val title = if (annual) "گزارش سال $year" else "گزارش ماه %04d-%02d".format(year, month)
    val summary = mutableListOf(listOf("عنوان", "مقدار"), listOf(title, ""), listOf("مجموع کارکرد", hm(days.sumOf { duration(it) })), listOf("مجموع اضافه کاری", hm(days.sumOf { overtimeMinutes(it, db) })), listOf("روزهای دوره", days.size.toString()), listOf("تعطیلات رسمی", days.count { db.officialHolidayTitle(it.date) != null || officialJalaliHolidays(year).toMap().containsKey(it.date) }.toString()), listOf("مرخصی استعلاجی (ج)", days.count { it.dayType == "استعلاجی" }.toString()), listOf("شیفت های ثبت شده", days.count { it.shiftEnabled }.toString()))
    if (annual) (1..12).forEach { m ->
        val md = days.filter { it.date.startsWith("%04d-%02d".format(year,m)) }
        summary.add(listOf("ماه $m - کارکرد", hm(md.sumOf { duration(it) })))
        summary.add(listOf("ماه $m - اضافه کاری", hm(md.sumOf { overtimeMinutes(it, db) })))
    }
    val details = mutableListOf(listOf("تاریخ شمسی", "وضعیت", "مناسبت/عنوان تعطیلی", "بازه ۱", "بازه ۲", "بازه ۳", "ورود تعطیل", "خروج تعطیل", "کارکرد عادی", "اضافه کاری", "شیفت فعال", "تاریخ ورود شیفت", "ساعت ورود شیفت", "تاریخ خروج شیفت", "ساعت خروج شیفت", "مدت شیفت", "یادداشت"))
    days.forEach { d -> details.add(listOf(d.date, d.dayType, db.displayHolidayTitle(d.date) ?: officialJalaliHolidays(year).toMap()[d.date].orEmpty(), "${d.in1}-${d.out1}", "${d.in2}-${d.out2}", "${d.in3}-${d.out3}", d.holidayIn, d.holidayOut, hm(duration(d)), hm(overtimeMinutes(d,db)), if(d.shiftEnabled) "بله" else "خیر", d.shiftStartDate.ifBlank { d.date }, d.shiftStart, d.shiftEndDate.ifBlank { defaultShiftEndDate(d.date, d.shiftStart, d.shiftEnd) }, d.shiftEnd, hm(shiftDurationMinutes(d, d.date)), d.note)) }
    val entries = linkedMapOf(
        "[Content_Types].xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""",
        "_rels/.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""",
        "xl/workbook.xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Summary" sheetId="1" r:id="rId1"/><sheet name="Details" sheetId="2" r:id="rId2"/></sheets></workbook>""",
        "xl/_rels/workbook.xml.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/></Relationships>""",
        "xl/worksheets/sheet1.xml" to sheetXml(summary), "xl/worksheets/sheet2.xml" to sheetXml(details)
    )
    val output = java.io.ByteArrayOutputStream()
    java.util.zip.ZipOutputStream(output).use { zip -> entries.forEach { (name,content) -> zip.putNextEntry(java.util.zip.ZipEntry(name)); zip.write(content.toByteArray(Charsets.UTF_8)); zip.closeEntry() } }
    return output.toByteArray()
}

fun buildReportPdf(db: WorkDb, year: Int, month: Int, annual: Boolean): ByteArray {
    val days = reportPeriodDays(db, year, month, annual)
    val pdf = android.graphics.pdf.PdfDocument()
    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { textSize = 12f; color = android.graphics.Color.BLACK; textAlign = android.graphics.Paint.Align.RIGHT }
    val titlePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { textSize = 18f; typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD); color = android.graphics.Color.rgb(57,73,171); textAlign = android.graphics.Paint.Align.RIGHT }
    val lines = mutableListOf<String>()
    lines.add(if(annual) "گزارش سالانه کارکرد - $year" else "گزارش ماهانه کارکرد - $year/$month")
    lines.add("مجموع کارکرد: ${hm(days.sumOf { duration(it) })}")
    lines.add("مجموع اضافه کاری: ${hm(days.sumOf { overtimeMinutes(it, db) })}")
    lines.add("مجموع مدت شیفت: ${hm(db.allDaysForBackup().filter { it.shiftEnabled && (it.shiftStartDate.ifBlank { it.date }.startsWith(if (annual) "%04d-".format(year) else "%04d-%02d".format(year,month))) }.sumOf { shiftDurationMinutes(it, it.date) })}")
    lines.add("روزهای دوره: ${days.size} | تعطیلات رسمی: ${days.count { db.officialHolidayTitle(it.date) != null || officialJalaliHolidays(year).toMap().containsKey(it.date) }} | استعلاجی (ج): ${days.count { it.dayType == "استعلاجی" }} | شیفت ها: ${days.count { it.shiftEnabled }}")
    if (annual) (1..12).forEach { m -> val md = days.filter { it.date.startsWith("%04d-%02d".format(year,m)) }; lines.add("ماه $m: کارکرد ${hm(md.sumOf { duration(it) })} - اضافه کاری ${hm(md.sumOf { overtimeMinutes(it,db) })} - شیفت ${hm(db.allDaysForBackup().filter { it.shiftEnabled && (it.shiftStartDate.ifBlank { it.date }.startsWith("%04d-%02d".format(year,m))) }.sumOf { shiftDurationMinutes(it, it.date) })}") }
    lines.add("جزئیات روزانه:")
    days.forEach { d -> lines.add("${d.date} | ${d.dayType}${db.displayHolidayTitle(d.date)?.let { " | $it" } ?: officialJalaliHolidays(year).toMap()[d.date]?.let { " | $it" }.orEmpty()} | کارکرد ${hm(duration(d))} | اضافه کاری ${hm(overtimeMinutes(d,db))}${if (isHolidayWorkDay(d) && (d.holidayIn.isNotBlank() || d.holidayOut.isNotBlank())) " | ورود/خروج تعطیل ${d.holidayIn} تا ${d.holidayOut}" else ""}${if(d.shiftEnabled) " | شیفت ${d.shiftStartDate.ifBlank { d.date }} ${d.shiftStart} تا ${d.shiftEndDate.ifBlank { defaultShiftEndDate(d.date, d.shiftStart, d.shiftEnd) }} ${d.shiftEnd} (${hm(shiftDurationMinutes(d, d.date))})" else ""}") }
    val perPage = 38
    lines.chunked(perPage).forEachIndexed { index, pageLines ->
        val info = android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, index+1).create()
        val page = pdf.startPage(info)
        var y = 48f
        pageLines.forEachIndexed { i, line ->
            if(index == 0 && i == 0) { page.canvas.drawText(line.toPersianDigits(), 560f, y, titlePaint); y += 34f }
            else { page.canvas.drawText(line.toPersianDigits().take(100), 560f, y, paint); y += 19f }
        }
        pdf.finishPage(page)
    }
    val out = java.io.ByteArrayOutputStream(); pdf.writeTo(out); pdf.close(); return out.toByteArray()
}

private fun xmlEscape(v: String): String = v.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;")
private fun colName(n: Int): String {
    var x=n; var out=""
    while(x>0){ val r=(x-1)%26; out=(('A'.code+r).toChar())+out; x=(x-1)/26 }
    return out
}
private fun sheetXml(rows: List<List<String>>): String {
    val body = rows.mapIndexed { ri,row ->
        val cells = row.mapIndexed { ci,value ->
            val ref = colName(ci+1)+(ri+1)
            "<c r=\"$ref\" t=\"inlineStr\"><is><t>${xmlEscape(value.toPersianDigits())}</t></is></c>"
        }.joinToString("")
        "<row r=\"${ri+1}\">$cells</row>"
    }.joinToString("")
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>$body</sheetData></worksheet>"""
}
fun buildBackupXlsx(db: WorkDb): ByteArray {
    val workRows = mutableListOf(listOf("date","dayType","in1","out1","in2","out2","in3","out3","duration","overtimeOverride","note","shiftEnabled","shiftStart","shiftEnd","shiftStartDate","shiftEndDate","holidayIn","holidayOut"))
    db.allDaysForBackup().forEach { d ->
        workRows.add(listOf(d.date,d.dayType,d.in1,d.out1,d.in2,d.out2,d.in3,d.out3,hm(duration(d)),d.overtimeOverride,d.note,d.shiftEnabled.toString(),d.shiftStart,d.shiftEnd,d.shiftStartDate,d.shiftEndDate,d.holidayIn,d.holidayOut))
    }
    val settingsRows = mutableListOf(listOf("key","value"))
    db.allSettings().forEach { settingsRows.add(listOf(it.first,it.second)) }
    val entries = linkedMapOf(
        "[Content_Types].xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""",
        "_rels/.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""",
        "xl/workbook.xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Workdays" sheetId="1" r:id="rId1"/><sheet name="Settings" sheetId="2" r:id="rId2"/></sheets></workbook>""",
        "xl/_rels/workbook.xml.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/></Relationships>""",
        "xl/worksheets/sheet1.xml" to sheetXml(workRows),
        "xl/worksheets/sheet2.xml" to sheetXml(settingsRows)
    )
    val output = java.io.ByteArrayOutputStream()
    java.util.zip.ZipOutputStream(output).use { zip ->
        entries.forEach { (name,content) ->
            zip.putNextEntry(java.util.zip.ZipEntry(name))
            zip.write(content.toByteArray(Charsets.UTF_8))
            zip.closeEntry()
        }
    }
    return output.toByteArray()
}
private fun readBackupXlsx(bytes: ByteArray): Pair<List<WorkDay>,List<Pair<String,String>>> {
    val entries = mutableMapOf<String,ByteArray>()
    java.util.zip.ZipInputStream(bytes.inputStream()).use { zip ->
        while(true) {
            val e = zip.nextEntry ?: break
            if (e.name == "xl/worksheets/sheet1.xml" || e.name == "xl/worksheets/sheet2.xml") {
                entries[e.name] = zip.readBytes()
            }
            zip.closeEntry()
        }
    }
    fun parseSheet(xmlBytes: ByteArray?): List<List<String>> {
        if(xmlBytes == null) return emptyList()
        val parser = android.util.Xml.newPullParser()
        parser.setInput(xmlBytes.inputStream(), "UTF-8")
        val rows = mutableListOf<List<String>>()
        var row: MutableList<String>? = null
        var cellText = StringBuilder()
        var inCell = false
        var event = parser.eventType
        while(event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
            when(event) {
                org.xmlpull.v1.XmlPullParser.START_TAG -> when(parser.name) {
                    "row" -> row = mutableListOf()
                    "c" -> { inCell = true; cellText = StringBuilder() }
                    "t" -> if(inCell) { }
                }
                org.xmlpull.v1.XmlPullParser.TEXT -> if(inCell) cellText.append(parser.text)
                org.xmlpull.v1.XmlPullParser.END_TAG -> when(parser.name) {
                    "c" -> { row?.add(cellText.toString()); inCell = false }
                    "row" -> { row?.let { rows.add(it) }; row = null }
                }
            }
            event = parser.next()
        }
        return rows
    }
    val workRows = parseSheet(entries["xl/worksheets/sheet1.xml"])
    val settingsRows = parseSheet(entries["xl/worksheets/sheet2.xml"])
    require(workRows.isNotEmpty() && workRows.first().firstOrNull() == "date") { "ساختار فایل پشتیبان معتبر نیست" }
    val days = workRows.drop(1).filter { it.size >= 11 && it[0].matches(Regex("\\d{4}-\\d{2}-\\d{2}")) }.map { r ->
        WorkDay(r[0],r[2],r[3],r[4],r[5],r[6],r[7],r[10],r[1].ifBlank{"کاری"},r[9], r.getOrNull(11)?.toBoolean() ?: false, r.getOrNull(12) ?: "", r.getOrNull(13) ?: "", r.getOrNull(14) ?: "", r.getOrNull(15) ?: "", r.getOrNull(16) ?: "", r.getOrNull(17) ?: "")
    }
    val settings = settingsRows.drop(1).filter { it.size >= 2 }.map { it[0] to it[1] }
    return days to settings
}
