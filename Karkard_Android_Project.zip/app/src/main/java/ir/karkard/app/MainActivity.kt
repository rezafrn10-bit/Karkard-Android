package ir.karkard.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


private val ShiftYellow = Color(0xFFFFF0B3)
private val ShiftYellowText = Color(0xFF795500)
private val OvertimeGreen = Color(0xFFD9F2D9)
private val OvertimeGreenText = Color(0xFF176B36)

private fun String.toLatinDigits(): String = map { ch ->
    when (ch) {
        '۰' -> '0'; '۱' -> '1'; '۲' -> '2'; '۳' -> '3'; '۴' -> '4'
        '۵' -> '5'; '۶' -> '6'; '۷' -> '7'; '۸' -> '8'; '۹' -> '9'
        '٠' -> '0'; '١' -> '1'; '٢' -> '2'; '٣' -> '3'; '٤' -> '4'
        '٥' -> '5'; '٦' -> '6'; '٧' -> '7'; '٨' -> '8'; '٩' -> '9'
        else -> ch
    }
}.joinToString("")

private val JalaliMonthNames = listOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
private val JalaliWeekdayNames = listOf("یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه")
private fun jalaliDisplayDate(value: String): String = value.replace('-', '/').toPersianDigits()

private fun String.toPersianDigits(): String = map { ch ->
    when (ch) {
        '0' -> '۰'; '1' -> '۱'; '2' -> '۲'; '3' -> '۳'; '4' -> '۴'
        '5' -> '۵'; '6' -> '۶'; '7' -> '۷'; '8' -> '۸'; '9' -> '۹'
        else -> ch
    }
}.joinToString("")

@Composable
private fun PersianText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = FontFamily.SansSerif,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    textDecoration: TextDecoration? = null,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    style: TextStyle = LocalTextStyle.current
) {
    androidx.compose.material3.Text(
        text = text.toPersianDigits(),
        modifier = modifier,
        color = color,
        fontSize = fontSize,
        fontStyle = fontStyle,
        fontWeight = fontWeight,
        fontFamily = fontFamily,
        letterSpacing = letterSpacing,
        textDecoration = textDecoration,
        textAlign = textAlign,
        lineHeight = lineHeight,
        overflow = overflow,
        softWrap = softWrap,
        maxLines = maxLines,
        minLines = minLines,
        style = style
    )
}

data class WorkDay(
    val date: String,
    val in1: String = "", val out1: String = "",
    val in2: String = "", val out2: String = "",
    val in3: String = "", val out3: String = "",
    val note: String = "",
    val dayType: String = "کاری",
    val overtimeOverride: String = "",
    val shiftEnabled: Boolean = false,
    val shiftStart: String = "",
    val shiftEnd: String = "",
    val shiftStartDate: String = "",
    val shiftEndDate: String = "",
    val holidayIn: String = "",
    val holidayOut: String = "",
    val leave1Start: String = "", val leave1End: String = "",
    val leave2Start: String = "", val leave2End: String = "",
    val hourlyLeaveEnabled: Boolean = false
)

class WorkDb(context: Context) : SQLiteOpenHelper(context, "karkard.db", null, 14) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE workdays(
            date TEXT PRIMARY KEY, in1 TEXT, out1 TEXT, in2 TEXT, out2 TEXT,
            in3 TEXT, out3 TEXT, note TEXT, day_type TEXT DEFAULT 'کاری',
            overtime_override TEXT DEFAULT '', shift_enabled INTEGER DEFAULT 0, shift_start TEXT DEFAULT '', shift_end TEXT DEFAULT '', shift_start_date TEXT DEFAULT '', shift_end_date TEXT DEFAULT '', holiday_in TEXT DEFAULT '', holiday_out TEXT DEFAULT '', leave1_start TEXT DEFAULT '', leave1_end TEXT DEFAULT '', leave2_start TEXT DEFAULT '', leave2_end TEXT DEFAULT '', leave_enabled INTEGER DEFAULT 0)""")
        db.execSQL("CREATE TABLE holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL)")
        db.execSQL("CREATE TABLE official_holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL, year INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE holiday_sync(year INTEGER PRIMARY KEY, synced_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE calendar_events(date TEXT PRIMARY KEY, title TEXT NOT NULL, year INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE long_leave_days(date TEXT PRIMARY KEY, batch_id TEXT NOT NULL, leave_type TEXT NOT NULL)")
        db.execSQL("""CREATE TABLE settings(
            key TEXT PRIMARY KEY, value TEXT NOT NULL)""")
        val defaults = mapOf(
            "overtime" to "true", "leave_hourly" to "true", "leave_daily" to "true",
            "mission" to "true", "shifts" to "true", "thursday_hours" to "true",
            "fixed_hours" to "false", "calendar" to "true",
            "workday_hours" to "07:00", "thursday_hours_value" to "05:00"
        )
        defaults.forEach { (k,v) ->
            val cv = ContentValues().apply { put("key", k); put("value", v) }
            db.insert("settings", null, cv)
        }
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN day_type TEXT DEFAULT 'کاری'")
            db.execSQL("ALTER TABLE workdays ADD COLUMN overtime_override TEXT DEFAULT ''")
            val defaults = mapOf("workday_hours" to "07:00", "thursday_hours_value" to "05:00")
            defaults.forEach { (k,v) ->
                val cv = ContentValues().apply { put("key",k); put("value",v) }
                db.insertWithOnConflict("settings", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
            }
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_enabled INTEGER DEFAULT 0")
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_start TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_end TEXT DEFAULT ''")
        }
        if (oldVersion < 4) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_start_date TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN shift_end_date TEXT DEFAULT ''")
            db.execSQL("DELETE FROM settings WHERE key='shift_hours'")
        }
        if (oldVersion < 5) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN holiday_in TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN holiday_out TEXT DEFAULT ''")
        }
        if (oldVersion < 11) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave1_start TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave1_end TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave2_start TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave2_end TEXT DEFAULT ''")
        }
        if (oldVersion < 12) {
            db.execSQL("ALTER TABLE workdays ADD COLUMN leave_enabled INTEGER DEFAULT 0")
            // Existing leave entries must remain active after an upgrade.
            db.execSQL("""UPDATE workdays SET leave_enabled=1 WHERE
                COALESCE(leave1_start,'')<>'' OR COALESCE(leave1_end,'')<>'' OR
                COALESCE(leave2_start,'')<>'' OR COALESCE(leave2_end,'')<>''""")
        }
        if (oldVersion < 13) {
            // Migrate factory defaults from prior versions, without overriding other custom choices.
            db.execSQL("UPDATE settings SET value='07:00' WHERE key='workday_hours' AND value='08:00'")
            db.execSQL("UPDATE settings SET value='05:00' WHERE key='thursday_hours_value' AND value='04:00'")
            db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('workday_hours','07:00')")
            db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('thursday_hours_value','05:00')")
        }
        if (oldVersion < 14) {
            db.execSQL("CREATE TABLE IF NOT EXISTS long_leave_days(date TEXT PRIMARY KEY, batch_id TEXT NOT NULL, leave_type TEXT NOT NULL)")
            // Older versions stored Fridays as the legacy 'تعطیل' status.
            db.execSQL("UPDATE workdays SET day_type='تعطیل رسمی' WHERE day_type='تعطیل'")
        }
        db.execSQL("CREATE TABLE IF NOT EXISTS holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS official_holidays(date TEXT PRIMARY KEY, title TEXT NOT NULL, year INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS holiday_sync(year INTEGER PRIMARY KEY, synced_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS calendar_events(date TEXT PRIMARY KEY, title TEXT NOT NULL, year INTEGER NOT NULL)")
        db.execSQL("DELETE FROM settings WHERE key='shift_hours'")
        if (oldVersion < 10) {
            // Force a fresh calendar download after holiday parser improvements.
            // Existing work records and saved calendar data are retained.
            db.delete("holiday_sync", null, null)
        }
    }

    fun hasWorkDay(date: String): Boolean = readableDatabase.rawQuery(
        "SELECT 1 FROM workdays WHERE date=? LIMIT 1", arrayOf(date)
    ).use { it.moveToFirst() }

    fun getDay(date: String): WorkDay {
        readableDatabase.rawQuery("SELECT * FROM workdays WHERE date=?", arrayOf(date)).use { c ->
            if (c.moveToFirst()) return WorkDay(
                c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "",
                c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "",
                c.getString(6) ?: "", c.getString(7) ?: "",
                if (c.columnCount > 8) c.getString(8) ?: "کاری" else "کاری",
                if (c.columnCount > 9) c.getString(9) ?: "" else "",
                if (c.columnCount > 10) c.getInt(10) == 1 else false,
                if (c.columnCount > 11) c.getString(11) ?: "" else "",
                if (c.columnCount > 12) c.getString(12) ?: "" else "",
                if (c.columnCount > 13) c.getString(13) ?: "" else "",
                if (c.columnCount > 14) c.getString(14) ?: "" else "",
                if (c.columnCount > 15) c.getString(15) ?: "" else "",
                if (c.columnCount > 16) c.getString(16) ?: "" else "",
                if (c.columnCount > 17) c.getString(17) ?: "" else "", if (c.columnCount > 18) c.getString(18) ?: "" else "",
                if (c.columnCount > 19) c.getString(19) ?: "" else "", if (c.columnCount > 20) c.getString(20) ?: "" else "",
                if (c.columnCount > 21) c.getInt(21) == 1 else listOf(17,18,19,20).any { i -> i < c.columnCount && !c.getString(i).isNullOrBlank() }
            )
        }
        return WorkDay(date)
    }
    /** Long-leave tags are separate so older workday records and export columns stay compatible. */
    fun isLongLeaveDay(date: String): Boolean = readableDatabase.rawQuery(
        "SELECT 1 FROM long_leave_days WHERE date=? LIMIT 1", arrayOf(date)
    ).use { it.moveToFirst() }

    fun unlinkLongLeaveDay(date: String) {
        writableDatabase.delete("long_leave_days", "date=?", arrayOf(date))
    }

    /** A long-leave entry stays active when its original date is revisited.
     * Each day is a separate record; batch ID is only needed to show the end. */
    fun longLeaveEndForDay(date: String): String? = readableDatabase.rawQuery(
        """SELECT MAX(b.date) FROM long_leave_days a JOIN long_leave_days b
           ON b.batch_id=a.batch_id WHERE a.date=?""", arrayOf(date)
    ).use { cursor -> if (cursor.moveToFirst() && !cursor.isNull(0)) cursor.getString(0) else null }

    /** Apply a leave from today to a chosen Jalali end date. Each day is an independent row.
     * Atomic transaction prevents partially inserted ranges. Existing non-empty records
     * are never overwritten without the user's individual edit. */
    fun saveLongLeave(start: String, end: String, leaveType: String, note: String): Int {
        require(leaveType == "مرخصی" || leaveType == "استعلاجی")
        val first = parsedJalaliDate(start) ?: error("تاریخ شروع نامعتبر است")
        val last = parsedJalaliDate(end) ?: error("تاریخ پایان نامعتبر است")
        require(!last.isBefore(first)) { "تاریخ پایان قبل از شروع مرخصی است" }
        require(java.time.temporal.ChronoUnit.DAYS.between(first, last) <= 365) { "بازهٔ مرخصی نباید بیشتر از ۳۶۶ روز باشد" }
        val days = generateSequence(first) { previous ->
            if (previous >= last) null else previous.plusDays(1)
        }.map { jalaliDateString(it) }.toList()
        val existing = days.drop(1).filter { date -> countWorkRecords(date, date) > 0 && !isLongLeaveDay(date) }
        require(existing.isEmpty()) { "${existing.size} روز در این بازه اطلاعات مستقل دارند؛ برای جلوگیری از بازنویسی، ابتدا آن روزها را بررسی کن" }
        val database = writableDatabase
        val batch = System.currentTimeMillis().toString()
        database.beginTransaction()
        try {
            days.forEach { date ->
                // UPDATE first so previously recorded shift/overtime/hour fields are
                // never erased by an INSERT OR REPLACE containing only three columns.
                val values = ContentValues().apply { put("day_type", leaveType); put("note", note) }
                val rowsUpdated = database.update("workdays", values, "date=?", arrayOf(date))
                if (rowsUpdated == 0) {
                    val created = ContentValues(values).apply { put("date", date) }
                    database.insertOrThrow("workdays", null, created)
                }
                val tag = ContentValues().apply { put("date", date);put("batch_id", batch);put("leave_type", leaveType) }
                database.insertWithOnConflict("long_leave_days", null, tag, SQLiteDatabase.CONFLICT_REPLACE)
            }
            database.setTransactionSuccessful()
        } finally { database.endTransaction() }
        return days.size
    }
    fun longLeaveDaysInPeriod(prefix: String): Int = readableDatabase.rawQuery(
        "SELECT COUNT(*) FROM long_leave_days WHERE date LIKE ?", arrayOf("$prefix%")
    ).use { if (it.moveToFirst()) it.getInt(0) else 0 }
    fun calendarSyncTime(year: Int): Long = readableDatabase.rawQuery(
        "SELECT synced_at FROM holiday_sync WHERE year=?", arrayOf(year.toString())
    ).use { if (it.moveToFirst()) it.getLong(0) else 0L }

    /** Deletes only user-entered daily work/leave/shift records in an inclusive Jalali range.
     * Calendar holidays, events, preferences and reminder databases are NOT affected. */
    fun countWorkRecords(start: String, end: String): Int {
        readableDatabase.rawQuery(
            "SELECT COUNT(*) FROM workdays WHERE date >= ? AND date <= ?", arrayOf(start, end)
        ).use { cursor -> return if (cursor.moveToFirst()) cursor.getInt(0) else 0 }
    }

    fun deleteWorkRecords(start: String, end: String): Int {
        require(start <= end)
        val database = writableDatabase
        database.beginTransaction()
        return try {
            val args = arrayOf(start, end)
            val deleted = database.delete("workdays", "date >= ? AND date <= ?", args)
            database.delete("long_leave_days", "date >= ? AND date <= ?", args)
            // Only user-authored holiday reasons; official calendar records are preserved.
            database.delete("holidays", "date >= ? AND date <= ?", args)
            database.setTransactionSuccessful()
            deleted
        } finally { database.endTransaction() }
    }

    fun saveDay(d: WorkDay) {
        val v = ContentValues().apply {
            put("date", d.date); put("in1",d.in1); put("out1",d.out1)
            put("in2",d.in2); put("out2",d.out2); put("in3",d.in3); put("out3",d.out3)
            put("note",d.note); put("day_type",d.dayType); put("overtime_override",d.overtimeOverride); put("shift_enabled", if(d.shiftEnabled) 1 else 0); put("shift_start",d.shiftStart); put("shift_end",d.shiftEnd); put("shift_start_date",d.shiftStartDate); put("shift_end_date",d.shiftEndDate)
            put("holiday_in", d.holidayIn); put("holiday_out", d.holidayOut); put("leave1_start", d.leave1Start); put("leave1_end", d.leave1End); put("leave2_start", d.leave2Start); put("leave2_end", d.leave2End); put("leave_enabled", if (d.hourlyLeaveEnabled) 1 else 0)
        }
        writableDatabase.insertWithOnConflict("workdays", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun allDays(month: String): List<WorkDay> {
        val result = mutableListOf<WorkDay>()
        readableDatabase.rawQuery("SELECT * FROM workdays WHERE date LIKE ? ORDER BY date", arrayOf("$month%")).use { c ->
            while(c.moveToNext()) result.add(WorkDay(
                c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "",
                c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "",
                c.getString(6) ?: "", c.getString(7) ?: "",
                c.getString(8) ?: "کاری", c.getString(9) ?: "", c.getInt(10) == 1, c.getString(11) ?: "", c.getString(12) ?: "", c.getString(13) ?: "", c.getString(14) ?: "",
                if (c.columnCount > 15) c.getString(15) ?: "" else "", if (c.columnCount > 16) c.getString(16) ?: "" else "",
                if (c.columnCount > 17) c.getString(17) ?: "" else "", if (c.columnCount > 18) c.getString(18) ?: "" else "",
                if (c.columnCount > 19) c.getString(19) ?: "" else "", if (c.columnCount > 20) c.getString(20) ?: "" else "",
                if (c.columnCount > 21) c.getInt(21) == 1 else listOf(17,18,19,20).any { i -> i < c.columnCount && !c.getString(i).isNullOrBlank() }
            ))
        }
        return result
    }
    fun allDaysYear(year: Int): List<WorkDay> = allDaysForBackup().filter { it.date.startsWith("%04d-".format(year)) }
    fun officialHolidays(year: Int): List<Pair<String, String>> {
        val result = mutableListOf<Pair<String, String>>()
        readableDatabase.rawQuery(
            "SELECT date,title FROM official_holidays WHERE year=? ORDER BY date",
            arrayOf(year.toString())
        ).use { c -> while (c.moveToNext()) result.add(c.getString(0) to c.getString(1)) }
        return result
    }

    fun officialHolidayTitle(date: String): String? {
        readableDatabase.rawQuery("SELECT title FROM official_holidays WHERE date=?", arrayOf(date)).use { c ->
            return if (c.moveToFirst()) c.getString(0) else null
        }
    }

    fun calendarEventTitle(date: String): String? {
        readableDatabase.rawQuery("SELECT title FROM calendar_events WHERE date=?", arrayOf(date)).use { c ->
            return if (c.moveToFirst()) c.getString(0) else null
        }
    }

    fun displayHolidayTitle(date: String): String? {
        val titles = listOfNotNull(officialHolidayTitle(date), holidayTitle(date), calendarEventTitle(date))
            .flatMap { value -> value.split("،").map { title -> title.trim() } }
            .filter { it.isNotBlank() }.distinct()
        return titles.takeIf { it.isNotEmpty() }?.joinToString("، ")
    }

    /** One-time verified offline seed for 1405. User workdays and manual holidays stay untouched. */
    fun ensureBundled1405Calendar() {
        if (getSettingText("calendar_1405_seed", "") == "1405.1") return
        val storedHolidays = officialHolidays(1405)
        val storedEvents = calendarEvents(1405)
        // A complete remotely synchronized calendar already has more observances than the seed.
        if (storedHolidays.size < 20 || storedEvents.size < 100) {
            val verified = Calendar1405.holidays
            val titles = (storedEvents + Calendar1405.events + verified).groupBy({ it.first }, { it.second })
                .map { (date, list) -> date to list.distinct().joinToString("، ") }
            replaceCalendarData(1405, verified, titles)
        }
        setSettingText("calendar_1405_seed", "1405.1")
    }

    fun shouldSyncOfficialHolidays(year: Int, now: Long = System.currentTimeMillis()): Boolean {
        // Force a refresh of 1405 data if the previous app version saved a partial calendar
        // without the official Mab'ath holiday. This avoids the old 7-day cache hiding the fix.
        if (year == 1405 && officialHolidayTitle("1405-10-16").isNullOrBlank()) return true
        readableDatabase.rawQuery("SELECT synced_at FROM holiday_sync WHERE year=?", arrayOf(year.toString())).use { c ->
            if (!c.moveToFirst()) return true
            // Refresh at most once per week unless the user explicitly requests an update.
            return now - c.getLong(0) >= 7L * 24L * 60L * 60L * 1000L
        }
    }

    fun replaceOfficialHolidays(year: Int, holidays: List<Pair<String, String>>) {
        require(holidays.isNotEmpty()) { "فهرست تعطیلات خالی است؛ اطلاعات قبلی حفظ شد." }
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("official_holidays", "year=?", arrayOf(year.toString()))
            holidays.forEach { (date, title) ->
                val values = ContentValues().apply {
                    put("date", date); put("title", title); put("year", year)
                }
                db.insertWithOnConflict("official_holidays", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            val meta = ContentValues().apply { put("year", year); put("synced_at", System.currentTimeMillis()) }
            db.insertWithOnConflict("holiday_sync", null, meta, SQLiteDatabase.CONFLICT_REPLACE)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun calendarEvents(year: Int): List<Pair<String, String>> {
        val result = mutableListOf<Pair<String, String>>()
        readableDatabase.rawQuery("SELECT date,title FROM calendar_events WHERE year=? ORDER BY date", arrayOf(year.toString())).use { c ->
            while (c.moveToNext()) result.add(c.getString(0) to c.getString(1))
        }
        return result
    }

    fun replaceCalendarData(year: Int, holidays: List<Pair<String, String>>, events: List<Pair<String, String>>) {
        require(holidays.isNotEmpty()) { "فهرست تعطیلات خالی است؛ اطلاعات قبلی حفظ شد." }
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("official_holidays", "year=?", arrayOf(year.toString()))
            holidays.forEach { (date, title) ->
                val values = ContentValues().apply { put("date", date); put("title", title); put("year", year) }
                db.insertWithOnConflict("official_holidays", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.delete("calendar_events", "year=?", arrayOf(year.toString()))
            events.forEach { (date, title) ->
                val values = ContentValues().apply { put("date", date); put("title", title); put("year", year) }
                db.insertWithOnConflict("calendar_events", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            val meta = ContentValues().apply { put("year", year); put("synced_at", System.currentTimeMillis()) }
            db.insertWithOnConflict("holiday_sync", null, meta, SQLiteDatabase.CONFLICT_REPLACE)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun saveHoliday(date: String, title: String) {
        val v = ContentValues().apply { put("date", date); put("title", title) }
        writableDatabase.insertWithOnConflict("holidays", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun removeHoliday(date: String) { writableDatabase.delete("holidays", "date=?", arrayOf(date)) }
    fun allHolidays(): List<Pair<String,String>> {
        val out = mutableListOf<Pair<String,String>>()
        readableDatabase.rawQuery("SELECT date,title FROM holidays ORDER BY date", null).use { c -> while(c.moveToNext()) out.add(c.getString(0) to c.getString(1)) }
        return out
    }
    fun holidayTitle(date: String): String? {
        readableDatabase.rawQuery("SELECT title FROM holidays WHERE date=?", arrayOf(date)).use { c -> return if(c.moveToFirst()) c.getString(0) else null }
    }
    fun getSetting(key: String): Boolean {
        readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?", arrayOf(key)).use { c ->
            return c.moveToFirst() && c.getString(0) == "true"
        }
    }
    fun getSettingText(key: String, fallback: String = ""): String {
        readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?", arrayOf(key)).use { c ->
            return if (c.moveToFirst()) c.getString(0) else fallback
        }
    }
    fun setSettingText(key: String, value: String) {
        val v = ContentValues().apply { put("key",key); put("value",value) }
        writableDatabase.insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun setSetting(key: String, value: Boolean) {
        val v = ContentValues().apply { put("key",key); put("value",value.toString()) }
        writableDatabase.insertWithOnConflict("settings",null,v,SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun allDaysForBackup(): List<WorkDay> {
        val result = mutableListOf<WorkDay>()
        readableDatabase.rawQuery("SELECT * FROM workdays ORDER BY date", null).use { c ->
            while(c.moveToNext()) result.add(WorkDay(
                c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "",
                c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "",
                c.getString(6) ?: "", c.getString(7) ?: "", c.getString(8) ?: "کاری",
                c.getString(9) ?: "", c.getInt(10) == 1, c.getString(11) ?: "", c.getString(12) ?: "", c.getString(13) ?: "", c.getString(14) ?: "",
                if (c.columnCount > 15) c.getString(15) ?: "" else "", if (c.columnCount > 16) c.getString(16) ?: "" else "",
                if (c.columnCount > 17) c.getString(17) ?: "" else "", if (c.columnCount > 18) c.getString(18) ?: "" else "",
                if (c.columnCount > 19) c.getString(19) ?: "" else "", if (c.columnCount > 20) c.getString(20) ?: "" else "",
                if (c.columnCount > 21) c.getInt(21) == 1 else listOf(17,18,19,20).any { i -> i < c.columnCount && !c.getString(i).isNullOrBlank() }
            ))
        }
        return result
    }
    fun allSettings(): List<Pair<String,String>> {
        val result = mutableListOf<Pair<String,String>>()
        readableDatabase.rawQuery("SELECT key,value FROM settings ORDER BY key", null).use { c ->
            while(c.moveToNext()) result.add(c.getString(0) to c.getString(1))
        }
        allHolidays().forEach { (date,title) -> result.add("holiday:$date" to title) }
        return result
    }
    fun restoreBackup(days: List<WorkDay>, settings: List<Pair<String,String>>) {
        writableDatabase.beginTransaction()
        try {
            writableDatabase.delete("workdays", null, null)
            writableDatabase.delete("holidays", null, null)
            days.forEach { d ->
                val v = ContentValues().apply {
                    put("date",d.date); put("in1",d.in1); put("out1",d.out1)
                    put("in2",d.in2); put("out2",d.out2); put("in3",d.in3); put("out3",d.out3)
                    put("note",d.note); put("day_type",d.dayType); put("overtime_override",d.overtimeOverride); put("shift_enabled", if(d.shiftEnabled) 1 else 0); put("shift_start",d.shiftStart); put("shift_end",d.shiftEnd); put("shift_start_date",d.shiftStartDate); put("shift_end_date",d.shiftEndDate)
                    put("holiday_in", d.holidayIn); put("holiday_out", d.holidayOut); put("leave1_start", d.leave1Start); put("leave1_end", d.leave1End); put("leave2_start", d.leave2Start); put("leave2_end", d.leave2End); put("leave_enabled", if (d.hourlyLeaveEnabled) 1 else 0)
                }
                writableDatabase.insertWithOnConflict("workdays",null,v,SQLiteDatabase.CONFLICT_REPLACE)
            }
            settings.forEach { (k,v) ->
                if (k.startsWith("holiday:")) {
                    val cv = ContentValues().apply { put("date",k.removePrefix("holiday:")); put("title",v) }
                    writableDatabase.insertWithOnConflict("holidays",null,cv,SQLiteDatabase.CONFLICT_REPLACE)
                } else {
                    val cv = ContentValues().apply { put("key",k); put("value",v) }
                    writableDatabase.insertWithOnConflict("settings",null,cv,SQLiteDatabase.CONFLICT_REPLACE)
                }
            }
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }
}

private data class DownloadedCalendarData(
    val holidays: List<Pair<String, String>>,
    val events: List<Pair<String, String>>
)

private fun fetchJson(url: String): org.json.JSONObject {
    val connection = java.net.URL(url).openConnection() as java.net.HttpURLConnection
    connection.requestMethod = "GET"
    connection.connectTimeout = 12_000
    connection.readTimeout = 18_000
    connection.setRequestProperty("Accept", "application/json")
    connection.setRequestProperty("User-Agent", "VaghtNegar-Android/0.7.0")
    try {
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        if (code !in 200..299) throw IllegalStateException("پاسخ سرویس تقویم: HTTP $code")
        return org.json.JSONObject(body)
    } finally { connection.disconnect() }
}

private fun fetchFarsiUiCalendarData(year: Int): DownloadedCalendarData? {
    // This source has an explicit, stable schema: items[].date, items[].title.fa,
    // and items[].isHoliday. It is the primary source to avoid schema drift in the
    // older Persian-Calendar API response.
    val base = "https://raw.githubusercontent.com/MiladJoodi/FarsiUI/main/calendar/years/$year"
    val holidayRoot = fetchJson("$base/holidays.json")
    if (holidayRoot.has("year") && holidayRoot.optInt("year", -1) != year) return null
    val holidayItems = holidayRoot.optJSONArray("items") ?: return null
    if (holidayItems.length() == 0) return null

    val holidays = linkedMapOf<String, MutableList<String>>()
    val allEvents = linkedMapOf<String, MutableList<String>>()
    fun add(target: MutableMap<String, MutableList<String>>, date: String, title: String) {
        val clean = title.trim()
        if (clean.isNotBlank()) {
            val list = target.getOrPut(date) { mutableListOf() }
            if (clean !in list) list.add(clean)
        }
    }
    fun parseItems(items: org.json.JSONArray, holidayOnly: Boolean) {
        for (i in 0 until items.length()) {
            val item = items.optJSONObject(i) ?: continue
            val date = item.optString("date")
            val parts = date.split("-").mapNotNull { it.toIntOrNull() }
            if (parts.size != 3 || parts[0] != year || parts[1] !in 1..12 || parts[2] !in 1..jalaliMonthLength(year, parts[1])) continue
            val titleObject = item.optJSONObject("title")
            val title = titleObject?.optString("fa").orEmpty().ifBlank { item.optString("title_fa") }
            if (title.isBlank()) continue
            if (!holidayOnly || item.optBoolean("isHoliday", item.optBoolean("is_holiday", false))) {
                if (item.optBoolean("isHoliday", item.optBoolean("is_holiday", false))) add(holidays, date, title)
            }
            add(allEvents, date, title)
        }
    }
    parseItems(holidayItems, holidayOnly = true)
    // Events file contains non-holiday observances, including non-holiday religious dates.
    val eventRoot = fetchJson("$base/events.json")
    if (eventRoot.has("year") && eventRoot.optInt("year", -1) != year) return null
    val eventItems = eventRoot.optJSONArray("items") ?: return null
    if (eventItems.length() == 0) return null
    parseItems(eventItems, holidayOnly = false)

    val holidayList = holidays.map { it.key to it.value.joinToString("، ") }
    val eventList = allEvents.map { it.key to it.value.joinToString("، ") }
    if (holidayList.isEmpty() || eventList.isEmpty()) return null
    return DownloadedCalendarData(holidayList, eventList)
}

private fun fetchCalendarData(year: Int): DownloadedCalendarData {
    require(year in 1347..1500) { "سال باید بین ۱۳۴۷ و ۱۵۰۰ باشد." }
    try {
        fetchFarsiUiCalendarData(year)?.let { return it }
    } catch (_: Exception) {
        // Use the documented Persian-Calendar API below as a fallback if this year
        // has not been published by FarsiUI or the static source is temporarily down.
    }
    val holidayRoot = try {
        fetchJson("https://www.persian-calendar.com/api/holidays?year=$year")
    } catch (e: Exception) {
        // No guessed lunar public holidays: preserve the previously saved calendar.
        throw e
    }
    if (holidayRoot.has("year") && holidayRoot.optInt("year", -1) != year) throw IllegalStateException("سال دریافت‌شده با سال درخواستی یکسان نیست.")
    val holidayDays = holidayRoot.optJSONArray("data") ?: throw IllegalStateException("فهرست تعطیلات معتبر نیست.")
    val holidays = linkedMapOf<String, MutableList<String>>()
    val allEvents = linkedMapOf<String, MutableList<String>>()

    fun addTitle(target: MutableMap<String, MutableList<String>>, date: String, title: String) {
        val cleaned = title.trim()
        if (cleaned.isNotBlank()) {
            val list = target.getOrPut(date) { mutableListOf() }
            if (cleaned !in list) list.add(cleaned)
        }
    }

    // The holidays endpoint is authoritative for days off and also supplies each holiday's title.
    for (i in 0 until holidayDays.length()) {
        val item = holidayDays.optJSONObject(i) ?: continue
        val month = item.optInt("month_sh", 0)
        val day = item.optInt("day_sh", 0)
        if (item.optInt("year_sh", year) != year || month !in 1..12 || day !in 1..jalaliMonthLength(year, month)) continue
        val date = "%04d-%02d-%02d".format(Locale.ROOT, year, month, day)
        val events = item.optJSONArray("events") ?: continue
        for (j in 0 until events.length()) {
            val event = events.optJSONObject(j) ?: continue
            val title = event.optString("title_fa").trim()
            if (event.optBoolean("is_holiday", false)) addTitle(holidays, date, title)
            // Put official holidays in the event list too, so their title is visible in every calendar view.
            addTitle(allEvents, date, title)
        }
    }

    // Fetch all other occasions month by month. A failed month must not discard the verified holiday list.
    for (month in 1..12) {
        try {
            val root = fetchJson("https://www.persian-calendar.com/api/events?year=$year&month_sh=$month")
            if (root.optInt("year", year) != year) continue
            val days = root.optJSONArray("data") ?: continue
            for (i in 0 until days.length()) {
                val item = days.optJSONObject(i) ?: continue
                val m = item.optInt("month_sh", month)
                val d = item.optInt("day_sh", 0)
                if (item.optInt("year_sh", year) != year || m !in 1..12 || d !in 1..jalaliMonthLength(year, m)) continue
                val date = "%04d-%02d-%02d".format(Locale.ROOT, year, m, d)
                // Current API returns one event per item; also accept nested event arrays for compatibility.
                val title = item.optString("title_fa").trim()
                if (title.isNotBlank()) addTitle(allEvents, date, title)
                val nested = item.optJSONArray("events")
                if (nested != null) for (j in 0 until nested.length()) {
                    val event = nested.optJSONObject(j) ?: continue
                    addTitle(allEvents, date, event.optString("title_fa"))
                    if (event.optBoolean("is_holiday", false)) addTitle(holidays, date, event.optString("title_fa"))
                }
            }
        } catch (_: Exception) {
            // Continue; official holiday data is still usable offline even if this month's occasions endpoint fails.
        }
    }

    // Do not mix calculated Hijri dates into an official holiday list. Iran's
    // announced lunar holiday dates can differ by a day from civil calculations.
    val holidayList = holidays.map { it.key to it.value.distinct().joinToString("، ") }
    val eventList = allEvents.map { it.key to it.value.distinct().joinToString("، ") }
    if (holidayList.isEmpty()) throw IllegalStateException("سرویس تعطیلات معتبری برنگرداند؛ اطلاعات قبلی حفظ شد.")
    if (eventList.isEmpty()) throw IllegalStateException("فهرست مناسبت‌ها خالی است؛ اطلاعات قبلی حفظ شد.")
    return DownloadedCalendarData(holidayList, eventList)
}

class MainActivity : ComponentActivity() {
    private lateinit var appDb: WorkDb
    private var systemDate by mutableStateOf(LocalDate.now())
    private var pendingBackup = false
    private var reportYear = 1405
    private var reportMonth = 1
    private var reportAnnual = false
    private var reportPdf = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        // Keep Android system status icons (time, signal, battery) visible.
        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN)
        // Match the system bars and the splash letterboxing to the warm ivory background
        // of the splash artwork, instead of showing dark teal strips.
        val splashIvory = android.graphics.Color.rgb(241, 246, 253)
        window.statusBarColor = splashIvory
        window.navigationBarColor = splashIvory
        window.decorView.systemUiVisibility =
            (window.decorView.systemUiVisibility and android.view.View.SYSTEM_UI_FLAG_FULLSCREEN.inv()) or
                android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val db = WorkDb(this)
        db.ensureBundled1405Calendar()
        appDb = db
        // Refresh enabled reminders and the optional date notification on every launch.
        CompanionAlerts.refresh(this)
        systemDate = LocalDate.now()
        setContent {
            var showIntro by remember { mutableStateOf(true) }
            LaunchedEffect(Unit) {
                kotlinx.coroutines.delay(1000)
                showIntro = false
            }
            if (showIntro) {
                androidx.compose.foundation.layout.Box(
                    modifier = Modifier.fillMaxSize().background(Color(0xFFFAFAF4)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.splash_vaghtnegar),
                        contentDescription = "وقت نگار حور",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                }
            } else {
                KarkardApp(db, systemDate)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh the phone's local date whenever the app returns to the foreground.
        systemDate = LocalDate.now()
        CompanionAlerts.refresh(this)
        // Refresh cached Tehran-method prayer times when the app resumes, even
        // if the user opens Home instead of the prayer page. Never block the UI.
        if (CompanionAlerts.enabled(this, "prayer_enabled")) {
            lifecycleScope.launch {
                val city = PrayerRemote.cities(this@MainActivity)[CompanionAlerts.selectedCity(this@MainActivity)]
                val today = LocalDate.now(java.time.ZoneId.of(city.zone))
                try {
                    if (PrayerRemote.cached(this@MainActivity, city, today) == null)
                        PrayerRemote.fetchDay(this@MainActivity, city, today)
                    if (PrayerRemote.cached(this@MainActivity, city, today.plusDays(1)) == null)
                        PrayerRemote.fetchDay(this@MainActivity, city, today.plusDays(1))
                    CompanionAlerts.refresh(this@MainActivity)
                } catch (_: Exception) { /* Keep estimated offline schedule if the network is unavailable. */ }
            }
        }
    }

    fun selectAlertSound(prayer: Boolean, fileAudio: Boolean = false) {
        if (fileAudio) {
            val fileIntent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "audio/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(fileIntent,if(prayer) 5302 else 5301)
            return
        }
        val intent = Intent(android.media.RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TYPE, android.media.RingtoneManager.TYPE_ALL)
            putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
            putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TITLE, if(prayer) "صدای اذان" else "صدای یادآور")
            val selected = CompanionAlerts.ringtone(this@MainActivity,prayer)
            if(selected.isNotBlank()) putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,android.net.Uri.parse(selected))
        }
        startActivityForResult(intent,if(prayer) 5202 else 5201)
    }

    fun createExcelBackup() {
        pendingBackup = true
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            putExtra(Intent.EXTRA_TITLE, "پشتیبان_دفتر_کارکرد.xlsx")
        }
        startActivityForResult(intent, 4101)
    }
    private var reportIncludeNotes: Boolean = true
    fun createReportExcel(year: Int, month: Int, annual: Boolean, includeNotes: Boolean = true) {
        reportIncludeNotes = includeNotes
        reportYear = year; reportMonth = month; reportAnnual = annual; reportPdf = false
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            putExtra(Intent.EXTRA_TITLE, if (annual) "گزارش_سالانه_$year.xlsx" else "گزارش_ماهانه_${year}_$month.xlsx")
        }
        startActivityForResult(intent, 4103)
    }
    fun createReportPdf(year: Int, month: Int, annual: Boolean, includeNotes: Boolean = true) {
        reportIncludeNotes = includeNotes
        reportYear = year; reportMonth = month; reportAnnual = annual; reportPdf = true
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"
            putExtra(Intent.EXTRA_TITLE, if (annual) "گزارش_سالانه_$year.pdf" else "گزارش_ماهانه_${year}_$month.pdf")
        }
        startActivityForResult(intent, 4104)
    }
    fun chooseExcelRestore() {
        pendingBackup = false
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        }
        startActivityForResult(intent, 4102)
    }
    @Deprecated("Deprecated Android callback kept for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        if (requestCode == 5301 || requestCode == 5302) {
            data?.data?.let { audioUri ->
                try { contentResolver.takePersistableUriPermission(audioUri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                if (requestCode == 5302) {
                    AdhanSelection.setPending(this, audioUri.toString())
                    android.widget.Toast.makeText(this,"فایل اذان آمادهٔ پیش‌شنیدن و انتخاب است؛ صفحهٔ اذان را باز کن",android.widget.Toast.LENGTH_LONG).show()
                } else {
                    CompanionAlerts.saveRingtone(this,false,audioUri.toString())
                    android.widget.Toast.makeText(this,"آهنگ یادآور ذخیره شد",android.widget.Toast.LENGTH_SHORT).show()
                }
            }
            return
        }
        if (requestCode == 5201 || requestCode == 5202) {
            val ringtone = if (android.os.Build.VERSION.SDK_INT >= 33)
                data?.getParcelableExtra(android.media.RingtoneManager.EXTRA_RINGTONE_PICKED_URI,android.net.Uri::class.java)
            else data?.getParcelableExtra<android.net.Uri>(android.media.RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            ringtone?.let {
                CompanionAlerts.saveRingtone(this,requestCode == 5202,it.toString())
                android.widget.Toast.makeText(this,"صدای انتخاب‌شده ذخیره شد",android.widget.Toast.LENGTH_SHORT).show()
            }
            return
        }
        if (data?.data == null) return
        val uri = data.data!!
        try {
            if (requestCode == 4101) {
                contentResolver.openOutputStream(uri)?.use { it.write(buildBackupXlsx(appDb)) }
                android.widget.Toast.makeText(this, "فایل Excel پشتیبان ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
            } else if (requestCode == 4103) {
                contentResolver.openOutputStream(uri)?.use { it.write(buildReportXlsx(appDb, reportYear, reportMonth, reportAnnual, reportIncludeNotes)) }
                android.widget.Toast.makeText(this, "گزارش Excel ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
            } else if (requestCode == 4104) {
                contentResolver.openOutputStream(uri)?.use { it.write(buildReportPdf(appDb, reportYear, reportMonth, reportAnnual, reportIncludeNotes)) }
                android.widget.Toast.makeText(this, "گزارش PDF ذخیره شد", android.widget.Toast.LENGTH_LONG).show()
            } else if (requestCode == 4102) {
                val input = contentResolver.openInputStream(uri) ?: error("فایل خوانده نشد")
                val restored = input.use { readBackupXlsx(it.readBytes()) }
                val isReport = restored.second.any { it.first == "export_format" && it.second == "period_report_v1" }
                android.app.AlertDialog.Builder(this)
                    .setTitle(if(isReport) "ورود اطلاعات گزارش" else "بازیابی پشتیبان")
                    .setMessage(if(isReport) "فقط روزهای ثبت‌شدهٔ همین گزارش با داده‌های موجود ادغام می‌شوند؛ سایر ماه‌ها پاک نمی‌شوند. ادامه؟" else "با ادامه، اطلاعات فعلی جایگزین می‌شود. ادامه می‌دهید؟")
                    .setNegativeButton("انصراف", null)
                    .setPositiveButton("بازیابی") { _, _ ->
                        if(isReport) restored.first.forEach { appDb.saveDay(it) }
                        else appDb.restoreBackup(restored.first, restored.second)
                        android.widget.Toast.makeText(this, "بازیابی انجام شد؛ صفحه را دوباره باز کنید", android.widget.Toast.LENGTH_LONG).show()
                    }.show()
            }
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, "خطا در فایل Excel: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
        }
    }
}

private fun formatTimeInput(raw: String): String {
    val digits = raw.toLatinDigits().filter { it.isDigit() }.take(4)
    return when (digits.length) {
        0, 1 -> digits
        2 -> digits
        else -> digits.substring(0, 2) + ":" + digits.substring(2)
    }
}

private fun mins(time: String): Int? {
    val p = time.trim().split(":")
    if (p.size != 2) return null
    val h = p[0].toIntOrNull() ?: return null
    val m = p[1].toIntOrNull() ?: return null
    if (h !in 0..23 || m !in 0..59) return null
    return h*60+m
}
private fun timeRangeMinutes(startText: String, endText: String): Int {
    val start = mins(startText) ?: return 0
    val end = mins(endText) ?: return 0
    return if (end >= start) end - start else end + 24 * 60 - start
}
private fun hourlyLeaveMinutes(day: WorkDay): Int =
    if (!day.hourlyLeaveEnabled) 0 else
        timeRangeMinutes(day.leave1Start, day.leave1End) + timeRangeMinutes(day.leave2Start, day.leave2End)

private fun duration(day: WorkDay): Int {
    // Holiday work is tracked separately and counted as overtime only.
    if (isHolidayWorkDay(day)) return 0
    val gross = listOf(day.in1 to day.out1, day.in2 to day.out2, day.in3 to day.out3).sumOf { (a,b) ->
        val start = mins(a); val end = mins(b)
        if (start != null && end != null) { if (end >= start) end - start else (end + 24 * 60) - start } else 0
    }
    return (gross - hourlyLeaveMinutes(day)).coerceAtLeast(0)
}

private fun normalizeDateInput(raw: String): String {
    val digits = raw.toLatinDigits().filter { it.isDigit() }.take(8)
    return when {
        digits.length <= 4 -> digits
        digits.length <= 6 -> digits.take(4) + "-" + digits.drop(4)
        else -> digits.take(4) + "-" + digits.substring(4, 6) + "-" + digits.drop(6)
    }
}

private fun parsedJalaliDate(value: String): LocalDate? {
    val parts = value.replace('/', '-').split("-").mapNotNull { it.toIntOrNull() }
    if (parts.size != 3 || !isValidJalali(parts[0], parts[1], parts[2])) return null
    return jalaliToGregorian(parts[0], parts[1], parts[2])
}

private fun jalaliDateString(date: LocalDate): String {
    val (y, m, d) = gregorianToJalali(date)
    return "%04d-%02d-%02d".format(Locale.ROOT, y, m, d)
}

private fun defaultShiftEndDate(startDate: String, startTime: String, endTime: String): String {
    val start = parsedJalaliDate(startDate) ?: return startDate
    val startMinutes = mins(startTime)
    val endMinutes = mins(endTime)
    val endDate = if (startMinutes != null && endMinutes != null && endMinutes <= startMinutes) start.plusDays(1) else start
    return jalaliDateString(endDate)
}

private fun shiftDurationMinutes(day: WorkDay, fallbackDate: String = day.date): Int {
    if (!day.shiftEnabled) return 0

    val startDateText = day.shiftStartDate.ifBlank { fallbackDate }
    val endDateText = day.shiftEndDate.ifBlank {
        defaultShiftEndDate(startDateText, day.shiftStart, day.shiftEnd)
    }
    val startDate = parsedJalaliDate(startDateText) ?: return 0
    var endDate = parsedJalaliDate(endDateText) ?: return 0
    val startMinutes = mins(day.shiftStart) ?: return 0
    val endMinutes = mins(day.shiftEnd) ?: return 0

    // If both dates are the same but the entered end time is earlier (or equal),
    // treat the shift as crossing midnight. Explicit end dates on a later day
    // are respected as entered.
    if (endDate == startDate && endMinutes <= startMinutes) {
        endDate = startDate.plusDays(1)
    }
    if (endDate.isBefore(startDate)) return 0

    val total = (endDate.toEpochDay() - startDate.toEpochDay()) * 1440L +
        endMinutes.toLong() - startMinutes.toLong()
    return total.coerceIn(0L, 31L * 1440L).toInt()
}
private fun hm(n: Int) = "%02d:%02d".format(Locale.ROOT, n/60, n%60)

private fun jalaliWeekday(date: String): Int? {
    val p = date.split("-").mapNotNull { it.toIntOrNull() }
    if (p.size != 3 || !isValidJalali(p[0],p[1],p[2])) return null
    return jalaliToGregorian(p[0],p[1],p[2]).dayOfWeek.value % 7
    // Java Sunday=0, Saturday=6
}
private fun officialJalaliHolidays(year: Int): List<Pair<String,String>> {
    val fixed = mutableListOf<Triple<Int,Int,String>>()
    for (d in 1..4) fixed.add(Triple(1, d, "تعطیل رسمی نوروز"))
    fixed.add(Triple(1, 12, "روز جمهوری اسلامی"))
    fixed.add(Triple(1, 13, "روز طبیعت"))
    fixed.add(Triple(3, 14, "رحلت امام خمینی"))
    fixed.add(Triple(3, 15, "قیام ۱۵ خرداد"))
    fixed.add(Triple(11, 22, "پیروزی انقلاب اسلامی"))
    fixed.add(Triple(12, 29, "روز ملی شدن صنعت نفت"))
    return fixed.map { (m,d,title) -> "%04d-%02d-%02d".format(year,m,d) to title }
}

private fun defaultDayType(date: String): String =
    if (jalaliWeekday(date) == 5) "تعطیل رسمی" else "کاری"

private fun applyCalendarHoliday(day: WorkDay, db: WorkDb): WorkDay {
    val fixedHoliday = officialJalaliHolidays(day.date.take(4).toIntOrNull() ?: 0).toMap()[day.date]
    val officialTitle = db.officialHolidayTitle(day.date) ?: fixedHoliday
    return when {
        !officialTitle.isNullOrBlank() && day.dayType in setOf("کاری", "تعطیل") -> day.copy(dayType = "تعطیل رسمی")
        !db.holidayTitle(day.date).isNullOrBlank() && day.dayType == "کاری" -> day.copy(dayType = "تعطیل مناسبتی")
        else -> day
    }
}

private fun reportPeriodDays(db: WorkDb, year: Int, month: Int, annual: Boolean): List<WorkDay> {
    val stored = db.allDaysYear(year).associateBy { it.date }
    val months = if (annual) (1..12).toList() else listOf(month)
    return months.flatMap { m ->
        (1..jalaliMonthLength(year, m)).map { d ->
            val key = "%04d-%02d-%02d".format(year, m, d)
            val base = stored[key] ?: db.getDay(key).copy(dayType = defaultDayType(key))
            applyCalendarHoliday(base, db)
        }
    }
}

private fun isHolidayWorkDay(day: WorkDay): Boolean =
    day.dayType in setOf("تعطیل", "تعطیل رسمی", "تعطیل مناسبتی", "مرخصی", "استعلاجی")

private fun holidayWorkDurationMinutes(day: WorkDay): Int {
    val start = mins(day.holidayIn)
    val end = mins(day.holidayOut)
    if (start == null || end == null) return 0
    return if (end >= start) end - start else (end + 24 * 60) - start
}

private fun overtimeMinutes(day: WorkDay, db: WorkDb): Int {
    val override = mins(day.overtimeOverride)
    if (override != null) return override
    if (isHolidayWorkDay(day)) return holidayWorkDurationMinutes(day)
    if (day.dayType != "کاری") return 0
    val weekday = jalaliWeekday(day.date)
    val targetText = if (weekday == 4 && db.getSetting("thursday_hours"))
        db.getSettingText("thursday_hours_value") else db.getSettingText("workday_hours")
    val target = mins(targetText) ?: (if (weekday == 4) 300 else 420)
    return (duration(day) - target).coerceAtLeast(0)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KarkardApp(db: WorkDb, systemDate: LocalDate) {
    val context = LocalContext.current
    var screen by remember { mutableStateOf("home") }
    val nowJalali = remember(systemDate) { gregorianToJalali(systemDate) }
    var jalaliYear by remember { mutableIntStateOf(nowJalali.first) }
    var jalaliMonth by remember { mutableIntStateOf(nowJalali.second) }
    var date by remember { mutableStateOf("%04d-%02d-%02d".format(nowJalali.first, nowJalali.second, nowJalali.third)) }
    var lastObservedSystemDate by remember { mutableStateOf(systemDate) }
    LaunchedEffect(systemDate) {
        val previousDeviceDate = jalaliDateString(lastObservedSystemDate)
        val currentDeviceDate = jalaliDateString(systemDate)
        // Update automatically if the user is still on the previous phone-today date.
        // A deliberately selected earlier/later day is left alone.
        if (date == previousDeviceDate) {
            date = currentDeviceDate
            val parts = currentDeviceDate.split("-")
            if (parts.size == 3) {
                jalaliYear = parts[0].toIntOrNull() ?: jalaliYear
                jalaliMonth = parts[1].toIntOrNull() ?: jalaliMonth
            }
        }
        lastObservedSystemDate = systemDate
    }
    var refresh by remember { mutableIntStateOf(0) }
    var workRevision by remember { mutableIntStateOf(0) }
    // One editor state for the lifetime of the screen. A keyed remember(date)
    // would recreate the mutable state during date navigation and could replace
    // the just-reloaded record with a stale frame's values.
    var day by remember {
        mutableStateOf(db.getDay(date).let { if (db.hasWorkDay(date)) it else it.copy(dayType=defaultDayType(date)) })
    }
    // Every persisted edit increments workRevision; this read is the display's
    // source of truth when returning to any date, without restarting the app.
    val persistedDay = remember(date, refresh, workRevision) {
        db.getDay(date).let { if (db.hasWorkDay(date)) it else it.copy(dayType=defaultDayType(date)) }
    }
    var menuExpanded by remember { mutableStateOf(false) }
    var holidaySyncing by remember { mutableStateOf(false) }
    var holidaySyncMessage by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()
    val syncOfficialHolidays: (Int, Boolean) -> Unit = { yearToSync, force ->
        if (!holidaySyncing && (force || db.shouldSyncOfficialHolidays(yearToSync))) {
            holidaySyncing = true
            holidaySyncMessage = "در حال دریافت تعطیلات سال $yearToSync…"
            coroutineScope.launch {
                try {
                    val synced = withContext(Dispatchers.IO) {
                        val calendarData = fetchCalendarData(yearToSync)
                        db.replaceCalendarData(yearToSync, calendarData.holidays, calendarData.events)
                        db.setSettingText("calendar_last_online_$yearToSync", System.currentTimeMillis().toString())
                        calendarData.events.size
                    }
                    holidaySyncMessage = "تقویم سال $yearToSync به‌روزرسانی شد؛ $synced روز دارای مناسبت و ${db.officialHolidays(yearToSync).size} روز تعطیل رسمی ذخیره شد. پس از ذخیره، آفلاین هم در دسترس است."
                    refresh++
                } catch (e: Exception) {
                    val reason = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName
                    holidaySyncMessage = "به‌روزرسانی انجام نشد ($reason)؛ اطلاعات ذخیره‌شده حفظ شد. اینترنت را بررسی و دوباره تلاش کن."
                } finally {
                    holidaySyncing = false
                }
            }
        }
    }
    LaunchedEffect(jalaliYear) {
        syncOfficialHolidays(jalaliYear, false)
    }

    var lastBackPressed by remember { mutableLongStateOf(0L) }
    BackHandler {
        if (menuExpanded) menuExpanded = false
        else if (screen != "home") screen = "home"
        else {
            val now = android.os.SystemClock.elapsedRealtime()
            if (now - lastBackPressed < 2200L) (context as? MainActivity)?.finish()
            else {
                lastBackPressed = now
                android.widget.Toast.makeText(context, "برای خروج دوباره بازگشت را بزنید", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF173F71),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFDCEAFB),
            onPrimaryContainer = Color(0xFF173F71),
            secondary = Color(0xFF008F91),
            tertiary = Color(0xFFB48C42),
            background = Color(0xFFF1F6FD),
            surface = Color.White
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = MaterialTheme.colorScheme.background,
                topBar = {
                    // The title is centered against the entire screen, not the area left beside an action button.
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFF1F6FD))
                            // Respect Android status-bar and camera-cutout safe areas.
                            // Insets adapt automatically to each phone instead of using a fixed offset.
                            .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Top))
                            .height(60.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        PersianText(
                            when (screen) {
                                "home" -> "خانه"
                                "calendar" -> "تقویم"
                                "report-monthly" -> "گزارش‌گیری ماهانه"
                                "report-annual" -> "گزارش‌گیری سالانه"
                                "settings" -> "تنظیمات"
                                "help" -> "راهنما"
                                "reminders" -> "یادآور اقساط و جلسات"
                                "prayer" -> "اوقات شرعی و اذان‌گو"
                                else -> "وقت‌نگار حور"
                            },
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 60.dp),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF123C70),
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        // In RTL, CenterEnd is physically on the left edge.
                        Box(Modifier.align(Alignment.CenterEnd)) {
                            IconButton(onClick = { menuExpanded = true }) {
                                PersianText("⋮", fontSize = 29.sp, color = Color(0xFF123C70))
                            }
                            DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                                DropdownMenuItem(text = { PersianText("گزارش‌گیری ماهانه") }, onClick = { menuExpanded = false; screen = "report-monthly" })
                                DropdownMenuItem(text = { PersianText("گزارش‌گیری سالانه") }, onClick = { menuExpanded = false; screen = "report-annual" })
                                DropdownMenuItem(text = { PersianText("راهنما") }, onClick = { menuExpanded = false; screen = "help" })
                            }
                        }
                    }
                },
                bottomBar = {
                    NavigationBar(containerColor = Color.White, tonalElevation = 8.dp, modifier = Modifier.heightIn(min = 67.dp)) {
                        listOf(
                            Triple("home", "خانه", R.drawable.nav_home),
                            Triple("calendar", "تقویم", R.drawable.nav_calendar),
                            Triple("reminders", "یادآورها", R.drawable.nav_reminder),
                            Triple("prayer", "اذان", R.drawable.nav_prayer),
                            Triple("settings", "تنظیمات", R.drawable.nav_settings)
                        ).forEach { (target,label,iconRes) ->
                            NavigationBarItem(
                                selected = screen == target,
                                onClick = {
                                    if (target == "calendar") {
                                        val now = gregorianToJalali(LocalDate.now())
                                        jalaliYear = now.first; jalaliMonth = now.second
                                    }
                                    screen = target
                                },
                                icon = {
                                    Icon(
                                        painter = painterResource(iconRes),
                                        contentDescription = label,
                                        modifier = Modifier.size(if (target == "calendar") 22.dp else 26.dp),
                                        tint = if (screen == target) Color(0xFF173F71) else Color(0xFF62809F)
                                    )
                                },
                                label = { PersianText(label, fontSize = 10.sp, maxLines = 1) },
                                alwaysShowLabel = true
                            )
                        }
                    }
                }
            ) { padding ->
                when (screen) {
                    "settings" -> SettingsScreen(
                        db = db, modifier = Modifier.padding(padding),
                        onBackup = { (context as? MainActivity)?.createExcelBackup() },
                        onRestore = { (context as? MainActivity)?.chooseExcelRestore() },
                        onSyncHolidays = { selectedYear -> syncOfficialHolidays(selectedYear, true) },
                        syncYear = jalaliYear,
                        holidaySyncing = holidaySyncing,
                        holidaySyncMessage = holidaySyncMessage,
                        onRecordsDeleted = {
                            refresh++
                            workRevision++
                            day = db.getDay(date).let { if (db.hasWorkDay(date)) it else it.copy(dayType = defaultDayType(date)) }
                        }
                    ) { screen = "home" }
                    "help" -> HelpScreen(Modifier.padding(padding))
                    "reminders" -> RemindersScreen(
                        modifier = Modifier.padding(padding),
                        onPickRingtone = { fromFile -> (context as? MainActivity)?.selectAlertSound(false,fromFile) }
                    )
                    "prayer" -> PrayerTimesScreen(
                        modifier = Modifier.padding(padding),
                        onPickRingtone = { fromFile -> (context as? MainActivity)?.selectAlertSound(true,fromFile) }
                    )
                    "calendar" -> JalaliCalendarScreen(
                        year = jalaliYear, month = jalaliMonth, selectedDate = jalaliDateString(LocalDate.now()),
                        onMonthChange = { y,m -> jalaliYear = y; jalaliMonth = m },
                        onSelectDate = { selected ->
                            date = selected
                            day = db.getDay(selected).let { if (db.hasWorkDay(selected)) it else it.copy(dayType=defaultDayType(selected)) }
                            val parts = selected.split("-")
                            if (parts.size == 3) { jalaliYear = parts[0].toInt(); jalaliMonth = parts[1].toInt() }
                            screen = "home"
                        },
                        modifier = Modifier.padding(padding),
                        holidays = remember(refresh, jalaliYear, jalaliMonth) {
                            (officialJalaliHolidays(jalaliYear) + db.officialHolidays(jalaliYear) + db.allHolidays()).toMap()
                        },
                        events = remember(refresh, jalaliYear, jalaliMonth) { db.calendarEvents(jalaliYear).toMap() },
                        hijriDayOffset = 0
                    )
                    "report-monthly" -> ReportScreen(
                        db = db, year = jalaliYear, monthNumber = jalaliMonth, refresh = refresh,
                        modifier = Modifier.padding(padding), annual = false,
                        onPeriodChange = { y, m -> jalaliYear = y; jalaliMonth = m },
                        export = { a, notes -> (context as? MainActivity)?.createReportExcel(jalaliYear, jalaliMonth, a, notes) },
                        exportPdf = { a, notes -> (context as? MainActivity)?.createReportPdf(jalaliYear, jalaliMonth, a, notes) }
                    )
                    "report-annual" -> ReportScreen(
                        db = db, year = jalaliYear, monthNumber = jalaliMonth, refresh = refresh,
                        modifier = Modifier.padding(padding), annual = true,
                        onPeriodChange = { y, m -> jalaliYear = y; jalaliMonth = m },
                        export = { a, notes -> (context as? MainActivity)?.createReportExcel(jalaliYear, jalaliMonth, a, notes) },
                        exportPdf = { a, notes -> (context as? MainActivity)?.createReportPdf(jalaliYear, jalaliMonth, a, notes) }
                    )
                    else -> key(date) { HomeDashboard(
                        modifier = Modifier.padding(padding), date = date, rawDay = persistedDay,
                        jalaliYear = jalaliYear, jalaliMonth = jalaliMonth, db = db, refresh = refresh,
                        workRevision = workRevision,
                        onLongLeaveSaved = { savedCount ->
                            refresh++
                            workRevision++
                            day = db.getDay(date)
                            android.widget.Toast.makeText(context, "مرخصی ${savedCount} روز ثبت شد", android.widget.Toast.LENGTH_LONG).show()
                        },
                        onDateChange = { newDate ->
                            if (newDate != date && parsedJalaliDate(newDate) != null) {
                                // Writes are performed on each edit. Reload the destination explicitly,
                                // so returning to a visited date never shows a stale editor snapshot.
                                val destination = db.getDay(newDate).let {
                                    if (db.hasWorkDay(newDate)) it else it.copy(dayType = defaultDayType(newDate))
                                }
                                day = destination
                                date = newDate
                                workRevision++
                                val p = newDate.split("-")
                                if (p.size == 3) {
                                    jalaliYear = p[0].toIntOrNull() ?: jalaliYear
                                    jalaliMonth = p[1].toIntOrNull() ?: jalaliMonth
                                }
                            }
                        },
                        onDayChange = { updated ->
                            // Save every edit immediately, so navigating to another date does not discard it.
                            val saved = updated.copy(date = date)
                            val previousType = day.dayType
                            day = saved
                            db.saveDay(saved)
                            // A note/time edit must not silently switch off an already
                            // recorded long leave. Only changing to a non-leave type
                            // detaches this *one* day from its original leave range.
                            if (saved.dayType !in setOf("مرخصی", "استعلاجی")) db.unlinkLongLeaveDay(date)
                            workRevision++
                            if (previousType == "تعطیل مناسبتی" && saved.dayType != "تعطیل مناسبتی") {
                                db.removeHoliday(date)
                            }
                        },
                        onSaved = { saved -> day = saved; date = saved.date; refresh++; workRevision++ },
                        onOpenCalendar = {
                            val now = gregorianToJalali(LocalDate.now())
                            jalaliYear = now.first; jalaliMonth = now.second
                            screen = "calendar"
                        }
                    ) }
                }
            }
        }
    }
}

@Composable
private fun HomeDashboard(
    modifier: Modifier,
    date: String,
    rawDay: WorkDay,
    jalaliYear: Int,
    jalaliMonth: Int,
    db: WorkDb,
    refresh: Int,
    workRevision: Int,
    onLongLeaveSaved: (Int) -> Unit,
    onDateChange: (String) -> Unit,
    onDayChange: (WorkDay) -> Unit,
    onSaved: (WorkDay) -> Unit,
    onOpenCalendar: () -> Unit
) {
    val context = LocalContext.current
    val day = applyCalendarHoliday(rawDay, db)
    val calendarTitle = remember(date, refresh) { db.displayHolidayTitle(date) ?: officialJalaliHolidays(date.take(4).toIntOrNull() ?: jalaliYear).toMap()[date] }
    val monthPrefix = "%04d-%02d".format(jalaliYear, jalaliMonth)
    val monthDays = remember(jalaliYear, jalaliMonth) { (1..31).filter { isValidJalali(jalaliYear, jalaliMonth, it) } }
    val recordedDays = remember(refresh, workRevision, monthPrefix) { db.allDays(monthPrefix) }
    val monthWork = recordedDays.sumOf { duration(it) }
    val monthOvertime = recordedDays.sumOf { overtimeMinutes(it, db) }
    val monthShiftDays = remember(refresh, workRevision, monthPrefix) { db.allDaysForBackup().filter { it.shiftEnabled && (it.shiftStartDate.ifBlank { it.date }).startsWith(monthPrefix) } }
    val monthShift = monthShiftDays.sumOf { shiftDurationMinutes(it, it.date) }
    val missionCount = recordedDays.count { it.dayType == "مأموریت" }
    val monthlyHourlyLeave = recordedDays.sumOf { hourlyLeaveMinutes(it) }
    val entitledLeaveCount = recordedDays.count { it.dayType == "مرخصی" }
    val sickLeaveCount = recordedDays.count { it.dayType == "استعلاجی" }
    val dateParts = date.split("-").mapNotNull { it.toIntOrNull() }
    val dateDay = dateParts.getOrElse(2) { 1 }
    val weekday = jalaliWeekday(date)?.let { JalaliWeekdayNames.getOrNull(it) }.orEmpty()
    var holidayReason by remember(date, refresh) { mutableStateOf(db.holidayTitle(date).orEmpty()) }
    // Visibility belongs to the UI, not the saved work record. Existing entries are
    // expanded automatically when the user opens a day that already has those times.
    var showSecondWorkPair by remember(date) {
        mutableStateOf(day.in2.isNotBlank() || day.out2.isNotBlank() || day.in3.isNotBlank() || day.out3.isNotBlank())
    }
    var showThirdWorkPair by remember(date) {
        mutableStateOf(day.in3.isNotBlank() || day.out3.isNotBlank())
    }
    var longLeaveEnabled by remember(date, refresh) { mutableStateOf(db.isLongLeaveDay(date)) }
    var longLeaveEnd by remember(date, refresh) { mutableStateOf(db.longLeaveEndForDay(date) ?: date) }
    var longLeaveError by remember(date) { mutableStateOf("") }

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 5.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        contentPadding = PaddingValues(bottom = 8.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFCFDFF)), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFD9E6F5), RoundedCornerShape(20.dp))) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                        PersianText("▦", fontSize = 21.sp, color = Color(0xFF426A6D))
                        Spacer(Modifier.width(7.dp))
                        PersianText("${JalaliMonthNames.getOrElse(jalaliMonth - 1) { "ماه" }} $jalaliYear", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF073B45))
                    }
                    Divider(color = Color(0xFFC8DCD9))
                    // Logical RTL order: work, overtime, hourly leave, entitled leave,
                    // sick leave, shift count, mission count. Split into rows to keep text readable.
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        MonthMetric("مجموع کارکرد", hm(monthWork), "◷", Color(0xFF426A6D), Modifier.weight(1f))
                        MetricDivider()
                        MonthMetric("اضافه‌کار", hm(monthOvertime), "◴", OvertimeGreenText, Modifier.weight(1f))
                        MetricDivider()
                        MonthMetric("مرخصی ساعتی", hm(monthlyHourlyLeave), "◷", Color(0xFF28588A), Modifier.weight(1f))
                        MetricDivider()
                        MonthMetric("استحقاقی", entitledLeaveCount.toString(), "☼", Color(0xFF28588A), Modifier.weight(1f), "روز")
                    }
                    Divider(color = Color(0xFFC8DCD9))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        MonthMetric("استعلاجی", sickLeaveCount.toString(), "✚", Color(0xFF28588A), Modifier.weight(1f), "روز")
                        MetricDivider()
                        MonthMetric("تعداد شیفت", monthShiftDays.size.toString(), "▤", ShiftYellowText, Modifier.weight(1f), "شیفت")
                        MetricDivider()
                        MonthMetric("مأموریت", missionCount.toString(), "✈", Color(0xFF426A6D), Modifier.weight(1f), "روز")
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        IconButton(onClick = {
                            val prev = parsedJalaliDate(date)?.minusDays(1)?.let { jalaliDateString(it) }
                            if (prev != null) onDateChange(prev)
                        }, modifier = Modifier.size(48.dp)) {
                            PersianText("‹", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color(0xFF075565))
                        }
                        PersianText("روز $dateDay از ${monthDays.size}", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF173F71))
                        IconButton(onClick = {
                            val next = parsedJalaliDate(date)?.plusDays(1)?.let { jalaliDateString(it) }
                            if (next != null) onDateChange(next)
                        }, modifier = Modifier.size(48.dp)) {
                            PersianText("›", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color(0xFF075565))
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Column(horizontalAlignment = Alignment.End) {
                            PersianText(weekday, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF073B45))
                            PersianText(jalaliDisplayDate(date), style = MaterialTheme.typography.bodyMedium, color = Color(0xFF426A6D))
                        }
                        TextButton(onClick = onOpenCalendar, contentPadding = PaddingValues(2.dp)) { PersianText("▦", fontSize = 23.sp, color = Color(0xFF426A6D)) }
                    }
                }
            }
        }
        if (!calendarTitle.isNullOrBlank()) {
            item {
                val isOfficialCalendarHoliday = db.officialHolidayTitle(date) != null || officialJalaliHolidays(jalaliYear).toMap().containsKey(date)
                Card(
                    colors = CardDefaults.cardColors(containerColor = if (isOfficialCalendarHoliday) Color(0xFFFFF0F0) else Color(0xFFFFF8E5)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, if (isOfficialCalendarHoliday) Color(0xFFE57373) else Color(0xFFE5C34A), RoundedCornerShape(10.dp))
                ) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        PersianText(if (isOfficialCalendarHoliday) "تعطیل رسمی" else "مناسبت تقویم", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (isOfficialCalendarHoliday) Color(0xFFB3261E) else Color(0xFF795500))
                        PersianText(calendarTitle, fontSize = 12.sp, color = if (isOfficialCalendarHoliday) Color(0xFF7F1D1D) else Color(0xFF5F4500))
                    }
                }
            }
        }
        item {
            val dayTypes = listOf(
                "کاری" to "◷", "تعطیل رسمی" to "♜", "مرخصی" to "☼",
                "مأموریت" to "✈", "استعلاجی" to "✚", "تعطیل مناسبتی" to "▦"
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                dayTypes.forEach { (type, symbol) ->
                    val selected = day.dayType == type
                    Card(
                        modifier = Modifier.weight(1f).height(59.dp).border(1.dp, if (selected) Color(0xFF6BA1F9) else Color(0xFFB6D0CE), RoundedCornerShape(10.dp)),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFFE3EEFF) else Color.White),
                        onClick = { onDayChange(day.copy(dayType = type)) }
                    ) {
                        Column(Modifier.fillMaxSize().padding(horizontal = 2.dp, vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            PersianText(symbol, fontSize = 18.sp, color = if (selected) Color(0xFF1556A6) else Color(0xFF426A6D), maxLines = 1)
                            PersianText(type, fontSize = 9.sp, color = if (selected) Color(0xFF1556A6) else Color(0xFF426A6D), textAlign = TextAlign.Center, maxLines = 2, lineHeight = 11.sp)
                        }
                    }
                }
            }
        }
        if (day.dayType == "تعطیل مناسبتی") {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFB6D0CE), RoundedCornerShape(10.dp))) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        PersianText("علت تعطیلی (اختیاری)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF073B45))
                        OutlinedTextField(
                            value = holidayReason.toPersianDigits(),
                            onValueChange = {
                                holidayReason = it
                                // Persist the title while typing; changing dates will not lose it.
                                if (day.dayType == "تعطیل مناسبتی") {
                                    if (it.isBlank()) db.removeHoliday(date)
                                    else db.saveHoliday(date, it.trim())
                                }
                            },
                            placeholder = { PersianText("علت تعطیلی را وارد کنید", fontSize = 12.sp, color = Color(0xFF7E9ABD)) },
                            leadingIcon = { PersianText("✎", fontSize = 18.sp) },
                            modifier = Modifier.fillMaxWidth(), singleLine = true,
                            textStyle = TextStyle(fontSize = 12.sp, textAlign = TextAlign.Start),
                        )
                    }
                }
            }
        }
        if (isHolidayWorkDay(day)) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = OvertimeGreen.copy(alpha = 0.55f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF99D5A8), RoundedCornerShape(12.dp))
                ) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 7.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        PersianText(if (day.dayType == "مرخصی" || day.dayType == "استعلاجی") "ثبت اضافه‌کاری در روز مرخصی" else "ساعت کار در روز تعطیل", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = OvertimeGreenText)
                        PersianText("زمان ثبت‌شده در این بخش، تماماً اضافه‌کاری محاسبه می‌شود.", fontSize = 10.sp, color = OvertimeGreenText)
                        CompactTimePairRow("تعطیل", "ورود", day.holidayIn, "خروج", day.holidayOut,
                            { onDayChange(day.copy(holidayIn = it)) },
                            { onDayChange(day.copy(holidayOut = it)) })
                        PersianText("اضافه‌کاری تعطیل: ${hm(holidayWorkDurationMinutes(day))}", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = OvertimeGreenText)
                    }
                }
            }
        } else {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        PersianText("ساعت کار روزانه", modifier = Modifier.fillMaxWidth(), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color(0xFF073B45), textAlign = TextAlign.Start)
                        Divider(color = Color(0xFFC8DCD9))
                        CompactTimePairRow("۱", "ورود", day.in1, "خروج", day.out1, { onDayChange(day.copy(in1=it)) }, { onDayChange(day.copy(out1=it)) }, fieldFontSize = 13)
                        // The next two pairs are optional. Collapsing only hides the
                        // fields; it never clears recorded arrival/departure times.
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            OutlinedButton(
                                onClick = {
                                    showSecondWorkPair = !showSecondWorkPair
                                    if (!showSecondWorkPair) showThirdWorkPair = false
                                },
                                modifier = Modifier.heightIn(min = 32.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                            ) { PersianText(if (showSecondWorkPair) "۲ −" else "۲ +", fontSize = 13.sp) }
                            if (showSecondWorkPair) {
                                OutlinedButton(
                                    onClick = { showThirdWorkPair = !showThirdWorkPair },
                                    modifier = Modifier.heightIn(min = 32.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                                ) { PersianText(if (showThirdWorkPair) "۳ −" else "۳ +", fontSize = 13.sp) }
                            }
                        }
                        if (showSecondWorkPair) {
                            Divider(color = Color(0xFFC8DCD9))
                            CompactTimePairRow("۲", "ورود", day.in2, "خروج", day.out2, { onDayChange(day.copy(in2=it)) }, { onDayChange(day.copy(out2=it)) }, fieldFontSize = 13)
                        }
                        if (showSecondWorkPair && showThirdWorkPair) {
                            Divider(color = Color(0xFFC8DCD9))
                            CompactTimePairRow("۳", "ورود", day.in3, "خروج", day.out3, { onDayChange(day.copy(in3=it)) }, { onDayChange(day.copy(out3=it)) }, fieldFontSize = 13)
                        }
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF2E5D7)), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFD5B99F), RoundedCornerShape(12.dp))) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        PersianText("مرخصی ساعتی", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color(0xFF073B45))
                        Switch(
                            checked = day.hourlyLeaveEnabled,
                            onCheckedChange = { onDayChange(day.copy(hourlyLeaveEnabled = it)) }
                        )
                    }
                    if (day.hourlyLeaveEnabled) {
                        Divider(color = Color(0xFFC8DCD9))
                        CompactTimePairRow("۱", "از ساعت", day.leave1Start, "الی ساعت", day.leave1End, { onDayChange(day.copy(leave1Start=it)) }, { onDayChange(day.copy(leave1End=it)) })
                        Divider(color = Color(0xFFC8DCD9))
                        CompactTimePairRow("۲", "از ساعت", day.leave2Start, "الی ساعت", day.leave2End, { onDayChange(day.copy(leave2Start=it)) }, { onDayChange(day.copy(leave2End=it)) })
                        PersianText("مجموع مرخصی ساعتی: ${hm(hourlyLeaveMinutes(day))}", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF0B6865))
                    }
                }
            }
        }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEE)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFFFD24D), RoundedCornerShape(12.dp))
            ) {
                Column(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().background(Color(0xFFFFF6DD)).padding(horizontal = 9.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
                        PersianText("☼", fontSize = 21.sp, color = Color(0xFFE9A600))
                        Spacer(Modifier.width(6.dp))
                        PersianText("شیفت کاری", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = ShiftYellowText)
                        Spacer(Modifier.weight(1f))
                        Switch(checked = day.shiftEnabled, onCheckedChange = { enabled ->
                            val start = day.shiftStartDate.ifBlank { date }
                            onDayChange(day.copy(
                                shiftEnabled = enabled,
                                shiftStart = if (enabled && day.shiftStart.isBlank()) "17:00" else day.shiftStart,
                                shiftEnd = if (enabled && day.shiftEnd.isBlank()) "07:00" else day.shiftEnd,
                                shiftStartDate = if (enabled && day.shiftStartDate.isBlank()) date else day.shiftStartDate,
                                shiftEndDate = if (enabled && day.shiftEndDate.isBlank()) defaultShiftEndDate(start, "17:00", "07:00") else day.shiftEndDate
                            ))
                        })
                    }
                    if (day.shiftEnabled) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 5.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        // Row 1: shift dates
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Top) {
                            CompactShiftField("تاریخ شروع", jalaliDisplayDate(day.shiftStartDate.ifBlank { date }), Modifier.weight(1f), true) {
                                // SplitDateField already owns year/month/day separators.
                                // Preserve partially edited segments; never merge them back
                                // into a new 8-digit stream while the user is typing.
                                val newStartDate = it
                                val oldStartDate = day.shiftStartDate.ifBlank { date }
                                val oldAutomaticEndDate = defaultShiftEndDate(oldStartDate, day.shiftStart, day.shiftEnd)
                                val endDateWasAutomatic = day.shiftEndDate.isBlank() || day.shiftEndDate == oldStartDate || day.shiftEndDate == oldAutomaticEndDate
                                val computedEnd = if (endDateWasAutomatic && parsedJalaliDate(newStartDate) != null)
                                    defaultShiftEndDate(newStartDate, day.shiftStart, day.shiftEnd) else day.shiftEndDate
                                onDayChange(day.copy(shiftStartDate = newStartDate, shiftEndDate = computedEnd))
                            }
                            CompactShiftField("تاریخ پایان", jalaliDisplayDate(day.shiftEndDate.ifBlank { defaultShiftEndDate(day.shiftStartDate.ifBlank { date }, day.shiftStart.ifBlank { "17:00" }, day.shiftEnd.ifBlank { "07:00" }) }), Modifier.weight(1f), true) { onDayChange(day.copy(shiftEndDate=it)) }
                        }
                        // Row 2: shift times
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Top) {
                            CompactShiftField("ساعت شروع", day.shiftStart.ifBlank { "17:00" }, Modifier.weight(1f), false) {
                                val startDate = day.shiftStartDate.ifBlank { date }
                                val oldAutomaticEndDate = defaultShiftEndDate(startDate, day.shiftStart, day.shiftEnd)
                                val endDateWasAutomatic = day.shiftEndDate.isBlank() || day.shiftEndDate == startDate || day.shiftEndDate == oldAutomaticEndDate
                                onDayChange(day.copy(shiftStart = it, shiftStartDate = startDate, shiftEndDate = if (endDateWasAutomatic) defaultShiftEndDate(startDate, it, day.shiftEnd) else day.shiftEndDate))
                            }
                            CompactShiftField("ساعت پایان", day.shiftEnd.ifBlank { "07:00" }, Modifier.weight(1f), false) {
                                val startDate = day.shiftStartDate.ifBlank { date }
                                val oldAutomaticEndDate = defaultShiftEndDate(startDate, day.shiftStart, day.shiftEnd)
                                val endDateWasAutomatic = day.shiftEndDate.isBlank() || day.shiftEndDate == startDate || day.shiftEndDate == oldAutomaticEndDate
                                onDayChange(day.copy(shiftEnd = it, shiftStartDate = startDate, shiftEndDate = if (endDateWasAutomatic) defaultShiftEndDate(startDate, day.shiftStart, it) else day.shiftEndDate))
                            }
                        }
                        }
                    }
                    PersianText("مدت شیفت: ${hm(shiftDurationMinutes(day, date))}", modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp), fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = ShiftYellowText)
                    Spacer(Modifier.height(5.dp))
                    }
                }
            }
        }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF0FC)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF9DB8DF), RoundedCornerShape(12.dp))
            ) {
                Column(Modifier.fillMaxWidth().padding(9.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PersianText("ثبت مرخصی بلندمدت", modifier = Modifier.weight(1f), fontSize = 14.sp,
                            fontWeight = FontWeight.Bold, color = Color(0xFF173F71))
                        Switch(checked = longLeaveEnabled, onCheckedChange = { longLeaveEnabled = it })
                    }
                    if (longLeaveEnabled) {
                        PersianText("شروع مرخصی: ${jalaliDisplayDate(date)} — وضعیت و یادداشت این روز برای همهٔ روزهای بازه ثبت می‌شود.", fontSize = 11.sp)
                        if (day.dayType !in listOf("مرخصی", "استعلاجی")) {
                            PersianText("ابتدا وضعیت روز را روی «مرخصی استحقاقی» یا «استعلاجی» قرار بده.", color = Color(0xFFB3261E), fontSize = 11.sp)
                        }
                        PersianText("تاریخ پایان مرخصی", fontSize = 11.sp)
                        key(date) { ReminderDateFieldLeftToRight(longLeaveEnd, { longLeaveEnd = it }, Modifier.fillMaxWidth()) }
                        if (longLeaveError.isNotBlank()) PersianText(longLeaveError, color = Color(0xFFB3261E), fontSize = 11.sp)
                        Button(onClick = {
                            try {
                                val normalizedEnd = longLeaveEnd.toLatinDigits().replace('/', '-')
                                val endParts = normalizedEnd.split('-').map { it.toIntOrNull() }
                                require(endParts.size == 3 && endParts.all { it != null } &&
                                    isValidJalali(endParts[0]!!, endParts[1]!!, endParts[2]!!)) { "تاریخ پایان معتبر نیست" }
                                val end = "%04d-%02d-%02d".format(endParts[0]!!, endParts[1]!!, endParts[2]!!)
                                val result = db.saveLongLeave(date, end, day.dayType, day.note)
                                longLeaveEnabled = true
                                longLeaveEnd = end
                                longLeaveError = ""
                                onLongLeaveSaved(result)
                            } catch (e: Exception) {
                                longLeaveError = e.message ?: "ثبت مرخصی انجام نشد"
                            }
                        }, modifier = Modifier.fillMaxWidth(), enabled = day.dayType in listOf("مرخصی", "استعلاجی")) {
                            PersianText("ثبت مرخصی در تمام روزهای بازه")
                        }
                        PersianText("روزهایی که بعداً به‌صورت مستقل ویرایش شوند، از گروه مرخصی جدا می‌شوند. داده‌های مستقل قبلی بازنویسی نمی‌شوند.", fontSize = 10.sp, color = Color(0xFF426A6D))
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PersianText("▤", fontSize = 20.sp, color = Color(0xFF426A6D))
                        Spacer(Modifier.width(6.dp))
                        PersianText("یادداشت روز", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color(0xFF073B45))
                    }
                    OutlinedTextField(value = day.note.toPersianDigits(), onValueChange = { onDayChange(day.copy(note=it)) }, placeholder = { PersianText("یادداشت اختیاری…", fontSize = 11.sp) }, modifier = Modifier.fillMaxWidth(), minLines = 1, maxLines = Int.MAX_VALUE, textStyle = TextStyle(fontSize = 12.sp))
                }
            }
        }
        item {
            Button(
                onClick = {
                    val p = date.toLatinDigits().replace('/', '-').split("-").mapNotNull { it.toIntOrNull() }
                    if (p.size == 3 && isValidJalali(p[0], p[1], p[2])) {
                        val normalized = "%04d-%02d-%02d".format(p[0], p[1], p[2])
                        val startDate = day.shiftStartDate.ifBlank { normalized }
                        val endDate = day.shiftEndDate.ifBlank { defaultShiftEndDate(startDate, day.shiftStart, day.shiftEnd) }
                        val savedDay = day.copy(date=normalized, shiftStartDate=startDate, shiftEndDate=endDate)
                        if (savedDay.shiftEnabled && (parsedJalaliDate(startDate) == null || parsedJalaliDate(endDate) == null)) {
                            android.widget.Toast.makeText(context, "تاریخ شروع و پایان شیفت معتبر نیست.", android.widget.Toast.LENGTH_LONG).show()
                        } else if (savedDay.shiftEnabled && (mins(savedDay.shiftStart) == null || mins(savedDay.shiftEnd) == null)) {
                            android.widget.Toast.makeText(context, "ساعت شروع و پایان شیفت را درست وارد کنید.", android.widget.Toast.LENGTH_LONG).show()
                        } else {
                            db.saveDay(savedDay)
                            if (savedDay.dayType == "تعطیل مناسبتی") {
                                if (holidayReason.isNotBlank()) db.saveHoliday(normalized, holidayReason.trim()) else db.removeHoliday(normalized)
                            } else {
                                db.removeHoliday(normalized)
                            }
                            onSaved(savedDay)
                            android.widget.Toast.makeText(context, "اطلاعات روز ذخیره شد", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().heightIn(min = 38.dp),
                contentPadding = PaddingValues(vertical = 5.dp)
            ) { PersianText("ذخیره اطلاعات روز", fontSize = 13.sp) }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                SummaryMiniTile("مجموع کارکرد", hm(duration(day)), Color(0xFFEAF3FF), Color(0xFF075565), Modifier.weight(1f))
                SummaryMiniTile("اضافه‌کار", hm(overtimeMinutes(day, db)), OvertimeGreen, OvertimeGreenText, Modifier.weight(1f))
                SummaryMiniTile("مدت شیفت", hm(shiftDurationMinutes(day, date)), ShiftYellow, ShiftYellowText, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun MonthMetric(label: String, value: String, symbol: String, valueColor: Color, modifier: Modifier, unit: String = "ساعت") {
    Column(modifier.padding(horizontal = 2.dp, vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            PersianText(symbol, fontSize = 13.sp, color = valueColor, maxLines = 1)
            Spacer(Modifier.width(2.dp))
            PersianText(label, fontSize = 9.sp, color = Color(0xFF426A6D), maxLines = 2, textAlign = TextAlign.Center, lineHeight = 10.sp)
        }
        PersianText(value, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = valueColor, maxLines = 1)
        PersianText(unit, fontSize = 8.sp, color = Color(0xFF426A6D), maxLines = 1)
    }
}

@Composable
private fun MetricDivider() {
    Box(Modifier.width(1.dp).height(44.dp).background(Color(0xFFB6D0CE)))
}

@Composable
private fun CompactTimePairRow(index: String, label1: String, value1: String, label2: String, value2: String, onChange1: (String) -> Unit, onChange2: (String) -> Unit, fieldFontSize: Int = 17) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Box(Modifier.size(25.dp).background(Color(0xFFDDEBE8), RoundedCornerShape(50)), contentAlignment = Alignment.Center) { PersianText(index, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF075565)) }
            CompactTimeTextField(label1, value1, onChange1, Modifier.weight(1f), fieldFontSize)
            CompactTimeTextField(label2, value2, onChange2, Modifier.weight(1f), fieldFontSize)
        }
    }
}

@Composable
private fun CompactTimeTextField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier, fieldFontSize: Int = 17) {
    SplitTimeField(label, value, onChange, modifier, fieldFontSize)
}

@Composable
private fun CompactShiftField(label: String, value: String, modifier: Modifier, isDate: Boolean, onChange: (String) -> Unit) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        PersianText(label, fontSize = 8.sp, color = Color(0xFF426A6D), textAlign = TextAlign.Center, maxLines = 2, lineHeight = 9.sp)
        if (isDate) {
            SplitDateField(value, onChange, Modifier.fillMaxWidth())
        } else {
            SplitTimeField("", value, onChange, Modifier.fillMaxWidth(), 13)
        }
    }
}

/**
 * Extract what the user actually typed, excluding the old value that the IME
 * included in the editing event. Cursor moves/selection changes produce no digits.
 */
private fun insertedDigits(oldText: String, newText: String): String {
    val old = oldText.toLatinDigits()
    val new = newText.toLatinDigits()
    val commonPrefix = old.indices.takeWhile { it < new.length && old[it] == new[it] }.count()
    var oldEnd = old.length
    var newEnd = new.length
    while (oldEnd > commonPrefix && newEnd > commonPrefix && old[oldEnd - 1] == new[newEnd - 1]) {
        oldEnd--
        newEnd--
    }
    return new.substring(commonPrefix, newEnd).filter(Char::isDigit)
}

/**
 * Touching a field only arms replacement. The old digits remain visible and
 * unselected until the first new digit is actually entered. This also avoids
 * focus jumps caused by selection-only TextFieldValue updates.
 */
@Composable
private fun ReplaceableNumberField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier,
    maxDigits: Int,
    fontSize: TextUnit,
    imeAction: ImeAction,
    placeholder: String = ""
) {
    var input by remember { mutableStateOf(TextFieldValue(value.toPersianDigits())) }
    var replaceOnNextDigit by remember { mutableStateOf(false) }
    SideEffect {
        if (input.text.toLatinDigits() != value.toLatinDigits()) {
            val shown = value.toPersianDigits()
            input = TextFieldValue(shown, selection = TextRange(shown.length))
        }
    }
    OutlinedTextField(
        value = input,
        onValueChange = { incoming ->
            if (incoming.text == input.text) {
                // Pure selection/caret movement: do not publish, do not auto-advance.
                input = incoming
            } else {
                val added = insertedDigits(input.text, incoming.text)
                val cleaned = if (replaceOnNextDigit && added.isNotEmpty()) {
                    replaceOnNextDigit = false
                    added.take(maxDigits)
                } else {
                    replaceOnNextDigit = false
                    incoming.text.toLatinDigits().filter(Char::isDigit).take(maxDigits)
                }
                val shown = cleaned.toPersianDigits()
                input = TextFieldValue(shown, selection = TextRange(shown.length))
                if (cleaned != value.toLatinDigits()) onValueChange(cleaned)
            }
        },
        modifier = modifier
            // Re-arm replacement on *every* tap, even when this field already has focus.
            // The initial-pass listener does not consume the tap or select the old text.
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    replaceOnNextDigit = true
                    waitForUpOrCancellation()
                }
            }
            .onFocusChanged { focus ->
                if (focus.isFocused) replaceOnNextDigit = true
                else replaceOnNextDigit = false
            },
        singleLine = true,
        textStyle = TextStyle(fontSize = fontSize, textAlign = TextAlign.Center),
        placeholder = if (placeholder.isNotBlank()) { { PersianText(placeholder, fontSize = 9.sp) } } else null,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = imeAction)
    )
}

/** The same first-new-digit replacement rule for HH:MM settings values. */
@Composable
private fun ReplaceableSettingsTimeField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String
) {
    var input by remember { mutableStateOf(TextFieldValue(value.toPersianDigits())) }
    var replaceOnNextDigit by remember { mutableStateOf(false) }
    SideEffect {
        if (input.text.toLatinDigits() != value.toLatinDigits()) {
            val shown = value.toPersianDigits()
            input = TextFieldValue(shown, selection = TextRange(shown.length))
        }
    }
    OutlinedTextField(
        value = input,
        onValueChange = { incoming ->
            if (incoming.text == input.text) {
                input = incoming
            } else {
                val added = insertedDigits(input.text, incoming.text)
                val normalized = if (replaceOnNextDigit && added.isNotEmpty()) {
                    replaceOnNextDigit = false
                    formatTimeInput(added)
                } else {
                    replaceOnNextDigit = false
                    formatTimeInput(incoming.text)
                }
                val shown = normalized.toPersianDigits()
                input = TextFieldValue(shown, selection = TextRange(shown.length))
                if (normalized != value.toLatinDigits()) onValueChange(normalized)
            }
        },
        label = { PersianText(label) },
        modifier = Modifier.fillMaxWidth()
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    replaceOnNextDigit = true
                    waitForUpOrCancellation()
                }
            }
            .onFocusChanged { focus -> replaceOnNextDigit = focus.isFocused },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done)
    )
}

/**
 * Reminder-only field row with absolute LEFT-to-RIGHT screen coordinates.
 * Unlike a normal Row, its physical order is independent of the outer Persian
 * RTL layout direction: place() (not placeRelative()) is intentional.
 */
@Composable
private fun ReminderPhysicalLtrRow(
    weights: List<Float>,
    modifier: Modifier = Modifier,
    gap: Dp = 4.dp,
    content: @Composable () -> Unit
) {
    androidx.compose.ui.layout.Layout(content = content, modifier = modifier) { measurables, constraints ->
        require(measurables.size == weights.size) { "Every reminder field requires a width weight" }
        val gapPx = gap.roundToPx()
        val width = constraints.maxWidth
        val available = (width - gapPx * (measurables.size - 1)).coerceAtLeast(0)
        val sumWeights = weights.sum().coerceAtLeast(0.01f)
        var usedWidth = 0
        val placeables = measurables.mapIndexed { index, measurable ->
            val childWidth = if (index == measurables.lastIndex) {
                available - usedWidth
            } else {
                (available * weights[index] / sumWeights).toInt().coerceAtLeast(0)
            }
            usedWidth += childWidth
            measurable.measure(androidx.compose.ui.unit.Constraints(
                minWidth = childWidth,
                maxWidth = childWidth,
                minHeight = 0,
                maxHeight = constraints.maxHeight
            ))
        }
        val height = placeables.maxOfOrNull { it.height } ?: 0
        layout(width, height) {
            var x = 0
            placeables.forEach { item ->
                item.place(x, height - item.height)
                x += item.width + gapPx
            }
        }
    }
}

/** Persian reminder year/month/day, physically left to right on screen. */
@Composable
fun ReminderDateFieldLeftToRight(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val parts = value.toLatinDigits().replace('-', '/').split('/')
    val year = parts.getOrElse(0) { "" }.take(4)
    val month = parts.getOrElse(1) { "" }.take(2)
    val day = parts.getOrElse(2) { "" }.take(2)
    val monthFocus = remember { FocusRequester() }
    val dayFocus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    fun publish(y: String, m: String, d: String) {
        onChange(when {
            y.isBlank() && m.isBlank() && d.isBlank() -> ""
            else -> y + (if (m.isNotEmpty() || d.isNotEmpty()) "-" + m else "") + (if (d.isNotEmpty()) "-" + d else "")
        })
    }
    ReminderPhysicalLtrRow(listOf(1.15f, 0.85f, 0.85f), modifier.fillMaxWidth()) {
        ReplaceableNumberField(
            value = year,
            onValueChange = { y -> publish(y, month, day); if (y.length == 4) monthFocus.requestFocus() },
            modifier = Modifier.height(50.dp), maxDigits = 4, fontSize = 13.sp,
            placeholder = "سال", imeAction = ImeAction.Next
        )
        ReplaceableNumberField(
            value = month,
            onValueChange = { m -> publish(year, m, day); if (m.length == 2) dayFocus.requestFocus() },
            modifier = Modifier.height(50.dp).focusRequester(monthFocus), maxDigits = 2,
            fontSize = 13.sp, placeholder = "ماه", imeAction = ImeAction.Next
        )
        ReplaceableNumberField(
            value = day,
            onValueChange = { d -> publish(year, month, d); if (d.length == 2) keyboard?.hide() },
            modifier = Modifier.height(50.dp).focusRequester(dayFocus), maxDigits = 2,
            fontSize = 13.sp, placeholder = "روز", imeAction = ImeAction.Done
        )
    }
}

/** Persian reminder hour/minute, physically left to right on screen. */
@Composable
fun ReminderTimeFieldLeftToRight(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val parts = value.toLatinDigits().split(':')
    val hour = parts.getOrElse(0) { "" }.take(2)
    val minute = parts.getOrElse(1) { "" }.take(2)
    val minuteFocus = remember { FocusRequester() }
    ReminderPhysicalLtrRow(listOf(1f, 0.07f, 1f), modifier.fillMaxWidth(), 3.dp) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
            PersianText("ساعت", fontSize = 9.sp, maxLines = 1, color = Color(0xFF426A6D))
            ReplaceableNumberField(
                value = hour,
                onValueChange = { h ->
                    onChange(if (h.isBlank() && minute.isBlank()) "" else "$h:$minute")
                    if (h.length == 2) minuteFocus.requestFocus()
                },
                modifier = Modifier.fillMaxWidth().height(54.dp), maxDigits = 2,
                fontSize = 17.sp, imeAction = ImeAction.Next
            )
        }
        Box(Modifier.height(54.dp), contentAlignment = Alignment.Center) {
            PersianText(":", fontSize = 16.sp, maxLines = 1)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
            PersianText("دقیقه", fontSize = 9.sp, maxLines = 1, color = Color(0xFF426A6D))
            ReplaceableNumberField(
                value = minute,
                onValueChange = { m -> onChange(if (hour.isBlank() && m.isBlank()) "" else "$hour:$m") },
                modifier = Modifier.fillMaxWidth().height(54.dp).focusRequester(minuteFocus), maxDigits = 2,
                fontSize = 17.sp, imeAction = ImeAction.Done
            )
        }
    }
}

@Composable
fun SplitDateField(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val parts = value.toLatinDigits().replace('-', '/').split('/')
    val year = parts.getOrElse(0) { "" }.take(4)
    val month = parts.getOrElse(1) { "" }.take(2)
    val day = parts.getOrElse(2) { "" }.take(2)
    val monthFocus = remember { FocusRequester() }
    val dayFocus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    fun publish(y: String, m: String, d: String) {
        val out = when {
            y.isBlank() && m.isBlank() && d.isBlank() -> ""
            else -> y + (if (m.isNotEmpty() || d.isNotEmpty()) "-" + m else "") + (if (d.isNotEmpty()) "-" + d else "")
        }
        onChange(out)
    }
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
        ReplaceableNumberField(
            value = year,
            onValueChange = { y -> publish(y, month, day); if (y.length == 4) monthFocus.requestFocus() },
            modifier = Modifier.weight(1.15f).height(50.dp),
            maxDigits = 4, fontSize = 13.sp, placeholder = "سال", imeAction = ImeAction.Next
        )
        ReplaceableNumberField(
            value = month,
            onValueChange = { m -> publish(year, m, day); if (m.length == 2) dayFocus.requestFocus() },
            modifier = Modifier.weight(0.85f).height(50.dp).focusRequester(monthFocus),
            maxDigits = 2, fontSize = 13.sp, placeholder = "ماه", imeAction = ImeAction.Next
        )
        ReplaceableNumberField(
            value = day,
            onValueChange = { d -> publish(year, month, d); if (d.length == 2) keyboard?.hide() },
            modifier = Modifier.weight(0.85f).height(50.dp).focusRequester(dayFocus),
            maxDigits = 2, fontSize = 13.sp, placeholder = "روز", imeAction = ImeAction.Done
        )
    }
}

@Composable
private fun SummaryMiniTile(label: String, value: String, background: Color, foreground: Color, modifier: Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = background), shape = RoundedCornerShape(10.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 3.dp, vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
            PersianText(label, fontSize = 10.sp, color = foreground, textAlign = TextAlign.Center, maxLines = 1)
            PersianText(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = foreground, maxLines = 1)
            PersianText("ساعت", fontSize = 8.sp, color = foreground)
        }
    }
}

@Composable
fun SplitTimeField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, fieldFontSize: Int = 17) {
    // One controlled implementation for daily entry, hourly leave and work shifts.
    // Do not reset internal hour/minute state after every parent save/recomposition.
    val parts = value.toLatinDigits().split(":")
    val hour = parts.getOrElse(0) { "" }.take(2)
    val minute = parts.getOrElse(1) { "" }.take(2)
    val minuteFocus = remember { FocusRequester() }
    val stableClockFontSize = fieldFontSize.coerceIn(15, 17).sp
    Column(modifier, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        if (label.isNotBlank()) PersianText(label, fontSize = 10.sp, maxLines = 1)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                PersianText("ساعت", fontSize = 9.sp, maxLines = 1, color = Color(0xFF426A6D))
                ReplaceableNumberField(
                    value = hour,
                    onValueChange = { typedHour ->
                        onChange(if (typedHour.isBlank() && minute.isBlank()) "" else "$typedHour:$minute")
                        // A real edit reaches 2 digits; a mere tap/selection never calls this.
                        if (typedHour.length == 2) minuteFocus.requestFocus()
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    maxDigits = 2,
                    fontSize = stableClockFontSize,
                    imeAction = ImeAction.Next
                )
            }
            Box(Modifier.height(54.dp), contentAlignment = Alignment.Center) {
                PersianText(":", fontSize = 16.sp, maxLines = 1)
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                PersianText("دقیقه", fontSize = 9.sp, maxLines = 1, color = Color(0xFF426A6D))
                ReplaceableNumberField(
                    value = minute,
                    onValueChange = { typedMinute ->
                        onChange(if (hour.isBlank() && typedMinute.isBlank()) "" else "$hour:$typedMinute")
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp).focusRequester(minuteFocus),
                    maxDigits = 2,
                    fontSize = stableClockFontSize,
                    imeAction = ImeAction.Done
                )
            }
        }
    }
}

@Composable
fun TimePair(label1: String, v1: String, label2: String, v2: String, c1: (String)->Unit, c2: (String)->Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        SplitTimeField(label1, v1, c1, Modifier.weight(1f))
        SplitTimeField(label2, v2, c2, Modifier.weight(1f))
    }
}

@Composable
fun SettingsScreen(
    db: WorkDb,
    modifier: Modifier = Modifier,
    onBackup: () -> Unit,
    onRestore: () -> Unit,
    onSyncHolidays: (Int) -> Unit,
    syncYear: Int,
    holidaySyncing: Boolean,
    holidaySyncMessage: String,
    onRecordsDeleted: () -> Unit,
    back: () -> Unit
) {
    var tick by remember { mutableIntStateOf(0) }
    val settings = listOf(
        "fixed_hours" to "ساعت ورود و خروج ثابت",
        "thursday_hours" to "تنظیم جداگانه ساعت پنجشنبه",
        "overtime" to "ثبت و محاسبه اضافه‌کاری",
        "leave_hourly" to "مرخصی ساعتی",
        "leave_daily" to "مرخصی روزانه و نوع مرخصی",
        "mission" to "مأموریت روزانه",
        "shifts" to "تعریف و ثبت شیفت کاری",
        "calendar" to "تقویم ماهانه و تعطیلات"
    )
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF173F71)), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                PersianText("وقت‌نگار حور", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Color.White)
                PersianText("تنظیمات، پشتیبان‌گیری و شخصی‌سازی برنامه", fontSize = 12.sp, color = Color(0xFFD9EAFB))
            }
        }
        PersianText("امکانات و تقویم", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF173F71))
        PersianText("تعطیلات و همهٔ مناسبت‌های تقویم ایران", style = MaterialTheme.typography.titleMedium)
        PersianText("سال شمسی را انتخاب کن تا تعطیلات رسمی و مناسبت‌های ملی، مذهبی، فرهنگی و جهانی همان سال دریافت و روی گوشی ذخیره شوند. پس از ذخیره، بدون اینترنت هم در دسترس‌اند. تاریخ قمری آینده ممکن است تا اعلام رسمی تخمینی باشد.", style = MaterialTheme.typography.bodySmall)
        var selectedCalendarYear by remember(syncYear) { mutableIntStateOf(syncYear) }
        var yearMenuExpanded by remember { mutableStateOf(false) }
        Box {
            OutlinedButton(onClick = { yearMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                PersianText("سال انتخاب‌شده: ${selectedCalendarYear.toString().toPersianDigits()}  ▾")
            }
            DropdownMenu(expanded = yearMenuExpanded, onDismissRequest = { yearMenuExpanded = false }) {
                (maxOf(1347, syncYear - 5)..minOf(1500, syncYear + 10)).forEach { optionYear ->
                    DropdownMenuItem(text = { PersianText(optionYear.toString().toPersianDigits()) }, onClick = {
                        selectedCalendarYear = optionYear
                        yearMenuExpanded = false
                    })
                }
            }
        }
        Button(onClick = { onSyncHolidays(selectedCalendarYear) }, enabled = !holidaySyncing, modifier = Modifier.fillMaxWidth()) {
            PersianText(if (holidaySyncing) "در حال دریافت تقویم…" else "دریافت مناسبت‌های سال انتخاب‌شده")
        }
        if (holidaySyncMessage.isNotBlank()) PersianText(holidaySyncMessage, style = MaterialTheme.typography.bodySmall, color = if (holidaySyncMessage.contains("نشد")) Color(0xFFB3261E) else Color(0xFF075565))
        val syncedAt = remember(selectedCalendarYear, tick, holidaySyncMessage) { db.getSettingText("calendar_last_online_$selectedCalendarYear", "0").toLongOrNull() ?: 0L }
        PersianText("آخرین به‌روزرسانی آنلاین تقویم: " + if (syncedAt == 0L) "هنوز انجام نشده" else formattedSyncStamp(syncedAt), fontSize = 11.sp, color = Color(0xFF52708F))
        Divider()
        PersianText("تاریخ قمری آبان ۱۴۰۵ با مرجع تقویم تطبیق داده می‌شود؛ برای سایر تاریخ‌ها نمایش محاسباتی است.", fontSize = 11.sp, color = Color(0xFF52708F))
        AlertManagementSettings()
        Divider()
        DeleteWorkRecordsPanel(db = db, onDeleted = { tick++; onRecordsDeleted() })
        Divider()
        PersianText("پشتیبان‌گیری و بازیابی", style = MaterialTheme.typography.titleMedium)
        Button(onClick = onBackup, modifier = Modifier.fillMaxWidth()) { PersianText("ساخت پشتیبان Excel (.xlsx)") }
        OutlinedButton(onClick = onRestore, modifier = Modifier.fillMaxWidth()) { PersianText("بازیابی از فایل Excel") }
        PersianText("بازیابی، اطلاعات فعلی را پس از تأیید جایگزین می‌کند.", style = MaterialTheme.typography.bodySmall)
        PersianText("دسترسی به فایل‌ها از طریق انتخابگر امن اندروید انجام می‌شود. هر بار که فایلی انتخاب کنی، اندروید مجوز همان فایل را به برنامه می‌دهد و نیازی به دسترسی کامل حافظه نیست.", fontSize = 11.sp, color = Color(0xFF52708F))
        settings.forEach { (key, label) ->
            val enabled = remember(key, tick) { db.getSetting(key) }
            Surface(shape = RoundedCornerShape(12.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp)) {
                    PersianText(label, modifier = Modifier.weight(1f), fontSize = 13.sp)
                    Switch(checked = enabled, onCheckedChange = { db.setSetting(key,it); tick++ })
                }
            }
        }
        var dailyHours by remember { mutableStateOf(db.getSettingText("workday_hours","07:00")) }
        var thursdayHours by remember { mutableStateOf(db.getSettingText("thursday_hours_value","05:00")) }
        PersianText("ساعت موظفی", style = MaterialTheme.typography.titleMedium)
        ReplaceableSettingsTimeField(dailyHours, { dailyHours = it }, "شنبه تا چهارشنبه (HH:MM)")
        ReplaceableSettingsTimeField(thursdayHours, { thursdayHours = it }, "پنجشنبه (HH:MM)")
        Button(onClick = {
            if (mins(dailyHours) != null && mins(thursdayHours) != null) {
                db.setSettingText("workday_hours",dailyHours)
                db.setSettingText("thursday_hours_value",thursdayHours)
                tick++
            }
        }, modifier = Modifier.fillMaxWidth()) { PersianText("ذخیره ساعت موظفی") }
        Divider()
        Spacer(Modifier.height(12.dp))
        PersianText("نسخهٔ برنامه: ۰.۱۹.۰", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 12.sp, color = Color(0xFF52708F))
        PersianText("طراح : عروج", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF173F71))
        Button(onClick = back, modifier = Modifier.fillMaxWidth()) { PersianText("بازگشت") }
    }
}



@Composable
private fun DeleteWorkRecordsPanel(db: WorkDb, onDeleted: () -> Unit) {
    val today = remember { val (y, m, d) = gregorianToJalali(LocalDate.now()); "%04d-%02d-%02d".format(y, m, d) }
    var from by remember { mutableStateOf(today) }
    var until by remember { mutableStateOf(today) }
    var error by remember { mutableStateOf("") }
    var proposed by remember { mutableIntStateOf(0) }
    var confirm by remember { mutableStateOf(false) }
    var acceptPermanent by remember { mutableStateOf(false) }
    var acceptBackup by remember { mutableStateOf(false) }

    fun normalized(input: String): String? {
        val fields = input.toLatinDigits().replace('/', '-').split('-')
        if (fields.size != 3) return null
        val numbers = fields.map { it.toIntOrNull() ?: return null }
        if (!isValidJalali(numbers[0], numbers[1], numbers[2])) return null
        return "%04d-%02d-%02d".format(numbers[0], numbers[1], numbers[2])
    }
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7F5)), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            PersianText("حذف اطلاعات کارکرد در بازهٔ زمانی", fontWeight = FontWeight.Bold, color = Color(0xFFB3261E))
            PersianText("فقط ثبت‌های روزانهٔ کارکرد، مرخصی و شیفت در این بازه حذف می‌شوند؛ تقویم و تنظیمات دست‌نخورده می‌مانند.", fontSize = 12.sp)
            PersianText("از تاریخ شمسی", fontSize = 12.sp)
            ReminderDateFieldLeftToRight(from, { from = it }, Modifier.fillMaxWidth())
            PersianText("تا تاریخ شمسی (شامل خود این روز)", fontSize = 12.sp)
            ReminderDateFieldLeftToRight(until, { until = it }, Modifier.fillMaxWidth())
            if (error.isNotBlank()) PersianText(error, color = Color(0xFFB3261E), fontSize = 12.sp)
            OutlinedButton(onClick = {
                val a = normalized(from); val b = normalized(until)
                when {
                    a == null || b == null -> error = "تاریخ شروع یا پایان معتبر نیست."
                    a > b -> error = "تاریخ شروع نباید بعد از پایان باشد."
                    else -> {
                        proposed = db.countWorkRecords(a,b)
                        error = if (proposed == 0) "در این بازه هیچ رکورد ثبت‌شده‌ای وجود ندارد." else ""
                        if (proposed > 0) { acceptPermanent = false; acceptBackup = false; confirm = true }
                    }
                }
            }, modifier = Modifier.fillMaxWidth()) { PersianText("بررسی تعداد رکوردها و درخواست حذف") }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { PersianText("تأیید حذف ${persianDigits(proposed.toString())} روز", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PersianText("آیا مطمئنی؟ آیا از این اطلاعات پشتیبان گرفته‌ای؟\nپس از حذف، بازیابی بدون نسخهٔ پشتیبان ممکن نیست.")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = acceptPermanent, onCheckedChange = { acceptPermanent = it })
                    PersianText("بله، از حذف دائمی مطمئن هستم.", fontSize = 12.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = acceptBackup, onCheckedChange = { acceptBackup = it })
                    PersianText("پشتیبان دارم یا مسئولیت حذف بدون پشتیبان را می‌پذیرم.", fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            TextButton(enabled = acceptPermanent && acceptBackup, onClick = {
                val a = normalized(from); val b = normalized(until)
                if (a != null && b != null && a <= b) {
                    // Verify that the number of records has not changed since preview.
                    if (db.countWorkRecords(a, b) != proposed) {
                        error = "تعداد رکوردها تغییر کرده است؛ دوباره بازه را بررسی کن."
                    } else {
                        val count = db.deleteWorkRecords(a, b)
                        error = "${persianDigits(count.toString())} روز حذف شد."
                        onDeleted()
                    }
                }
                confirm = false
            }) { PersianText("حذف قطعی", color = Color(0xFFB3261E)) }
        },
        dismissButton = { TextButton(onClick = { confirm = false }) { PersianText("انصراف") } }
    )
}

@Composable
fun SummaryTile(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.fillMaxWidth().padding(vertical = 10.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            PersianText(value, style = MaterialTheme.typography.titleMedium)
            PersianText(label, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportScreen(
    db: WorkDb, year: Int, monthNumber: Int, refresh: Int,
    modifier: Modifier = Modifier, annual: Boolean,
    onPeriodChange: (Int, Int) -> Unit,
    export: (Boolean, Boolean) -> Unit, exportPdf: (Boolean, Boolean) -> Unit
) {
    var monthMenuExpanded by remember { mutableStateOf(false) }
    var yearMenuExpanded by remember { mutableStateOf(false) }
    var includeReportNotes by remember { mutableStateOf(true) }
    val monthKey = "%04d-%02d".format(year, monthNumber)
    val storedMonthDays = remember(monthKey, refresh) { db.allDays(monthKey).associateBy { it.date } }
    val reportDays = remember(year, monthNumber, refresh) { reportPeriodDays(db, year, monthNumber, false) }
    val yearDays = remember(year, refresh) { reportPeriodDays(db, year, monthNumber, true) }
    val yearPrefix = "%04d-".format(year)
    val yearShiftMinutes = remember(year, refresh) {
        db.allDaysForBackup().filter { it.shiftEnabled && (it.shiftStartDate.ifBlank { it.date }).startsWith(yearPrefix) }
            .sumOf { shiftDurationMinutes(it, it.date) }
    }
    val monthShiftDays = remember(monthKey, refresh) {
        db.allDaysForBackup().filter { it.shiftEnabled && (it.shiftStartDate.ifBlank { it.date }).startsWith(monthKey) }
    }
    val selectedDays = if (annual) yearDays else reportDays
    val totalWork = selectedDays.sumOf { duration(it) }
    val totalOvertime = selectedDays.sumOf { overtimeMinutes(it, db) }
    val totalShift = if (annual) yearShiftMinutes else monthShiftDays.sumOf { shiftDurationMinutes(it, it.date) }
    val shiftCount = if (annual) yearDays.count { it.shiftEnabled } else monthShiftDays.size
    val missionCount = selectedDays.count { it.dayType == "مأموریت" }
    val sickCount = selectedDays.count { it.dayType == "استعلاجی" }
    val entitledCount = selectedDays.count { it.dayType == "مرخصی" }

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 5.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(bottom = 14.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!annual) {
                    Box(Modifier.weight(1f)) {
                        OutlinedButton(onClick = { monthMenuExpanded = true }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 7.dp)) {
                            PersianText("ماه: ${JalaliMonthNames.getOrElse(monthNumber - 1) { "ماه" }}  ⌄", fontSize = 13.sp, maxLines = 1)
                        }
                        DropdownMenu(expanded = monthMenuExpanded, onDismissRequest = { monthMenuExpanded = false }) {
                            JalaliMonthNames.forEachIndexed { index, name ->
                                DropdownMenuItem(text = { PersianText(name) }, onClick = { monthMenuExpanded = false; onPeriodChange(year, index + 1) })
                            }
                        }
                    }
                } else {
                    Surface(Modifier.weight(1f), color = Color(0xFFEAF3FF), shape = RoundedCornerShape(9.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBEDBFA))) {
                        Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) { PersianText("خلاصهٔ سالانه", fontSize = 13.sp, color = Color(0xFF073B45)) }
                    }
                }
                Box(Modifier.weight(1f)) {
                    OutlinedButton(onClick = { yearMenuExpanded = true }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 7.dp)) {
                        PersianText("سال: ${persianDigits(year.toString())}  ⌄", fontSize = 13.sp, maxLines = 1)
                    }
                    DropdownMenu(expanded = yearMenuExpanded, onDismissRequest = { yearMenuExpanded = false }) {
                        ((year - 5)..(year + 1)).toList().reversed().forEach { y ->
                            DropdownMenuItem(text = { PersianText(persianDigits(y.toString())) }, onClick = { yearMenuExpanded = false; onPeriodChange(y, monthNumber) })
                        }
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF3F8F6)), shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(14.dp))) {
                Column(Modifier.fillMaxWidth().padding(7.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        ReportMetricTile("مجموع کارکرد", hm(totalWork), "◷", Color(0xFF153F78), Modifier.weight(1f))
                        ReportMetricTile("اضافه‌کار", hm(totalOvertime), "◴", OvertimeGreenText, Modifier.weight(1f))
                        ReportMetricTile("جمع مدت شیفت", hm(totalShift), "◷", ShiftYellowText, Modifier.weight(1f))
                        ReportMetricTile("تعداد شیفت", shiftCount.toString(), "▦", Color(0xFF153F78), Modifier.weight(1f))
                    }
                    Divider(color = Color(0xFFD2E5FA))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        ReportMetricTile("مرخصی ساعتی", hm(selectedDays.sumOf { hourlyLeaveMinutes(it) }), "◷", Color(0xFF153F78), Modifier.weight(1.05f))
                        ReportMetricTile("مأموریت", missionCount.toString(), "✈", Color(0xFF153F78), Modifier.weight(0.9f))
                        ReportMetricTile("مرخصی استحقاقی", entitledCount.toString(), "☼", Color(0xFF153F78), Modifier.weight(1.1f))
                        ReportMetricTile("مرخصی استعلاجی", sickCount.toString(), "✚", Color(0xFF153F78), Modifier.weight(1.1f))
                    }
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = includeReportNotes, onCheckedChange = { includeReportNotes = it })
                    PersianText("درج یادداشت‌ها در خروجی گزارش", fontSize = 12.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { export(annual, includeReportNotes) }, modifier = Modifier.weight(1f)) {
                        PersianText("خروجی Excel", fontSize = 12.sp)
                    }
                    OutlinedButton(onClick = { exportPdf(annual, includeReportNotes) }, modifier = Modifier.weight(1f)) {
                        PersianText("خروجی PDF", fontSize = 12.sp)
                    }
                }
                PersianText("مرخصی بلندمدت ثبت‌شده: ${persianDigits(db.longLeaveDaysInPeriod(if (annual) year.toString() else monthKey).toString())} روز", fontSize = 11.sp, color = Color(0xFF315C8D))
            }
        }
        if (!annual) {
            items(reportDays, key = { it.date }) { d -> ReportDayCard(d, db, db.displayHolidayTitle(d.date) ?: officialJalaliHolidays(d.date.take(4).toIntOrNull() ?: year).toMap()[d.date]) }
        } else {
            item { PersianText("خلاصهٔ ماه‌به‌ماه سال ${persianDigits(year.toString())}", style = MaterialTheme.typography.titleMedium, color = Color(0xFF073B45)) }
            items((1..12).toList()) { m ->
                val monthDays = yearDays.filter { it.date.startsWith("%04d-%02d".format(year, m)) }
                val monthShift = db.allDaysForBackup().filter { it.shiftEnabled && (it.shiftStartDate.ifBlank { it.date }).startsWith("%04d-%02d".format(year, m)) }.sumOf { shiftDurationMinutes(it, it.date) }
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF3F8F6)), shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(12.dp))) {
                    Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        PersianText(JalaliMonthNames[m - 1], style = MaterialTheme.typography.titleSmall, color = Color(0xFF073B45), fontWeight = FontWeight.Bold)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            PersianText("کارکرد ${hm(monthDays.sumOf { duration(it) })}", fontSize = 12.sp)
                            PersianText("اضافه‌کار ${hm(monthDays.sumOf { overtimeMinutes(it, db) })}", fontSize = 12.sp, color = OvertimeGreenText)
                            PersianText("شیفت ${hm(monthShift)}", fontSize = 12.sp, color = ShiftYellowText)
                        }
                        val officialHolidayCount = monthDays.count { d ->
                            db.officialHolidayTitle(d.date) != null || officialJalaliHolidays(year).toMap().containsKey(d.date)
                        }
                        PersianText("تعطیلات رسمی: ${officialHolidayCount.toString().toPersianDigits()} روز | مرخصی بلندمدت: ${persianDigits(db.longLeaveDaysInPeriod("%04d-%02d".format(year, m)).toString())} روز", fontSize = 11.sp, color = Color(0xFFB3261E))
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportMetricTile(title: String, value: String, symbol: String, valueColor: Color, modifier: Modifier = Modifier) {
    Column(modifier = modifier.heightIn(min = 86.dp).background(Color(0xFFF5FAFF), RoundedCornerShape(9.dp)).padding(horizontal = 3.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        PersianText(title, fontSize = 9.sp, color = Color(0xFF315C8D), textAlign = TextAlign.Center, maxLines = 2, lineHeight = 11.sp)
        Spacer(Modifier.height(2.dp))
        PersianText(symbol, fontSize = 17.sp, color = valueColor, maxLines = 1)
        PersianText(value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = valueColor, maxLines = 1)
    }
}

@Composable
private fun ReportDayCard(day: WorkDay, db: WorkDb, holidayTitle: String?) {
    val weekDay = jalaliWeekday(day.date)?.let { JalaliWeekdayNames.getOrNull(it) }.orEmpty()
    val holidayEntryExists = isHolidayWorkDay(day) && (day.holidayIn.isNotBlank() || day.holidayOut.isNotBlank())

    // Only include entry/exit values that the user actually entered.
    // Keep the original order: entry 1, exit 1, entry 2, exit 2, entry 3, exit 3.
    val timeEntries: List<Pair<String, String>> = if (holidayEntryExists) {
        buildList {
            if (day.holidayIn.isNotBlank()) add("ورود" to day.holidayIn)
            if (day.holidayOut.isNotBlank()) add("خروج" to day.holidayOut)
        }
    } else {
        buildList {
            if (day.in1.isNotBlank()) add("ورود" to day.in1)
            if (day.out1.isNotBlank()) add("خروج" to day.out1)
            if (day.in2.isNotBlank()) add("ورود" to day.in2)
            if (day.out2.isNotBlank()) add("خروج" to day.out2)
            if (day.in3.isNotBlank()) add("ورود" to day.in3)
            if (day.out3.isNotBlank()) add("خروج" to day.out3)
        }
    }

    val shiftDuration = if (day.shiftEnabled) shiftDurationMinutes(day, day.date) else 0

    // Holiday cards are distinguished with a soft red fill and red outline.
    // Friday is detected by the Jalali weekday index used in this project (5 = Friday).
    val isHolidayCard = jalaliWeekday(day.date) == 5 ||
        day.dayType in setOf("تعطیل", "تعطیل رسمی", "تعطیل مناسبتی") ||
        db.officialHolidayTitle(day.date) != null || db.holidayTitle(day.date) != null ||
        officialJalaliHolidays(day.date.take(4).toIntOrNull() ?: 0).toMap().containsKey(day.date)
    val holidayCardBackground = if (isHolidayCard) Color(0xFFFFF5F5) else Color(0xFFF3F8F6)
    val holidayCardBorder = if (isHolidayCard) Color(0xFFE57373) else Color(0xFFBEDBFA)
    val holidayHeaderColor = if (isHolidayCard) Color(0xFFB3261E) else Color(0xFF073B45)

    // Show only the selected day category, rather than all available categories.
    val selectedStatus = when (day.dayType) {
        "مرخصی" -> "مرخصی استحقاقی"
        else -> day.dayType
    }
    val statusItems = buildList {
        if (db.isLongLeaveDay(day.date)) add("مرخصی بلندمدت")
        if (selectedStatus.isNotBlank()) add(selectedStatus)
        if (day.shiftEnabled) add("شیفت")
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = holidayCardBackground),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth().border(1.5.dp, holidayCardBorder, RoundedCornerShape(14.dp))
    ) {
        Column(
            Modifier.fillMaxWidth().padding(7.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                PersianText(
                    "${weekDay} ${jalaliDisplayDate(day.date)}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = holidayHeaderColor
                )
                PersianText("▦", fontSize = 20.sp, color = if (isHolidayCard) Color(0xFFB3261E) else Color(0xFF426A6D))
            }

            Divider(color = if (isHolidayCard) Color(0xFFF0B4B4) else Color(0xFFD9E8F8))

            if (timeEntries.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    timeEntries.forEach { (label, time) ->
                        Column(
                            Modifier.weight(1f)
                                .defaultMinSize(minHeight = 55.dp)
                                .border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(8.dp))
                                .padding(horizontal = 2.dp, vertical = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            PersianText(label, fontSize = 9.sp, color = Color(0xFF075565), maxLines = 1)
                            PersianText(
                                time.toPersianDigits(),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF073B45),
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            if (statusItems.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    statusItems.forEach { status ->
                        val isShift = status == "شیفت"
                        val bg = when {
                            isShift -> ShiftYellow
                            status == "تعطیل مناسبتی" -> Color(0xFFE0F5E9)
                            else -> Color(0xFFE4F0FF)
                        }
                        val foreground = when {
                            isShift -> ShiftYellowText
                            status == "تعطیل مناسبتی" -> Color(0xFF176B36)
                            else -> Color(0xFF1556A6)
                        }
                        Surface(
                            modifier = Modifier.weight(1f).heightIn(min = 52.dp),
                            shape = RoundedCornerShape(8.dp),
                            color = bg,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isShift) Color(0xFFE5C34A) else Color(0xFF8DBFFF)
                            )
                        ) {
                            Box(
                                Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 5.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                PersianText(
                                    status,
                                    fontSize = 10.sp,
                                    color = foreground,
                                    textAlign = TextAlign.Center,
                                    maxLines = 2,
                                    lineHeight = 12.sp
                                )
                            }
                        }
                    }
                }
            }

            if (day.dayType == "تعطیل مناسبتی" || !holidayTitle.isNullOrBlank()) {
                Row(
                    Modifier.fillMaxWidth()
                        .border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(8.dp))
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PersianText("✎", fontSize = 17.sp, color = Color(0xFF075565))
                    PersianText("مناسبت / عنوان تعطیلی:", fontSize = 11.sp, color = Color(0xFF075565))
                    PersianText(
                        holidayTitle ?: "—",
                        modifier = Modifier.weight(1f),
                        fontSize = 11.sp,
                        color = Color(0xFF073B45),
                        maxLines = 3,
                        lineHeight = 14.sp
                    )
                }
            }

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                ReportValueTile("جمع کار", hm(duration(day)), Color(0xFFEAF3FF), Color(0xFF153F78), Modifier.weight(1f))
                ReportValueTile("مدت شیفت", hm(shiftDuration), Color(0xFFFFF7E1), ShiftYellowText, Modifier.weight(1f))
                ReportValueTile("اضافه‌کار", hm(overtimeMinutes(day, db)), Color(0xFFE4F7EE), OvertimeGreenText, Modifier.weight(1f))
            }

            // The note wraps to as many lines as necessary; the card grows with the text.
            Row(
                Modifier.fillMaxWidth()
                    .border(1.dp, Color(0xFFBEDBFA), RoundedCornerShape(8.dp))
                    .padding(8.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PersianText("▤", fontSize = 17.sp, color = Color(0xFF075565))
                PersianText("یادداشت روز:", fontSize = 11.sp, color = Color(0xFF073B45))
                PersianText(
                    day.note.ifBlank { "—" }.toPersianDigits(),
                    modifier = Modifier.weight(1f),
                    fontSize = 12.sp,
                    color = Color(0xFF5D7898),
                    lineHeight = 16.sp,
                    maxLines = Int.MAX_VALUE,
                    softWrap = true
                )
            }
        }
    }
}

@Composable
private fun ReportValueTile(title: String, value: String, background: Color, foreground: Color, modifier: Modifier = Modifier) {
    Column(modifier = modifier.background(background, RoundedCornerShape(9.dp)).padding(horizontal = 5.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        PersianText(title, fontSize = 11.sp, color = foreground, textAlign = TextAlign.Center, maxLines = 1)
        PersianText(value, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = foreground, maxLines = 1)
    }
}

fun buildReportXlsx(db: WorkDb, year: Int, month: Int, annual: Boolean, includeNotes: Boolean = true): ByteArray {
    // Two hidden, lossless import sheets contain ONLY the selected reporting period.
    // This avoids leaking unrelated private records when a report is shared.
    val months = if (annual) (1..12).toList() else listOf(month)
    val allowedPrefixes = months.map { "%04d-%02d".format(year,it) }
    val recordedDays = db.allDaysForBackup().filter { day -> allowedPrefixes.any { day.date.startsWith(it) } }
    val raw = mutableListOf(listOf("date","dayType","in1","out1","in2","out2","in3","out3","duration","overtimeOverride","note","shiftEnabled","shiftStart","shiftEnd","shiftStartDate","shiftEndDate","holidayIn","holidayOut","leave1Start","leave1End","leave2Start","leave2End","hourlyLeaveEnabled"))
    recordedDays.forEach { d -> raw.add(listOf(d.date,d.dayType,d.in1,d.out1,d.in2,d.out2,d.in3,d.out3,hm(duration(d)),d.overtimeOverride,if (includeNotes) d.note else "",d.shiftEnabled.toString(),d.shiftStart,d.shiftEnd,d.shiftStartDate,d.shiftEndDate,d.holidayIn,d.holidayOut,d.leave1Start,d.leave1End,d.leave2Start,d.leave2End,d.hourlyLeaveEnabled.toString())) }
    val metadata = listOf(listOf("key","value"),listOf("export_format","period_report_v1"),listOf("period",if(annual) "%04d".format(year) else "%04d-%02d".format(year,month)))

    val sheets = mutableListOf<Pair<String,String>>()
    sheets.add("داده‌های بازیابی" to sheetXml(raw))
    sheets.add("اطلاعات فایل" to sheetXml(metadata))
    months.forEach { m -> sheets.add(JalaliMonthNames[m-1] to monthReportSheetXml(db,year,m,includeNotes)) }
    val content = linkedMapOf<String,String>()
    content["[Content_Types].xml"] = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.indices.joinToString("") { "<Override PartName=\"/xl/worksheets/sheet${it+1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" }}</Types>"""
    content["_rels/.rels"] = """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>"""
    val sheetDefs = sheets.mapIndexed { i,pair -> "<sheet name=\"${xmlEscape(pair.first)}\" sheetId=\"${i+1}\" r:id=\"rId${i+1}\"${if(i<2) " state=\"hidden\"" else ""}/>" }.joinToString("")
    content["xl/workbook.xml"] = """<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="2" firstSheet="2"/></bookViews><sheets>$sheetDefs</sheets></workbook>"""
    val relationships = sheets.indices.joinToString("") { i -> "<Relationship Id=\"rId${i+1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet${i+1}.xml\"/>" }
    content["xl/_rels/workbook.xml.rels"] = """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">$relationships<Relationship Id="rId${sheets.size+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>"""
    content["xl/styles.xml"] = reportStylesXml()
    sheets.forEachIndexed { i,pair -> content["xl/worksheets/sheet${i+1}.xml"] = pair.second }
    val output = java.io.ByteArrayOutputStream()
    java.util.zip.ZipOutputStream(output).use { zip -> content.forEach { (name,value) ->
        zip.putNextEntry(java.util.zip.ZipEntry(name));zip.write(value.toByteArray(Charsets.UTF_8));zip.closeEntry()
    } }
    return output.toByteArray()
}

private fun monthReportSheetXml(db: WorkDb, year: Int, month: Int, includeNotes: Boolean): String {
    val days=reportPeriodDays(db,year,month,false)
    val shifts=db.allDaysForBackup().filter { it.shiftEnabled && (it.shiftStartDate.ifBlank { it.date }).startsWith("%04d-%02d".format(year,month)) }
    val title="وقت‌نگار حور | گزارش ${JalaliMonthNames[month-1]} ${year.toString().toPersianDigits()}"
    val summary="کارکرد: ${hm(days.sumOf { duration(it) })}     اضافه‌کاری: ${hm(days.sumOf { overtimeMinutes(it,db) })}     مرخصی ساعتی: ${hm(days.sumOf { hourlyLeaveMinutes(it) })}"
    val summary2="مدت شیفت: ${hm(shifts.sumOf { shiftDurationMinutes(it,it.date) })}     تعداد شیفت: ${shifts.size}     استحقاقی: ${days.count { it.dayType=="مرخصی" }}     استعلاجی: ${days.count { it.dayType=="استعلاجی" }}"
    val rows=mutableListOf(
        listOf(title), listOf("گزارش فشردهٔ ماهانه • مناسب چاپ روی یک صفحه A4"), listOf(summary), listOf(summary2),
        listOf("تاریخ", "وضعیت", "ورود / خروج‌ها", "کارکرد", "اضافه‌کار", "شیفت", "مرخصی", if (includeNotes) "یادداشت" else "یادداشت (حذف‌شده)")
    )
    days.forEach { day ->
        val pairs=listOf(day.in1 to day.out1,day.in2 to day.out2,day.in3 to day.out3).filter { it.first.isNotBlank() || it.second.isNotBlank() }
        val interval=if(isHolidayWorkDay(day) && (day.holidayIn.isNotBlank() || day.holidayOut.isNotBlank())) "${day.holidayIn}–${day.holidayOut}" else pairs.joinToString(" | ") { "${it.first}–${it.second}" }
        rows.add(listOf(day.date.replace('-', '/'),if (db.isLongLeaveDay(day.date)) "مرخصی بلندمدت (${day.dayType})" else day.dayType,interval,hm(duration(day)),hm(overtimeMinutes(day,db)),if(day.shiftEnabled) hm(shiftDurationMinutes(day,day.date)) else "—",hm(hourlyLeaveMinutes(day)),if (includeNotes) day.note else ""))
    }
    val cols=listOf(16,17,32,13,14,13,13,64).mapIndexed { i,width -> "<col min=\"${i+1}\" max=\"${i+1}\" width=\"$width\" customWidth=\"1\"/>" }.joinToString("")
    val body=rows.mapIndexed { idx,row ->
        val style=if(idx==0) 2 else if(idx==4) 1 else if(idx in 1..3) 2 else 3
        val cells=row.mapIndexed { j,v -> "<c r=\"${colName(j+1)}${idx+1}\" s=\"$style\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${xmlEscape(v.toPersianDigits())}</t></is></c>" }.joinToString("")
        val height=when(idx) { 0->29; 1,2,3->24;4->28;else->if (includeNotes) 30 else 18 }
        "<row r=\"${idx+1}\" ht=\"$height\" customHeight=\"1\">$cells</row>"
    }.joinToString("")
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><sheetViews><sheetView workbookViewId="0" rightToLeft="1"><pane ySplit="5" topLeftCell="A6" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>$cols</cols><sheetData>$body</sheetData><mergeCells count="4"><mergeCell ref="A1:H1"/><mergeCell ref="A2:H2"/><mergeCell ref="A3:H3"/><mergeCell ref="A4:H4"/></mergeCells><printOptions horizontalCentered="1"/><pageMargins left="0.2" right="0.2" top="0.3" bottom="0.3" header="0.1" footer="0.1"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="1"/></worksheet>"""
}

fun buildReportPdf(db: WorkDb, year: Int, month: Int, annual: Boolean, includeNotes: Boolean = true): ByteArray {
    val pdf=android.graphics.pdf.PdfDocument()
    val months=if(annual) (1..12).toList() else listOf(month)
    val pageWidth=842;val pageHeight=595;val left=24f;val right=818f
    val navy=android.graphics.Color.rgb(21,54,93)
    val teal=android.graphics.Color.rgb(0,125,129)
    val gold=android.graphics.Color.rgb(195,150,58)
    val muted=android.graphics.Color.rgb(90,115,141)
    val soft=android.graphics.Color.rgb(239,246,253)
    val white=android.graphics.Color.WHITE
    val p=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    fun rect(canvas:android.graphics.Canvas,l:Float,t:Float,r:Float,b:Float,color:Int,radius:Float=0f) {
        p.color=color;p.style=android.graphics.Paint.Style.FILL
        if(radius>0f) canvas.drawRoundRect(l,t,r,b,radius,radius,p) else canvas.drawRect(l,t,r,b,p)
    }
    fun rtl(canvas:android.graphics.Canvas,value:String,xRight:Float,yTop:Float,width:Int,size:Float,color:Int,bold:Boolean=false,lines:Int=1) {
        val str=value.toPersianDigits()
        val paint=android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textSize=size;this.color=color;typeface=android.graphics.Typeface.create("sans-serif",if(bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        }
        val layout=android.text.StaticLayout.Builder.obtain(str,0,str.length,paint,width.coerceAtLeast(1))
            .setTextDirection(android.text.TextDirectionHeuristics.RTL)
            .setAlignment(android.text.Layout.Alignment.ALIGN_OPPOSITE)
            .setIncludePad(false).setMaxLines(lines)
            .setEllipsize(android.text.TextUtils.TruncateAt.END).build()
        canvas.save();canvas.translate(xRight-width,yTop);layout.draw(canvas);canvas.restore()
    }
    months.forEachIndexed { index,m ->
        val page=pdf.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth,pageHeight,index+1).create())
        val canvas=page.canvas
        rect(canvas,0f,0f,pageWidth.toFloat(),pageHeight.toFloat(),white)
        rect(canvas,0f,0f,pageWidth.toFloat(),7f,gold)
        rect(canvas,left,18f,right,69f,navy,10f)
        rtl(canvas,"وقت‌نگار حور",right-14,27f,145,16f,white,true)
        rtl(canvas,"گزارش ماهانه ${JalaliMonthNames[m-1]} ${year}",right-178,27f,350,15f,white,true)
        rtl(canvas,"برگه ${index+1} از ${months.size}",left+133,29f,120,10f,android.graphics.Color.rgb(222,237,249))

        val days=reportPeriodDays(db,year,m,false)
        val shiftList=db.allDaysForBackup().filter { it.shiftEnabled && (it.shiftStartDate.ifBlank { it.date }).startsWith("%04d-%02d".format(year,m)) }
        val metrics=listOf(
            "کارکرد" to hm(days.sumOf { duration(it) }),
            "اضافه‌کاری" to hm(days.sumOf { overtimeMinutes(it,db) }),
            "مرخصی ساعتی" to hm(days.sumOf { hourlyLeaveMinutes(it) }),
            "شیفت" to hm(shiftList.sumOf { shiftDurationMinutes(it,it.date) }),
            "تعداد شیفت" to shiftList.size.toString(),
            "استحقاقی" to days.count { it.dayType=="مرخصی" }.toString(),
            "استعلاجی" to days.count { it.dayType=="استعلاجی" }.toString()
        )
        val gap=6f;val tileWidth=(right-left-gap*(metrics.size-1))/metrics.size
        metrics.forEachIndexed { i,metric ->
            val l=left+(tileWidth+gap)*i
            rect(canvas,l,78f,l+tileWidth,125f,soft,6f)
            rtl(canvas,metric.first,l+tileWidth-6,84f,(tileWidth-12).toInt(),10f,muted)
            rtl(canvas,metric.second,l+tileWidth-6,103f,(tileWidth-12).toInt(),15f,if(i==1)teal else navy,true)
        }
        val widths=listOf(72f,84f,128f,60f,68f,60f,57f,265f)
        val headers=listOf("تاریخ", "وضعیت", "ورود و خروج", "کارکرد", "اضافه‌کاری", "شیفت", "مرخصی", if (includeNotes) "یادداشت" else "یادداشت (حذف‌شده)")
        val tableTop=137f;val headerHeight=24f;val rowHeight=12.8f
        rect(canvas,left,tableTop,right,tableTop+headerHeight,navy,5f)
        var x=right
        headers.forEachIndexed { i,heading ->
            rtl(canvas,heading,x-4,tableTop+5,(widths[i]-7).toInt(),9.5f,white,true)
            x-=widths[i]
        }
        days.forEachIndexed { i,d ->
            val top=tableTop+headerHeight+i*rowHeight
            val highlight=jalaliWeekday(d.date)==5 || d.dayType in setOf("تعطیل","تعطیل رسمی","تعطیل مناسبتی")
            val color=when {highlight -> android.graphics.Color.rgb(255,239,239);i%2==0 -> android.graphics.Color.rgb(248,251,255);else -> white}
            rect(canvas,left,top,right,top+rowHeight,color)
            x=right
            val entries=if(isHolidayWorkDay(d) && (d.holidayIn.isNotBlank() || d.holidayOut.isNotBlank())) "${d.holidayIn}-${d.holidayOut}" else listOf(d.in1 to d.out1,d.in2 to d.out2,d.in3 to d.out3).filter { it.first.isNotBlank() || it.second.isNotBlank() }.joinToString("  ") { "${it.first}-${it.second}" }
            val cellValues=listOf(d.date.replace('-', '/'),if (db.isLongLeaveDay(d.date)) "مرخصی بلندمدت (${d.dayType})" else d.dayType,entries,hm(duration(d)),hm(overtimeMinutes(d,db)),if(d.shiftEnabled) hm(shiftDurationMinutes(d,d.date)) else "—",hm(hourlyLeaveMinutes(d)),if (includeNotes) d.note else "")
            cellValues.forEachIndexed { j,value ->
                rtl(canvas,value,x-4,top+1.6f,(widths[j]-7).toInt(),if (j==7) 5.9f else 8.1f,if(highlight && j==0) android.graphics.Color.rgb(170,41,45) else navy,j==0,if (j==7 && includeNotes) 2 else 1)
                x-=widths[j]
            }
            rect(canvas,left,top+rowHeight-0.5f,right,top+rowHeight,android.graphics.Color.rgb(221,230,242))
        }
        val footerY=tableTop+headerHeight+days.size*rowHeight+12f
        rtl(canvas,"برای نگهداری یا بازیابی اطلاعات، فایل Excel همین گزارش را ذخیره کنید. ستون یادداشت پهن‌تر شده و متن طولانی تا دو سطر چاپ می‌شود.",right,footerY,(right-left).toInt(),9f,muted)
        rect(canvas,left,footerY+20,right,footerY+22,gold)
        pdf.finishPage(page)
    }
    val out=java.io.ByteArrayOutputStream();pdf.writeTo(out);pdf.close();return out.toByteArray()
}

private fun xmlEscape(v: String): String = v.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;")
private fun colName(n: Int): String {
    var x=n; var out=""
    while(x>0){ val r=(x-1)%26; out=(('A'.code+r).toChar())+out; x=(x-1)/26 }
    return out
}
private fun reportStylesXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="3"><font><sz val="11"/><name val="Arial"/><family val="2"/></font><font><b/><sz val="12"/><color rgb="FFFFFFFF"/><name val="Arial"/><family val="2"/></font><font><b/><sz val="14"/><color rgb="FF163D6B"/><name val="Arial"/><family val="2"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF28588A"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFD2E0F1"/></left><right style="thin"><color rgb="FFD2E0F1"/></right><top style="thin"><color rgb="FFD2E0F1"/></top><bottom style="thin"><color rgb="FFD2E0F1"/></bottom><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="4"><xf numFmtId="0" fontId="0" fillId="0" borderId="1" applyBorder="1"/><xf numFmtId="0" fontId="1" fillId="2" borderId="1" applyFont="1" applyFill="1" applyBorder="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="2" fillId="0" borderId="1" applyFont="1" applyBorder="1"/><xf numFmtId="0" fontId="0" fillId="0" borderId="1" applyBorder="1"><alignment vertical="center" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>"""
private fun sheetXml(rows: List<List<String>>): String {
    val maxCols = rows.maxOfOrNull { it.size } ?: 1
    val cols = (1..maxCols).joinToString("") { i ->
        val width = when { i == 1 -> 17; i == 2 -> 18; i == 3 -> 30; else -> 15 }
        "<col min=\"$i\" max=\"$i\" width=\"$width\" customWidth=\"1\"/>"
    }
    val body = rows.mapIndexed { ri,row ->
        val cells = row.mapIndexed { ci,value ->
            val ref = colName(ci+1)+(ri+1)
            val style = if (ri == 0) 1 else if (ci == 0 && ri < 4) 2 else 3
            "<c r=\"$ref\" s=\"$style\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${xmlEscape(value.toPersianDigits())}</t></is></c>"
        }.joinToString("")
        "<row r=\"${ri+1}\" ht=\"${if (ri==0) 30 else 24}\" customHeight=\"1\">$cells</row>"
    }.joinToString("")
    return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0" rightToLeft="1"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>$cols</cols><sheetData>$body</sheetData><pageMargins left="0.25" right="0.25" top="0.45" bottom="0.45" header="0.2" footer="0.2"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/><printOptions horizontalCentered="1"/><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr></worksheet>"""
}

fun buildBackupXlsx(db: WorkDb): ByteArray {
    val workRows = mutableListOf(listOf("date","dayType","in1","out1","in2","out2","in3","out3","duration","overtimeOverride","note","shiftEnabled","shiftStart","shiftEnd","shiftStartDate","shiftEndDate","holidayIn","holidayOut","leave1Start","leave1End","leave2Start","leave2End","hourlyLeaveEnabled"))
    db.allDaysForBackup().forEach { d ->
        workRows.add(listOf(d.date,d.dayType,d.in1,d.out1,d.in2,d.out2,d.in3,d.out3,hm(duration(d)),d.overtimeOverride,d.note,d.shiftEnabled.toString(),d.shiftStart,d.shiftEnd,d.shiftStartDate,d.shiftEndDate,d.holidayIn,d.holidayOut,d.leave1Start,d.leave1End,d.leave2Start,d.leave2End,d.hourlyLeaveEnabled.toString()))
    }
    val settingsRows = mutableListOf(listOf("key","value"))
    db.allSettings().forEach { settingsRows.add(listOf(it.first,it.second)) }
    val entries = linkedMapOf(
        "[Content_Types].xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""",
        "_rels/.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""",
        "xl/workbook.xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Workdays" sheetId="1" r:id="rId1"/><sheet name="Settings" sheetId="2" r:id="rId2"/></sheets></workbook>""",
        "xl/_rels/workbook.xml.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/></Relationships>""",
        "xl/worksheets/sheet1.xml" to sheetXml(workRows),
        "xl/worksheets/sheet2.xml" to sheetXml(settingsRows)
    )
    val output = java.io.ByteArrayOutputStream()
    java.util.zip.ZipOutputStream(output).use { zip ->
        entries.forEach { (name,content) ->
            zip.putNextEntry(java.util.zip.ZipEntry(name))
            zip.write(content.toByteArray(Charsets.UTF_8))
            zip.closeEntry()
        }
    }
    return output.toByteArray()
}
private fun readBackupXlsx(bytes: ByteArray): Pair<List<WorkDay>,List<Pair<String,String>>> {
    val entries = mutableMapOf<String,ByteArray>()
    java.util.zip.ZipInputStream(bytes.inputStream()).use { zip ->
        while(true) {
            val e = zip.nextEntry ?: break
            if (e.name == "xl/worksheets/sheet1.xml" || e.name == "xl/worksheets/sheet2.xml") {
                entries[e.name] = zip.readBytes()
            }
            zip.closeEntry()
        }
    }
    fun parseSheet(xmlBytes: ByteArray?): List<List<String>> {
        if(xmlBytes == null) return emptyList()
        val parser = android.util.Xml.newPullParser()
        parser.setInput(xmlBytes.inputStream(), "UTF-8")
        val rows = mutableListOf<List<String>>()
        var row: MutableList<String>? = null
        var cellText = StringBuilder()
        var inCell = false
        var event = parser.eventType
        while(event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
            when(event) {
                org.xmlpull.v1.XmlPullParser.START_TAG -> when(parser.name) {
                    "row" -> row = mutableListOf()
                    "c" -> { inCell = true; cellText = StringBuilder() }
                    "t" -> if(inCell) { }
                }
                org.xmlpull.v1.XmlPullParser.TEXT -> if(inCell) cellText.append(parser.text)
                org.xmlpull.v1.XmlPullParser.END_TAG -> when(parser.name) {
                    "c" -> { row?.add(cellText.toString()); inCell = false }
                    "row" -> { row?.let { rows.add(it) }; row = null }
                }
            }
            event = parser.next()
        }
        return rows
    }
    val workRows = parseSheet(entries["xl/worksheets/sheet1.xml"])
    val settingsRows = parseSheet(entries["xl/worksheets/sheet2.xml"])
    require(workRows.isNotEmpty() && workRows.first().firstOrNull() == "date") { "ساختار فایل پشتیبان معتبر نیست" }
    val days = workRows.drop(1).map { row -> row.map { it.toLatinDigits() } }
        .filter { it.size >= 11 && it[0].matches(Regex("\\d{4}-\\d{2}-\\d{2}")) }.map { r ->
        WorkDay(r[0],r[2],r[3],r[4],r[5],r[6],r[7],r[10],r[1].ifBlank{"کاری"},r[9], r.getOrNull(11)?.toBoolean() ?: false, r.getOrNull(12) ?: "", r.getOrNull(13) ?: "", r.getOrNull(14) ?: "", r.getOrNull(15) ?: "", r.getOrNull(16) ?: "", r.getOrNull(17) ?: "",
            r.getOrNull(18) ?: "", r.getOrNull(19) ?: "", r.getOrNull(20) ?: "", r.getOrNull(21) ?: "",
            r.getOrNull(22)?.toBoolean() ?: listOf(18,19,20,21).any { !r.getOrNull(it).isNullOrBlank() })
    }
    val settings = settingsRows.drop(1).filter { it.size >= 2 }.map { it[0] to it[1].toLatinDigits() }
    return days to settings
}


@Composable
private fun HelpScreen(modifier: Modifier = Modifier) {
    val sections = listOf(
        "خانه و کارکرد روزانه" to "ورود و خروج اول همیشه مشخص است؛ با دکمه‌های ۲ و ۳ نوبت‌های بعدی را باز کن. روز، وضعیت، مرخصی ساعتی و شیفت را انتخاب کن. اطلاعات هنگام ویرایش ذخیره می‌شوند؛ ذخیرهٔ روز هم برای تأیید نهایی وجود دارد.",
        "ثبت مرخصی بلندمدت" to "از صفحهٔ خانه وضعیت را روی استحقاقی یا استعلاجی قرار بده و یادداشت را وارد کن؛ کلید مرخصی بلندمدت را روشن کن، تاریخ پایان را انتخاب و ثبت کن. روزهای مستقل قبلی بازنویسی نمی‌شوند و هر روز را بعداً جداگانه می‌توان ویرایش کرد.",
        "تقویم" to "مناسبت‌ها، تعطیلات رسمی و تاریخ‌های شمسی، میلادی و قمری را ببین. برای شروع صفحه، تاریخ امروز انتخاب می‌شود. نمایش قمری آبان ۱۴۰۵ با دادهٔ مرجع تطبیق شده است.",
        "یادآورها" to "برای جلسه یا قسط عنوان، تاریخ شمسی، ساعت و تکرار ماهانه ثبت کن. هر مورد بعداً قابل مشاهده، ویرایش و حذف است. انتخاب صدای گوشی از انتخابگر اندروید انجام می‌شود.",
        "اوقات شرعی و اذان" to "شهر را انتخاب کن تا شش وقت شرعی نشان داده شود. هشدار صبح، ظهر و مغرب جداگانه قابل کنترل است. دانلود و استفاده از صوت باید مجاز و مورد تأیید منبع باشد.",
        "گزارش‌ها" to "گزارش ماهانه و سالانه از منوی سه‌نقطه باز می‌شوند. قبل از Excel یا PDF مشخص کن یادداشت‌ها در فایل خروجی درج شوند یا خیر. خروجی Excel حاوی دادهٔ قابل بازگردانی همان دوره است.",
        "تنظیمات، پشتیبان و حذف" to "ساعت موظفی، نمایش اعلان تاریخ و همگام‌سازی تقویم را کنترل کن. قبل از حذف رکوردهای روزانه بازهٔ تاریخ، شمارش رکوردها و دو تأیید دربارهٔ حذف و پشتیبان لازم است.",
        "بروزرسانی امن" to "برای نصب نسخهٔ جدید، شمارهٔ نسخه باید بالاتر باشد و در GitHub از گردش‌کار امضاشده با کلید ثابت استفاده شود؛ برنامهٔ قبلی را برای بروزرسانی حذف نکن."
    )
    LazyColumn(modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        items(sections) { section ->
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp)) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    PersianText(section.first, color = Color(0xFF173F71), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    PersianText(section.second, fontSize = 12.sp, color = Color(0xFF426A6D), lineHeight = 20.sp)
                }
            }
        }
    }
}
