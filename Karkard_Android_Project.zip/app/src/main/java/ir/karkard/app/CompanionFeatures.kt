package ir.karkard.app

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.*

// Companion features intentionally use a separate SQLite database. Work records are untouched.
data class PersonalReminder(val id: Long, val kind: String, val title: String,
    val whenMillis: Long, val monthly: Boolean, val soundUri: String, val enabled: Boolean = true)

class ReminderStore(context: Context): SQLiteOpenHelper(context, "vaghtnegar_reminders.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE reminders(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,title TEXT NOT NULL,when_ms INTEGER NOT NULL,monthly INTEGER NOT NULL DEFAULT 0,sound TEXT DEFAULT '',enabled INTEGER NOT NULL DEFAULT 1)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun all(): List<PersonalReminder> {
        val result = mutableListOf<PersonalReminder>()
        readableDatabase.rawQuery("SELECT id,kind,title,when_ms,monthly,sound,enabled FROM reminders ORDER BY when_ms",null).use { c ->
            while(c.moveToNext()) result.add(PersonalReminder(c.getLong(0),c.getString(1),c.getString(2),c.getLong(3),c.getInt(4)==1,c.getString(5)?:"",c.getInt(6)==1))
        }
        return result
    }
    fun byId(id: Long): PersonalReminder? = all().firstOrNull { it.id == id }
    fun add(kind: String, title: String, millis: Long, monthly: Boolean, sound: String): Long {
        val row = ContentValues().apply { put("kind",kind);put("title",title);put("when_ms",millis);put("monthly",if(monthly) 1 else 0);put("sound",sound);put("enabled",1) }
        return writableDatabase.insert("reminders", null, row)
    }
    fun delete(id: Long) { writableDatabase.delete("reminders","id=?",arrayOf(id.toString())) }
    fun updateTime(id: Long, millis: Long, enabled: Boolean) {
        writableDatabase.update("reminders",ContentValues().apply { put("when_ms",millis); put("enabled",if(enabled) 1 else 0) },"id=?",arrayOf(id.toString()))
    }
}

internal data class PrayerCity(val name:String, val latitude:Double, val longitude:Double, val zone:String)
internal val prayerCities = listOf(
    PrayerCity("تهران",35.6892,51.3890,"Asia/Tehran"),
    PrayerCity("مشهد",36.2605,59.6168,"Asia/Tehran"),
    PrayerCity("قم",34.6416,50.8746,"Asia/Tehran"),
    PrayerCity("اصفهان",32.6546,51.6680,"Asia/Tehran"),
    PrayerCity("شیراز",29.5918,52.5837,"Asia/Tehran"),
    PrayerCity("تبریز",38.0962,46.2738,"Asia/Tehran"),
    PrayerCity("اهواز",31.3183,48.6706,"Asia/Tehran"),
    PrayerCity("کرمان",30.2839,57.0834,"Asia/Tehran"),
    PrayerCity("رشت",37.2808,49.5832,"Asia/Tehran"),
    PrayerCity("بندرعباس",27.1832,56.2666,"Asia/Tehran"),
    PrayerCity("برلین",52.5200,13.4050,"Europe/Berlin"),
    PrayerCity("استانبول",41.0082,28.9784,"Europe/Istanbul"),
    PrayerCity("نجف",31.9950,44.3140,"Asia/Baghdad")
)

/** Approximate solar calculation. Official local prayer timetables may differ. */
internal fun prayerTimes(date: LocalDate, city: PrayerCity, adjustmentMin: Int): Map<String, ZonedDateTime> {
    val zone=ZoneId.of(city.zone)
    val n=date.dayOfYear.toDouble()
    val gamma=2.0*Math.PI/365.0*(n-1.0)
    val eq=229.18*(0.000075+0.001868*cos(gamma)-0.032077*sin(gamma)-0.014615*cos(2*gamma)-0.040849*sin(2*gamma))
    val decl=0.006918-0.399912*cos(gamma)+0.070257*sin(gamma)-0.006758*cos(2*gamma)+0.000907*sin(2*gamma)-0.002697*cos(3*gamma)+0.00148*sin(3*gamma)
    val localOffset=date.atTime(12,0).atZone(zone).offset.totalSeconds/60.0
    val noon=720.0-4.0*city.longitude-eq+localOffset
    val lat=Math.toRadians(city.latitude)
    fun angle(altitude:Double): Double {
        val cosH=(sin(Math.toRadians(altitude))-sin(lat)*sin(decl))/(cos(lat)*cos(decl))
        return Math.toDegrees(acos(cosH.coerceIn(-1.0,1.0)))
    }
    fun at(minutes:Double): ZonedDateTime {
        val base=date.atStartOfDay(zone)
        return base.plusMinutes(minutes.roundToLong())
    }
    return linkedMapOf(
        "صبح" to at(noon-4.0*angle(-17.7)+adjustmentMin),
        "ظهر" to at(noon+adjustmentMin),
        // Maghrib is later than sunset; -4 degrees is an approximation for a common Shia method.
        "مغرب" to at(noon+4.0*angle(-4.0)+adjustmentMin)
    )
}

internal object CompanionAlerts {
    private const val CHANNEL_DAY = "vaghtnegar_day_v1"
    private const val CHANNEL_REMIND = "vaghtnegar_remind_v1"
    private const val CHANNEL_PRAYER = "vaghtnegar_prayer_v1"
    private const val DAY_ID=140501
    private fun prefs(c: Context)=c.getSharedPreferences("vaghtnegar_companion",Context.MODE_PRIVATE)
    fun enabled(c:Context,key:String,default:Boolean=false)=prefs(c).getBoolean(key,default)
    fun setEnabled(c:Context,key:String,value:Boolean) { prefs(c).edit().putBoolean(key,value).apply(); refresh(c) }
    fun selectedCity(c:Context):Int=prefs(c).getInt("city",0).coerceIn(prayerCities.indices)
    fun selectCity(c:Context,index:Int) { prefs(c).edit().putInt("city",index).apply(); refresh(c) }
    fun offset(c:Context):Int=prefs(c).getInt("offset",0)
    fun changeOffset(c:Context,value:Int) { prefs(c).edit().putInt("offset",value.coerceIn(-30,30)).apply();refresh(c) }
    fun ringtone(c:Context,prayer:Boolean):String=prefs(c).getString(if(prayer) "adhan_sound" else "reminder_sound","")?:""
    fun saveRingtone(c:Context,prayer:Boolean,uri:String) { prefs(c).edit().putString(if(prayer) "adhan_sound" else "reminder_sound",uri).apply() }
    fun channels(c:Context) {
        val manager=c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel(CHANNEL_DAY,"تاریخ امروز",NotificationManager.IMPORTANCE_LOW).apply { setSound(null,null);enableVibration(false);description="نمایش تاریخ شمسی و قمری در اعلان" })
        manager.createNotificationChannel(NotificationChannel(CHANNEL_REMIND,"یادآور اقساط و جلسات",NotificationManager.IMPORTANCE_HIGH).apply { description="یادآوری‌های شخصی وقت‌نگار";setSound(null,null) })
        manager.createNotificationChannel(NotificationChannel(CHANNEL_PRAYER,"هشدار اوقات شرعی",NotificationManager.IMPORTANCE_HIGH).apply { description="هشدار صبح، ظهر و مغرب";setSound(null,null) })
    }
    fun hasNotificationPermission(c:Context)=Build.VERSION.SDK_INT<33 || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED
    fun requestPermissions(activity:Activity) {
        if(Build.VERSION.SDK_INT>=33 && !hasNotificationPermission(activity)) activity.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),911)
    }
    private fun request(c:Context,action:String,id:Int):PendingIntent {
        val intent=Intent(c,CompanionAlarmReceiver::class.java).setAction(action).putExtra("alarm_id",id)
        return PendingIntent.getBroadcast(c,id,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
    private fun schedule(c:Context,time:Long,action:String,id:Int) {
        if(time<=System.currentTimeMillis()) return
        val manager=c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pending=request(c,action,id)
        try {
            if(Build.VERSION.SDK_INT<31 || manager.canScheduleExactAlarms()) manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,time,pending)
            else manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,time,pending)
        } catch(_:SecurityException) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,time,pending)
        }
    }
    private fun cancel(c:Context,action:String,id:Int) {
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(request(c,action,id))
    }
    fun askExactAlarmSettings(activity:Activity) {
        if(Build.VERSION.SDK_INT>=31) try {
            activity.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${activity.packageName}")))
        } catch (_:Exception) { Toast.makeText(activity,"مجوز هشدار دقیق از تنظیمات گوشی قابل مدیریت است",Toast.LENGTH_LONG).show() }
    }
    private fun dayIcon(c:Context,day:Int):Int {
        val id=c.resources.getIdentifier("ic_status_$day","drawable",c.packageName)
        return if(id!=0) id else android.R.drawable.ic_popup_reminder
    }
    fun showDay(c:Context) {
        val manager=c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if(!enabled(c,"day_notification") || !hasNotificationPermission(c)) { manager.cancel(DAY_ID);return }
        channels(c)
        val today=LocalDate.now()
        val (y,m,d)=gregorianToJalali(today)
        val jalali="${d.toString().toPersianDigitsLocal()} ${listOf("فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند")[m-1]} ${y.toString().toPersianDigitsLocal()}"
        val hijri=try {
            val islamic=com.ibm.icu.util.IslamicCalendar(com.ibm.icu.util.TimeZone.getTimeZone("UTC"))
            islamic.timeInMillis=today.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
            val names=listOf("محرم","صفر","ربیع‌الاول","ربیع‌الثانی","جمادی‌الاول","جمادی‌الثانی","رجب","شعبان","رمضان","شوال","ذی‌القعده","ذی‌الحجه")
            "${islamic.get(com.ibm.icu.util.Calendar.DAY_OF_MONTH).toString().toPersianDigitsLocal()} ${names[islamic.get(com.ibm.icu.util.Calendar.MONTH)]} ${islamic.get(com.ibm.icu.util.Calendar.YEAR).toString().toPersianDigitsLocal()} (محاسباتی)"
        } catch(_:Exception) { "" }
        val open=PendingIntent.getActivity(c,0,Intent(c,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification=Notification.Builder(c,CHANNEL_DAY)
            .setSmallIcon(dayIcon(c,d)).setContentTitle("وقت‌نگار حور  •  $jalali")
            .setContentText(hijri).setContentIntent(open)
            .setOngoing(true).setOnlyAlertOnce(true).setShowWhen(false)
            .setCategory(Notification.CATEGORY_STATUS).build()
        manager.notify(DAY_ID,notification)
    }
    private fun notifyEvent(c:Context,title:String,description:String,prayer:Boolean,sound:String,id:Int) {
        if(!hasNotificationPermission(c)) return
        channels(c)
        val channel=if(prayer) CHANNEL_PRAYER else CHANNEL_REMIND
        val open=PendingIntent.getActivity(c,0,Intent(c,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification=Notification.Builder(c,channel)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title)
            .setContentText(description).setContentIntent(open).setAutoCancel(true)
            .setCategory(Notification.CATEGORY_ALARM).build()
        (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id,notification)
        val uri=if(sound.isNotBlank()) Uri.parse(sound) else RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        try {
            val playback=Intent(c,AlertSoundService::class.java).apply {
                putExtra("sound_uri",uri.toString());putExtra("message",title)
            }
            c.startForegroundService(playback)
        } catch(_:Exception) {
            // Some Android versions block background service starts even from alarm broadcasts.
            try { RingtoneManager.getRingtone(c,uri)?.play() } catch(_:Exception) { }
        }
    }
    fun refresh(c:Context) {
        channels(c)
        showDay(c)
        if(enabled(c,"day_notification")) {
            val next=LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()+30000L
            schedule(c,next,"DAY",9701)
        } else cancel(c,"DAY",9701)
        val reminders=ReminderStore(c).all()
        reminders.forEach { r ->
            val code=(100000L+r.id).toInt()
            if(r.enabled && r.whenMillis>System.currentTimeMillis()) schedule(c,r.whenMillis,"REMINDER",code)
            else cancel(c,"REMINDER",code)
        }
        for(i in 0..2) {
            val label=listOf("صبح","ظهر","مغرب")[i]
            val action="PRAYER_$label"
            val code=9800+i
            cancel(c,action,code)
            if(enabled(c,"prayer_enabled") && enabled(c,"prayer_$i",true)) {
                val city=prayerCities[selectedCity(c)]
                val now=ZonedDateTime.now(ZoneId.of(city.zone))
                val next=(0..2).asSequence().map { prayerTimes(now.toLocalDate().plusDays(it.toLong()),city,offset(c)).getValue(label) }.firstOrNull { it.isAfter(now.plusSeconds(2)) }
                if(next!=null) schedule(c,next.toInstant().toEpochMilli(),action,code)
            }
        }
    }
    fun onAlarm(c:Context,action:String,id:Int) {
        when {
            action=="DAY" -> showDay(c)
            action=="REMINDER" -> {
                val r=ReminderStore(c).byId(id.toLong()-100000L) ?: return
                if(r.enabled) {
                    notifyEvent(c,"یادآور ${r.kind}",r.title,false,r.soundUri,190000+id)
                    if(r.monthly) {
                        val current=Instant.ofEpochMilli(r.whenMillis).atZone(ZoneId.systemDefault())
                        val (y,m,d)=gregorianToJalali(current.toLocalDate())
                        val total=y*12+m // Gregorian-independent Jalali month index
                        val nextY=(total/12)
                        val nextM=(total%12)+1
                        val safeD=d.coerceAtMost(jalaliMonthLength(nextY,nextM))
                        val next=jalaliToGregorian(nextY,nextM,safeD).atTime(current.toLocalTime()).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                        var upcoming=next
                        var safety=0
                        while(upcoming<=System.currentTimeMillis() && safety++<24) {
                            val local=Instant.ofEpochMilli(upcoming).atZone(ZoneId.systemDefault())
                            val (cy,cm,cd)=gregorianToJalali(local.toLocalDate())
                            val ix=cy*12+cm
                            val yy=ix/12
                            val mm=ix%12+1
                            upcoming=jalaliToGregorian(yy,mm,cd.coerceAtMost(jalaliMonthLength(yy,mm)))
                                .atTime(local.toLocalTime()).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                        }
                        ReminderStore(c).updateTime(r.id,upcoming,true)
                    } else ReminderStore(c).updateTime(r.id,r.whenMillis,false)
                }
            }
            action.startsWith("PRAYER_") -> {
                val label=action.removePrefix("PRAYER_")
                if(enabled(c,"prayer_enabled")) notifyEvent(c,"وقت اذان $label","اوقات شرعی تقریبی شهر ${prayerCities[selectedCity(c)].name}",true,ringtone(c,true),192000+id)
            }
        }
        refresh(c)
    }
}

/** Plays an alarm sound (including a user-selected audio file) with a foreground notification. */
class AlertSoundService:android.app.Service() {
    private var player:android.media.MediaPlayer?=null
    private val playbackId=240016
    override fun onBind(intent:Intent?):android.os.IBinder?=null
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
        if(intent?.action=="STOP_SOUND") { stopSelf(); return START_NOT_STICKY }
        CompanionAlerts.channels(this)
        val stopSound=PendingIntent.getService(this,240017,
            Intent(this,AlertSoundService::class.java).setAction("STOP_SOUND"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification=Notification.Builder(this,"vaghtnegar_prayer_v1")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(intent?.getStringExtra("message")?:"صدای هشدار وقت‌نگار")
            .setContentText("در حال پخش صدای انتخاب‌شده")
            .addAction(android.R.drawable.ic_media_pause,"توقف صدا",stopSound)
            .setContentIntent(PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            .setOngoing(true).build()
        try {
            if(Build.VERSION.SDK_INT>=29) startForeground(playbackId,notification,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            else startForeground(playbackId,notification)
            player?.release()
            player=android.media.MediaPlayer().apply {
                setAudioAttributes(android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_ALARM)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC).build())
                setDataSource(applicationContext,Uri.parse(intent?.getStringExtra("sound_uri")?:""))
                setOnCompletionListener { stopSelf() }
                setOnErrorListener { _,_,_ -> stopSelf();true }
                prepare();start()
            }
        } catch(_:Exception) { stopSelf() }
        return START_NOT_STICKY
    }
    override fun onDestroy() {
        try { player?.stop() } catch(_:Exception) {}
        player?.release();player=null
        super.onDestroy()
    }
}

class CompanionAlarmReceiver:BroadcastReceiver() {
    override fun onReceive(context:Context,intent:Intent) {
        CompanionAlerts.onAlarm(context,intent.action?:return,intent.getIntExtra("alarm_id",0))
    }
}

class CompanionBootReceiver:BroadcastReceiver() {
    override fun onReceive(context:Context,intent:Intent) {
        CompanionAlerts.refresh(context)
    }
}

private val ink=Color(0xFF173A60)
private val pale=Color(0xFFF6FAFF)
private val gold=Color(0xFFBC8D35)

@Composable
fun RemindersScreen(modifier:Modifier=Modifier,onPickRingtone:(Boolean)->Unit) {
    val c=LocalContext.current
    val store=remember { ReminderStore(c) }
    var revision by remember { mutableIntStateOf(0) }
    val rows=remember(revision) { store.all() }
    var kind by remember { mutableStateOf("قسط") }
    var title by remember { mutableStateOf("") }
    val dateDefault=remember { val (y,m,d)=gregorianToJalali(LocalDate.now()); "%04d/%02d/%02d".format(y,m,d) }
    var jalali by remember { mutableStateOf(dateDefault) }
    var clock by remember { mutableStateOf("09:00") }
    var repeat by remember { mutableStateOf(false) }
    LazyColumn(modifier.fillMaxSize().padding(12.dp),verticalArrangement=Arrangement.spacedBy(10.dp), contentPadding=PaddingValues(bottom=22.dp)) {
        item {
            Card(colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                    Text("یادآور تازه",fontSize=20.sp,fontWeight=FontWeight.Bold,color=ink)
                    Text("برای قسط یا جلسه، تاریخ شمسی و ساعت را وارد کن.",fontSize=12.sp,color=Color.Gray)
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected=kind=="قسط",onClick={kind="قسط"},label={Text("قسط")})
                        FilterChip(selected=kind=="جلسه",onClick={kind="جلسه"},label={Text("جلسه")})
                    }
                    OutlinedTextField(value=title,onValueChange={title=it},label={Text("عنوان یا توضیح")},singleLine=true,modifier=Modifier.fillMaxWidth())
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value=jalali,onValueChange={jalali=it},label={Text("تاریخ شمسی")},singleLine=true,modifier=Modifier.weight(1.5f))
                        OutlinedTextField(value=clock,onValueChange={clock=it},label={Text("ساعت")},singleLine=true,modifier=Modifier.weight(1f),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Text))
                    }
                    Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()) {
                        Text("تکرار ماهانه در تقویم شمسی",modifier=Modifier.weight(1f),fontSize=13.sp)
                        Switch(checked=repeat,onCheckedChange={repeat=it})
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick={onPickRingtone(false)},modifier=Modifier.weight(1f)) { Text("رینگتون گوشی",fontSize=12.sp) }
                        OutlinedButton(onClick={onPickRingtone(true)},modifier=Modifier.weight(1f)) { Text("فایل آهنگ",fontSize=12.sp) }
                    }
                    Button(onClick={
                        val dp=jalali.replace('/','-').toLatinDigitsLocal().split('-')
                        val tp=clock.toLatinDigitsLocal().split(':')
                        try {
                            require(title.isNotBlank()) { "عنوان یادآور را وارد کن" }
                            require(dp.size==3 && tp.size==2) { "تاریخ یا ساعت نادرست است" }
                            val y=dp[0].toInt();val m=dp[1].toInt();val d=dp[2].toInt()
                            val hh=tp[0].toInt();val mm=tp[1].toInt()
                            require(isValidJalali(y,m,d) && hh in 0..23 && mm in 0..59)
                            val millis=jalaliToGregorian(y,m,d).atTime(hh,mm).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                            require(millis>System.currentTimeMillis()) { "زمان یادآور باید در آینده باشد" }
                            store.add(kind,title.trim(),millis,repeat,CompanionAlerts.ringtone(c,false))
                            title=""; revision++;CompanionAlerts.requestPermissions(c as Activity);CompanionAlerts.refresh(c)
                            Toast.makeText(c,"یادآور ذخیره شد",Toast.LENGTH_SHORT).show()
                        } catch(e:Exception){Toast.makeText(c,e.message?:"مقدار تاریخ یا ساعت صحیح نیست",Toast.LENGTH_LONG).show()}
                    },modifier=Modifier.fillMaxWidth()) { Text("ثبت یادآور") }
                }
            }
        }
        item { Text("یادآورهای ثبت‌شده",fontSize=17.sp,fontWeight=FontWeight.Bold,color=ink) }
        if(rows.isEmpty()) item { Text("هنوز یادآوری ثبت نشده است.",color=Color.Gray) }
        items(rows,key={it.id}) { item ->
            Card(colors=CardDefaults.cardColors(containerColor=pale),shape=RoundedCornerShape(15.dp)) {
                Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text("${item.kind}  •  ${item.title}",fontWeight=FontWeight.Bold,color=ink)
                        val z=Instant.ofEpochMilli(item.whenMillis).atZone(ZoneId.systemDefault())
                        val (y,m,d)=gregorianToJalali(z.toLocalDate())
                        Text("${"%04d/%02d/%02d".format(y,m,d).toPersianDigitsLocal()}  ${z.toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm")).toPersianDigitsLocal()}${if(item.monthly) "  •  ماهانه" else ""}${if(!item.enabled) "  •  انجام‌شده" else ""}",fontSize=12.sp,color=Color.Gray)
                    }
                    TextButton(onClick={store.delete(item.id);CompanionAlerts.refresh(c);revision++}) { Text("حذف",color=Color(0xFFB3261E)) }
                }
            }
        }
    }
}

@Composable
fun PrayerTimesScreen(modifier:Modifier=Modifier,onPickRingtone:(Boolean)->Unit) {
    val c=LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var cityExpanded by remember { mutableStateOf(false) }
    val index=CompanionAlerts.selectedCity(c)
    val city=prayerCities[index]
    val isEnabled=CompanionAlerts.enabled(c,"prayer_enabled")
    val times=remember(index,tick) { prayerTimes(LocalDate.now(ZoneId.of(city.zone)),city,CompanionAlerts.offset(c)) }
    Column(modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(14.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFF163A63))) {
            Column(Modifier.fillMaxWidth().padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                Text("اوقات شرعی امروز",fontSize=22.sp,fontWeight=FontWeight.Bold,color=Color.White)
                Text("محاسبهٔ آفلاین خورشیدی؛ ممکن است با جدول رسمی شهر اختلاف داشته باشد.",fontSize=12.sp,color=Color(0xFFD7E7F8))
                Text("شهر: ${city.name}",color=Color(0xFFF2D59A),fontWeight=FontWeight.Bold)
                times.forEach { (name,time) ->
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                        Text(name,color=Color.White,fontSize=17.sp)
                        Text(time.format(DateTimeFormatter.ofPattern("HH:mm")).toPersianDigitsLocal(),color=Color(0xFFF2D59A),fontWeight=FontWeight.Bold,fontSize=19.sp)
                    }
                }
            }
        }
        Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
            Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Text("هشدار صوتی اذان",modifier=Modifier.weight(1f),fontWeight=FontWeight.Bold,color=ink)
                    Switch(checked=isEnabled,onCheckedChange={ CompanionAlerts.setEnabled(c,"prayer_enabled",it);if(it) CompanionAlerts.requestPermissions(c as Activity);tick++ })
                }
                if(isEnabled) {
                    Box {
                        OutlinedButton(onClick={cityExpanded=true},modifier=Modifier.fillMaxWidth()) { Text("انتخاب شهر: ${city.name}  ▾") }
                        DropdownMenu(expanded=cityExpanded,onDismissRequest={cityExpanded=false}) {
                            prayerCities.forEachIndexed { i,value -> DropdownMenuItem(text={Text(value.name)},onClick={cityExpanded=false;CompanionAlerts.selectCity(c,i);tick++}) }
                        }
                    }
                    listOf("صبح","ظهر","مغرب").forEachIndexed { i,label ->
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Text("هشدار $label",modifier=Modifier.weight(1f))
                            Switch(checked=CompanionAlerts.enabled(c,"prayer_$i",true),onCheckedChange={CompanionAlerts.setEnabled(c,"prayer_$i",it);tick++})
                        }
                    }
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text("تصحیح زمان (دقیقه): ${CompanionAlerts.offset(c).toString().toPersianDigitsLocal()}",modifier=Modifier.weight(1f),fontSize=12.sp)
                        TextButton(onClick={ CompanionAlerts.changeOffset(c,CompanionAlerts.offset(c)-1);tick++ }) {Text("−")}
                        TextButton(onClick={ CompanionAlerts.changeOffset(c,CompanionAlerts.offset(c)+1);tick++ }) {Text("+")}
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick={onPickRingtone(false)},modifier=Modifier.weight(1f)) { Text("رینگتون",fontSize=12.sp) }
                        OutlinedButton(onClick={onPickRingtone(true)},modifier=Modifier.weight(1f)) { Text("فایل اذان / آهنگ",fontSize=12.sp) }
                    }
                    Text("برای پخش اذان کامل، یک فایل اذان را به‌عنوان زنگ انتخاب کن. پخش صدا به تنظیمات گوشی و مجوز اعلان وابسته است.",fontSize=12.sp,color=Color.Gray)
                }
            }
        }
    }
}

@Composable
fun PersistentDaySettings(modifier:Modifier=Modifier) {
    val c=LocalContext.current
    var enabled by remember { mutableStateOf(CompanionAlerts.enabled(c,"day_notification")) }
    Card(modifier=modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
        Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("تاریخ در اعلان دائمی",fontWeight=FontWeight.Bold,color=ink)
                    Text("تاریخ شمسی و قمری، با نشان روز ماه در آیکون اعلان",fontSize=12.sp,color=Color.Gray)
                }
                Switch(checked=enabled,onCheckedChange={enabled=it;CompanionAlerts.setEnabled(c,"day_notification",it); if(it) CompanionAlerts.requestPermissions(c as Activity)})
            }
            Text("چیدمان آیکون اعلان کنار ساعت یا سایر نمادها را سیستم‌عامل تعیین می‌کند. با خاموش‌کردن این گزینه اعلان و زمان‌بندی آن حذف می‌شود.",fontSize=11.sp,color=Color.Gray)
            OutlinedButton(onClick={CompanionAlerts.askExactAlarmSettings(c as Activity)},modifier=Modifier.fillMaxWidth()) { Text("مجوز هشدارهای دقیق در تنظیمات اندروید") }
        }
    }
}

private fun String.toLatinDigitsLocal() = map { c -> when(c) {'۰'->'0';'۱'->'1';'۲'->'2';'۳'->'3';'۴'->'4';'۵'->'5';'۶'->'6';'۷'->'7';'۸'->'8';'۹'->'9';'٠'->'0';'١'->'1';'٢'->'2';'٣'->'3';'٤'->'4';'٥'->'5';'٦'->'6';'٧'->'7';'٨'->'8';'٩'->'9';else->c} }.joinToString("")
private fun String.toPersianDigitsLocal() = map { c -> if(c in '0'..'9') "۰۱۲۳۴۵۶۷۸۹"[c-'0'] else c }.joinToString("")
