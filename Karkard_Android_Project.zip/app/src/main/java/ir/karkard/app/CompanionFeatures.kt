package ir.karkard.app

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.widget.RemoteViews
import android.graphics.Typeface
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.app.PendingIntent
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.mutableStateListOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import androidx.compose.ui.text.input.ImeAction
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.io.File
import java.io.FileOutputStream
import org.json.JSONObject
import org.json.JSONArray
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.*

internal fun formattedSyncStamp(millis:Long):String {
    val local=Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault())
    val (y,m,d)=gregorianToJalali(local.toLocalDate())
    return "%04d/%02d/%02d  %02d:%02d".format(Locale.ROOT,y,m,d,local.hour,local.minute).toPersianDigitsLocal()
}

// Companion features intentionally use a separate SQLite database. Work records are untouched.
data class PersonalReminder(val id: Long, val kind: String, val title: String,
    val whenMillis: Long, val monthly: Boolean, val soundUri: String, val enabled: Boolean = true)

class ReminderStore(context: Context): SQLiteOpenHelper(context, "vaghtnegar_reminders.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE reminders(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,title TEXT NOT NULL,when_ms INTEGER NOT NULL,monthly INTEGER NOT NULL DEFAULT 0,sound TEXT DEFAULT '',enabled INTEGER NOT NULL DEFAULT 1)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun all(): List<PersonalReminder> {
        val result = mutableListOf<PersonalReminder>()
        readableDatabase.rawQuery("SELECT id,kind,title,when_ms,monthly,sound,enabled FROM reminders ORDER BY when_ms",null).use { c ->
            while(c.moveToNext()) result.add(PersonalReminder(c.getLong(0),c.getString(1),c.getString(2),c.getLong(3),c.getInt(4)==1,c.getString(5)?:"",c.getInt(6)==1))
        }
        return result
    }
    fun byId(id: Long): PersonalReminder? = all().firstOrNull { it.id == id }
    /** Reminders due on the selected Jalali day, including monthly repetitions.
     * The same underlying reminder records are used by the reminder editor and scheduler.
     * We intentionally include elapsed one-off reminders: they remain visible on their day.
     */
    fun forJalaliDay(date: String): List<PersonalReminder> {
        val parts = date.split('-').mapNotNull { it.toIntOrNull() }
        if (parts.size != 3 || !isValidJalali(parts[0], parts[1], parts[2])) return emptyList()
        val (year, month, day) = parts
        val selectedMonthIndex = year * 12 + month
        val zone = ZoneId.systemDefault()
        return all().filter { reminder ->
            val originalDate = Instant.ofEpochMilli(reminder.whenMillis).atZone(zone).toLocalDate()
            val (originalYear, originalMonth, originalDay) = gregorianToJalali(originalDate)
            if (!reminder.monthly) {
                originalYear == year && originalMonth == month && originalDay == day
            } else {
                val reminderMonthIndex = originalYear * 12 + originalMonth
                selectedMonthIndex >= reminderMonthIndex &&
                    day == originalDay.coerceAtMost(jalaliMonthLength(year, month))
            }
        }.sortedWith(compareBy({
            Instant.ofEpochMilli(it.whenMillis).atZone(zone).toLocalTime()
        }, { it.id }))
    }
    fun add(kind: String, title: String, millis: Long, monthly: Boolean, sound: String): Long {
        val row = ContentValues().apply { put("kind",kind);put("title",title);put("when_ms",millis);put("monthly",if(monthly) 1 else 0);put("sound",sound);put("enabled",1) }
        return writableDatabase.insert("reminders", null, row)
    }
    fun update(id: Long, kind: String, title: String, millis: Long, monthly: Boolean, sound: String) {
        val row = ContentValues().apply {
            put("kind", kind); put("title", title); put("when_ms", millis)
            put("monthly", if (monthly) 1 else 0); put("sound", sound); put("enabled", 1)
        }
        writableDatabase.update("reminders", row, "id=?", arrayOf(id.toString()))
    }
    fun delete(id: Long) { writableDatabase.delete("reminders","id=?",arrayOf(id.toString())) }
    fun updateTime(id: Long, millis: Long, enabled: Boolean) {
        writableDatabase.update("reminders",ContentValues().apply { put("when_ms",millis); put("enabled",if(enabled) 1 else 0) },"id=?",arrayOf(id.toString()))
    }
}

internal data class PrayerCity(val name:String, val latitude:Double, val longitude:Double, val zone:String, val slug:String = "tehran")
internal val prayerCities = listOf(
    PrayerCity("تهران",35.6892,51.3890,"Asia/Tehran","tehran"),
    PrayerCity("مشهد",36.2605,59.6168,"Asia/Tehran","mashhad"),
    PrayerCity("قم",34.6416,50.8746,"Asia/Tehran","qom"),
    PrayerCity("اصفهان",32.6546,51.6680,"Asia/Tehran","isfahan"),
    PrayerCity("شیراز",29.5918,52.5837,"Asia/Tehran","shiraz"),
    PrayerCity("تبریز",38.0962,46.2738,"Asia/Tehran","tabriz"),
    PrayerCity("اهواز",31.3183,48.6706,"Asia/Tehran","ahvaz"),
    PrayerCity("کرمان",30.2839,57.0834,"Asia/Tehran","kerman"),
    PrayerCity("رشت",37.2808,49.5832,"Asia/Tehran","rasht"),
    PrayerCity("بندرعباس",27.1832,56.2666,"Asia/Tehran","bandar-abbas"),
    PrayerCity("کرج",35.8355,50.9916,"Asia/Tehran","karaj"),
    PrayerCity("یزد",31.8974,54.3569,"Asia/Tehran","yazd"),
    PrayerCity("ارومیه",37.5527,45.0761,"Asia/Tehran","urmia"),
    PrayerCity("زاهدان",29.4963,60.8629,"Asia/Tehran","zahedan"),
    PrayerCity("زنجان",36.6736,48.4787,"Asia/Tehran","zanjan"),
    PrayerCity("ساری",36.5633,53.0601,"Asia/Tehran","sari"),
    PrayerCity("گرگان",36.8456,54.4393,"Asia/Tehran","gorgan"),
    PrayerCity("سنندج",35.3149,46.9988,"Asia/Tehran","sanandaj"),
    PrayerCity("همدان",34.7989,48.5150,"Asia/Tehran","hamedan"),
    PrayerCity("بوشهر",28.9234,50.8203,"Asia/Tehran","bushehr")
)

/** Approximate solar calculation. Official local prayer timetables may differ. */
internal fun prayerTimes(date: LocalDate, city: PrayerCity, adjustmentMin: Int): Map<String, ZonedDateTime> {
    val zone=ZoneId.of(city.zone)
    val n=date.dayOfYear.toDouble()
    val gamma=2.0*Math.PI/365.0*(n-1.0)
    val eq=229.18*(0.000075+0.001868*cos(gamma)-0.032077*sin(gamma)-0.014615*cos(2*gamma)-0.040849*sin(2*gamma))
    val decl=0.006918-0.399912*cos(gamma)+0.070257*sin(gamma)-0.006758*cos(2*gamma)+0.000907*sin(2*gamma)-0.002697*cos(3*gamma)+0.00148*sin(3*gamma)
    val localOffset=date.atTime(12,0).atZone(zone).offset.totalSeconds/60.0
    val noon=720.0-4.0*city.longitude-eq+localOffset
    val lat=Math.toRadians(city.latitude)
    fun angle(altitude:Double): Double {
        val cosH=(sin(Math.toRadians(altitude))-sin(lat)*sin(decl))/(cos(lat)*cos(decl))
        return Math.toDegrees(acos(cosH.coerceIn(-1.0,1.0)))
    }
    fun at(minutes:Double): ZonedDateTime {
        val base=date.atStartOfDay(zone)
        return base.plusMinutes(minutes.roundToLong())
    }
    val dawn=noon-4.0*angle(-17.7)
    val sunrise=noon-4.0*angle(-0.833)
    val sunset=noon+4.0*angle(-0.833)
    val maghrib=noon+4.0*angle(-4.5)
    val midnight=sunset+(1440.0+dawn-sunset)/2.0
    return linkedMapOf(
        "اذان صبح" to at(dawn+adjustmentMin),
        "طلوع آفتاب" to at(sunrise+adjustmentMin),
        "اذان ظهر" to at(noon+adjustmentMin),
        "غروب آفتاب" to at(sunset+adjustmentMin),
        "اذان مغرب" to at(maghrib+adjustmentMin),
        "نیمه‌شب شرعی" to at(midnight+adjustmentMin)
    )
}

/** Third-party public API using the Institute of Geophysics, University of Tehran
 * calculation METHOD; this is not an official University-hosted service. */
internal object PrayerRemote {
    private fun prefs(c:Context) = c.getSharedPreferences("vaghtnegar_prayer_remote", Context.MODE_PRIVATE)
    private fun getJson(url:String): JSONObject {
        val connection=(URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout=10000; readTimeout=12000
            setRequestProperty("User-Agent", "Morakh/0.28 (Android application)")
        }
        try {
            if(connection.responseCode!=200) throw java.io.IOException("HTTP ${connection.responseCode}")
            return connection.inputStream.bufferedReader(Charsets.UTF_8).use { JSONObject(it.readText()) }
        } finally { connection.disconnect() }
    }
    fun cities(c:Context): List<PrayerCity> {
        val serialized=prefs(c).getString("iran_cities", "").orEmpty()
        if(serialized.isBlank()) return prayerCities
        return try {
            val array=JSONArray(serialized)
            val list=(0 until array.length()).map { i ->
                val item=array.getJSONObject(i)
                PrayerCity(item.getString("city_name"),item.getDouble("latitude"),item.getDouble("longitude"),
                    item.optString("timezone_id","Asia/Tehran"),item.getString("slug"))
            }.filter { it.zone=="Asia/Tehran" }
            if(list.size<prayerCities.size) prayerCities else list.sortedWith(compareBy<PrayerCity> { it.name!="تهران" }.thenBy { it.name })
        } catch (_:Exception) { prayerCities }
    }
    suspend fun fetchCities(c:Context): Int = withContext(Dispatchers.IO) {
        val rows=getJson("https://www.persian-calendar.com/api/timezones?country_code=IR").getJSONArray("data")
        val filtered=JSONArray()
        for(i in 0 until rows.length()) {
            val obj=rows.getJSONObject(i)
            if(obj.optString("country_code")=="IR" && obj.optString("slug").isNotBlank() &&
                obj.has("latitude") && obj.has("longitude")) filtered.put(obj)
        }
        if(filtered.length()<15) throw java.io.IOException("فهرست دریافتی شهرها ناقص بود")
        prefs(c).edit().putString("iran_cities",filtered.toString()).apply()
        filtered.length()
    }
    private fun key(city:PrayerCity,date:LocalDate):String = "${city.slug}_${date}"
    fun cached(c:Context,city:PrayerCity,date:LocalDate):Map<String,ZonedDateTime>? {
        val value=prefs(c).getString(key(city,date),null) ?: return null
        return try {
            val json=JSONObject(value)
            val result=linkedMapOf<String,ZonedDateTime>()
            val zone=ZoneId.of(city.zone)
            for ((title,k) in listOf(
                "اذان صبح" to "fajr", "طلوع آفتاب" to "sunrise",
                "اذان ظهر" to "dhuhr", "غروب آفتاب" to "sunset",
                "اذان مغرب" to "maghrib", "نیمه‌شب شرعی" to "midnight"
            )) {
                val time=LocalTime.parse(json.getString(k).take(5))
                result[title]=date.atTime(time).atZone(zone)
            }
            result
        } catch(_:Exception) { null }
    }
    suspend fun fetchDay(c:Context,city:PrayerCity,date:LocalDate):Boolean = withContext(Dispatchers.IO) {
        val (y,m,d)=gregorianToJalali(date)
        val safeSlug=URLEncoder.encode(city.slug,"UTF-8")
        val root=getJson("https://www.persian-calendar.com/api/prayer-times?city=$safeSlug&year=$y&month=$m&day=$d")
        val times=root.getJSONObject("times")
        for(k in listOf("fajr","sunrise","dhuhr","sunset","maghrib","midnight")) LocalTime.parse(times.getString(k).take(5))
        prefs(c).edit().putString(key(city,date),times.toString())
            .putLong("last_prayer_sync", System.currentTimeMillis()).apply()
        true
    }
    fun resolved(c:Context,city:PrayerCity,date:LocalDate,adjustment:Int):Map<String,ZonedDateTime> {
        val base=cached(c,city,date) ?: prayerTimes(date,city,0)
        return base.mapValues { (_,v) -> v.plusMinutes(adjustment.toLong()) }
    }
}

/** Ahlolbait audio catalog cannot be redistributed or hot-linked without confirmed
 * per-record source URLs and rights. Users may select their own lawfully acquired
 * audio through Android's document picker; only that document's URI is stored. */

/** Download-on-demand adhan catalog linked from Ahlolbait Institute's public listing.
 * Titles and HTTPS MP3 links were checked against the actual catalog article.
 * Audio files are NOT bundled or fetched in bulk. */
internal data class CatalogAdhan(val id:String, val muezzin:String, val url:String)

internal object AhlolbaitAdhans {
    private const val BASE = "https://static.ahlolbait.com/files/ahlolbait/old/u12/download/"
    const val SOURCE = "https://ahlolbait.com/content/13886/مجموعه-صوتی-اذان-های-زیبا-و-ماندگار"
    val entries = listOf(
        CatalogAdhan("rahim", "رحیم مؤذن‌زاده اردبیلی", BASE + "rahim_moazenzadeh.mp3"),
        CatalogAdhan("salim", "سلیم مؤذن‌زاده اردبیلی", BASE + "salim_moazenzadeh.mp3"),
        CatalogAdhan("razi", "قاسم رضیعی", BASE + "13920230000576.mp3"),
        CatalogAdhan("rezaian", "حسن رضائیان", BASE + "13920305000907.mp3"),
        CatalogAdhan("sobhedel", "حسین صبحدل", BASE + "13920305000909.mp3"),
        CatalogAdhan("karami", "حسین کرمی", BASE + "13920305000910.mp3"),
        CatalogAdhan("sharif", "حسینعلی شریف", BASE + "13920305000915.mp3"),
        CatalogAdhan("alajgerdi", "حمیدرضا الاجگردی", BASE + "13920305000918.mp3"),
        CatalogAdhan("ghalwash", "راغب مصطفی غلوش", BASE + "13920305000921.mp3")
    )
    fun localFile(c:Context, item:CatalogAdhan):File = File(File(c.filesDir,"adhans"),"ahlolbait_${item.id}.mp3")
    /** Physically removes only the downloaded audio owned by this catalog entry.
     * The catalog entry and muezzin name remain available for a fresh download.
     * An externally selected document URI is NEVER deleted here.
     */
    fun deleteDownloaded(c:Context, item:CatalogAdhan):Boolean {
        require(entries.any { it.id==item.id && it.url==item.url }) { "اذان ناشناخته" }
        val audio=localFile(c,item)
        val partial=File(audio.parentFile,"${item.id}.part")
        val removed=!audio.exists() || audio.delete()
        if (partial.exists()) partial.delete()
        return removed && !audio.exists()
    }
    suspend fun download(c:Context,item:CatalogAdhan):File=withContext(Dispatchers.IO) {
        require(entries.any { it.id==item.id && it.url==item.url }) { "فایل ناشناخته" }
        val target=localFile(c,item)
        target.parentFile?.mkdirs()
        val temp=File(target.parentFile,"${item.id}.part")
        val connection=(URL(item.url).openConnection() as HttpURLConnection).apply {
            connectTimeout=15000; readTimeout=25000; instanceFollowRedirects=false
            setRequestProperty("User-Agent","Morakh/0.28")
        }
        try {
            if(connection.responseCode!=200) throw java.io.IOException("خطای دانلود ${connection.responseCode}")
            val kind=connection.contentType.orEmpty().lowercase(Locale.ROOT)
            if(!kind.contains("audio") && !kind.contains("octet-stream")) throw java.io.IOException("پاسخ سایت صوت نیست")
            val maxBytes=25L*1024*1024
            if(connection.contentLengthLong>maxBytes) throw java.io.IOException("حجم فایل بیش از حد مجاز است")
            var size=0L
            connection.inputStream.use { input -> FileOutputStream(temp).use { output ->
                val bytes=ByteArray(8192)
                while(true) {
                    val n=input.read(bytes)
                    if(n<0) break
                    size+=n
                    if(size>maxBytes) throw java.io.IOException("حجم فایل بیش از حد مجاز است")
                    output.write(bytes,0,n)
                }
            } }
            if(size<1024) throw java.io.IOException("فایل صوتی ناقص دریافت شد")
            if(!temp.renameTo(target)) throw java.io.IOException("ذخیره فایل امکان‌پذیر نبود")
            target
        } catch(e:Exception) { temp.delete();throw e }
        finally { connection.disconnect() }
    }
}

internal object AdhanSelection {
    val revision = androidx.compose.runtime.mutableIntStateOf(0)
    private fun prefs(c: Context) = c.getSharedPreferences("vaghtnegar_adhan_choices",Context.MODE_PRIVATE)
    fun pending(c: Context): String = prefs(c).getString("pending_uri", "").orEmpty()
    fun pendingName(c: Context): String = prefs(c).getString("pending_muezzin", "").orEmpty()
    fun setPending(c: Context, uri: String) {
        prefs(c).edit().putString("pending_uri",uri).putString("pending_muezzin", "نام مؤذن را وارد کنید").apply()
        revision.intValue++
    }
    fun setMuezzin(c: Context, name: String) {
        prefs(c).edit().putString("pending_muezzin",name.take(90)).apply()
    }
    fun clearPending(c: Context) {
        prefs(c).edit().remove("pending_uri").remove("pending_muezzin").apply()
        revision.intValue++
    }
    fun clearOldCatalog(c: Context) {
        if (prefs(c).getBoolean("legacy_cleared", false)) return
        val dir=File(c.filesDir,"adhans")
        listOf("Muslim calling to prayer.ogg","Adhan.ogg","AzaanMaahur.ogg").forEach { name ->
            val f=File(dir,name)
            if (f.exists()) {
                val current=CompanionAlerts.ringtone(c,true)
                if (current==Uri.fromFile(f).toString()) CompanionAlerts.saveRingtone(c,true,"")
                f.delete()
            }
        }
        prefs(c).edit().putBoolean("legacy_cleared", true).apply()
    }
}

internal object CompanionAlerts {
    private const val CHANNEL_DAY = "vaghtnegar_day_v3"
    private const val CHANNEL_REMIND = "vaghtnegar_remind_v1"
    private const val CHANNEL_PRAYER = "vaghtnegar_prayer_v1"
    private const val DAY_ID=140501
    private fun prefs(c: Context)=c.getSharedPreferences("vaghtnegar_companion",Context.MODE_PRIVATE)
    fun enabled(c:Context,key:String,default:Boolean=false)=prefs(c).getBoolean(key,default)
    fun masterEnabled(c:Context):Boolean=enabled(c,"all_alerts_enabled",true)
    fun categoryEnabled(c:Context,kind:String):Boolean = when(kind) {
        "قسط" -> enabled(c,"installment_alerts",true)
        "جلسه" -> enabled(c,"meeting_alerts",true)
        else -> true
    }
    fun setEnabled(c:Context,key:String,value:Boolean) {
        prefs(c).edit().putBoolean(key,value).apply()
        if (!value && key in setOf("all_alerts_enabled","prayer_enabled","installment_alerts","meeting_alerts")) {
            try { c.stopService(Intent(c,AlertSoundService::class.java)) } catch (_:Exception) { }
        }
        if (!value && key=="all_alerts_enabled") {
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancelAll()
        }
        refresh(c)
    }
    fun selectedCity(c:Context):Int {
        val selected=prefs(c).getString("city_slug","tehran")
        return PrayerRemote.cities(c).indexOfFirst { it.slug==selected }.takeIf { it>=0 } ?: 0
    }
    fun selectCity(c:Context,index:Int) {
        val city=PrayerRemote.cities(c).getOrNull(index) ?: return
        prefs(c).edit().putString("city_slug",city.slug).apply(); refresh(c)
    }
    fun offset(c:Context):Int=prefs(c).getInt("offset",0)
    fun changeOffset(c:Context,value:Int) { prefs(c).edit().putInt("offset",value.coerceIn(-30,30)).apply();refresh(c) }
    fun ringtone(c:Context,prayer:Boolean):String=prefs(c).getString(if(prayer) "adhan_sound" else "reminder_sound","")?:""
    fun saveRingtone(c:Context,prayer:Boolean,uri:String) {
        prefs(c).edit().putString(if(prayer) "adhan_sound" else "reminder_sound",uri)
            .putLong(if(prayer) "adhan_sound_version" else "reminder_sound_version",System.currentTimeMillis()).apply()
    }
    fun reminderSoundVersion(c:Context):Long=prefs(c).getLong("reminder_sound_version",0L)
    fun channels(c:Context) {
        val manager=c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel(CHANNEL_DAY,"تاریخ و اذان بعدی",NotificationManager.IMPORTANCE_DEFAULT).apply {
            setSound(null,null);enableVibration(false)
            description="تاریخ امروز و زمان اذان بعدی، بدون صدا و لرزش";setShowBadge(false)
        })
        manager.createNotificationChannel(NotificationChannel(CHANNEL_REMIND,"یادآور اقساط و جلسات",NotificationManager.IMPORTANCE_HIGH).apply { description="یادآوری‌های شخصی مورخ";setSound(null,null) })
        manager.createNotificationChannel(NotificationChannel(CHANNEL_PRAYER,"هشدار اوقات شرعی",NotificationManager.IMPORTANCE_HIGH).apply { description="هشدار صبح، ظهر و مغرب";setSound(null,null) })
    }
    fun hasNotificationPermission(c:Context)=Build.VERSION.SDK_INT<33 || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED
    fun requestPermissions(activity:Activity) {
        if(Build.VERSION.SDK_INT>=33 && !hasNotificationPermission(activity)) activity.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),911)
    }
    private fun request(c:Context,action:String,id:Int):PendingIntent {
        val intent=Intent(c,CompanionAlarmReceiver::class.java).setAction(action).putExtra("alarm_id",id)
        return PendingIntent.getBroadcast(c,id,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
    private fun schedule(c:Context,time:Long,action:String,id:Int) {
        if(time<=System.currentTimeMillis()) return
        val manager=c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pending=request(c,action,id)
        try {
            if(Build.VERSION.SDK_INT<31 || manager.canScheduleExactAlarms()) manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,time,pending)
            else manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,time,pending)
        } catch(_:SecurityException) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,time,pending)
        }
    }
    private fun cancel(c:Context,action:String,id:Int) {
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(request(c,action,id))
    }
    fun askExactAlarmSettings(activity:Activity) {
        if(Build.VERSION.SDK_INT>=31) try {
            activity.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${activity.packageName}")))
        } catch (_:Exception) { Toast.makeText(activity,"مجوز هشدار دقیق از تنظیمات گوشی قابل مدیریت است",Toast.LENGTH_LONG).show() }
    }
    private val jalaliMonthNames = listOf("فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند")
    private val jalaliWeekdayNames = listOf("یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه","شنبه")
    private fun dayIcon(c:Context,day:Int):Int {
        // Each day uses its own white monochrome 24x24 PNG; no generic bell icon.
        val resource=c.resources.getIdentifier("ic_status_${day.coerceIn(1,31)}","drawable",c.packageName)
        return if(resource != 0) resource else R.drawable.ic_status_1
    }

    private fun nextPrayer(c:Context, now:ZonedDateTime?=null):Pair<String,ZonedDateTime>? {
        val city=PrayerRemote.cities(c).getOrNull(selectedCity(c)) ?: prayerCities.first()
        val current=now ?: ZonedDateTime.now(ZoneId.of(city.zone))
        return (0L..2L).asSequence().flatMap { offsetDays ->
            val times=PrayerRemote.resolved(c,city,current.toLocalDate().plusDays(offsetDays),offset(c))
            listOf("اذان صبح","اذان ظهر","اذان مغرب").asSequence().mapNotNull { name ->
                times[name]?.let { name to it }
            }
        }.filter { it.second.isAfter(current) }.minByOrNull { it.second.toInstant() }
    }

    private fun dayViews(c:Context,dateText:String,lunar:String,gregorian:String,dayText:String,nextPrayerText:String,expanded:Boolean):RemoteViews {
        // Exactly two user-facing lines: Shamsi date + next adhan, then Hijri + Gregorian.
        // Strip calculation/reference annotations from the notification only.
        val cleanLunar = lunar.substringBefore(" (").trim()
        val secondLine = "$cleanLunar    $gregorian"
        // One TextView guarantees that date and next adhan are in the SAME physical row.
        // Date is bold/large, adhan matches the smaller Hijri/Gregorian text.
        val firstLine = SpannableString("$dateText    $nextPrayerText")
        val prayerStart = dateText.length + 4
        firstLine.setSpan(StyleSpan(Typeface.BOLD), 0, dateText.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        firstLine.setSpan(
            RelativeSizeSpan(if (expanded) 13f / 18f else 12f / 16f),
            prayerStart, firstLine.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        firstLine.setSpan(
            ForegroundColorSpan(android.graphics.Color.rgb(89, 111, 113)),
            prayerStart, firstLine.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        return RemoteViews(c.packageName, if (expanded) R.layout.notification_day else R.layout.notification_day_compact).apply {
            setTextViewText(R.id.day_badge, dayText)
            setTextViewText(R.id.notification_primary, firstLine)
            setTextViewText(R.id.notification_subtitle, secondLine)
        }
    }
    fun showDay(c:Context) {
        val manager=c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if(!masterEnabled(c) || !enabled(c,"day_notification") || !hasNotificationPermission(c)) {
            manager.cancel(DAY_ID);return
        }
        channels(c)
        val today=LocalDate.now()
        val (y,m,d)=gregorianToJalali(today)
        // Compute locally: MainActivity's jalaliWeekday helper is file-private.
        val weekday=jalaliWeekdayNames.getOrNull(today.dayOfWeek.value % 7).orEmpty()
        val jalali="${weekday} ${d.toString().toPersianDigitsLocal()} ${jalaliMonthNames[m-1]} ${y.toString().toPersianDigitsLocal()}"
        val hijri=jalaliLunarDateDisplay("%04d-%02d-%02d".format(y,m,d))
        val gregorian=today.format(DateTimeFormatter.ofPattern("d MMMM yyyy",Locale.forLanguageTag("fa"))).toPersianDigitsLocal()
        val coming=try { nextPrayer(c) } catch (_:Exception) { null }
        val prayerText=coming?.let { (label,time) ->
            "$label ${time.format(DateTimeFormatter.ofPattern("HH:mm")).toPersianDigitsLocal()}"
        } ?: "اوقات شرعی در دسترس نیست"
        val open=PendingIntent.getActivity(c,0,Intent(c,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification=Notification.Builder(c,CHANNEL_DAY)
            .setSmallIcon(dayIcon(c,d))
            .setContentTitle("$jalali    $prayerText")
            .setContentText("${hijri.substringBefore(" (").trim()}    $gregorian")
            .setSubText(null)
            .setCustomContentView(dayViews(c,jalali,hijri,gregorian,d.toString().toPersianDigitsLocal(),prayerText,false))
            .setCustomBigContentView(dayViews(c,jalali,hijri,gregorian,d.toString().toPersianDigitsLocal(),prayerText,true))
            .setStyle(Notification.DecoratedCustomViewStyle())
            .setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true)
            .setShowWhen(false).setPriority(Notification.PRIORITY_HIGH)
            .setCategory(Notification.CATEGORY_STATUS).setSortKey("0_date_prayer")
            .build()
        manager.notify(DAY_ID,notification)
    }
    private fun notifyEvent(c:Context,title:String,description:String,prayer:Boolean,sound:String,id:Int) {
        if(!masterEnabled(c) || !hasNotificationPermission(c)) return
        if(prayer && !enabled(c,"prayer_enabled")) return
        channels(c)
        val channel=if(prayer) CHANNEL_PRAYER else CHANNEL_REMIND
        val open=PendingIntent.getActivity(c,0,Intent(c,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification=Notification.Builder(c,channel)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title)
            .setContentText(description).setContentIntent(open).setAutoCancel(true)
            .setCategory(Notification.CATEGORY_ALARM).build()
        (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id,notification)
        if (prayer && sound.isBlank()) return // Prayer alert without an adhan file is silent.
        val uri=if(sound.isNotBlank()) Uri.parse(sound) else RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        try {
            val playback=Intent(c,AlertSoundService::class.java).apply {
                putExtra("sound_uri",uri.toString());putExtra("message",title)
            }
            c.startForegroundService(playback)
        } catch(_:Exception) {
            // Some Android versions block background audio. Do not start an
            // unmanaged Ringtone as a fallback: the master-off switch could not
            // reliably stop it. The text notification remains available.
        }
    }
    fun refresh(c:Context) {
        channels(c)
        val master=masterEnabled(c)
        val manager=c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!master) manager.cancelAll()
        showDay(c)
        if(master && enabled(c,"day_notification")) {
            val midnight=LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()+30000L
            schedule(c,midnight,"DAY",9701)
            // Recalculate the banner just after the *next* fajr/noon/maghrib.
            val coming=try { nextPrayer(c) } catch (_:Exception) { null }
            if (coming!=null) schedule(c,coming.second.toInstant().toEpochMilli()+2000L,"DAY_NEXT_PRAYER",9702)
            else cancel(c,"DAY_NEXT_PRAYER",9702)
        } else {
            cancel(c,"DAY",9701)
            cancel(c,"DAY_NEXT_PRAYER",9702)
        }
        val reminders=ReminderStore(c).all()
        reminders.forEach { r ->
            val code=(100000L+r.id).toInt()
            val allowed=master && categoryEnabled(c,r.kind)
            if(allowed && r.enabled && r.whenMillis>System.currentTimeMillis())
                schedule(c,r.whenMillis,"REMINDER",code)
            else {
                cancel(c,"REMINDER",code)
                manager.cancel(190000+code)
            }
        }
        for(i in 0..2) {
            val label=listOf("صبح","ظهر","مغرب")[i]
            val action="PRAYER_$label"
            val code=9800+i
            cancel(c,action,code)
            if(master && enabled(c,"prayer_enabled") && enabled(c,"prayer_$i",true)) {
                val city=PrayerRemote.cities(c)[selectedCity(c)]
                val now=ZonedDateTime.now(ZoneId.of(city.zone))
                val next=(0..2).asSequence().mapNotNull {
                    PrayerRemote.resolved(c,city,now.toLocalDate().plusDays(it.toLong()),offset(c))["اذان $label"]
                }.firstOrNull { it.isAfter(now.plusSeconds(2)) }
                if(next!=null) schedule(c,next.toInstant().toEpochMilli(),action,code)
            } else manager.cancel(192000+code)
        }
    }
    fun onAlarm(c:Context,action:String,id:Int) {
        if (!masterEnabled(c)) { refresh(c); return }
        when {
            action=="DAY" || action=="DAY_NEXT_PRAYER" -> showDay(c)
            action=="REMINDER" -> {
                val r=ReminderStore(c).byId(id.toLong()-100000L) ?: return
                if(r.enabled && categoryEnabled(c,r.kind)) {
                    notifyEvent(c,"یادآور ${r.kind}",r.title,false,r.soundUri,190000+id)
                    if(r.monthly) {
                        val current=Instant.ofEpochMilli(r.whenMillis).atZone(ZoneId.systemDefault())
                        val (y,m,d)=gregorianToJalali(current.toLocalDate())
                        val total=y*12+m // Gregorian-independent Jalali month index
                        val nextY=(total/12)
                        val nextM=(total%12)+1
                        val safeD=d.coerceAtMost(jalaliMonthLength(nextY,nextM))
                        val next=jalaliToGregorian(nextY,nextM,safeD).atTime(current.toLocalTime()).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                        var upcoming=next
                        var safety=0
                        while(upcoming<=System.currentTimeMillis() && safety++<24) {
                            val local=Instant.ofEpochMilli(upcoming).atZone(ZoneId.systemDefault())
                            val (cy,cm,cd)=gregorianToJalali(local.toLocalDate())
                            val ix=cy*12+cm
                            val yy=ix/12
                            val mm=ix%12+1
                            upcoming=jalaliToGregorian(yy,mm,cd.coerceAtMost(jalaliMonthLength(yy,mm)))
                                .atTime(local.toLocalTime()).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                        }
                        ReminderStore(c).updateTime(r.id,upcoming,true)
                    } else ReminderStore(c).updateTime(r.id,r.whenMillis,false)
                }
            }
            action.startsWith("PRAYER_") -> {
                val label=action.removePrefix("PRAYER_")
                val prayerIndex=listOf("صبح","ظهر","مغرب").indexOf(label)
                if(enabled(c,"prayer_enabled") && prayerIndex>=0 && enabled(c,"prayer_$prayerIndex",true)) {
                    val city=PrayerRemote.cities(c)[selectedCity(c)]
                    val today=LocalDate.now(ZoneId.of(city.zone))
                    val source=if(PrayerRemote.cached(c,city,today)!=null) "روش محاسباتی دانشگاه تهران" else "تخمینی آفلاین"
                    notifyEvent(c,"وقت اذان $label","${city.name} • $source",true,ringtone(c,true),192000+id)
                }
            }
        }
        refresh(c)
    }
}

/** Plays an alarm sound (including a user-selected audio file) with a foreground notification. */
class AlertSoundService:android.app.Service() {
    private var player:android.media.MediaPlayer?=null
    private val playbackId=240016
    override fun onBind(intent:Intent?):android.os.IBinder?=null
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
        if(intent?.action=="STOP_SOUND" || !CompanionAlerts.masterEnabled(this)) {
            stopSelf(); return START_NOT_STICKY
        }
        CompanionAlerts.channels(this)
        val stopSound=PendingIntent.getService(this,240017,
            Intent(this,AlertSoundService::class.java).setAction("STOP_SOUND"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification=Notification.Builder(this,"vaghtnegar_prayer_v1")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(intent?.getStringExtra("message")?:"صدای هشدار مورخ")
            .setContentText("در حال پخش صدای انتخاب‌شده")
            .addAction(android.R.drawable.ic_media_pause,"توقف صدا",stopSound)
            .setContentIntent(PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            .setOngoing(true).build()
        try {
            if(Build.VERSION.SDK_INT>=29) startForeground(playbackId,notification,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            else startForeground(playbackId,notification)
            player?.release()
            player=android.media.MediaPlayer().apply {
                setAudioAttributes(android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_ALARM)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC).build())
                setDataSource(applicationContext,Uri.parse(intent?.getStringExtra("sound_uri")?:""))
                setOnCompletionListener { stopSelf() }
                setOnErrorListener { _,_,_ -> stopSelf();true }
                prepare();start()
            }
        } catch(_:Exception) { stopSelf() }
        return START_NOT_STICKY
    }
    override fun onDestroy() {
        try { player?.stop() } catch(_:Exception) {}
        player?.release();player=null
        super.onDestroy()
    }
}

class CompanionAlarmReceiver:BroadcastReceiver() {
    override fun onReceive(context:Context,intent:Intent) {
        CompanionAlerts.onAlarm(context,intent.action?:return,intent.getIntExtra("alarm_id",0))
    }
}

class CompanionBootReceiver:BroadcastReceiver() {
    override fun onReceive(context:Context,intent:Intent) {
        CompanionAlerts.refresh(context)
    }
}

private val ink=Color(0xFF173A60)
private val pale=Color(0xFFF6FAFF)
private val gold=Color(0xFFBC8D35)

@Composable
fun RemindersScreen(modifier:Modifier=Modifier,onPickRingtone:(Boolean)->Unit) {
    val c=LocalContext.current
    val store=remember { ReminderStore(c) }
    val listState=rememberLazyListState()
    val scrollScope=rememberCoroutineScope()
    var revision by remember { mutableIntStateOf(0) }
    val rows=remember(revision) { store.all() }
    var editingId by remember { mutableStateOf<Long?>(null) }
    var kind by remember { mutableStateOf("قسط") }
    var title by remember { mutableStateOf("") }
    val dateDefault=remember { val (y,m,d)=gregorianToJalali(LocalDate.now()); "%04d-%02d-%02d".format(y,m,d) }
    var jalali by remember { mutableStateOf(dateDefault) }
    var clock by remember { mutableStateOf("09:00") }
    var repeat by remember { mutableStateOf(false) }
    var selectedSound by remember { mutableStateOf("") }
    var soundVersionAtOpen by remember { mutableLongStateOf(CompanionAlerts.reminderSoundVersion(c)) }
    var deleting by remember { mutableStateOf<Long?>(null) }
    fun reset() { editingId=null; kind="قسط";title="";jalali=dateDefault;clock="09:00";repeat=false;selectedSound="";soundVersionAtOpen=CompanionAlerts.reminderSoundVersion(c) }

    LazyColumn(modifier.fillMaxSize().padding(12.dp),state=listState,verticalArrangement=Arrangement.spacedBy(10.dp), contentPadding=PaddingValues(bottom=24.dp)) {
        item {
            Card(colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    Text(if(editingId==null) "یادآور تازه" else "ویرایش یادآور",fontSize=20.sp,fontWeight=FontWeight.Bold,color=ink)
                    Text("تاریخ شمسی و ساعت را رقم‌به‌رقم وارد کن؛ نخستین رقم تازه جای مقدار قبلی را می‌گیرد.",fontSize=12.sp,color=Color.Gray)
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected=kind=="قسط",onClick={kind="قسط"},label={Text("قسط")})
                        FilterChip(selected=kind=="جلسه",onClick={kind="جلسه"},label={Text("جلسه")})
                    }
                    OutlinedTextField(value=title,onValueChange={title=it},label={Text("عنوان یا توضیح")},singleLine=true,modifier=Modifier.fillMaxWidth())
                    Text("تاریخ شمسی",fontSize=12.sp,fontWeight=FontWeight.Bold)
                    // Absolute left-to-right placement independent of Persian RTL page direction.
                    key(editingId) {
                        ReminderDateFieldLeftToRight(jalali, { jalali=it }, Modifier.fillMaxWidth())
                    }
                    Text("ساعت یادآور",fontSize=12.sp,fontWeight=FontWeight.Bold)
                    key(editingId) {
                        ReminderTimeFieldLeftToRight(clock, { clock=it }, Modifier.fillMaxWidth())
                    }
                    Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()) {
                        Text("تکرار ماهانه در تقویم شمسی",modifier=Modifier.weight(1f),fontSize=13.sp)
                        Switch(checked=repeat,onCheckedChange={repeat=it})
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick={onPickRingtone(false)},modifier=Modifier.weight(1f)) { Text("رینگتون گوشی",fontSize=12.sp) }
                        OutlinedButton(onClick={onPickRingtone(true)},modifier=Modifier.weight(1f)) { Text("فایل صوتی",fontSize=12.sp) }
                    }
                    Text("هنگام ویرایش، صدای انتخابی قبلی حفظ می‌شود؛ برای انتخاب صدای جدید از دکمه‌های بالا استفاده کن.",fontSize=11.sp,color=Color.Gray)
                    Button(onClick={
                        val dp=jalali.replace('/','-').toLatinDigitsLocal().split('-')
                        val tp=clock.toLatinDigitsLocal().split(':')
                        try {
                            require(title.isNotBlank()) { "عنوان یادآور را وارد کن" }
                            require(dp.size==3 && tp.size==2) { "تاریخ یا ساعت نادرست است" }
                            val y=dp[0].toInt();val m=dp[1].toInt();val d=dp[2].toInt()
                            val hh=tp[0].toInt();val mm=tp[1].toInt()
                            require(isValidJalali(y,m,d) && hh in 0..23 && mm in 0..59) { "تاریخ یا ساعت نامعتبر است" }
                            val millis=jalaliToGregorian(y,m,d).atTime(hh,mm).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                            val now=System.currentTimeMillis()
                            val today=LocalDate.now(ZoneId.systemDefault())
                            require(editingId!=null || !jalaliToGregorian(y,m,d).isBefore(today)) { "برای تاریخ‌های پیش از امروز نمی‌توان یادآور تازه ثبت کرد" }
                            val sound = if (CompanionAlerts.reminderSoundVersion(c)!=soundVersionAtOpen)
                                CompanionAlerts.ringtone(c,false)
                            else if(editingId!=null) selectedSound
                            else CompanionAlerts.ringtone(c,false)
                            if(editingId==null) store.add(kind,title.trim(),millis,repeat,sound)
                            else store.update(editingId!!,kind,title.trim(),millis,repeat,sound)
                            reset();revision++;CompanionAlerts.requestPermissions(c as Activity);CompanionAlerts.refresh(c)
                            Toast.makeText(c,if(millis<=now) "ذخیره شد؛ زمان گذشته و هشدار اجرا نمی‌شود" else "یادآور ذخیره شد",Toast.LENGTH_LONG).show()
                        } catch(e:Exception){Toast.makeText(c,e.message?:"تاریخ یا ساعت صحیح نیست",Toast.LENGTH_LONG).show()}
                    },modifier=Modifier.fillMaxWidth()) { Text(if(editingId==null) "ثبت یادآور" else "ذخیرهٔ تغییرات") }
                    if(editingId!=null) OutlinedButton(onClick={reset()},modifier=Modifier.fillMaxWidth()) { Text("انصراف از ویرایش") }
                }
            }
        }
        item { Text("یادآورهای ثبت‌شده",fontSize=17.sp,fontWeight=FontWeight.Bold,color=ink) }
        if(rows.isEmpty()) item { Text("هنوز یادآوری ثبت نشده است.",color=Color.Gray) }
        items(rows,key={it.id}) { item ->
            Card(colors=CardDefaults.cardColors(containerColor=pale),shape=RoundedCornerShape(15.dp)) {
                Column(Modifier.fillMaxWidth().padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
                    Text("${item.kind}  •  ${item.title}",fontWeight=FontWeight.Bold,color=ink)
                    val z=Instant.ofEpochMilli(item.whenMillis).atZone(ZoneId.systemDefault())
                    val (y,m,d)=gregorianToJalali(z.toLocalDate())
                    val isPast=item.whenMillis<=System.currentTimeMillis()
                    Text("${"%04d/%02d/%02d".format(y,m,d).toPersianDigitsLocal()}  ${z.toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm")).toPersianDigitsLocal()}${if(item.monthly) "  •  ماهانه" else ""}${if(isPast) "  •  زمان گذشته" else if(!item.enabled) "  •  غیرفعال" else ""}",fontSize=12.sp,color=Color.Gray)
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick={
                            editingId=item.id; kind=item.kind;title=item.title
                            jalali="%04d-%02d-%02d".format(y,m,d)
                            clock=z.toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))
                            repeat=item.monthly; selectedSound=item.soundUri
                            soundVersionAtOpen=CompanionAlerts.reminderSoundVersion(c)
                            scrollScope.launch { listState.animateScrollToItem(0) }
                        },modifier=Modifier.weight(1f)) { Text("مشاهده و ویرایش") }
                        TextButton(onClick={deleting=item.id}) { Text("حذف",color=Color(0xFFB3261E)) }
                    }
                }
            }
        }
    }
    if(deleting!=null) AlertDialog(
        onDismissRequest={deleting=null},
        title={Text("حذف یادآور")},
        text={Text("آیا از حذف این یادآور مطمئن هستی؟")},
        confirmButton={TextButton(onClick={val id=deleting; if(id!=null) {store.delete(id); if(editingId==id)reset();CompanionAlerts.refresh(c);revision++};deleting=null}) {Text("حذف",color=Color.Red)}},
        dismissButton={TextButton(onClick={deleting=null}) {Text("انصراف")}}
    )
}

@Composable
fun PrayerTimesScreen(modifier:Modifier=Modifier,onPickRingtone:(Boolean)->Unit) {
    val c=LocalContext.current
    val scope=rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    var cityExpanded by remember { mutableStateOf(false) }
    var citySearch by remember { mutableStateOf("") }
    var onlineMessage by remember { mutableStateOf("در حال آماده‌سازی اوقات شرعی…") }
    var soundMessage by remember { mutableStateOf("") }
    var previewPlayer by remember { mutableStateOf<android.media.MediaPlayer?>(null) }
    DisposableEffect(Unit) {
        onDispose { try { previewPlayer?.release() } catch (_:Exception) {} }
    }
    LaunchedEffect(Unit) { AdhanSelection.clearOldCatalog(c) }
    val cityList=remember(tick) { PrayerRemote.cities(c) }
    val index=CompanionAlerts.selectedCity(c)
    val city=cityList.getOrElse(index) { cityList[0] }
    val isEnabled=CompanionAlerts.enabled(c,"prayer_enabled")
    val selectedAdhanUri = remember(tick) { CompanionAlerts.ringtone(c,true) }
    val today=LocalDate.now(ZoneId.of(city.zone))
    val times=remember(city.slug,tick) { PrayerRemote.resolved(c,city,today,CompanionAlerts.offset(c)) }
    val hasOnlineTimes=remember(city.slug,tick) { PrayerRemote.cached(c,city,today)!=null }

    // Network traffic is NEVER triggered by simply opening this screen or switching city.
    // Existing cached information (or a clearly marked offline estimate) is shown until
    // the user presses the explicit update button below.
    Column(modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(14.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFF163A63))) {
            Column(Modifier.fillMaxWidth().padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                Text("اوقات شرعی امروز",fontSize=22.sp,fontWeight=FontWeight.Bold,color=Color.White)
                Text(if(hasOnlineTimes) "روش محاسباتی مؤسسه ژئوفیزیک دانشگاه تهران؛ منبع دریافت: تقویم ایرانی" else "زمان‌های تخمینی آفلاین؛ برای دادهٔ دقیق‌تر اتصال اینترنت را برقرار کن.",fontSize=12.sp,color=Color(0xFFD7E7F8))
                Text("شهر: ${city.name}",color=Color(0xFFF2D59A),fontWeight=FontWeight.Bold)
                times.forEach { (name,time) ->
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                        Text(name,color=Color.White,fontSize=17.sp)
                        Text(time.format(DateTimeFormatter.ofPattern("HH:mm")).toPersianDigitsLocal(),color=Color(0xFFF2D59A),fontWeight=FontWeight.Bold,fontSize=19.sp)
                    }
                }
            }
        }
        Card(colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(16.dp)) {
            Column(Modifier.fillMaxWidth().padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("شهرهای ایران",color=ink,fontWeight=FontWeight.Bold)
                Box {
                    OutlinedButton(onClick={cityExpanded=true},modifier=Modifier.fillMaxWidth()) { Text("انتخاب شهر: ${city.name}  ▾") }
                    DropdownMenu(expanded=cityExpanded,onDismissRequest={cityExpanded=false}) {
                        OutlinedTextField(
                            value=citySearch,onValueChange={citySearch=it},
                            label={Text("جست‌وجوی نام شهر")},singleLine=true,
                            modifier=Modifier.width(260.dp).padding(horizontal=6.dp)
                        )
                        val filtered=cityList.withIndex().filter { it.value.name.contains(citySearch.trim(),ignoreCase=true) }.take(35)
                        filtered.forEach { row ->
                            DropdownMenuItem(text={Text(row.value.name)},onClick={
                                cityExpanded=false; citySearch=""; CompanionAlerts.selectCity(c,row.index);tick++
                            })
                        }
                        if(filtered.isEmpty()) Text("شهری پیدا نشد",modifier=Modifier.padding(12.dp))
                    }
                }
                Text(onlineMessage,fontSize=11.sp,color=Color(0xFF5C7899))
                OutlinedButton(onClick={
                    scope.launch {
                        onlineMessage="در حال به‌روزرسانی…"
                        try {
                            val count=PrayerRemote.fetchCities(c)
                            val current=PrayerRemote.cities(c)[CompanionAlerts.selectedCity(c)]
                            PrayerRemote.fetchDay(c,current,LocalDate.now(ZoneId.of(current.zone)))
                            PrayerRemote.fetchDay(c,current,LocalDate.now(ZoneId.of(current.zone)).plusDays(1))
                            CompanionAlerts.refresh(c);tick++
                            onlineMessage="فهرست ${count.toString().toPersianDigitsLocal()} شهر و اوقات شرعی به‌روز شد."
                        } catch(e:Exception) { onlineMessage="به‌روزرسانی ناموفق بود: ${e.message?:"اینترنت را بررسی کن"}" }
                    }
                },modifier=Modifier.fillMaxWidth()) { Text("دریافت تازهٔ شهرها و اوقات شرعی") }
                val lastSync = remember(tick) { c.getSharedPreferences("vaghtnegar_prayer_remote", Context.MODE_PRIVATE).getLong("last_prayer_sync",0L) }
                Text("آخرین به‌روزرسانی آنلاین اوقات شرعی: " + if (lastSync==0L) "هنوز انجام نشده" else
                    formattedSyncStamp(lastSync),fontSize=11.sp,color=Color(0xFF5C7899))
            }
        }
        Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
            Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Text("هشدار صوتی اذان",modifier=Modifier.weight(1f),fontWeight=FontWeight.Bold,color=ink)
                    Switch(checked=isEnabled,onCheckedChange={ CompanionAlerts.setEnabled(c,"prayer_enabled",it);if(it) CompanionAlerts.requestPermissions(c as Activity);tick++ })
                }
                if(isEnabled) {
                    listOf("صبح","ظهر","مغرب").forEachIndexed { i,label ->
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Text("هشدار $label",modifier=Modifier.weight(1f))
                            Switch(checked=CompanionAlerts.enabled(c,"prayer_$i",true),onCheckedChange={CompanionAlerts.setEnabled(c,"prayer_$i",it);tick++})
                        }
                    }
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text("تصحیح زمان (دقیقه): ${CompanionAlerts.offset(c).toString().toPersianDigitsLocal()}",modifier=Modifier.weight(1f),fontSize=12.sp)
                        TextButton(onClick={ CompanionAlerts.changeOffset(c,CompanionAlerts.offset(c)-1);tick++ }) {Text("−")}
                        TextButton(onClick={ CompanionAlerts.changeOffset(c,CompanionAlerts.offset(c)+1);tick++ }) {Text("+")}
                    }
                    Text("بانک اذان‌های اهل‌بیت",fontWeight=FontWeight.Bold,color=ink)
                    Text("مؤذن‌ها و لینک‌ها از فهرست مؤسسه اهل‌بیت گرفته شده‌اند. همه ابتدا دانلودنشده‌اند؛ فقط اذان انتخابی دانلود و روی گوشی ذخیره می‌شود.",fontSize=11.sp,color=Color.Gray)
                    var downloadingAdhan by remember { mutableStateOf("") }
                    AhlolbaitAdhans.entries.forEach { item ->
                        val downloaded = remember(item.id,tick) { AhlolbaitAdhans.localFile(c,item).exists() }
                        val savedUri=Uri.fromFile(AhlolbaitAdhans.localFile(c,item)).toString()
                        val chosen=selectedAdhanUri == savedUri
                        Card(colors=CardDefaults.cardColors(containerColor=if(chosen) Color(0xFFE6F3EA) else Color(0xFFF4F8FE)),shape=RoundedCornerShape(10.dp)) {
                            Column(Modifier.fillMaxWidth().padding(8.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                                    Text(item.muezzin,modifier=Modifier.weight(1f),fontSize=12.sp,fontWeight=FontWeight.SemiBold,color=ink)
                                    if(downloaded) Text("دانلود شده",fontSize=10.sp,color=Color(0xFF28734B))
                                    else Text("دانلود نشده",fontSize=10.sp,color=Color.Gray)
                                }
                                if (!downloaded) {
                                    OutlinedButton(onClick={
                                        downloadingAdhan=item.id
                                        scope.launch {
                                            try {
                                                AhlolbaitAdhans.download(c,item)
                                                soundMessage="اذان ${item.muezzin} دانلود شد؛ می‌توانی پخش و انتخاب کنی."
                                                tick++
                                            } catch(e:Exception) { soundMessage="دانلود ${item.muezzin} ناموفق بود: ${e.message}" }
                                            finally { downloadingAdhan="" }
                                        }
                                    },enabled=downloadingAdhan.isEmpty(),modifier=Modifier.fillMaxWidth()) {
                                        Text(if(downloadingAdhan==item.id) "در حال دانلود…" else "↓ دانلود همین اذان",fontSize=11.sp)
                                    }
                                } else {
                                    // RTL: selection on the RIGHT, matching playback/stop buttons together,
                                    // and removal at the far left. Each touch target is at least 48dp tall.
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        verticalAlignment=Alignment.CenterVertically,
                                        horizontalArrangement=Arrangement.spacedBy(4.dp)
                                    ) {
                                        Row(
                                            modifier=Modifier.clickable {
                                                CompanionAlerts.saveRingtone(c,true,savedUri)
                                                soundMessage="اذان انتخابی: ${item.muezzin}"
                                                tick++
                                            },
                                            verticalAlignment=Alignment.CenterVertically
                                        ) {
                                            RadioButton(
                                                selected=chosen,
                                                onClick={
                                                    CompanionAlerts.saveRingtone(c,true,savedUri)
                                                    soundMessage="اذان انتخابی: ${item.muezzin}"
                                                    tick++
                                                },
                                                modifier=Modifier.size(40.dp)
                                            )
                                            Text("انتخاب",fontSize=10.sp,maxLines=1)
                                        }
                                        OutlinedButton(
                                            onClick={
                                                try {
                                                    previewPlayer?.release()
                                                    previewPlayer=android.media.MediaPlayer().apply {
                                                        setDataSource(c,Uri.fromFile(AhlolbaitAdhans.localFile(c,item)))
                                                        setOnCompletionListener {
                                                            try { it.release() } catch (_:Exception) {}
                                                            previewPlayer=null
                                                        }
                                                        prepare(); start()
                                                    }
                                                } catch(e:Exception) {
                                                    try { previewPlayer?.release() } catch (_:Exception) {}
                                                    previewPlayer=null
                                                    soundMessage="پخش اذان ناموفق بود: ${e.message}"
                                                }
                                            },
                                            modifier=Modifier.weight(1f).heightIn(min=48.dp),
                                            contentPadding=PaddingValues(horizontal=2.dp)
                                        ) { Text("▶ پخش",fontSize=11.sp,maxLines=1) }
                                        OutlinedButton(
                                            onClick={
                                                try { previewPlayer?.stop() } catch (_:Exception) {}
                                                try { previewPlayer?.release() } catch (_:Exception) {}
                                                previewPlayer=null
                                            },
                                            modifier=Modifier.weight(1f).heightIn(min=48.dp),
                                            contentPadding=PaddingValues(horizontal=2.dp)
                                        ) { Text("■ توقف",fontSize=11.sp,maxLines=1) }
                                        TextButton(
                                            onClick={
                                                // Close the preview before removing the MP3 from internal storage.
                                                try { previewPlayer?.stop() } catch (_:Exception) {}
                                                try { previewPlayer?.release() } catch (_:Exception) {}
                                                previewPlayer=null
                                                // A selected audio can also be playing in the alarm service.
                                                if(chosen) {
                                                    try { c.stopService(Intent(c,AlertSoundService::class.java)) } catch (_:Exception) {}
                                                }
                                                val removed=try { AhlolbaitAdhans.deleteDownloaded(c,item) }
                                                    catch (_:Exception) { false }
                                                if(removed) {
                                                    if(chosen) CompanionAlerts.saveRingtone(c,true,"")
                                                    soundMessage="فایل صوتی ${item.muezzin} از حافظهٔ برنامه پاک شد؛ برای استفادهٔ دوباره آن را دانلود کن."
                                                } else {
                                                    soundMessage="پاک‌کردن فایل ${item.muezzin} موفق نبود؛ دوباره امتحان کن."
                                                }
                                                tick++
                                            },
                                            contentPadding=PaddingValues(horizontal=2.dp),
                                            modifier=Modifier.heightIn(min=48.dp)
                                        ) { Text("حذف",color=Color(0xFFB3261E),fontSize=10.sp,maxLines=1) }
                                    }
                                }
                            }
                        }
                    }
                    OutlinedButton(onClick={onPickRingtone(true)},modifier=Modifier.fillMaxWidth()) { Text("انتخاب یک فایل اذان از گوشی برای پیش‌شنیدن") }
                    val adhanRevision=AdhanSelection.revision.intValue
                    val pending=remember(tick, adhanRevision) { AdhanSelection.pending(c) }
                    val selected=remember(tick) { CompanionAlerts.ringtone(c,true) }
                    if(pending.isNotBlank()) {
                        var muezzin by remember(pending) { mutableStateOf(AdhanSelection.pendingName(c)) }
                        OutlinedTextField(value=muezzin,onValueChange={muezzin=it;AdhanSelection.setMuezzin(c,it)},
                            label={ Text("نام مؤذن / عنوان صوت") },singleLine=true,modifier=Modifier.fillMaxWidth())
                        Row(
                            Modifier.fillMaxWidth(),
                            verticalAlignment=Alignment.CenterVertically,
                            horizontalArrangement=Arrangement.spacedBy(4.dp)
                        ) {
                            Row(Modifier.clickable {
                                try { previewPlayer?.stop() } catch (_:Exception) {}
                                try { previewPlayer?.release() } catch (_:Exception) {}
                                previewPlayer=null
                                CompanionAlerts.saveRingtone(c,true,pending)
                                soundMessage="اذان انتخاب شد: $muezzin";tick++
                            },verticalAlignment=Alignment.CenterVertically) {
                                RadioButton(
                                    selected=selected==pending,
                                    onClick={
                                        try { previewPlayer?.stop() } catch (_:Exception) {}
                                        try { previewPlayer?.release() } catch (_:Exception) {}
                                        previewPlayer=null
                                        CompanionAlerts.saveRingtone(c,true,pending)
                                        soundMessage="اذان انتخاب شد: $muezzin";tick++
                                    },
                                    modifier=Modifier.size(40.dp)
                                )
                                Text("انتخاب",fontSize=10.sp,maxLines=1)
                            }
                            OutlinedButton(
                                onClick={
                                    try {
                                        previewPlayer?.release()
                                        previewPlayer=android.media.MediaPlayer().apply {
                                            setDataSource(c,Uri.parse(pending))
                                            setOnCompletionListener {
                                                try { it.release() } catch (_:Exception) {}
                                                previewPlayer=null
                                            }
                                            prepare();start()
                                        }
                                    } catch(e:Exception) {
                                        try { previewPlayer?.release() } catch (_:Exception) {}
                                        previewPlayer=null
                                        soundMessage="پخش ناموفق بود: ${e.message}"
                                    }
                                },
                                modifier=Modifier.weight(1f).heightIn(min=48.dp),
                                contentPadding=PaddingValues(horizontal=2.dp)
                            ) { Text("▶ پخش",fontSize=11.sp,maxLines=1) }
                            OutlinedButton(
                                onClick={
                                    try { previewPlayer?.stop() } catch (_:Exception) {}
                                    try { previewPlayer?.release() } catch (_:Exception) {}
                                    previewPlayer=null
                                },
                                modifier=Modifier.weight(1f).heightIn(min=48.dp),
                                contentPadding=PaddingValues(horizontal=2.dp)
                            ) { Text("■ توقف",fontSize=11.sp,maxLines=1) }
                            TextButton(
                                onClick={
                                    try { previewPlayer?.stop() } catch (_:Exception) {}
                                    try { previewPlayer?.release() } catch (_:Exception) {}
                                    previewPlayer=null
                                    if (selected==pending) CompanionAlerts.saveRingtone(c,true,"")
                                    AdhanSelection.clearPending(c)
                                    soundMessage="این فایل از فهرست برنامه حذف شد؛ فایل اصلی گوشی پاک نشده است."
                                    tick++
                                },
                                modifier=Modifier.heightIn(min=48.dp),
                                contentPadding=PaddingValues(horizontal=2.dp)
                            ) { Text("حذف",fontSize=10.sp,color=Color.Red,maxLines=1) }
                        }
                    }
                    TextButton(onClick={
                        CompanionAlerts.saveRingtone(c,true,"")
                        soundMessage="پخش اذان غیرفعال شد؛ اعلان متنی حفظ می‌شود.";tick++
                    }) {Text("فقط اعلان بدون پخش صدا")}
                    if(soundMessage.isNotBlank()) Text(soundMessage,fontSize=12.sp,color=ink)
                    Text("پخش اذان به مجوز اعلان، هشدار دقیق و محدودیت‌های باتری گوشی وابسته است.",fontSize=11.sp,color=Color.Gray)
                }
            }
        }
    }
}

/** All notification controls in one Settings card.
 * The master switch gates every scheduled alarm, notification and audio service;
 * category switches preserve their values while the master is off. */
@Composable
fun AlertManagementSettings(modifier:Modifier=Modifier) {
    val c=LocalContext.current
    var revision by remember { mutableIntStateOf(0) }
    fun change(key:String,value:Boolean) {
        CompanionAlerts.setEnabled(c,key,value)
        if (value) CompanionAlerts.requestPermissions(c as Activity)
        revision++
    }
    val master=remember(revision) { CompanionAlerts.masterEnabled(c) }
    Card(modifier=modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
        Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
            Text("مدیریت اعلان‌ها و هشدارها",fontWeight=FontWeight.Bold,fontSize=17.sp,color=ink)
            Row(verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("فعال‌سازی کلی اعلان‌ها",fontWeight=FontWeight.Bold,color=ink)
                    Text("خاموش: تاریخ، اذان، جلسات، اقساط و صدای هشدار همگی متوقف می‌شوند.",fontSize=11.sp,color=Color.Gray)
                }
                Switch(checked=master,onCheckedChange={change("all_alerts_enabled",it)})
            }
            HorizontalDivider(color=Color(0xFFDCE6EF))
            val categories=listOf(
                Triple("day_notification","اعلان دائمی تاریخ", "تاریخ شمسی و قمری، شمارهٔ روز و اذان بعدی"),
                Triple("prayer_enabled","هشدار اذان", "صبح، ظهر و مغرب؛ کلیدهای مستقل هر نوبت در صفحهٔ اذان"),
                Triple("installment_alerts","یادآور اقساط", "اعلان و صدای موعد اقساط"),
                Triple("meeting_alerts","یادآور جلسات", "اعلان و صدای زمان جلسات")
            )
            categories.forEach { (key,title,subtitle) ->
                val checked=remember(key,revision) { CompanionAlerts.enabled(c,key,key!="day_notification" && key!="prayer_enabled") }
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(title,fontSize=13.sp,color=ink)
                        Text(subtitle,fontSize=10.sp,color=Color.Gray)
                    }
                    Switch(checked=checked,onCheckedChange={change(key,it)},enabled=master)
                }
            }
            Text("چیدمان و جایگاه اعلان در نوار گوشی را سامسونگ/اندروید تعیین می‌کند؛ برنامه اولویت مناسب را درخواست می‌کند، نه جای ثابت.",fontSize=11.sp,color=Color.Gray)
            OutlinedButton(onClick={CompanionAlerts.askExactAlarmSettings(c as Activity)},modifier=Modifier.fillMaxWidth()) {
                Text("مجوز هشدارهای دقیق در تنظیمات اندروید")
            }
        }
    }
}

private fun String.toLatinDigitsLocal() = map { c -> when(c) {'۰'->'0';'۱'->'1';'۲'->'2';'۳'->'3';'۴'->'4';'۵'->'5';'۶'->'6';'۷'->'7';'۸'->'8';'۹'->'9';'٠'->'0';'١'->'1';'٢'->'2';'٣'->'3';'٤'->'4';'٥'->'5';'٦'->'6';'٧'->'7';'٨'->'8';'٩'->'9';else->c} }.joinToString("")
private fun String.toPersianDigitsLocal() = map { c -> if(c in '0'..'9') "۰۱۲۳۴۵۶۷۸۹"[c-'0'] else c }.joinToString("")
