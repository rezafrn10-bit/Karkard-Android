package ir.karkard.app

import com.ibm.icu.util.Calendar
import com.ibm.icu.util.IslamicCalendar
import com.ibm.icu.util.PersianCalendar
import com.ibm.icu.util.TimeZone
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.input.pointer.pointerInput

private val jalaliUtc = TimeZone.getTimeZone("UTC")
private val monthNames = listOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
private val islamicMonthNames = listOf("محرم", "صفر", "ربیع‌الاول", "ربیع‌الثانی", "جمادی‌الاول", "جمادی‌الثانی", "رجب", "شعبان", "رمضان", "شوال", "ذی‌القعده", "ذی‌الحجه")
private val weekDayNames = listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه")
private val calendarRed = AppPalette.Error
private val calendarBlue = AppPalette.Ink

fun isValidJalali(y: Int, m: Int, d: Int): Boolean {
    if (m !in 1..12 || d !in 1..31) return false
    return try {
        PersianCalendar(jalaliUtc).apply {
            isLenient = false
            clear()
            set(Calendar.YEAR, y)
            set(Calendar.MONTH, m - 1)
            set(Calendar.DAY_OF_MONTH, d)
            timeInMillis
        }
        true
    } catch (_: Exception) {
        false
    }
}

fun jalaliToGregorian(y: Int, m: Int, d: Int): LocalDate {
    val c = PersianCalendar(jalaliUtc).apply {
        isLenient = false
        clear()
        set(Calendar.YEAR, y)
        set(Calendar.MONTH, m - 1)
        set(Calendar.DAY_OF_MONTH, d)
    }
    return Instant.ofEpochMilli(c.timeInMillis).atZone(ZoneOffset.UTC).toLocalDate()
}

fun gregorianToJalali(date: LocalDate): Triple<Int, Int, Int> {
    val c = PersianCalendar(jalaliUtc)
    c.timeInMillis = date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
    return Triple(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
}

fun jalaliMonthLength(y: Int, m: Int): Int = when (m) {
    in 1..6 -> 31
    in 7..11 -> 30
    12 -> if (isValidJalali(y, 12, 30)) 30 else 29
    else -> 0
}

private fun fullCalendarDate(date: String): String {
    val dateParts = date.split('-').mapNotNull { it.toIntOrNull() }
    if (dateParts.size != 3 || !isValidJalali(dateParts[0], dateParts[1], dateParts[2])) return date
    val g = jalaliToGregorian(dateParts[0], dateParts[1], dateParts[2])
    val weekday = weekDayNames[(g.dayOfWeek.value + 1) % 7]
    return "$weekday ${persianDigits(dateParts[2].toString())} ${monthNames[dateParts[1] - 1]} ${persianDigits(dateParts[0].toString())}"
}

/** Shared lunar display for calendar and persistent date notification. */
fun jalaliLunarDateDisplay(date: String): String = monthGregorianAndHijri(date, 0).second

private fun monthGregorianAndHijri(date: String, dayOffset: Int): Pair<String, String> {
    val p = date.split('-').mapNotNull { it.toIntOrNull() }
    if (p.size != 3 || !isValidJalali(p[0],p[1],p[2])) return "" to ""
    val g = jalaliToGregorian(p[0],p[1],p[2])
    val gregorian = "${persianDigits(g.dayOfMonth.toString())} ${g.month.getDisplayName(java.time.format.TextStyle.FULL, Locale.ENGLISH)} ${persianDigits(g.year.toString())}"
    // Civil astronomical conversion is not the Iranian moon-sighting announcement.
    // Iranian-calendar reference anchors for 1405/08, independently corroborated:
    // 1405/08/01 = 1448/05/12 (2026-10-23),
    // 1405/08/20 = 1448/06/01 (2026-11-11),
    // 1405/08/22 = 1448/06/03 (2026-11-13).
    // This month is not derived from a user-controlled offset or a global +1 guess.
    if (p[0] == 1405 && p[1] == 8) {
        val nextMonth = LocalDate.of(2026, 11, 11)
        val firstAnchor = LocalDate.of(2026, 10, 23)
        val monthNumber = if (g.isBefore(nextMonth)) 4 else 5 // zero-based ICU month numbers
        val dayOfLunarMonth = if (g.isBefore(nextMonth)) {
            12 + java.time.temporal.ChronoUnit.DAYS.between(firstAnchor, g).toInt()
        } else {
            1 + java.time.temporal.ChronoUnit.DAYS.between(nextMonth, g).toInt()
        }
        return gregorian to "${persianDigits(dayOfLunarMonth.toString())} ${islamicMonthNames[monthNumber]} ۱۴۴۸"
    }
    // Outside the cross-checked interval, retain a clearly marked estimated Hijri date.
    val hijri = IslamicCalendar(jalaliUtc).apply {
        timeInMillis = g.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
    }
    val islamicMonth = islamicMonthNames.getOrElse(hijri.get(Calendar.MONTH)) { "" }
    return gregorian to "${persianDigits(hijri.get(Calendar.DAY_OF_MONTH).toString())} $islamicMonth ${persianDigits(hijri.get(Calendar.YEAR).toString())}"
}


// Numeric display derives from the same date data as the written display.
private fun numericGregorianForCalendar(jalaliDate: String): String {
    val parts = jalaliDate.split('-').mapNotNull { it.toIntOrNull() }
    if (parts.size != 3 || !isValidJalali(parts[0],parts[1],parts[2])) return jalaliDate
    val date = jalaliToGregorian(parts[0],parts[1],parts[2])
    return persianDigits("%04d/%02d/%02d".format(Locale.ROOT, date.year, date.monthValue, date.dayOfMonth))
}

private fun numericHijriForCalendar(written: String): String {
    val fields = written.substringBefore(" (").trim().split(Regex("\\s+"))
    if (fields.size < 3) return written
    val month = islamicMonthNames.indexOf(fields[1]) + 1
    if (month < 1) return written
    val persianNumbers = "۰۱۲۳۴۵۶۷۸۹"
    fun parseDigits(s:String): Int? = s.map { c ->
        val index = persianNumbers.indexOf(c)
        if (index >= 0) ('0' + index) else c
    }.joinToString("").toIntOrNull()
    val day = parseDigits(fields[0]) ?: return written
    val year = parseDigits(fields[2]) ?: return written
    return persianDigits("%04d/%02d/%02d".format(Locale.ROOT, year, month, day))
}

@Composable
fun JalaliCalendarScreen(
    year: Int,
    month: Int,
    selectedDate: String,
    onMonthChange: (Int, Int) -> Unit,
    onSelectDate: (String) -> Unit,
    modifier: Modifier = Modifier,
    holidays: Map<String, String> = emptyMap(),
    events: Map<String, String> = emptyMap(),
    hijriDayOffset: Int = 0
) {
    val firstDay = jalaliToGregorian(year, month, 1)
    // Month grid starts on Saturday and ends on Friday.
    val offset = (firstDay.dayOfWeek.value + 1) % 7
    val count = jalaliMonthLength(year, month)
    val cells = List(offset) { 0 } + (1..count).toList()
    val weeks = cells.chunked(7).map { week -> week + List(7 - week.size) { 0 } }
    var previewDate by remember(year, month, selectedDate) {
        mutableStateOf(if (selectedDate.startsWith("%04d-%02d".format(Locale.ROOT, year, month))) selectedDate else "%04d-%02d-01".format(Locale.ROOT, year, month))
    }
    val today = remember { LocalDate.now() }
    val selectedHoliday = holidays[previewDate]
    val selectedEvents = events[previewDate].orEmpty().split("،").map { it.trim() }.filter { it.isNotBlank() }
    val entries = (listOfNotNull(selectedHoliday).flatMap { it.split("،") } + selectedEvents).map { it.trim() }.filter { it.isNotBlank() }.distinct()
    val (gregorian, lunar) = remember(previewDate, hijriDayOffset) { monthGregorianAndHijri(previewDate, hijriDayOffset) }
    var gregorianNumeric by remember { mutableStateOf(false) }
    var lunarNumeric by remember { mutableStateOf(false) }
    val gregorianDisplay = if (gregorianNumeric) numericGregorianForCalendar(previewDate) else gregorian
    val lunarDisplay = if (lunarNumeric) numericHijriForCalendar(lunar) else lunar

    Column(
        modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 9.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Card(colors = CardDefaults.cardColors(containerColor = AppPalette.Surface), shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(15.dp)).padding(2.dp).border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(12.dp))) {
            Column(Modifier.fillMaxWidth().padding(9.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                val selectedParts = previewDate.split('-').mapNotNull { it.toIntOrNull() }
                val selectedDayNumber = selectedParts.getOrElse(2) { 1 }
                val selectedWeekday = fullCalendarDate(previewDate).substringBefore(' ')
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 7.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.Start, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        DigitAwareText(selectedWeekday, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = AppPalette.Ink)
                        DigitAwareText(lunarDisplay, modifier = Modifier.clickable { lunarNumeric = !lunarNumeric }, fontSize = 12.sp, color = AppPalette.Ink, maxLines = 2)
                    }
                    Box(Modifier.size(58.dp).background(AppPalette.PrimarySoft, RoundedCornerShape(50)), contentAlignment = Alignment.Center) {
                        DigitAwareText(persianDigits(selectedDayNumber.toString()), fontSize = 25.sp, fontWeight = FontWeight.Bold, color = AppPalette.Ink)
                    }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        DigitAwareText(monthNames[month - 1] + " " + persianDigits(year.toString()), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = AppPalette.Ink, textAlign = TextAlign.End)
                        DigitAwareText(gregorianDisplay, modifier = Modifier.clickable { gregorianNumeric = !gregorianNumeric }, fontSize = 12.sp, color = AppPalette.Ink, textAlign = TextAlign.End, maxLines = 2)
                    }
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = AppPalette.Surface), shape = RoundedCornerShape(15.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(15.dp)).padding(2.dp).border(1.dp, Color(0xFFC7A24A), RoundedCornerShape(12.dp)).pointerInput(year, month) {
                var drag = 0f
                detectHorizontalDragGestures(
                    onHorizontalDrag = { _, amount -> drag += amount },
                    onDragEnd = {
                        if (kotlin.math.abs(drag) > 55f) {
                            if (drag < 0) onMonthChange(if (month == 1) year - 1 else year, if (month == 1) 12 else month - 1)
                            else onMonthChange(if (month == 12) year + 1 else year, if (month == 12) 1 else month + 1)
                        }
                        drag = 0f
                    }
                )
            }) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 5.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth()) {
                    weekDayNames.forEachIndexed { i, name ->
                        Box(Modifier.weight(1f).height(30.dp), contentAlignment = Alignment.Center) {
                            DigitAwareText(name, color = if (i == 6) calendarRed else calendarBlue, fontWeight = FontWeight.Bold, fontSize = 8.sp, maxLines = 1, softWrap = false, textAlign = TextAlign.Center)
                        }
                    }
                }
                weeks.forEach { week ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        week.forEachIndexed { column, day ->
                            Box(Modifier.weight(1f).aspectRatio(0.90f), contentAlignment = Alignment.Center) {
                                if (day > 0) {
                                    val date = "%04d-%02d-%02d".format(Locale.ROOT, year, month, day)
                                    val isHoliday = column == 6 || holidays.containsKey(date)
                                    val hasEvent = events.containsKey(date)
                                    val isToday = jalaliToGregorian(year,month,day) == today
                                    val isPreview = date == previewDate
                                    Surface(
                                        onClick = { previewDate = date },
                                        color = when {
                                            isPreview -> AppPalette.PrimarySoft
                                            isHoliday -> AppPalette.ErrorSoft
                                            hasEvent -> AppPalette.SurfaceAlt
                                            else -> AppPalette.SurfaceAlt
                                        },
                                        shape = RoundedCornerShape(9.dp),
                                        modifier = Modifier.fillMaxSize().then(
                                            if (isPreview) Modifier.border(2.dp, AppPalette.Primary, RoundedCornerShape(9.dp))
                                            else if (isToday) Modifier.border(1.5.dp, AppPalette.Primary, RoundedCornerShape(9.dp))
                                            else Modifier
                                        )
                                    ) {
                                        Column(
                                            Modifier.fillMaxSize().padding(vertical = 3.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            DigitAwareText(persianDigits(day.toString()), color = if (isHoliday) calendarRed else calendarBlue, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                                            if (isHoliday || hasEvent) {
                                                DigitAwareText(if (isHoliday) "●" else "•", color = if (isHoliday) calendarRed else AppPalette.Muted, fontSize = 10.sp, lineHeight = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    LegendDot("تعطیل / جمعه", AppPalette.ErrorSoft, calendarRed)
                    LegendDot("مناسبت", AppPalette.SurfaceAlt, AppPalette.Muted)
                    LegendDot("انتخاب‌شده", AppPalette.PrimarySoft, AppPalette.Primary)
                }
            }
        }
        Card(
            colors = CardDefaults.cardColors(containerColor = if (selectedHoliday != null) AppPalette.ErrorSoft else AppPalette.SurfaceAlt),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, AppPalette.Border, RoundedCornerShape(14.dp))
        ) {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (selectedHoliday != null) {
                    DigitAwareText("تعطیل رسمی", color = calendarRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                } else if (jalaliToGregorian(year, month, previewDate.takeLast(2).toInt()) .dayOfWeek.value == 5) {
                    DigitAwareText("جمعه — تعطیل هفتگی", color = calendarRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                if (entries.isEmpty()) {
                    DigitAwareText("مناسبتی برای این روز در داده‌های فعلی ثبت نشده است.", fontSize = 11.sp, color = AppPalette.Muted)
                } else {
                    entries.forEach { title ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            DigitAwareText("•", color = if (selectedHoliday?.contains(title) == true) calendarRed else AppPalette.Muted)
                            DigitAwareText(title, fontSize = 12.sp, color = AppPalette.Ink, modifier = Modifier.weight(1f), lineHeight = 19.sp)
                        }
                    }
                }
                Button(onClick = { onSelectDate(previewDate) }, modifier = Modifier.fillMaxWidth()) {
                    DigitAwareText("مشاهده کارت این روز", fontSize = 13.sp)
                }
            }
        }
        DigitAwareText(
            if (year == 1405) "تعطیلات رسمی ۱۴۰۵ داخل برنامه ذخیره شده‌اند. برای دریافت فهرست کامل‌تر مناسبت‌ها به تنظیمات برو." else "برای دریافت تعطیلات رسمی و مناسبت‌های این سال از تنظیمات تقویم را به‌روزرسانی کن؛ تاریخ‌های قمری فقط با تقویم رسمی سال معتبرند.",
            color = AppPalette.Muted, fontSize = 10.sp, lineHeight = 16.sp
        )
    }
}

@Composable
private fun LegendDot(label: String, bg: Color, fg: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        Box(Modifier.size(10.dp).background(bg, RoundedCornerShape(3.dp)).border(1.dp, fg, RoundedCornerShape(3.dp)))
        DigitAwareText(label, fontSize = 9.sp, color = AppPalette.Muted)
    }
}

fun persianDigits(value: String): String = value.map { if (it in '0'..'9') (0x06F0 + (it - '0')).toChar() else it }.joinToString("")
