package ir.karkard.app

import com.ibm.icu.util.Calendar
import com.ibm.icu.util.IslamicCalendar
import com.ibm.icu.util.PersianCalendar
import com.ibm.icu.util.TimeZone
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val jalaliUtc = TimeZone.getTimeZone("UTC")
private val monthNames = listOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
private val islamicMonthNames = listOf("محرم", "صفر", "ربیع‌الاول", "ربیع‌الثانی", "جمادی‌الاول", "جمادی‌الثانی", "رجب", "شعبان", "رمضان", "شوال", "ذی‌القعده", "ذی‌الحجه")
private val weekDayNames = listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه")
private val calendarRed = Color(0xFFBD342B)
private val calendarBlue = Color(0xFF164673)

fun isValidJalali(y: Int, m: Int, d: Int): Boolean {
    if (m !in 1..12 || d !in 1..31) return false
    return try {
        PersianCalendar(jalaliUtc).apply {
            isLenient = false
            clear()
            set(Calendar.YEAR, y)
            set(Calendar.MONTH, m - 1)
            set(Calendar.DAY_OF_MONTH, d)
            timeInMillis
        }
        true
    } catch (_: Exception) {
        false
    }
}

fun jalaliToGregorian(y: Int, m: Int, d: Int): LocalDate {
    val c = PersianCalendar(jalaliUtc).apply {
        isLenient = false
        clear()
        set(Calendar.YEAR, y)
        set(Calendar.MONTH, m - 1)
        set(Calendar.DAY_OF_MONTH, d)
    }
    return Instant.ofEpochMilli(c.timeInMillis).atZone(ZoneOffset.UTC).toLocalDate()
}

fun gregorianToJalali(date: LocalDate): Triple<Int, Int, Int> {
    val c = PersianCalendar(jalaliUtc)
    c.timeInMillis = date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
    return Triple(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
}

fun jalaliMonthLength(y: Int, m: Int): Int = when (m) {
    in 1..6 -> 31
    in 7..11 -> 30
    12 -> if (isValidJalali(y, 12, 30)) 30 else 29
    else -> 0
}

private fun fullCalendarDate(date: String): String {
    val dateParts = date.split('-').mapNotNull { it.toIntOrNull() }
    if (dateParts.size != 3 || !isValidJalali(dateParts[0], dateParts[1], dateParts[2])) return date
    val g = jalaliToGregorian(dateParts[0], dateParts[1], dateParts[2])
    val weekday = weekDayNames[(g.dayOfWeek.value + 1) % 7]
    return "$weekday ${persianDigits(dateParts[2].toString())} ${monthNames[dateParts[1] - 1]} ${persianDigits(dateParts[0].toString())}"
}

private fun monthGregorianAndHijri(date: String, dayOffset: Int): Pair<String, String> {
    val p = date.split('-').mapNotNull { it.toIntOrNull() }
    if (p.size != 3 || !isValidJalali(p[0],p[1],p[2])) return "" to ""
    val g = jalaliToGregorian(p[0],p[1],p[2])
    val gregorian = "${persianDigits(g.dayOfMonth.toString())} ${g.month.getDisplayName(java.time.format.TextStyle.FULL, Locale.ENGLISH)} ${persianDigits(g.year.toString())}"
    // Civil astronomical conversion is not the Iranian moon-sighting announcement.
    // Iranian-calendar reference anchors for 1405/08, independently corroborated:
    // 1405/08/01 = 1448/05/12 (2026-10-23),
    // 1405/08/20 = 1448/06/01 (2026-11-11),
    // 1405/08/22 = 1448/06/03 (2026-11-13).
    // This month is not derived from a user-controlled offset or a global +1 guess.
    if (p[0] == 1405 && p[1] == 8) {
        val nextMonth = LocalDate.of(2026, 11, 11)
        val firstAnchor = LocalDate.of(2026, 10, 23)
        val monthNumber = if (g.isBefore(nextMonth)) 4 else 5 // zero-based ICU month numbers
        val dayOfLunarMonth = if (g.isBefore(nextMonth)) {
            12 + java.time.temporal.ChronoUnit.DAYS.between(firstAnchor, g).toInt()
        } else {
            1 + java.time.temporal.ChronoUnit.DAYS.between(nextMonth, g).toInt()
        }
        return gregorian to "${persianDigits(dayOfLunarMonth.toString())} ${islamicMonthNames[monthNumber]} ۱۴۴۸ (تطبیق تقویم ۱۴۰۵)"
    }
    // Outside the cross-checked interval, retain a clearly marked estimated Hijri date.
    val hijri = IslamicCalendar(jalaliUtc).apply {
        timeInMillis = g.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
    }
    val islamicMonth = islamicMonthNames.getOrElse(hijri.get(Calendar.MONTH)) { "" }
    return gregorian to "${persianDigits(hijri.get(Calendar.DAY_OF_MONTH).toString())} $islamicMonth ${persianDigits(hijri.get(Calendar.YEAR).toString())} (محاسباتی)"
}

@Composable
fun JalaliCalendarScreen(
    year: Int,
    month: Int,
    selectedDate: String,
    onMonthChange: (Int, Int) -> Unit,
    onSelectDate: (String) -> Unit,
    modifier: Modifier = Modifier,
    holidays: Map<String, String> = emptyMap(),
    events: Map<String, String> = emptyMap(),
    hijriDayOffset: Int = 0
) {
    val firstDay = jalaliToGregorian(year, month, 1)
    // Month grid starts on Saturday and ends on Friday.
    val offset = (firstDay.dayOfWeek.value + 1) % 7
    val count = jalaliMonthLength(year, month)
    val cells = List(offset) { 0 } + (1..count).toList()
    val weeks = cells.chunked(7).map { week -> week + List(7 - week.size) { 0 } }
    var previewDate by remember(year, month, selectedDate) {
        mutableStateOf(if (selectedDate.startsWith("%04d-%02d".format(Locale.ROOT, year, month))) selectedDate else "%04d-%02d-01".format(Locale.ROOT, year, month))
    }
    val today = remember { LocalDate.now() }
    val selectedHoliday = holidays[previewDate]
    val selectedEvents = events[previewDate].orEmpty().split("،").map { it.trim() }.filter { it.isNotBlank() }
    val entries = (listOfNotNull(selectedHoliday).flatMap { it.split("،") } + selectedEvents).map { it.trim() }.filter { it.isNotBlank() }.distinct()
    val (gregorian, lunar) = remember(previewDate, hijriDayOffset) { monthGregorianAndHijri(previewDate, hijriDayOffset) }

    Column(
        modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 9.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE0EEFD)), shape = RoundedCornerShape(15.dp)) {
            Column(Modifier.fillMaxWidth().padding(9.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(
                        onClick = { onMonthChange(if (month == 1) year - 1 else year, if (month == 1) 12 else month - 1) },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 3.dp),
                        modifier = Modifier.heightIn(min = 36.dp)
                    ) { Text("ماه قبل", fontSize = 12.sp) }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(monthNames[month - 1], fontSize = 19.sp, fontWeight = FontWeight.Bold, color = calendarBlue)
                        Text(persianDigits(year.toString()), fontSize = 14.sp, color = calendarBlue)
                    }
                    OutlinedButton(
                        onClick = { onMonthChange(if (month == 12) year + 1 else year, if (month == 12) 1 else month + 1) },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 3.dp),
                        modifier = Modifier.heightIn(min = 36.dp)
                    ) { Text("ماه بعد", fontSize = 12.sp) }
                }
                Text("برای دیدن مناسبت‌ها روی تاریخ بزن؛ برای ثبت کارکرد، دکمهٔ پایین تقویم را انتخاب کن.", fontSize = 10.sp, textAlign = TextAlign.Center, color = Color(0xFF3B6590), modifier = Modifier.fillMaxWidth())
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(15.dp)) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 5.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth()) {
                    listOf("ش", "ی", "د", "س", "چ", "پ", "ج").forEachIndexed { i, name ->
                        Box(Modifier.weight(1f).height(24.dp), contentAlignment = Alignment.Center) {
                            Text(name, color = if (i == 6) calendarRed else calendarBlue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
                weeks.forEach { week ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        week.forEachIndexed { column, day ->
                            Box(Modifier.weight(1f).aspectRatio(0.90f), contentAlignment = Alignment.Center) {
                                if (day > 0) {
                                    val date = "%04d-%02d-%02d".format(Locale.ROOT, year, month, day)
                                    val isHoliday = column == 6 || holidays.containsKey(date)
                                    val hasEvent = events.containsKey(date)
                                    val isToday = jalaliToGregorian(year,month,day) == today
                                    val isPreview = date == previewDate
                                    Surface(
                                        onClick = { previewDate = date },
                                        color = when {
                                            isPreview -> Color(0xFFD8E9FF)
                                            isHoliday -> Color(0xFFFFE6E6)
                                            hasEvent -> Color(0xFFFFF1D7)
                                            else -> Color(0xFFF4F8FE)
                                        },
                                        shape = RoundedCornerShape(9.dp),
                                        modifier = Modifier.fillMaxSize().then(
                                            if (isPreview) Modifier.border(2.dp, Color(0xFF3777C4), RoundedCornerShape(9.dp))
                                            else if (isToday) Modifier.border(1.5.dp, Color(0xFF3777C4), RoundedCornerShape(9.dp))
                                            else Modifier
                                        )
                                    ) {
                                        Column(
                                            Modifier.fillMaxSize().padding(vertical = 3.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            Text(persianDigits(day.toString()), color = if (isHoliday) calendarRed else calendarBlue, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                                            if (isHoliday || hasEvent) {
                                                Text(if (isHoliday) "●" else "•", color = if (isHoliday) calendarRed else Color(0xFFA86F0C), fontSize = 10.sp, lineHeight = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    LegendDot("تعطیل / جمعه", Color(0xFFFFE6E6), calendarRed)
                    LegendDot("مناسبت", Color(0xFFFFF1D7), Color(0xFFA86F0C))
                    LegendDot("انتخاب‌شده", Color(0xFFD8E9FF), Color(0xFF3777C4))
                }
            }
        }
        Card(
            colors = CardDefaults.cardColors(containerColor = if (selectedHoliday != null) Color(0xFFFFF2F2) else Color(0xFFF7FBFF)),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(fullCalendarDate(previewDate), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = if (selectedHoliday != null) calendarRed else calendarBlue)
                Text("میلادی: $gregorian", fontSize = 11.sp, color = Color(0xFF3A5C79))
                Text("قمری: $lunar", fontSize = 11.sp, color = Color(0xFF3A5C79))

                if (selectedHoliday != null) {
                    Text("تعطیل رسمی", color = calendarRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                } else if (jalaliToGregorian(year, month, previewDate.takeLast(2).toInt()) .dayOfWeek.value == 5) {
                    Text("جمعه — تعطیل هفتگی", color = calendarRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                if (entries.isEmpty()) {
                    Text("مناسبتی برای این روز در داده‌های فعلی ثبت نشده است.", fontSize = 11.sp, color = Color(0xFF64778A))
                } else {
                    entries.forEach { title ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("•", color = if (selectedHoliday?.contains(title) == true) calendarRed else Color(0xFFA86F0C))
                            Text(title, fontSize = 12.sp, color = Color(0xFF294B68), modifier = Modifier.weight(1f), lineHeight = 19.sp)
                        }
                    }
                }
                Button(onClick = { onSelectDate(previewDate) }, modifier = Modifier.fillMaxWidth()) {
                    Text("رفتن به ثبت کارکرد این روز", fontSize = 13.sp)
                }
            }
        }
        Text(
            if (year == 1405) "تعطیلات رسمی ۱۴۰۵ داخل برنامه ذخیره شده‌اند. برای دریافت فهرست کامل‌تر مناسبت‌ها به تنظیمات برو." else "برای دریافت تعطیلات رسمی و مناسبت‌های این سال از تنظیمات تقویم را به‌روزرسانی کن؛ تاریخ‌های قمری فقط با تقویم رسمی سال معتبرند.",
            color = Color(0xFF52718D), fontSize = 10.sp, lineHeight = 16.sp
        )
    }
}

@Composable
private fun LegendDot(label: String, bg: Color, fg: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        Box(Modifier.size(10.dp).background(bg, RoundedCornerShape(3.dp)).border(1.dp, fg, RoundedCornerShape(3.dp)))
        Text(label, fontSize = 9.sp, color = Color(0xFF41617E))
    }
}

fun persianDigits(value: String): String = value.map { if (it in '0'..'9') (0x06F0 + (it - '0')).toChar() else it }.joinToString("")
