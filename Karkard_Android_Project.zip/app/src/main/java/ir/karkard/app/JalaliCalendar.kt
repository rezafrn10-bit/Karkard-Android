package ir.karkard.app

import com.ibm.icu.util.Calendar
import com.ibm.icu.util.IslamicCalendar
import com.ibm.icu.util.PersianCalendar
import com.ibm.icu.util.TimeZone
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val jalaliUtc = TimeZone.getTimeZone("UTC")
private val monthNames = listOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
private val islamicMonthNames = listOf("محرم", "صفر", "ربیع‌الاول", "ربیع‌الثانی", "جمادی‌الاول", "جمادی‌الثانی", "رجب", "شعبان", "رمضان", "شوال", "ذی‌القعده", "ذی‌الحجه")
private val weekDayNames = listOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه")
private val calendarRed = Color(0xFFBD342B)
private val calendarBlue = Color(0xFF164673)

fun isValidJalali(y: Int, m: Int, d: Int): Boolean {
    if (m !in 1..12 || d !in 1..31) return false
    return try {
        PersianCalendar(jalaliUtc).apply {
            isLenient = false
            clear()
            set(Calendar.YEAR, y)
            set(Calendar.MONTH, m - 1)
            set(Calendar.DAY_OF_MONTH, d)
            timeInMillis
        }
        true
    } catch (_: Exception) {
        false
    }
}

fun jalaliToGregorian(y: Int, m: Int, d: Int): LocalDate {
    val c = PersianCalendar(jalaliUtc).apply {
        isLenient = false
        clear()
        set(Calendar.YEAR, y)
        set(Calendar.MONTH, m - 1)
        set(Calendar.DAY_OF_MONTH, d)
    }
    return Instant.ofEpochMilli(c.timeInMillis).atZone(ZoneOffset.UTC).toLocalDate()
}

fun gregorianToJalali(date: LocalDate): Triple<Int, Int, Int> {
    val c = PersianCalendar(jalaliUtc)
    c.timeInMillis = date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
    return Triple(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
}

fun jalaliMonthLength(y: Int, m: Int): Int = when (m) {
    in 1..6 -> 31
    in 7..11 -> 30
    12 -> if (isValidJalali(y, 12, 30)) 30 else 29
    else -> 0
}

internal fun fullCalendarDate(date: String): String {
    val dateParts = date.split('-').mapNotNull { it.toIntOrNull() }
    if (dateParts.size != 3 || !isValidJalali(dateParts[0], dateParts[1], dateParts[2])) return date
    val g = jalaliToGregorian(dateParts[0], dateParts[1], dateParts[2])
    val weekday = weekDayNames[(g.dayOfWeek.value + 1) % 7]
    return "$weekday ${persianDigits(dateParts[2].toString())} ${monthNames[dateParts[1] - 1]} ${persianDigits(dateParts[0].toString())}"
}

/** Shared lunar display for calendar and persistent date notification. */
fun jalaliLunarDateDisplay(date: String): String = monthGregorianAndHijri(date, 0).second

internal fun monthGregorianAndHijri(date: String, dayOffset: Int): Pair<String, String> {
    val p = date.split('-').mapNotNull { it.toIntOrNull() }
    if (p.size != 3 || !isValidJalali(p[0],p[1],p[2])) return "" to ""
    val g = jalaliToGregorian(p[0],p[1],p[2])
    val gregorian = "${persianDigits(g.dayOfMonth.toString())} ${g.month.getDisplayName(java.time.format.TextStyle.FULL, Locale.ENGLISH)} ${persianDigits(g.year.toString())}"
    // Civil astronomical conversion is not the Iranian moon-sighting announcement.
    // Iranian-calendar reference anchors for 1405/08, independently corroborated:
    // 1405/08/01 = 1448/05/12 (2026-10-23),
    // 1405/08/20 = 1448/06/01 (2026-11-11),
    // 1405/08/22 = 1448/06/03 (2026-11-13).
    // This month is not derived from a user-controlled offset or a global +1 guess.
    if (p[0] == 1405 && p[1] == 8) {
        val nextMonth = LocalDate.of(2026, 11, 11)
        val firstAnchor = LocalDate.of(2026, 10, 23)
        val monthNumber = if (g.isBefore(nextMonth)) 4 else 5 // zero-based ICU month numbers
        val dayOfLunarMonth = if (g.isBefore(nextMonth)) {
            12 + java.time.temporal.ChronoUnit.DAYS.between(firstAnchor, g).toInt()
        } else {
            1 + java.time.temporal.ChronoUnit.DAYS.between(nextMonth, g).toInt()
        }
        return gregorian to "${persianDigits(dayOfLunarMonth.toString())} ${islamicMonthNames[monthNumber]} ۱۴۴۸"
    }
    // Outside the cross-checked interval, retain a clearly marked estimated Hijri date.
    val hijri = IslamicCalendar(jalaliUtc).apply {
        timeInMillis = g.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
    }
    val islamicMonth = islamicMonthNames.getOrElse(hijri.get(Calendar.MONTH)) { "" }
    return gregorian to "${persianDigits(hijri.get(Calendar.DAY_OF_MONTH).toString())} $islamicMonth ${persianDigits(hijri.get(Calendar.YEAR).toString())} (محاسباتی)"
}


// Numeric display derives from the same date data as the written display.
internal fun numericGregorianForCalendar(jalaliDate: String): String {
    val parts = jalaliDate.split('-').mapNotNull { it.toIntOrNull() }
    if (parts.size != 3 || !isValidJalali(parts[0],parts[1],parts[2])) return jalaliDate
    val date = jalaliToGregorian(parts[0],parts[1],parts[2])
    return persianDigits("%04d/%02d/%02d".format(Locale.ROOT, date.year, date.monthValue, date.dayOfMonth))
}

internal fun numericHijriForCalendar(written: String): String {
    val fields = written.substringBefore(" (").trim().split(Regex("\\s+"))
    if (fields.size < 3) return written
    val month = islamicMonthNames.indexOf(fields[1]) + 1
    if (month < 1) return written
    val persianNumbers = "۰۱۲۳۴۵۶۷۸۹"
    fun parseDigits(s:String): Int? = s.map { c ->
        val index = persianNumbers.indexOf(c)
        if (index >= 0) ('0' + index) else c
    }.joinToString("").toIntOrNull()
    val day = parseDigits(fields[0]) ?: return written
    val year = parseDigits(fields[2]) ?: return written
    return persianDigits("%04d/%02d/%02d".format(Locale.ROOT, year, month, day))
}

@Composable
fun JalaliCalendarScreen(
    year: Int,
    month: Int,
    selectedDate: String,
    onMonthChange: (Int, Int) -> Unit,
    onSelectDate: (String) -> Unit,
    onOpenWorkday: (String) -> Unit,
    modifier: Modifier = Modifier,
    holidays: Map<String, String> = emptyMap(),
    events: Map<String, String> = emptyMap(),
    hijriDayOffset: Int = 0
) {
    val context = LocalContext.current
    val firstDay = jalaliToGregorian(year, month, 1)
    // Week starts Saturday; each weekday is fully written, not abbreviated.
    val offset = (firstDay.dayOfWeek.value + 1) % 7
    val count = jalaliMonthLength(year, month)
    val cells = List(offset) { 0 } + (1..count).toList()
    val weeks = cells.chunked(7).map { week -> week + List(7 - week.size) { 0 } }
    var previewDate by remember(year, month, selectedDate) {
        mutableStateOf(
            if (selectedDate.startsWith("%04d-%02d".format(Locale.ROOT, year, month))) selectedDate
            else "%04d-%02d-01".format(Locale.ROOT, year, month)
        )
    }
    val today = remember { LocalDate.now() }
    val selectedHoliday = holidays[previewDate]
    val selectedEvents = events[previewDate].orEmpty().split("،").map { it.trim() }.filter { it.isNotBlank() }
    val entries = (listOfNotNull(selectedHoliday).flatMap { it.split("،") } + selectedEvents)
        .map { it.trim() }.filter { it.isNotBlank() }.distinct()
    val dateParts = previewDate.split('-').mapNotNull { it.toIntOrNull() }
    val selectedDay = dateParts.getOrElse(2) { 1 }
    val (_, lunar) = remember(previewDate, hijriDayOffset) { monthGregorianAndHijri(previewDate, hijriDayOffset) }
    var gregorianNumeric by remember(previewDate) { mutableStateOf(false) }
    var lunarNumeric by remember(previewDate) { mutableStateOf(false) }
    val gregorianDisplay = if (gregorianNumeric) numericGregorianForCalendar(previewDate) else monthGregorianAndHijri(previewDate, hijriDayOffset).first
    val lunarDisplay = if (lunarNumeric) numericHijriForCalendar(lunar) else lunar
    val prayerCities = remember(context) { PrayerRemote.cities(context) }
    val prayerCityIndex = CompanionAlerts.selectedCity(context).coerceIn(0, (prayerCities.size - 1).coerceAtLeast(0))
    val prayerCity = prayerCities.getOrNull(prayerCityIndex) ?: prayerCities.firstOrNull()
    val prayerAdjustment = CompanionAlerts.offset(context)
    val prayerTimes = remember(previewDate, prayerCity?.slug, prayerAdjustment) {
        try {
            val parts = previewDate.split('-').mapNotNull { it.toIntOrNull() }
            if (parts.size == 3 && prayerCity != null && isValidJalali(parts[0], parts[1], parts[2])) {
                PrayerRemote.resolved(context, prayerCity, jalaliToGregorian(parts[0], parts[1], parts[2]), prayerAdjustment)
            } else emptyMap()
        } catch (_: Exception) { emptyMap() }
    }
    val prayerLabels = listOf("اذان صبح", "طلوع آفتاب", "اذان ظهر", "غروب آفتاب", "اذان مغرب", "نیمه‌شب شرعی")

    Column(
        modifier = modifier.fillMaxSize()
            .pointerInput(year, month) {
                var horizontalDistance = 0f
                detectHorizontalDragGestures(
                    onHorizontalDrag = { _, dragAmount -> horizontalDistance += dragAmount },
                    onDragEnd = {
                        when {
                            // Finger moving right advances to the next month; left goes back.
                            horizontalDistance > 75f -> onMonthChange(if (month == 12) year + 1 else year, if (month == 12) 1 else month + 1)
                            horizontalDistance < -75f -> onMonthChange(if (month == 1) year - 1 else year, if (month == 1) 12 else month - 1)
                        }
                        horizontalDistance = 0f
                    },
                    onDragCancel = { horizontalDistance = 0f }
                )
            }
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 9.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Replacement for the old previous/next controls: a compact two-row date header.
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFFE0EEFD)),
            shape = RoundedCornerShape(15.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFB6D2EF), RoundedCornerShape(15.dp))
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(weekDayNames[(jalaliToGregorian(year, month, selectedDay.coerceIn(1, count)).dayOfWeek.value + 1) % 7], fontSize = 15.sp, fontWeight = FontWeight.Bold, color = calendarBlue, textAlign = TextAlign.End, maxLines = 1)
                    Text(
                        "قمری: $lunarDisplay",
                        modifier = Modifier.fillMaxWidth().clickable { lunarNumeric = !lunarNumeric },
                        fontSize = 10.sp, color = Color(0xFF426A8A), textAlign = TextAlign.End, maxLines = 2, lineHeight = 13.sp
                    )
                }
                Box(
                    Modifier.size(64.dp).background(Color.White, androidx.compose.foundation.shape.CircleShape)
                        .border(2.dp, Color(0xFF3777C4), androidx.compose.foundation.shape.CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(persianDigits(selectedDay.toString()), fontSize = 27.sp, fontWeight = FontWeight.Bold, color = calendarBlue)
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.Start, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${monthNames[month - 1]} ${persianDigits(year.toString())}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = calendarBlue, maxLines = 1)
                    Text(
                        "میلادی: $gregorianDisplay",
                        modifier = Modifier.fillMaxWidth().clickable { gregorianNumeric = !gregorianNumeric },
                        fontSize = 10.sp, color = Color(0xFF426A8A), textAlign = TextAlign.Start, maxLines = 2, lineHeight = 13.sp
                    )
                }
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(15.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFD3E3F4), RoundedCornerShape(15.dp))
        ) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth()) {
                    weekDayNames.forEachIndexed { i, name ->
                        Box(Modifier.weight(1f).height(28.dp), contentAlignment = Alignment.Center) {
                            Text(name, color = if (i == 6) calendarRed else calendarBlue, fontWeight = FontWeight.Bold, fontSize = 8.5.sp, maxLines = 1)
                        }
                    }
                }
                weeks.forEach { week ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        week.forEachIndexed { column, dayNumber ->
                            Box(Modifier.weight(1f).aspectRatio(0.88f), contentAlignment = Alignment.Center) {
                                if (dayNumber > 0) {
                                    val itemDate = "%04d-%02d-%02d".format(Locale.ROOT, year, month, dayNumber)
                                    val isHoliday = column == 6 || holidays.containsKey(itemDate)
                                    val hasEvent = events.containsKey(itemDate)
                                    val isToday = jalaliToGregorian(year, month, dayNumber) == today
                                    val isPreview = itemDate == previewDate
                                    Surface(
                                        onClick = { previewDate = itemDate; onSelectDate(itemDate) },
                                        color = when {
                                            isPreview -> Color(0xFFD8E9FF)
                                            isHoliday -> Color(0xFFFFE6E6)
                                            hasEvent -> Color(0xFFFFF1D7)
                                            else -> Color(0xFFF4F8FE)
                                        },
                                        shape = RoundedCornerShape(9.dp),
                                        modifier = Modifier.fillMaxSize().then(
                                            if (isPreview) Modifier.border(2.dp, Color(0xFF3777C4), RoundedCornerShape(9.dp))
                                            else if (isToday) Modifier.border(1.5.dp, Color(0xFF3777C4), RoundedCornerShape(9.dp))
                                            else Modifier
                                        )
                                    ) {
                                        Column(Modifier.fillMaxSize().padding(vertical = 3.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                            Text(persianDigits(dayNumber.toString()), color = if (isHoliday) calendarRed else calendarBlue, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                                            if (isHoliday || hasEvent) Text(if (isHoliday) "●" else "•", color = if (isHoliday) calendarRed else Color(0xFFA86F0C), fontSize = 10.sp, lineHeight = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    LegendDot("تعطیل / جمعه", Color(0xFFFFE6E6), calendarRed)
                    LegendDot("مناسبت", Color(0xFFFFF1D7), Color(0xFFA86F0C))
                    LegendDot("انتخاب‌شده", Color(0xFFD8E9FF), Color(0xFF3777C4))
                }
                Text("کشیدن به راست: ماه بعد  •  کشیدن به چپ: ماه قبل", color = Color(0xFF52718D), fontSize = 10.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(13.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFB6D2EF), RoundedCornerShape(13.dp))
        ) {
            Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("اوقات شرعی", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = calendarBlue)
                    Text(prayerCity?.name.orEmpty(), fontSize = 10.sp, color = Color(0xFF52718D))
                }
                prayerLabels.chunked(3).forEach { rowLabels ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        rowLabels.forEach { label ->
                            Column(
                                Modifier.weight(1f).background(Color(0xFFF3F8FE), RoundedCornerShape(8.dp))
                                    .border(1.dp, Color(0xFFD8E6F5), RoundedCornerShape(8.dp)).padding(vertical = 7.dp, horizontal = 2.dp),
                                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(label, fontSize = 9.sp, fontWeight = FontWeight.Medium, color = Color(0xFF426A8A), maxLines = 1)
                                val time = prayerTimes[label]?.format(DateTimeFormatter.ofPattern("HH:mm", Locale.ROOT))
                                Text(time?.let(::persianDigits) ?: "—", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = calendarBlue)
                            }
                        }
                    }
                }
                if (prayerTimes.isEmpty()) Text("اوقات شرعی برای این تاریخ در دسترس نیست.", fontSize = 10.sp, color = Color(0xFF7A8794))
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = if (selectedHoliday != null) Color(0xFFFFF2F2) else Color(0xFFFFFBF1)),
            shape = RoundedCornerShape(13.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, if (selectedHoliday != null) Color(0xFFE57373) else Color(0xFFE5C34A), RoundedCornerShape(13.dp))
        ) {
            Column(Modifier.fillMaxWidth().padding(11.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("مناسبت‌های روز", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = if (selectedHoliday != null) calendarRed else Color(0xFF795500))
                Text(fullCalendarDate(previewDate), fontSize = 11.sp, color = Color(0xFF52718D))
                if (selectedHoliday != null) Text("تعطیل رسمی", color = calendarRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                if (entries.isEmpty()) {
                    Text("مناسبتی برای این روز در داده‌های فعلی ثبت نشده است.", fontSize = 11.sp, color = Color(0xFF64778A))
                } else {
                    entries.forEach { title ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("•", color = if (selectedHoliday?.contains(title) == true) calendarRed else Color(0xFFA86F0C))
                            Text(title, fontSize = 12.sp, color = Color(0xFF294B68), modifier = Modifier.weight(1f), lineHeight = 19.sp)
                        }
                    }
                }
                Button(
                    onClick = { onOpenWorkday(previewDate) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("رفتن به مدیریت کارکرد این روز", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun LegendDot(label: String, bg: Color, fg: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        Box(Modifier.size(10.dp).background(bg, RoundedCornerShape(3.dp)).border(1.dp, fg, RoundedCornerShape(3.dp)))
        Text(label, fontSize = 9.sp, color = Color(0xFF41617E))
    }
}

fun persianDigits(value: String): String = value.map { if (it in '0'..'9') (0x06F0 + (it - '0')).toChar() else it }.joinToString("")
