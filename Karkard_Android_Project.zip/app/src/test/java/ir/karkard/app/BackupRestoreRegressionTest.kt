package ir.karkard.app

import java.time.Instant
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

/** End-to-end regression tests for the actual SQLite + CSV/XLSX backup paths. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class BackupRestoreRegressionTest {
    private lateinit var context: android.app.Application
    private lateinit var db: WorkDb

    @Before
    fun setUp() {
        context = RuntimeEnvironment.getApplication()
        context.deleteDatabase("karkard.db")
        context.deleteDatabase("vaghtnegar_reminders.db")
        db = WorkDb(context)
    }

    @After
    fun tearDown() {
        db.close()
        context.deleteDatabase("karkard.db")
        context.deleteDatabase("vaghtnegar_reminders.db")
    }

    private fun fullTestDay(): WorkDay = WorkDay(
        date = "1405-08-11",
        in1 = "07:55", out1 = "12:10",
        in2 = "13:00", out2 = "16:35",
        in3 = "", out3 = "",
        note = "جلسه, بررسی \"گزارش\"\nپیگیری کار روزانه",
        dayType = "کاری",
        overtimeOverride = "00:45",
        shiftEnabled = true,
        shiftStart = "17:00", shiftEnd = "07:00",
        shiftStartDate = "1405-08-11", shiftEndDate = "1405-08-12",
        holidayIn = "17:10", holidayOut = "20:20",
        leave1Start = "09:15", leave1End = "09:30",
        leave2Start = "14:00", leave2End = "14:20",
        hourlyLeaveEnabled = true,
        extraDayTypes = "استحقاقی",
        leave3Start = "", leave3End = "",
        holidayIn2 = "21:00", holidayOut2 = "22:00",
        scheduleMode = "ثابت"
    )

    private fun assertRestored(expected: WorkDay) {
        assertEquals(listOf(expected), db.allDaysForBackup())
    }

    @Test
    fun csvBackupRestoresAllDayFieldsSettingsHolidayAndReminders() {
        val expected = fullTestDay()
        db.saveDay(expected)
        db.setSettingText("custom_regression_setting", "مقدار آزمایشی")
        db.saveHoliday("1405-08-13", "تعطیلی موردی")

        val reminderStore = ReminderStore(context)
        val reminderId = reminderStore.add(
            kind = "سایر",
            title = "یادآور آزمون رگرسیون",
            millis = Instant.parse("2026-11-02T09:30:00Z").toEpochMilli(),
            monthly = true,
            sound = "content://test/regression"
        )
        val backup = buildBackupCsv(db)

        // Spreadsheet-edited Persian digits and slash separators must still import.
        val localizedBackup = backup
            .replace("1405-08-11", "۱۴۰۵/۰۸/۱۱")
            .replace("1405-08-12", "۱۴۰۵/۰۸/۱۲")
        val (days, settings) = readBackupCsv(localizedBackup)
        assertEquals(listOf(expected), days)
        assertTrue(settings.any { it.first == "custom_regression_setting" && it.second == "مقدار آزمایشی" })

        db.deleteWorkRecord(expected.date)
        db.removeHoliday("1405-08-13")
        db.setSettingText("custom_regression_setting", "مقدار قدیمی")
        reminderStore.delete(reminderId)

        assertEquals(1, db.restoreBackup(days, settings))
        assertRestored(expected)
        assertEquals("تعطیلی موردی", db.holidayTitle("1405-08-13"))
        assertEquals("مقدار آزمایشی", db.getSettingText("custom_regression_setting", ""))
        val restoredReminder = ReminderStore(context).all().single()
        assertEquals(reminderId, restoredReminder.id)
        assertEquals("یادآور آزمون رگرسیون", restoredReminder.title)
        assertEquals("content://test/regression", restoredReminder.soundUri)
        assertTrue(restoredReminder.monthly)
        assertTrue(restoredReminder.enabled)
    }

    @Test
    fun xlsxBackupRestoresDayFieldsAndSettings() {
        val expected = fullTestDay()
        db.saveDay(expected)
        db.setSettingText("xlsx_regression_setting", "restored")
        val backup = buildBackupXlsx(db)

        val (days, settings) = readBackupXlsx(backup)
        assertEquals(listOf(expected), days)

        db.deleteWorkRecord(expected.date)
        db.setSettingText("xlsx_regression_setting", "changed")
        assertEquals(1, db.restoreBackup(days, settings))

        assertRestored(expected)
        assertEquals("restored", db.getSettingText("xlsx_regression_setting", ""))
    }

    @Test
    fun complementaryDuplicateCsvRowsMergeWithoutDroppingIntervalsOrNotes() {
        val first = WorkDay(
            date = "1405-08-11", in1 = "08:00", out1 = "12:00", note = "نوبت اول"
        )
        val second = WorkDay(
            date = "1405-08-11", in2 = "13:00", out2 = "17:00", note = "نوبت دوم"
        )
        val backup = buildBackupCsv(db, listOf(first, second))

        val (days, _) = readBackupCsv(backup)

        assertEquals(1, days.size)
        assertEquals("08:00", days.single().in1)
        assertEquals("12:00", days.single().out1)
        assertEquals("13:00", days.single().in2)
        assertEquals("17:00", days.single().out2)
        assertEquals("نوبت اول\nنوبت دوم", days.single().note)
    }

    @Test
    fun invalidOrEmptyRestoreDoesNotEraseExistingRecords() {
        val existing = fullTestDay()
        db.saveDay(existing)

        assertThrows(IllegalArgumentException::class.java) {
            db.restoreBackup(emptyList(), emptyList())
        }
        assertThrows(IllegalArgumentException::class.java) {
            db.restoreBackup(listOf(WorkDay(date = "1405-13-40")), emptyList())
        }

        assertRestored(existing)
    }
}
