package ir.karkard.app

import java.time.Instant
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

/** End-to-end regression tests for the actual SQLite + CSV/XLSX backup paths. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class BackupRestoreRegressionTest {
    private lateinit var context: android.app.Application
    private lateinit var db: WorkDb

    @Before
    fun setUp() {
        context = RuntimeEnvironment.getApplication()
        context.deleteDatabase("karkard.db")
        context.deleteDatabase("vaghtnegar_reminders.db")
        db = WorkDb(context)
    }

    @After
    fun tearDown() {
        db.close()
        context.deleteDatabase("karkard.db")
        context.deleteDatabase("vaghtnegar_reminders.db")
    }

    private fun fullTestDay(): WorkDay = WorkDay(
        date = "1405-08-11",
        in1 = "07:55", out1 = "12:10",
        in2 = "13:00", out2 = "16:35",
        in3 = "", out3 = "",
        note = "جلسه, بررسی \"گزارش\"\nپیگیری کار روزانه",
        dayType = "کاری",
        overtimeOverride = "00:45",
        shiftEnabled = true,
        shiftStart = "17:00", shiftEnd = "07:00",
        shiftStartDate = "1405-08-11", shiftEndDate = "1405-08-12",
        holidayIn = "17:10", holidayOut = "20:20",
        leave1Start = "09:15", leave1End = "09:30",
        leave2Start = "14:00", leave2End = "14:20",
        hourlyLeaveEnabled = true,
        extraDayTypes = "استحقاقی",
        leave3Start = "", leave3End = "",
        holidayIn2 = "21:00", holidayOut2 = "22:00",
        scheduleMode = "ثابت"
    )

    private fun assertRestored(expected: WorkDay) {
        assertEquals(listOf(expected), db.allDaysForBackup())
    }

    @Test
    fun csvWorkBackupRestoresWorkDataButNeverIncludesOrChangesReminders() {
        val expected = fullTestDay()
        db.saveDay(expected)
        db.setSettingText("custom_regression_setting", "مقدار آزمایشی")
        db.saveHoliday("1405-08-13", "تعطیلی موردی")

        val reminderStore = ReminderStore(context)
        val reminderId = reminderStore.add(
            kind = "سایر",
            title = "یادآور آزمون رگرسیون",
            millis = Instant.parse("2026-11-02T09:30:00Z").toEpochMilli(),
            monthly = true,
            sound = "content://test/regression"
        )
        val backup = buildBackupCsv(db)

        // Spreadsheet-edited Persian digits and slash separators must still import.
        val localizedBackup = backup
            .replace("1405-08-11", "۱۴۰۵/۰۸/۱۱")
            .replace("1405-08-12", "۱۴۰۵/۰۸/۱۲")
        val (days, settings) = readBackupCsv(localizedBackup)
        assertEquals(listOf(expected), days)
        assertTrue(settings.any { it.first == "custom_regression_setting" && it.second == "مقدار آزمایشی" })
        assertFalse(settings.any { it.first == "backup_reminders_included" || it.first.startsWith("backup_reminder:") })

        db.deleteWorkRecord(expected.date)
        db.removeHoliday("1405-08-13")
        db.setSettingText("custom_regression_setting", "مقدار قدیمی")
        // Change the reminder after making the work backup. Restoring work data must
        // neither restore its old value nor delete the independent reminder record.
        reminderStore.update(reminderId, "جلسه", "یادآور مستقل و جدید", Instant.parse("2026-11-03T10:45:00Z").toEpochMilli(), false, "content://test/changed")

        assertEquals(1, db.restoreBackup(days, settings))
        assertRestored(expected)
        assertEquals("تعطیلی موردی", db.holidayTitle("1405-08-13"))
        assertEquals("مقدار آزمایشی", db.getSettingText("custom_regression_setting", ""))
        val reminderAfterWorkRestore = ReminderStore(context).all().single()
        assertEquals(reminderId, reminderAfterWorkRestore.id)
        assertEquals("یادآور مستقل و جدید", reminderAfterWorkRestore.title)
        assertEquals("content://test/changed", reminderAfterWorkRestore.soundUri)
        assertEquals("جلسه", reminderAfterWorkRestore.kind)
        assertFalse(reminderAfterWorkRestore.monthly)
    }

    @Test
    fun xlsxBackupRestoresDayFieldsAndSettings() {
        val expected = fullTestDay()
        db.saveDay(expected)
        db.setSettingText("xlsx_regression_setting", "restored")
        val reminderStore = ReminderStore(context)
        val reminderId = reminderStore.add(
            kind = "جلسه",
            title = "یادآور مستقل از پشتیبان کارکرد",
            millis = Instant.parse("2026-11-07T12:20:00Z").toEpochMilli(),
            monthly = false,
            sound = "content://test/xlsx-reminder"
        )
        val backup = buildBackupXlsx(db)

        val (days, settings) = readBackupXlsx(backup)
        assertEquals(listOf(expected), days)
        assertFalse(settings.any { it.first == "backup_reminders_included" || it.first.startsWith("backup_reminder:") })
        assertFalse(settings.any { it.second.contains("یادآور مستقل از پشتیبان کارکرد") })

        db.deleteWorkRecord(expected.date)
        db.setSettingText("xlsx_regression_setting", "changed")
        reminderStore.update(reminderId, "قسط", "یادآور پس از تهیه فایل", Instant.parse("2026-11-08T13:25:00Z").toEpochMilli(), true, "content://test/changed-xlsx-reminder")
        assertEquals(1, db.restoreBackup(days, settings))

        assertRestored(expected)
        assertEquals("restored", db.getSettingText("xlsx_regression_setting", ""))
        val reminderAfterRestore = ReminderStore(context).all().single()
        assertEquals(reminderId, reminderAfterRestore.id)
        assertEquals("یادآور پس از تهیه فایل", reminderAfterRestore.title)
        assertEquals("content://test/changed-xlsx-reminder", reminderAfterRestore.soundUri)
        assertEquals("قسط", reminderAfterRestore.kind)
        assertTrue(reminderAfterRestore.monthly)
    }

    @Test
    fun legacyFullBackupReminderRowsAreIgnoredAndCannotOverwriteReminderStore() {
        val day = fullTestDay()
        db.saveDay(day)
        val reminderStore = ReminderStore(context)
        val currentId = reminderStore.add(
            kind = "جلسه",
            title = "یادآور فعلی گوشی",
            millis = Instant.parse("2026-11-04T08:15:00Z").toEpochMilli(),
            monthly = false,
            sound = "content://current/sound"
        )
        val legacySettings = listOf(
            "backup_reminders_included" to "true",
            "backup_reminder:999" to "{\"kind\":\"قسط\",\"title\":\"یادآور قدیمی\",\"whenMillis\":1793696400000,\"monthly\":true,\"soundUri\":\"content://legacy\",\"enabled\":true}"
        )

        assertEquals(1, db.restoreBackup(listOf(day), legacySettings))
        val after = ReminderStore(context).all().single()
        assertEquals(currentId, after.id)
        assertEquals("یادآور فعلی گوشی", after.title)
        assertEquals("content://current/sound", after.soundUri)
    }

    @Test
    fun dedicatedReminderExcelBackupRoundTripsOnlyReminderRecords() {
        val reminderStore = ReminderStore(context)
        val firstId = reminderStore.add(
            kind = "قسط",
            title = "قسط ماهانه، بخش اول",
            millis = Instant.parse("2026-11-05T09:30:00Z").toEpochMilli(),
            monthly = true,
            sound = "content://test/installment"
        )
        val secondId = reminderStore.add(
            kind = "جلسه",
            title = "جلسه بررسی & <گزارش>",
            millis = Instant.parse("2026-11-06T14:05:00Z").toEpochMilli(),
            monthly = false,
            sound = "content://test/sound?a=1&b=2",
            description = "شرح جلسه برای آزمون پشتیبان",
            location = "اتاق جلسات؛ طبقه دوم",
            color = 0xFF2E7D32.toInt(),
            recurrence = ReminderRecurrence.DAILY,
            repeatEndType = ReminderRecurrence.END_COUNT,
            occurrenceLimit = 12,
            alertOffsetMinutes = 15
        )
        reminderStore.onOccurrenceFired(reminderStore.byId(secondId)!!, Instant.parse("2026-11-06T14:05:00Z").toEpochMilli())
        val secondNextDue = reminderStore.byId(secondId)!!.whenMillis
        reminderStore.updateTime(secondId, secondNextDue, false)
        val expected = reminderStore.all()
        val workday = fullTestDay()
        db.saveDay(workday)
        db.setSettingText("keep_work_setting", "unchanged")

        val bytes = buildReminderBackupXlsx(expected)
        val workbookEntries = mutableSetOf<String>()
        java.util.zip.ZipInputStream(bytes.inputStream()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                workbookEntries += entry.name
                zip.closeEntry()
            }
        }
        assertTrue(workbookEntries.contains("xl/styles.xml"))
        assertTrue(workbookEntries.contains("xl/worksheets/sheet1.xml"))
        assertFalse(workbookEntries.contains("xl/worksheets/sheet2.xml"))
        val restored = readReminderBackupXlsx(bytes)
        assertEquals(expected, restored)
        assertEquals(listOf(workday), db.allDaysForBackup())
        assertEquals("unchanged", db.getSettingText("keep_work_setting", ""))

        reminderStore.replaceAll(emptyList())
        reminderStore.replaceAll(restored)
        val finalRows = reminderStore.all()
        assertEquals(2, finalRows.size)
        assertEquals(firstId, finalRows.first { it.kind == "قسط" }.id)
        assertEquals("قسط ماهانه، بخش اول", finalRows.first { it.kind == "قسط" }.title)
        assertTrue(finalRows.first { it.kind == "قسط" }.monthly)
        assertEquals("content://test/installment", finalRows.first { it.kind == "قسط" }.soundUri)
        val restoredMeeting = finalRows.first { it.kind == "جلسه" }
        assertEquals("شرح جلسه برای آزمون پشتیبان", restoredMeeting.description)
        assertEquals("اتاق جلسات؛ طبقه دوم", restoredMeeting.location)
        assertEquals(0xFF2E7D32.toInt(), restoredMeeting.color)
        assertEquals(ReminderRecurrence.DAILY, restoredMeeting.recurrence)
        assertEquals(ReminderRecurrence.END_COUNT, restoredMeeting.repeatEndType)
        assertEquals(12, restoredMeeting.occurrenceLimit)
        assertEquals(15, restoredMeeting.alertOffsetMinutes)
        assertEquals(1, restoredMeeting.firedCount)
        assertTrue(restoredMeeting.whenMillis > restoredMeeting.anchorMillis)
        assertEquals(listOf(workday), db.allDaysForBackup())
    }

    @Test
    fun dedicatedReminderExcelBackupCanRepresentAnIntentionallyEmptyListAndRejectWorkBackup() {
        val emptyReminderBackup = buildReminderBackupXlsx(emptyList())
        assertTrue(readReminderBackupXlsx(emptyReminderBackup).isEmpty())
        assertThrows(IllegalArgumentException::class.java) {
            readReminderBackupXlsx(buildBackupXlsx(db))
        }
        assertThrows(IllegalArgumentException::class.java) {
            readReminderBackupXlsx("not an xlsx".toByteArray())
        }
    }

    @Test
    fun complementaryDuplicateCsvRowsMergeWithoutDroppingIntervalsOrNotes() {
        val first = WorkDay(
            date = "1405-08-11", in1 = "08:00", out1 = "12:00", note = "نوبت اول"
        )
        val second = WorkDay(
            date = "1405-08-11", in2 = "13:00", out2 = "17:00", note = "نوبت دوم"
        )
        val backup = buildBackupCsv(db, listOf(first, second))

        val (days, _) = readBackupCsv(backup)

        assertEquals(1, days.size)
        assertEquals("08:00", days.single().in1)
        assertEquals("12:00", days.single().out1)
        assertEquals("13:00", days.single().in2)
        assertEquals("17:00", days.single().out2)
        assertEquals("نوبت اول\nنوبت دوم", days.single().note)
    }

    @Test
    fun invalidOrEmptyRestoreDoesNotEraseExistingRecords() {
        val existing = fullTestDay()
        db.saveDay(existing)

        assertThrows(IllegalArgumentException::class.java) {
            db.restoreBackup(emptyList(), emptyList())
        }
        assertThrows(IllegalArgumentException::class.java) {
            db.restoreBackup(listOf(WorkDay(date = "1405-13-40")), emptyList())
        }

        assertRestored(existing)
    }

    @Test
    fun reminderDatabaseV1MigratesAdditivelyAndPreservesLegacyMonthlyRows() {
        context.deleteDatabase("vaghtnegar_reminders.db")
        val file = context.getDatabasePath("vaghtnegar_reminders.db")
        file.parentFile?.mkdirs()
        val legacy = android.database.sqlite.SQLiteDatabase.openOrCreateDatabase(file, null)
        legacy.execSQL("CREATE TABLE reminders(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,title TEXT NOT NULL,when_ms INTEGER NOT NULL,monthly INTEGER NOT NULL DEFAULT 0,sound TEXT DEFAULT '',enabled INTEGER NOT NULL DEFAULT 1)")
        legacy.execSQL("INSERT INTO reminders(id,kind,title,when_ms,monthly,sound,enabled) VALUES(7,'قسط','یادآور قدیمی',1793696400000,1,'content://legacy',1)")
        legacy.version = 1
        legacy.close()

        val migrated = ReminderStore(context).all().single()
        assertEquals(7L, migrated.id)
        assertEquals("یادآور قدیمی", migrated.title)
        assertEquals("content://legacy", migrated.soundUri)
        assertEquals(ReminderRecurrence.MONTHLY, migrated.recurrence)
        assertEquals("", migrated.description)
        assertEquals("", migrated.location)
        assertEquals(0, migrated.alertOffsetMinutes)
        assertEquals(migrated.whenMillis, migrated.anchorMillis)
    }


    @Test
    fun reminderOccurrenceAdvancesNextDueWithoutChangingAnchorOrLosingCountOnEdit() {
        val store = ReminderStore(context)
        val start = jalaliToGregorian(1405, 8, 10).atTime(9, 0).atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        val id = store.add(
            kind = "سایر", title = "تکرار روزانه", millis = start, monthly = false, sound = "",
            recurrence = ReminderRecurrence.DAILY,
            repeatEndType = ReminderRecurrence.END_COUNT,
            occurrenceLimit = 2
        )
        val first = store.byId(id)!!
        store.onOccurrenceFired(first, start)
        val second = store.byId(id)!!
        assertEquals(1, second.firedCount)
        assertTrue(second.enabled)
        assertEquals(start, second.anchorMillis)
        assertTrue(second.whenMillis > start)

        store.update(
            id = id, kind = second.kind, title = "عنوان ویرایش‌شده", millis = second.anchorMillis,
            monthly = false, sound = second.soundUri, recurrence = ReminderRecurrence.DAILY,
            repeatEndType = ReminderRecurrence.END_COUNT, occurrenceLimit = 2,
            currentDueMillis = second.whenMillis, anchorMillis = second.anchorMillis
        )
        val edited = store.byId(id)!!
        assertEquals(1, edited.firedCount)
        assertEquals(second.whenMillis, edited.whenMillis)
        assertEquals(start, edited.anchorMillis)

        store.onOccurrenceFired(edited, edited.whenMillis)
        val finished = store.byId(id)!!
        assertEquals(2, finished.firedCount)
        assertFalse(finished.enabled)
    }

}
