package ir.karkard.app

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

/** Regression tests for non-destructive calendar synchronization in the real SQLite store. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class CalendarSyncRegressionTest {
    private lateinit var context: android.app.Application
    private lateinit var db: WorkDb

    @Before
    fun setUp() {
        context = RuntimeEnvironment.getApplication()
        context.deleteDatabase("karkard.db")
        db = WorkDb(context)
    }

    @After
    fun tearDown() {
        db.close()
        context.deleteDatabase("karkard.db")
    }

    @Test
    fun repeatedSyncMergesEventsAndPreservesManualHolidayAndWorkRecord() {
        val workRecord = WorkDay(
            date = "1405-09-02",
            in1 = "08:00",
            out1 = "16:00",
            note = "یادداشت ثبت‌شده کاربر"
        )
        db.saveDay(workRecord)
        db.saveHoliday("1405-09-05", "تعطیل خاص ثبت‌شده توسط کاربر")

        db.replaceCalendarData(
            1405,
            holidays = listOf("1405-10-16" to "مبعث رسول اکرم (ص)"),
            events = listOf("1405-09-05" to "روز بسیج مستضعفان")
        )
        db.replaceCalendarData(
            1405,
            holidays = listOf("1405-10-16" to "مبعث رسول اکرم (ص)"),
            events = listOf(
                "1405-09-02" to "وفات حضرت ام‌البنین (س) و روز تکریم مادران و همسران شهدا",
                "1405-09-05" to "روز بسیج مستضعفان"
            )
        )

        val events = db.calendarEvents(1405).toMap()
        assertTrue(events.getValue("1405-09-02").contains("وفات حضرت ام‌البنین"))
        assertEquals("روز بسیج مستضعفان", events.getValue("1405-09-05"))
        assertEquals("تعطیل خاص ثبت‌شده توسط کاربر", db.holidayTitle("1405-09-05"))
        assertEquals(listOf(workRecord), db.allDaysForBackup())
        assertEquals(1, db.officialHolidays(1405).size)
    }

    @Test
    fun bundledCalendarMarkerUpgradeMergesCorrectionIntoExistingInstall() {
        db.replaceCalendarData(
            1405,
            holidays = Calendar1405.holidays,
            events = listOf("1405-09-05" to "روز بسیج مستضعفان")
        )
        db.setSettingText("calendar_1405_seed", "1405.2")
        db.saveHoliday("1405-09-06", "تعطیل خاص")
        val record = WorkDay(date = "1405-09-02", in1 = "07:30", out1 = "15:30")
        db.saveDay(record)

        db.ensureBundled1405Calendar()

        val events = db.calendarEvents(1405).toMap()
        assertTrue(events.getValue("1405-09-02").contains("وفات حضرت ام‌البنین"))
        assertTrue(events.getValue("1405-09-05").contains("روز بسیج مستضعفان"))
        assertFalse(db.officialHolidays(1405).any { it.first == "1405-09-02" })
        assertEquals("1405.3", db.getSettingText("calendar_1405_seed"))
        assertEquals("تعطیل خاص", db.holidayTitle("1405-09-06"))
        assertEquals(listOf(record), db.allDaysForBackup())
    }

    @Test
    fun invalidCalendarPayloadDoesNotDestroyPreviouslySavedCalendar() {
        db.replaceCalendarData(
            1405,
            holidays = listOf("1405-10-16" to "مبعث"),
            events = listOf("1405-09-02" to "مناسبت معتبر")
        )

        try {
            db.replaceCalendarData(1405, holidays = emptyList(), events = emptyList())
            throw AssertionError("An empty holiday payload should be rejected")
        } catch (_: IllegalArgumentException) {
            // Expected: empty/incomplete source responses must preserve the prior data.
        }

        assertEquals(listOf("1405-10-16" to "مبعث"), db.officialHolidays(1405))
        assertEquals("مناسبت معتبر", db.calendarEventTitle("1405-09-02"))
        assertTrue(db.calendarSyncTime(1405) > 0L)
    }
}
