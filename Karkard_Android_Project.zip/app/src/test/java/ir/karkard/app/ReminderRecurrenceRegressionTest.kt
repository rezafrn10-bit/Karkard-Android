package ir.karkard.app

import java.time.LocalTime
import java.time.ZoneId
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Regression coverage for reminder recurrence, end rules and pre-alert scheduling. */
class ReminderRecurrenceRegressionTest {
    private val zone = ZoneId.systemDefault()
    private fun instant(y: Int, m: Int, d: Int, h: Int = 9, min: Int = 0): Long =
        jalaliToGregorian(y, m, d).atTime(h, min).atZone(zone).toInstant().toEpochMilli()

    private fun reminder(
        whenMillis: Long,
        recurrence: String,
        weekdays: String = "",
        endType: String = ReminderRecurrence.END_NEVER,
        endDate: Long = 0L,
        limit: Int = 0,
        fired: Int = 0,
        offset: Int = 0
    ) = PersonalReminder(
        id = 1, kind = "سایر", title = "آزمون", whenMillis = whenMillis,
        monthly = recurrence == ReminderRecurrence.MONTHLY, soundUri = "", enabled = true,
        recurrence = recurrence, weekdays = weekdays, repeatEndType = endType,
        repeatEndDateMillis = endDate, occurrenceLimit = limit, firedCount = fired,
        alertOffsetMinutes = offset
    )

    @Test fun dailyRecurrenceMovesToNextLocalDayAndKeepsClockTime() {
        val r = reminder(instant(1405, 8, 10, 8, 45), ReminderRecurrence.DAILY)
        val next = ReminderRecurrence.next(r, r.whenMillis)!!
        assertEquals(instant(1405, 8, 11, 8, 45), next)
    }

    @Test fun weeklyRecurrenceHonorsSelectedIsoWeekdays() {
        val start = instant(1405, 8, 10, 9, 0)
        val r = reminder(start, ReminderRecurrence.WEEKLY, weekdays = "1,3")
        val next = ReminderRecurrence.next(r, start)!!
        val local = java.time.Instant.ofEpochMilli(next).atZone(zone)
        assertTrue(local.dayOfWeek.value == 1 || local.dayOfWeek.value == 3)
        assertTrue(next > start)
    }

    @Test fun monthlyRecurrenceClampsThirtyFirstToLastJalaliDay() {
        val start = instant(1405, 6, 31, 10, 15)
        val r = reminder(start, ReminderRecurrence.MONTHLY)
        val next = ReminderRecurrence.next(r, start)!!
        val (year, month, day) = gregorianToJalali(java.time.Instant.ofEpochMilli(next).atZone(zone).toLocalDate())
        assertEquals(1405, year)
        assertEquals(7, month)
        assertEquals(30, day)
        assertEquals(LocalTime.of(10, 15), java.time.Instant.ofEpochMilli(next).atZone(zone).toLocalTime())
        // The 31st remains the immutable pattern anchor after several months are clamped.
        val lateYearDue = instant(1405, 12, 29, 10, 15)
        val following = ReminderRecurrence.next(r.copy(whenMillis = lateYearDue), lateYearDue)!!
        val (followingYear, followingMonth, followingDay) = gregorianToJalali(java.time.Instant.ofEpochMilli(following).atZone(zone).toLocalDate())
        assertEquals(1406, followingYear)
        assertEquals(1, followingMonth)
        assertEquals(31, followingDay)
    }

    @Test fun yearlyRecurrenceClampsEsfandThirtiethInNonLeapYear() {
        val start = instant(1403, 12, 30, 7, 0)
        val r = reminder(start, ReminderRecurrence.YEARLY)
        val next = ReminderRecurrence.next(r, start)!!
        val (year, month, day) = gregorianToJalali(java.time.Instant.ofEpochMilli(next).atZone(zone).toLocalDate())
        assertEquals(1404, year)
        assertEquals(12, month)
        assertEquals(29, day)
        val lateYearDue = instant(1407, 12, 29, 7, 0)
        val nextLeapCycle = ReminderRecurrence.next(r.copy(whenMillis = lateYearDue), lateYearDue)!!
        val (nextYear, nextMonth, nextDay) = gregorianToJalali(java.time.Instant.ofEpochMilli(nextLeapCycle).atZone(zone).toLocalDate())
        assertEquals(1408, nextYear)
        assertEquals(12, nextMonth)
        assertEquals(if (isValidJalali(1408, 12, 30)) 30 else 29, nextDay)
    }

    @Test fun countEndRuleStopsAfterConfiguredTotalOccurrences() {
        val start = instant(1405, 8, 10)
        val r = reminder(start, ReminderRecurrence.DAILY, endType = ReminderRecurrence.END_COUNT, limit = 3, fired = 2)
        assertNull(ReminderRecurrence.next(r, start))
    }

    @Test fun dateEndRuleDoesNotScheduleBeyondEndDate() {
        val start = instant(1405, 8, 10)
        val end = instant(1405, 8, 10, 23, 59)
        val r = reminder(start, ReminderRecurrence.DAILY, endType = ReminderRecurrence.END_DATE, endDate = end)
        assertNull(ReminderRecurrence.next(r, start))
    }

    @Test fun alertOffsetSchedulesBeforeDueWithoutChangingDueInstant() {
        val due = instant(1405, 8, 10, 12, 0)
        val r = reminder(due, ReminderRecurrence.NONE, offset = 30)
        assertEquals(due - 30 * 60_000L, ReminderRecurrence.alarmTime(r))
        assertEquals(due, r.whenMillis)
        assertNotNull(r)
    }
}
