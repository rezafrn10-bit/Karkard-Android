package ir.karkard.app

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

/** Regression checks for time aggregation and the fixed weekly schedule. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class WorkTimeCalculationRegressionTest {
    private lateinit var context: android.app.Application
    private lateinit var db: WorkDb

    @Before
    fun setUp() {
        context = RuntimeEnvironment.getApplication()
        context.deleteDatabase("karkard.db")
        db = WorkDb(context)
    }

    @After
    fun tearDown() {
        db.close()
        context.deleteDatabase("karkard.db")
    }

    @Test
    fun floatingAttendanceSubtractsOverlappingHourlyLeaveOnlyOnce() {
        val day = WorkDay(
            date = "1405-08-11",
            in1 = "08:00", out1 = "12:00",
            in2 = "13:00", out2 = "17:00",
            leave1Start = "09:00", leave1End = "10:00",
            leave2Start = "09:30", leave2End = "10:30",
            scheduleMode = "شناور"
        )

        // Eight hours of presence minus the 90-minute union of overlapping leave intervals.
        assertEquals(390, duration(day))
    }

    @Test
    fun overnightAttendanceIsCountedAcrossMidnight() {
        val day = WorkDay(
            date = "1405-08-11",
            in1 = "22:00", out1 = "06:00",
            scheduleMode = "شناور"
        )

        assertEquals(480, duration(day))
    }

    @Test
    fun fixedScheduleUsesWeekdayAndThursdayHoursAndCapsMandatoryCredit() {
        val monday = WorkDay(
            date = "1405-08-11",
            in1 = "08:00", out1 = "12:00",
            scheduleMode = "ثابت"
        )
        val thursday = WorkDay(date = "1405-08-14", scheduleMode = "ثابت")
        val friday = WorkDay(date = "1405-08-15", scheduleMode = "ثابت")

        assertEquals(420, dailyRequiredMinutes(monday, db))
        assertEquals(300, dailyRequiredMinutes(thursday, db))
        assertEquals(0, dailyRequiredMinutes(friday, db))
        assertEquals(240, registeredMandatoryMinutes(monday, db))
        assertEquals(180, remainingMandatoryMinutes(monday, db))
    }
    @Test
    fun fixedSaturdayHourlyLeaveCompletesMandatoryWithoutReducingActualWork() {
        val saturday = WorkDay(
            date = "1405-08-09",
            in1 = "08:00", out1 = "14:00",
            leave1Start = "07:00", leave1End = "08:00",
            scheduleMode = "ثابت"
        )

        assertEquals(360, duration(saturday, db))
        assertEquals(60, hourlyLeaveMinutes(saturday, db))
        assertEquals(420, registeredMandatoryMinutes(saturday, db))
        assertEquals(0, remainingMandatoryMinutes(saturday, db))
        assertEquals(0, overtimeMinutes(saturday, db))
    }

    @Test
    fun fixedThursdayHourlyLeaveCompletesMandatoryAndKeepsOutsideOvertime() {
        val thursday = WorkDay(
            date = "1405-08-14",
            in1 = "07:00", out1 = "13:00",
            leave1Start = "09:00", leave1End = "10:00",
            scheduleMode = "ثابت"
        )

        assertEquals(360, duration(thursday, db))
        assertEquals(60, hourlyLeaveMinutes(thursday, db))
        assertEquals(300, registeredMandatoryMinutes(thursday, db))
        assertEquals(0, remainingMandatoryMinutes(thursday, db))
        assertEquals(60, overtimeMinutes(thursday, db))
    }

    @Test
    fun fixedHourlyLeaveOverlappingAttendanceIsNotDoubleCounted() {
        val saturday = WorkDay(
            date = "1405-08-09",
            in1 = "08:00", out1 = "14:00",
            leave1Start = "08:00", leave1End = "09:00",
            scheduleMode = "ثابت"
        )

        assertEquals(360, registeredMandatoryMinutes(saturday, db))
        assertEquals(60, hourlyLeaveMinutes(saturday, db))
        assertEquals(60, remainingMandatoryMinutes(saturday, db))
    }

}
