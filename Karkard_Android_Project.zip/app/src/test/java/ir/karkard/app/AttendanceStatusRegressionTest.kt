package ir.karkard.app

import org.junit.Assert.assertEquals
import org.junit.Test

/** Keeps the day category and attendance/leave status as independent dimensions. */
class AttendanceStatusRegressionTest {
    @Test
    fun legacyLeaveDayIsNormalizedWithoutLosingItsMeaning() {
        val legacy = WorkDay(date = "1405-08-11", dayType = "مرخصی")

        assertEquals("کاری", normalizedDayCategory(legacy))
        assertEquals("استحقاقی", normalizedAttendance(legacy))
    }

    @Test
    fun officialHolidayCanCoexistWithEntitlementLeaveStatus() {
        val workingDayWithLeave = WorkDay(
            date = "1405-08-11",
            dayType = "کاری",
            extraDayTypes = "استحقاقی"
        )

        val holiday = toggleDayStatus(workingDayWithLeave, "تعطیل رسمی")

        assertEquals("تعطیل رسمی", normalizedDayCategory(holiday))
        assertEquals("استحقاقی", normalizedAttendance(holiday))
    }

    @Test
    fun ordinaryAttendanceCannotBeAddedToAHoliday() {
        val holiday = WorkDay(date = "1405-08-11", dayType = "تعطیل رسمی")

        val updated = toggleDayStatus(holiday, "عادی")

        assertEquals("تعطیل رسمی", normalizedDayCategory(updated))
        assertEquals("", normalizedAttendance(updated))
    }
}
