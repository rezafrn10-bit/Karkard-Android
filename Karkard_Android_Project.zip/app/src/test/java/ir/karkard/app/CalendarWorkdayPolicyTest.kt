package ir.karkard.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CalendarWorkdayPolicyTest {
    @Test fun officialHolidayBecomesDefaultEvenWhenNonCategoryDataWasSaved() {
        val savedNoteOnly = WorkDay(
            date = "1405-03-06",
            note = "یادداشت کاربر",
            in1 = "07:00",
            out1 = "14:00"
        )
        val resolved = resolveCalendarWorkdayStatus(
            current = savedNoteOnly,
            hasManualDayType = savedNoteOnly.dayTypeManual,
            isFriday = false,
            isOfficialHoliday = true
        )
        assertEquals("تعطیل رسمی", resolved.dayType)
        assertEquals("یادداشت کاربر", resolved.note)
        assertFalse(resolved.dayTypeManual)
    }

    @Test fun ordinaryUntouchedDayRemainsWorkingAndFridayRemainsHoliday() {
        val ordinary = resolveCalendarWorkdayStatus(WorkDay(date = "1405-02-10"), false, false, false)
        val friday = resolveCalendarWorkdayStatus(WorkDay(date = "1405-02-11"), false, true, false)
        assertEquals("کاری", ordinary.dayType)
        assertEquals("تعطیل رسمی", friday.dayType)
    }

    @Test fun officialHolidayCanNeverBeChangedBackToWorkingEvenIfLegacyFlagSaysManual() {
        val manuallyWorking = WorkDay(date = "1405-03-06", dayType = "کاری", dayTypeManual = true)
        val resolved = resolveCalendarWorkdayStatus(manuallyWorking, true, false, true)
        assertEquals("تعطیل رسمی", resolved.dayType)
        assertFalse(resolved.dayTypeManual)
    }

    @Test fun savedManualOccasionHolidayIsNeverOverwrittenByCalendarUpdate() {
        val manualHoliday = WorkDay(
            date = "1405-03-06",
            dayType = "تعطیل خاص",
            attendanceStatus = "استحقاقی",
            dayTypeManual = true
        )
        val resolved = resolveCalendarWorkdayStatus(
            current = manualHoliday,
            hasManualDayType = manualHoliday.dayTypeManual,
            isFriday = false,
            isOfficialHoliday = false
        )
        assertEquals("تعطیل خاص", resolved.dayType)
        assertEquals("استحقاقی", resolved.attendanceStatus)
    }

    @Test fun specialHolidayIsPreservedDuringCalendarRefresh() {
        val special = WorkDay(date = "1405-02-11", dayType = "تعطیل خاص", dayTypeManual = true)
        val resolved = resolveCalendarWorkdayStatus(special, true, false, false)
        assertEquals("تعطیل خاص", resolved.dayType)
    }

    @Test fun officialDateIsAlwaysAHolidayEvenWhenLegacyRowClaimsManualWork() {
        val manuallyWorking = WorkDay(date = "1405-03-06", dayType = "کاری", dayTypeManual = true)
        assertTrue(isCalendarDefaultHoliday(manuallyWorking, isFriday = false, isOfficialHoliday = true))
    }

    @Test fun invalidWorkingLabelCannotAppearAsAttendanceOnAnOfficialHoliday() {
        val resolved = resolveCalendarWorkdayStatus(
            current = WorkDay(
                date = "1405-03-06",
                dayType = "کاری",
                attendanceStatus = "کاری",
                extraDayTypes = "کاری"
            ),
            hasManualDayType = false,
            isFriday = false,
            isOfficialHoliday = true
        )
        assertEquals("تعطیل رسمی", resolved.dayType)
        assertTrue("تعطیل رسمی" in dayStatuses(resolved))
        assertFalse("کاری" in dayStatuses(resolved))
    }

    @Test fun normalAttendanceExistsOnlyOnWorkingDays() {
        val working = resolveCalendarWorkdayStatus(WorkDay(date = "1405-02-10"), false, false, false)
        val holiday = resolveCalendarWorkdayStatus(WorkDay(date = "1405-03-06", attendanceStatus = "عادی"), false, false, true)
        assertEquals("عادی", working.attendanceStatus)
        assertEquals("", holiday.attendanceStatus)
    }

    @Test fun untouchedOfficialHolidayUsesCalendarDefault() {
        val untouched = WorkDay(date = "1405-03-06")
        assertTrue(isCalendarDefaultHoliday(untouched, isFriday = false, isOfficialHoliday = true))
    }

    @Test fun attendanceEditsDoNotCountAsCategorySelection() {
        assertFalse(hasDayTypeCategoryChanged("تعطیل رسمی", "", "تعطیل رسمی", ""))
        assertTrue(hasDayTypeCategoryChanged("تعطیل رسمی", "", "کاری", ""))
        assertFalse(hasDayTypeCategoryChanged("کاری", "", "کاری", ""))
    }

    @Test fun legacyMigrationUsesCategoryNotAttendanceAsEvidenceOfManualChoice() {
        assertTrue(legacyDayTypeWasManuallyChosen("تعطیل خاص", ""))
        assertTrue(legacyDayTypeWasManuallyChosen("کاری", "استحقاقی"))
        assertFalse(legacyDayTypeWasManuallyChosen("کاری", ""))
        assertFalse(legacyDayTypeWasManuallyChosen("", ""))
    }

    @Test fun legacyMixedCategoriesMigrateIntoIndependentDayAndAttendanceFields() {
        assertEquals("تعطیل خاص", migrateLegacyDayCategory("تعطیل مناسبتی"))
        assertEquals("تعطیل رسمی", migrateLegacyDayCategory("تعطیل"))
        assertEquals("کاری", migrateLegacyDayCategory("مرخصی"))
        assertEquals("استحقاقی", migrateLegacyAttendanceStatus("مرخصی", ""))
        assertEquals("مأموریت", migrateLegacyAttendanceStatus("کاری", "مأموریت"))
        assertEquals("استعلاجی", migrateLegacyAttendanceStatus("کاری", "استعلاجی"))
    }

    @Test fun v066AttendanceDetectionIncludesOrdinaryAndHolidayTimeEntries() {
        assertTrue(hasAnyAttendanceData("07:00", "14:00", null, null, null, null, null, null, null, null))
        assertTrue(hasAnyAttendanceData(null, null, null, null, null, null, null, null, "10:00", "12:00"))
        assertFalse(hasAnyAttendanceData(null, null, null, null, null, null, null, null, null, null))
    }

    @Test fun v066FalsePositiveIsReleasedOnlyForOfficialHolidayWithPlainWorkingStatus() {
        assertTrue(shouldReleaseLegacyWorkingDayFlag("کاری", "", true, true))
        assertFalse(shouldReleaseLegacyWorkingDayFlag("کاری", "", true, false))
        assertFalse(shouldReleaseLegacyWorkingDayFlag("کاری", "مأموریت", true, true))
        assertFalse(shouldReleaseLegacyWorkingDayFlag("تعطیل خاص", "", true, true))
        assertFalse(shouldReleaseLegacyWorkingDayFlag("کاری", "", false, true))
    }
    @Test fun annualMonthHolidayCountIncludesOfficialDatesButExcludesFridaysAndOtherMonths() {
        val dates = setOf(
            "1405-10-01",
            "1405-10-16",
            "1405-10-23",
            "1405-11-01"
        )
        val expected = dates.count { it.startsWith("1405-10-") && jalaliWeekday(it) != 5 }
        assertEquals(expected, countOfficialHolidaysInJalaliMonth(dates, 1405, 10))
        assertEquals(0, countOfficialHolidaysInJalaliMonth(dates, 1405, 13))
    }

    @Test fun dey1405ShowsTwoOfficialHolidaysFromBundledCalendar() {
        val dates = Calendar1405.holidays.map { it.first }.toSet()
        assertEquals(2, countOfficialHolidaysInJalaliMonth(dates, 1405, 10))
    }

    @Test fun annualMonthHolidayCountDoesNotCountFridayOfficialHolidaysTwice() {
        val friday = (1..30).map { day -> "1405-10-%02d".format(day) }
            .first { jalaliWeekday(it) == 5 }
        val dates = setOf(friday, "1405-10-16")
        assertEquals(1, countOfficialHolidaysInJalaliMonth(dates, 1405, 10))
    }

}
