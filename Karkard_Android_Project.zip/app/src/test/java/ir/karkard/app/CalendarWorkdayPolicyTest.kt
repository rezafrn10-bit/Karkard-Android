package ir.karkard.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CalendarWorkdayPolicyTest {
    @Test fun officialHolidayBecomesDefaultEvenWhenNonCategoryDataWasSaved() {
        val savedNoteOnly = WorkDay(date = "1405-03-06", note = "یادداشت کاربر")
        val resolved = resolveCalendarWorkdayStatus(
            current = savedNoteOnly,
            hasManualDayType = savedNoteOnly.dayTypeManual,
            isFriday = false,
            isOfficialHoliday = true
        )
        assertEquals("تعطیل رسمی", resolved.dayType)
        assertEquals("یادداشت کاربر", resolved.note)
        assertFalse(resolved.dayTypeManual)
    }

    @Test fun ordinaryUntouchedDayRemainsWorkingAndFridayRemainsHoliday() {
        val ordinary = resolveCalendarWorkdayStatus(WorkDay(date = "1405-02-10"), false, false, false)
        val friday = resolveCalendarWorkdayStatus(WorkDay(date = "1405-02-11"), false, true, false)
        assertEquals("کاری", ordinary.dayType)
        assertEquals("تعطیل رسمی", friday.dayType)
    }

    @Test fun explicitlySelectedWorkingStatusIsNeverOverwrittenByCalendarUpdate() {
        val manuallyWorking = WorkDay(date = "1405-03-06", dayType = "کاری", dayTypeManual = true)
        val resolved = resolveCalendarWorkdayStatus(
            current = manuallyWorking,
            hasManualDayType = manuallyWorking.dayTypeManual,
            isFriday = false,
            isOfficialHoliday = true
        )
        assertSame(manuallyWorking, resolved)
        assertEquals("کاری", resolved.dayType)
    }

    @Test fun savedManualOccasionHolidayIsNeverOverwrittenByCalendarUpdate() {
        val manualHoliday = WorkDay(
            date = "1405-03-06",
            dayType = "تعطیل مناسبتی",
            extraDayTypes = "مرخصی",
            dayTypeManual = true
        )
        val resolved = resolveCalendarWorkdayStatus(
            current = manualHoliday,
            hasManualDayType = manualHoliday.dayTypeManual,
            isFriday = false,
            isOfficialHoliday = false
        )
        assertSame(manualHoliday, resolved)
        assertEquals("تعطیل مناسبتی", resolved.dayType)
        assertEquals("مرخصی", resolved.extraDayTypes)
    }

    @Test fun manualWorkingOverrideAlsoWorksOnFriday() {
        val manualWorking = WorkDay(date = "1405-02-11", dayType = "کاری", dayTypeManual = true)
        val resolved = resolveCalendarWorkdayStatus(manualWorking, manualWorking.dayTypeManual, true, false)
        assertEquals("کاری", resolved.dayType)
    }

    @Test fun explicitManualWorkdayOverridesBothFridayAndOfficialHolidayDefaults() {
        val manuallyWorking = WorkDay(date = "1405-03-06", dayType = "کاری", dayTypeManual = true)
        assertFalse(isCalendarDefaultHoliday(manuallyWorking, isFriday = true, isOfficialHoliday = true))
    }

    @Test fun untouchedOfficialHolidayUsesCalendarDefault() {
        val untouched = WorkDay(date = "1405-03-06")
        assertTrue(isCalendarDefaultHoliday(untouched, isFriday = false, isOfficialHoliday = true))
    }

    @Test fun legacyMigrationPreservesNonDefaultCategoriesAndAttendanceButNotPlainDefaultRows() {
        assertTrue(legacyDayTypeWasManuallyChosen("تعطیل مناسبتی", "", false))
        assertTrue(legacyDayTypeWasManuallyChosen("کاری", "", true))
        assertTrue(legacyDayTypeWasManuallyChosen("کاری", "مرخصی", false))
        assertFalse(legacyDayTypeWasManuallyChosen("کاری", "", false))
    }
}
