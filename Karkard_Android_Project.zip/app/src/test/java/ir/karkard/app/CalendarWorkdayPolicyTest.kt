package ir.karkard.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Test

class CalendarWorkdayPolicyTest {
    @Test fun officialHolidayBecomesDefaultForAnUnrecordedDay() {
        val untouched = WorkDay(date = "1405-03-06")
        val resolved = resolveCalendarWorkdayStatus(
            current = untouched,
            hasSavedRecord = false,
            isFriday = false,
            isOfficialHoliday = true
        )
        assertEquals("تعطیل رسمی", resolved.dayType)
    }

    @Test fun ordinaryUntouchedDayRemainsWorkingAndFridayRemainsHoliday() {
        val ordinary = resolveCalendarWorkdayStatus(
            WorkDay(date = "1405-02-10"), false, false, false
        )
        val friday = resolveCalendarWorkdayStatus(
            WorkDay(date = "1405-02-11"), false, true, false
        )
        assertEquals("کاری", ordinary.dayType)
        assertEquals("تعطیل رسمی", friday.dayType)
    }

    @Test fun savedManualWorkStatusIsNeverOverwrittenByCalendarUpdate() {
        val manuallyWorking = WorkDay(date = "1405-03-06", dayType = "کاری")
        val resolved = resolveCalendarWorkdayStatus(
            current = manuallyWorking,
            hasSavedRecord = true,
            isFriday = false,
            isOfficialHoliday = true
        )
        assertSame(manuallyWorking, resolved)
        assertEquals("کاری", resolved.dayType)
    }

    @Test fun savedManualOccasionHolidayIsNeverOverwrittenByCalendarUpdate() {
        val manualHoliday = WorkDay(
            date = "1405-03-06",
            dayType = "تعطیل مناسبتی",
            extraDayTypes = "مرخصی"
        )
        val resolved = resolveCalendarWorkdayStatus(
            current = manualHoliday,
            hasSavedRecord = true,
            isFriday = false,
            isOfficialHoliday = false
        )
        assertSame(manualHoliday, resolved)
        assertEquals("تعطیل مناسبتی", resolved.dayType)
        assertEquals("مرخصی", resolved.extraDayTypes)
    }
}
