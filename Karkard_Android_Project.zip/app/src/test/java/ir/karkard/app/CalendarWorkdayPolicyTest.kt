package ir.karkard.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class CalendarWorkdayPolicyTest {
    @Test fun officialCalendarHolidayIsResolvedEvenWhenAttendanceAndNotesExist() {
        val savedRow = WorkDay(
            date = "1405-03-06",
            note = "یادداشت کاربر",
            in1 = "07:00",
            out1 = "14:00"
        )
        val resolved = resolveCalendarWorkdayStatus(
            current = savedRow,
            isFriday = false,
            isOfficialHoliday = true
        )
        assertEquals("تعطیل رسمی", resolved.dayType)
        assertEquals("یادداشت کاربر", resolved.note)
        assertEquals("07:00", resolved.in1)
        assertFalse(resolved.dayTypeManual)
    }

    @Test fun ordinaryDayAndFridayUseCalendarDefaults() {
        val ordinary = resolveCalendarWorkdayStatus(WorkDay(date = "1405-02-10"), false, false)
        val friday = resolveCalendarWorkdayStatus(WorkDay(date = "1405-02-11"), true, false)
        assertEquals("کاری", ordinary.dayType)
        assertEquals("تعطیل رسمی", friday.dayType)
    }

    @Test fun officialCalendarHolidayCannotBeChangedToWorkingOrManualOccasion() {
        val official = WorkDay(date = "1405-03-06", dayType = "تعطیل رسمی")
        assertSame(official, toggleWorkdayStatus(official, "کاری", true, false))
        assertSame(official, toggleWorkdayStatus(official, "تعطیل مناسبتی", true, false))
        assertSame(official, toggleWorkdayStatus(official, "تعطیل رسمی", true, false))
        val resolved = resolveCalendarWorkdayStatus(official, false, true)
        assertEquals("تعطیل رسمی", resolved.dayType)
    }

    @Test fun manualOccasionHolidayPersistsWhenCalendarIsDownloadedAgain() {
        val selected = toggleWorkdayStatus(
            day = WorkDay(date = "1405-06-15"),
            selected = "تعطیل مناسبتی",
            isOfficialCalendarHoliday = false,
            isFriday = false
        )
        assertEquals("تعطیل مناسبتی", selected.dayType)
        assertTrue(selected.dayTypeManual)

        // Even when a later calendar download has a different classification,
        // the user-owned exceptional holiday remains unchanged.
        val afterCalendarRefresh = resolveCalendarWorkdayStatus(
            current = selected,
            isFriday = false,
            isOfficialHoliday = true
        )
        assertSame(selected, afterCalendarRefresh)
        assertEquals("تعطیل مناسبتی", afterCalendarRefresh.dayType)
        assertTrue(afterCalendarRefresh.dayTypeManual)
    }

    @Test fun removingManualOccasionOnOfficialDateRestoresCalendarHolidayNotWorking() {
        val manualOccasion = WorkDay(
            date = "1405-03-06",
            dayType = "تعطیل مناسبتی",
            dayTypeManual = true
        )
        val restored = toggleWorkdayStatus(manualOccasion, "تعطیل مناسبتی", true, false)
        assertEquals("تعطیل رسمی", restored.dayType)
        assertFalse(restored.dayTypeManual)
    }

    @Test fun removingManualOccasionOnOrdinaryDateRestoresWorkingDefault() {
        val manualOccasion = WorkDay(
            date = "1405-06-15",
            dayType = "تعطیل مناسبتی",
            dayTypeManual = true
        )
        val restored = toggleWorkdayStatus(manualOccasion, "تعطیل مناسبتی", false, false)
        assertEquals("کاری", restored.dayType)
        assertFalse(restored.dayTypeManual)
    }

    @Test fun allThreeIndependentStatusesCanBeEnabledAtTheSameTimeOnOfficialHoliday() {
        var day = WorkDay(date = "1405-03-06", dayType = "تعطیل رسمی")
        day = toggleWorkdayStatus(day, "مرخصی", true, false)
        day = toggleWorkdayStatus(day, "استعلاجی", true, false)
        day = toggleWorkdayStatus(day, "مأموریت", true, false)

        assertEquals("تعطیل رسمی", day.dayType)
        assertEquals(setOf("مرخصی", "استعلاجی", "مأموریت"), day.extraDayTypes.split('|').toSet())
        assertFalse(day.dayTypeManual)
    }

    @Test fun togglingOneIndependentStatusDoesNotClearTheOtherTwo() {
        val all = WorkDay(
            date = "1405-03-06",
            dayType = "تعطیل رسمی",
            extraDayTypes = "مرخصی|استعلاجی|مأموریت"
        )
        val withoutSick = toggleWorkdayStatus(all, "استعلاجی", true, false)
        assertEquals(setOf("مرخصی", "مأموریت"), withoutSick.extraDayTypes.split('|').toSet())
        assertEquals("تعطیل رسمی", withoutSick.dayType)
        assertFalse(withoutSick.dayTypeManual)
    }

    @Test fun independentStatusesNeverBecomeManualPrimaryOverride() {
        val initial = WorkDay(date = "1405-06-15", dayType = "کاری")
        val withLeave = toggleWorkdayStatus(initial, "مرخصی", false, false)
        val withSick = toggleWorkdayStatus(withLeave, "استعلاجی", false, false)
        val withMission = toggleWorkdayStatus(withSick, "مأموریت", false, false)
        assertEquals("کاری", withMission.dayType)
        assertFalse(withMission.dayTypeManual)
        val afterSync = resolveCalendarWorkdayStatus(withMission, false, true)
        assertEquals("تعطیل رسمی", afterSync.dayType)
        assertEquals(withMission.extraDayTypes, afterSync.extraDayTypes)
    }

    @Test fun aFridayIsNotAllowedToBeChangedToWorkingFromTheTypeCard() {
        val friday = WorkDay(date = "1405-02-11", dayType = "تعطیل رسمی")
        assertSame(friday, toggleWorkdayStatus(friday, "کاری", false, true))
    }

    @Test fun legacyPrimaryLeaveAndMissionCategoriesBecomeIndependentFlags() {
        val legacy = WorkDay(
            date = "1405-06-15",
            dayType = "مرخصی",
            extraDayTypes = "استعلاجی"
        )
        val normalized = normalizeWorkDayCategories(legacy)
        assertEquals("کاری", normalized.dayType)
        assertEquals(setOf("مرخصی", "استعلاجی"), normalized.extraDayTypes.split('|').toSet())
        assertFalse(normalized.dayTypeManual)
    }

    @Test fun manualOccasionIsTheOnlyManualPrimaryHolidayThatSurvivesNormalization() {
        val manual = normalizeWorkDayCategories(
            WorkDay(date = "1405-06-15", dayType = "تعطیل مناسبتی", dayTypeManual = false)
        )
        assertEquals("تعطیل مناسبتی", manual.dayType)
        assertTrue(manual.dayTypeManual)

        val oldOfficial = normalizeWorkDayCategories(
            WorkDay(date = "1405-03-06", dayType = "تعطیل رسمی", dayTypeManual = true)
        )
        assertEquals("کاری", oldOfficial.dayType)
        assertFalse(oldOfficial.dayTypeManual)
    }

    @Test fun manualOccasionIsCountedSeparatelyFromCalendarDefaultHoliday() {
        val manual = WorkDay(date = "1405-06-15", dayType = "تعطیل مناسبتی", dayTypeManual = true)
        assertFalse(isCalendarDefaultHoliday(manual, false, true))
        val official = WorkDay(date = "1405-03-06", dayType = "تعطیل رسمی")
        assertTrue(isCalendarDefaultHoliday(official, false, true))
    }


    @Test fun bundled1405EidAlAdhaIsRecognizedAsAnOfficialHoliday() {
        val officialDate = "1405-03-06"
        assertTrue(Calendar1405.holidays.any { it.first == officialDate })
        val resolved = resolveCalendarWorkdayStatus(
            current = WorkDay(date = officialDate),
            isFriday = false,
            isOfficialHoliday = officialDate in Calendar1405.holidays.map { it.first }.toSet()
        )
        assertEquals("تعطیل رسمی", resolved.dayType)
    }

    @Test fun leaveFlagsCanBeAddedToManualOccasionWithoutRemovingItsOwnership() {
        val manual = WorkDay(
            date = "1405-06-15",
            dayType = "تعطیل مناسبتی",
            dayTypeManual = true
        )
        var updated = manual
        listOf("مرخصی", "استعلاجی", "مأموریت").forEach { status ->
            updated = toggleWorkdayStatus(updated, status, false, false)
        }
        assertEquals("تعطیل مناسبتی", updated.dayType)
        assertTrue(updated.dayTypeManual)
        assertEquals(setOf("مرخصی", "استعلاجی", "مأموریت"), updated.extraDayTypes.split('|').toSet())
    }

    @Test fun backupNormalizationPreservesManualOccasionAndAllIndependentFlags() {
        val backupRecord = WorkDay(
            date = "1405-06-15",
            dayType = "تعطیل مناسبتی",
            extraDayTypes = "مرخصی|استعلاجی|مأموریت",
            dayTypeManual = true
        )
        val restored = normalizeWorkDayCategories(backupRecord)
        assertEquals("تعطیل مناسبتی", restored.dayType)
        assertTrue(restored.dayTypeManual)
        assertEquals(setOf("مرخصی", "استعلاجی", "مأموریت"), restored.extraDayTypes.split('|').toSet())
    }


    @Test fun cardRulesDisablePrimaryOverridesOnOfficialDaysButKeepIndependentFlagsEnabled() {
        val official = WorkDay(date = "1405-03-06", dayType = "تعطیل رسمی")
        assertFalse(canToggleWorkdayStatus(official, "کاری", true, false))
        assertFalse(canToggleWorkdayStatus(official, "تعطیل مناسبتی", true, false))
        assertFalse(canToggleWorkdayStatus(official, "تعطیل رسمی", true, false))
        assertTrue(canToggleWorkdayStatus(official, "مرخصی", true, false))
        assertTrue(canToggleWorkdayStatus(official, "استعلاجی", true, false))
        assertTrue(canToggleWorkdayStatus(official, "مأموریت", true, false))
    }


    @Test fun officialHolidayFollowsLatestCalendarWhileManualOccasionDoesNot() {
        val normal = WorkDay(date = "1405-06-15", note = "متن کاربر")
        val whenCalendarAddsHoliday = resolveCalendarWorkdayStatus(normal, false, true)
        assertEquals("تعطیل رسمی", whenCalendarAddsHoliday.dayType)
        assertEquals("متن کاربر", whenCalendarAddsHoliday.note)
        val whenCalendarRemovesHoliday = resolveCalendarWorkdayStatus(whenCalendarAddsHoliday, false, false)
        assertEquals("کاری", whenCalendarRemovesHoliday.dayType)

        val userOccasion = toggleWorkdayStatus(normal, "تعطیل مناسبتی", false, false)
        val stillManualWhenAdded = resolveCalendarWorkdayStatus(userOccasion, false, true)
        val stillManualWhenRemoved = resolveCalendarWorkdayStatus(userOccasion, false, false)
        assertEquals("تعطیل مناسبتی", stillManualWhenAdded.dayType)
        assertEquals("تعطیل مناسبتی", stillManualWhenRemoved.dayType)
        assertTrue(stillManualWhenAdded.dayTypeManual)
        assertTrue(stillManualWhenRemoved.dayTypeManual)
    }

    @Test fun saveNormalizationDoesNotPersistCalendarDerivedOfficialStatus() {
        val officialOnScreen = resolveCalendarWorkdayStatus(
            WorkDay(date = "1405-03-06", in1 = "07:00", out1 = "14:00"),
            isFriday = false,
            isOfficialHoliday = true
        )
        assertEquals("تعطیل رسمی", officialOnScreen.dayType)
        val stored = normalizeWorkDayCategories(officialOnScreen)
        assertEquals("کاری", stored.dayType)
        assertFalse(stored.dayTypeManual)
        val afterRead = resolveCalendarWorkdayStatus(stored, false, true)
        assertEquals("تعطیل رسمی", afterRead.dayType)
        assertEquals("07:00", afterRead.in1)
        assertEquals("14:00", afterRead.out1)
    }

    @Test fun manualOccasionAndIndependentFlagsSurviveSaveAndRefreshTogether() {
        var selected = toggleWorkdayStatus(WorkDay(date = "1405-06-15"), "تعطیل مناسبتی", false, false)
        listOf("مرخصی", "استعلاجی", "مأموریت").forEach { selected = toggleWorkdayStatus(selected, it, false, false) }
        val stored = normalizeWorkDayCategories(selected.copy(note = "تعطیلی فوری"))
        val afterCalendarRefresh = resolveCalendarWorkdayStatus(stored, false, true)
        assertEquals("تعطیل مناسبتی", afterCalendarRefresh.dayType)
        assertTrue(afterCalendarRefresh.dayTypeManual)
        assertEquals("تعطیلی فوری", afterCalendarRefresh.note)
        assertEquals(setOf("مرخصی", "استعلاجی", "مأموریت"), afterCalendarRefresh.extraDayTypes.split('|').toSet())
    }

    @Test fun userCanRemoveTheirOccasionOverrideAfterCalendarMarksThatDateOfficial() {
        val manual = WorkDay(
            date = "1405-06-15",
            dayType = "تعطیل مناسبتی",
            dayTypeManual = true
        )
        assertTrue(canToggleWorkdayStatus(manual, "تعطیل مناسبتی", true, false))
        assertFalse(canToggleWorkdayStatus(manual, "کاری", true, false))
    }



    @Test fun legacyMigrationHelpersAreAvailableAndKeepTheirNarrowPurpose() {
        assertTrue(legacyDayTypeWasManuallyChosen("تعطیل مناسبتی", ""))
        assertTrue(legacyDayTypeWasManuallyChosen("کاری", "مرخصی"))
        assertFalse(legacyDayTypeWasManuallyChosen("کاری", ""))

        assertTrue(hasAnyAttendanceData("07:00", "14:00", null, null))
        assertTrue(hasAnyAttendanceData(null, null, "10:00", "12:00"))
        assertFalse(hasAnyAttendanceData(null, null, null, null))

        assertTrue(shouldReleaseLegacyWorkingDayFlag("کاری", "", true, true))
        assertFalse(shouldReleaseLegacyWorkingDayFlag("کاری", "", false, true))
        assertFalse(shouldReleaseLegacyWorkingDayFlag("کاری", "مأموریت", true, true))
        assertFalse(shouldReleaseLegacyWorkingDayFlag("تعطیل مناسبتی", "", true, true))
        assertFalse(shouldReleaseLegacyWorkingDayFlag("کاری", "", true, false))
    }
}
