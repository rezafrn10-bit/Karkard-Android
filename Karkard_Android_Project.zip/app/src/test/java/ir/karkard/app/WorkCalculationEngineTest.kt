package ir.karkard.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class WorkCalculationEngineTest {
    @Test fun fixedModeDeductsLeaveFromRequiredAndKeepsOvertimeOutsideWindow() {
        val result = WorkCalculationEngine.calculate(
            WorkCalculationInput(
                attendance = listOf(WorkMinuteInterval(7 * 60, 16 * 60)),
                hourlyLeave = listOf(WorkMinuteInterval(9 * 60, 10 * 60)),
                fixedMode = true,
                targetMinutes = 7 * 60,
                fixedStartMinute = 7 * 60,
                fixedEndMinute = 14 * 60
            )
        )
        assertEquals(8 * 60, result.workedMinutes)
        assertEquals(6 * 60, result.requiredMinutes)
        assertEquals(2 * 60, result.overtimeMinutes)
        assertEquals(6 * 60, result.recordedRequiredMinutes)
    }

    @Test fun flexibleModeCapsHourlyLeaveAtScheduledRequirement() {
        val result = WorkCalculationEngine.calculate(
            WorkCalculationInput(
                attendance = listOf(WorkMinuteInterval(7 * 60, 23 * 60 + 30)),
                hourlyLeave = listOf(
                    WorkMinuteInterval(10 * 60, 15 * 60),
                    WorkMinuteInterval(16 * 60, 19 * 60)
                ),
                fixedMode = false,
                targetMinutes = 7 * 60,
                fixedStartMinute = 7 * 60,
                fixedEndMinute = 14 * 60
            )
        )
        assertEquals(7 * 60, result.hourlyLeaveMinutes)
        assertEquals(9 * 60 + 30, result.workedMinutes)
        assertEquals(7 * 60, result.requiredMinutes)
        assertEquals(2 * 60 + 30, result.overtimeMinutes)
        assertEquals(7 * 60, result.recordedRequiredMinutes)
    }

    @Test fun fixedModeCountsEarlyArrivalAsOvertime() {
        val result = WorkCalculationEngine.calculate(
            WorkCalculationInput(
                attendance = listOf(WorkMinuteInterval(6 * 60, 14 * 60)),
                hourlyLeave = emptyList(),
                fixedMode = true,
                targetMinutes = 7 * 60,
                fixedStartMinute = 7 * 60,
                fixedEndMinute = 14 * 60,
                hourlyLeaveEnabled = false
            )
        )
        assertEquals(8 * 60, result.workedMinutes)
        assertEquals(60, result.overtimeMinutes)
        assertEquals(7 * 60, result.recordedRequiredMinutes)
    }

    @Test fun fixedThursdayWindowCountsAfterNoonAsOvertime() {
        val result = WorkCalculationEngine.calculate(
            WorkCalculationInput(
                attendance = listOf(WorkMinuteInterval(7 * 60, 14 * 60)),
                hourlyLeave = emptyList(),
                fixedMode = true,
                targetMinutes = 5 * 60,
                fixedStartMinute = 7 * 60,
                fixedEndMinute = 12 * 60,
                hourlyLeaveEnabled = false
            )
        )
        assertEquals(7 * 60, result.workedMinutes)
        assertEquals(2 * 60, result.overtimeMinutes)
    }

    @Test fun overlappingAttendanceIntervalsAreNeverCountedTwice() {
        val result = WorkCalculationEngine.calculate(
            WorkCalculationInput(
                attendance = listOf(WorkMinuteInterval(7 * 60, 12 * 60), WorkMinuteInterval(10 * 60, 16 * 60)),
                hourlyLeave = emptyList(),
                fixedMode = false,
                targetMinutes = 7 * 60,
                fixedStartMinute = 7 * 60,
                fixedEndMinute = 14 * 60,
                hourlyLeaveEnabled = false
            )
        )
        assertEquals(9 * 60, result.workedMinutes)
        assertEquals(2 * 60, result.overtimeMinutes)
    }

    @Test fun incompleteInformationDoesNotBecomeConfirmedWorkTime() {
        val result = WorkCalculationEngine.calculate(
            WorkCalculationInput(
                attendance = listOf(WorkMinuteInterval(7 * 60, 12 * 60)),
                hourlyLeave = emptyList(),
                fixedMode = true,
                targetMinutes = 7 * 60,
                fixedStartMinute = 7 * 60,
                fixedEndMinute = 14 * 60,
                incomplete = true
            )
        )
        assertTrue(result.incomplete)
        assertEquals(0, result.workedMinutes)
        assertEquals(0, result.overtimeMinutes)
        assertEquals(7 * 60, result.requiredMinutes)
    }
}
