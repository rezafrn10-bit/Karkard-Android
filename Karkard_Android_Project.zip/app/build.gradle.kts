plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val releaseStorePath = providers.environmentVariable("VAGHTNEGAR_KEYSTORE_PATH").orNull

android {
    signingConfigs {
        if (!releaseStorePath.isNullOrBlank()) {
            create("vaghtnegar") {
                storeFile = file(releaseStorePath)
                storePassword = System.getenv("VAGHTNEGAR_STORE_PASSWORD")
                keyAlias = System.getenv("VAGHTNEGAR_KEY_ALIAS")
                keyPassword = System.getenv("VAGHTNEGAR_KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            if (!releaseStorePath.isNullOrBlank()) {
                signingConfig = signingConfigs.getByName("vaghtnegar")
            }
        }
    }
    namespace = "ir.karkard.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "ir.karkard.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 60
        versionName = "0.60.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation("com.ibm.icu:icu4j:76.1")
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    debugImplementation("androidx.compose.ui:ui-tooling")
}