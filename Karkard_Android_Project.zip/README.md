# وقت نگار حور — نسخه ۰.۷.۰

پروژه Android با Kotlin و Jetpack Compose، مناسب ساخت APK از طریق GitHub Actions.

## تغییرات نسخه ۰.۷.۰
- دریافت تعطیلات رسمی و مناسبت‌های غیرتعطیل از فایل‌های JSON سالانهٔ FarsiUI با ساختار `items/date/title.fa/isHoliday`؛ در صورت در دسترس نبودن سال، استفاده از API تقویم به‌عنوان جایگزین.
- انتخاب سال شمسی برای دانلود تقویم از تنظیمات.
- ذخیرهٔ اطلاعات در SQLite برای استفادهٔ آفلاین.
- اگر دریافت فهرست مناسبت‌های یک ماه با خطا روبه‌رو شود، دریافت تعطیلات رسمی سال به‌طور کامل لغو نمی‌شود.
- نمایش تعطیلات رسمی در صفحهٔ خانه، تقویم، گزارش ماهانه و گزارش سالانه.
- گزارش‌های PDF و Excel هم وضعیت روز تعطیل و عنوان مناسبت را نشان می‌دهند.
- پس از نصب این نسخه، دریافت تقویم سال دوباره فعال می‌شود؛ داده‌های ذخیره‌شده تا دریافت موفق حفظ می‌شوند.

## منبع داده
- تعطیلات رسمی: `https://raw.githubusercontent.com/MiladJoodi/FarsiUI/main/calendar/years/YYYY/holidays.json`
- مناسبت‌های غیرتعطیل: `https://raw.githubusercontent.com/MiladJoodi/FarsiUI/main/calendar/years/YYYY/events.json`
- جایگزین در صورت نبودن فایل سال: `https://www.persian-calendar.com/api/holidays?year=YYYY` و `https://www.persian-calendar.com/api/events?year=YYYY&month_sh=M`
- راهنمای ساختار JSON: `https://farsiui.ir/calendar`

تاریخ‌های قمری آینده ممکن است تا اعلام رسمی تقویم همان سال تخمینی باشند. دریافت آنلاین فقط برای به‌روزرسانی است؛ پس از ذخیره، داده‌ها از پایگاه دادهٔ محلی قابل استفاده‌اند.

## ساخت APK
در مخزن GitHub، فایل ZIP را با نام دقیق `Karkard_Android_Project.zip` در ریشهٔ مخزن جایگزین کنید. فایل `.github/workflows/build.yml` را تغییر ندهید. سپس از بخش Actions اجرای workflow را بررسی کنید.
