package ir.karkard.app
fun main() {
    val fixed = WorkCalculationEngine.calculate(WorkCalculationInput(
        attendance=listOf(WorkMinuteInterval(420,960)), hourlyLeave=listOf(WorkMinuteInterval(540,600)),
        fixedMode=true,targetMinutes=420,fixedStartMinute=420,fixedEndMinute=840))
    check(fixed.workedMinutes==480 && fixed.requiredMinutes==360 && fixed.overtimeMinutes==120)
    val flexible = WorkCalculationEngine.calculate(WorkCalculationInput(
        attendance=listOf(WorkMinuteInterval(420,1410)), hourlyLeave=listOf(WorkMinuteInterval(600,900),WorkMinuteInterval(960,1140)),
        fixedMode=false,targetMinutes=420,fixedStartMinute=420,fixedEndMinute=840))
    check(flexible.hourlyLeaveMinutes==420 && flexible.workedMinutes==570 && flexible.overtimeMinutes==150)
    val incomplete = WorkCalculationEngine.calculate(WorkCalculationInput(
        attendance=emptyList(), hourlyLeave=emptyList(), fixedMode=true,targetMinutes=420,
        fixedStartMinute=420,fixedEndMinute=840,incomplete=true))
    check(incomplete.incomplete && incomplete.workedMinutes==0 && incomplete.overtimeMinutes==0)
    println("work calculation smoke tests: PASS")
}
